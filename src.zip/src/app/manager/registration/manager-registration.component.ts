import { environment } from '../../../environments/environment';
import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { ManagerLayoutComponent } from '../layout/manager-layout.component';
import { HttpClient } from '@angular/common/http';

/* ── Toaster ── */
interface Toast {
  id:      number;
  type:    'success' | 'error' | 'warning';
  title:   string;
  message: string;
  visible: boolean;
}

@Component({
  selector: 'app-manager-form',
  standalone: true,
  imports: [CommonModule, ManagerLayoutComponent, ReactiveFormsModule, RouterModule],
  templateUrl: './manager-registration.component.html',
  styleUrls: ['./manager-registration.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class ManagerRegistrationComponent implements OnInit {

  public steps = ['Basic & Classification', 'Analysis & Solution', 'Results & Deployment'];
  public currentStep = 0;

  public kaizenNo        = '';
  public today           = new Date();
  public kaizenForm!: FormGroup;
  public showConfirmModal  = false;
  public showSuccessModal  = false;
  public lastSubmittedNo   = '';
  public isDuplicate       = false;

  public compressing:  { [key: string]: boolean } = { before_img: false, after_img: false };
  public compressInfo: { [key: string]: string  } = { before_img: '', after_img: '' };
  public fileErrors:   { [key: string]: boolean } = { before_img: false, after_img: false };
  private files:       { [key: string]: File | null } = { before_img: null, after_img: null };
  private allThemes:   string[] = [];

  public departmentOptions: string[] = [];
  public sectionOptions:    string[] = [];

  /* ── Toaster state ── */
  public toasts: Toast[] = [];
  private toastCounter = 0;

  private readonly plantDeptMap: { [plant: string]: string[] } = {
    'Unit 1': ['Production','Maintenance','Quality','Stores','HR & Admin'],
    'Unit 2': ['Production','Maintenance','Quality','Stores','HR & Admin'],
    'Unit 3': ['Production','Maintenance','Quality','Stores','HR & Admin'],
    'Unit 4': ['Production','Maintenance','Quality','Stores','HR & Admin'],
    'Unit 5': ['Production','Maintenance','Quality','Stores','HR & Admin'],
  };

  private readonly deptSectionMap: { [dept: string]: string[] } = {
    'Production':  ['Assembly','Welding','Machining','Painting','Packing'],
    'Maintenance': ['Electrical','Mechanical','Civil','Utilities'],
    'Quality':     ['Incoming','In-Process','Final Inspection','Lab'],
    'Stores':      ['Raw Material','Finished Goods','Spare Parts'],
    'HR & Admin':  ['Recruitment','Training','Payroll','Administration'],
  };

  public pillars = ['KK','JH','PM','QM','NEDM','NPDM','DM','E&T','SHE','LM'];

  public categories = [
    { v: 'C-1|Restorative (TPM)',              l: 'C-1: Restorative (Using TPM Methodology)' },
    { v: 'C-2|Renovative (TPM)',               l: 'C-2: Renovative (Using TPM Methodology)' },
    { v: 'C-3|Innovative (TPM)',               l: 'C-3: Innovative (Using TPM Methodology)' },
    { v: 'C-4|Breakthrough (TPM)',             l: 'C-4: Breakthrough (Using TPM Methodology)' },
    { v: 'C-5|Poka Yoke (TPM)',                l: 'C-5: Poka Yoke (Using TPM Methodology)' },
    { v: 'C-6|KARAKURI & YUTORI',              l: 'C-6: KARAKURI (No Energy Loss) & YUTORI' },
    { v: 'C-7|JH Shop Floor Visualization',    l: 'C-7: JH - Shop Floor Visualization' },
    { v: 'C-8|KK OEE Compliance',              l: 'C-8: KK OEE Compliance' },
    { v: 'C-9|KK Bottleneck Process Solution', l: 'C-9: KK Bottleneck Process Solution' },
    { v: 'C-10|JH Circle Board Updating',      l: 'C-10: JH - Circle Board updating' },
    { v: 'C-11|JH One Point Lessons',          l: 'C-11: JH - One Point Lessons' },
    { v: 'C-12|JH White Tag Abnormality',      l: 'C-12: JH: White tag abnormality' },
    { v: 'C-13|JH (HTA / SOC / Ease for CLITA)', l: 'C-13: JH (HTA / SOC / Ease for CLITA)' },
    { v: 'C-14|JH Step 4 M-M Combination',    l: 'C-14: JH step 4 Man-Machine combination' },
    { v: 'C-15|JH Step 5 M-M Combination',    l: 'C-15: JH step 5 Man-Machine combination' },
    { v: 'C-16|JH Step 1, 2, 3 Repeat',       l: 'C-16: JH: Repeat of JH Step 1, 2, 3' },
    { v: 'C-17|JH Minor Stoppage Monitoring',  l: 'C-17: JH: Minor Stoppage Monitoring' },
    { v: 'C-18|JH RED Tag Abnormality',        l: 'C-18: JH: RED tag abnormality' },
    { v: 'C-19|QM Assembly Pokamapping',       l: 'C-19: QM: Product Assembly Pokamapping' },
    { v: 'C-20|PM MP Sheets Generation',       l: 'C-20: PM: Generation of MP sheets' },
    { v: 'C-21|NEDM MP Sheets Implementation', l: 'C-21: NEDM: Implementation of MP sheets' },
    { v: 'C-22|NEDM Low Cost Automation',      l: 'C-22: NEDM: Low Cost Automation' },
    { v: 'C-23|OTPM MAKIGAMI',                 l: 'C-23: OTPM: MAKIGAMI' },
    { v: 'C-24|OTPM Red Tag Office',           l: 'C-24: OTPM: Red tag at Office area (5S)' },
    { v: 'C-25|SHE Near Miss/Unsafe Condition',l: 'C-25: SHE: Near miss & Unsafe condition' },
    { v: 'C-26|SHE Unsafe Act',                l: 'C-26: SHE: Unsafe act' },
    { v: 'C-27|SHE Ergonomic Hazard',          l: 'C-27: SHE: Ergonomic hazard' },
    { v: 'C-28|SHE CO2 Emission Reduction',    l: 'C-28: SHE: CO2 emission reduction' },
    { v: 'C-29|SHE Micro Level HIRA',          l: 'C-29: SHE: Micro level HIRA' },
    { v: 'C-30|5S Zone Space Saved',           l: 'C-30: 5S: Zone wise space saved' },
    { v: 'C-31|5S Best 1S-3S',                 l: 'C-31: 5S: Best 1S, 2S, 3S at Zones' },
    { v: 'C-32|All Members',                   l: 'C-32: Sure Appreciation' },
    { v: 'C-33|All Members',                   l: 'C-33: Won the Awards from CII (Platinium & Gold)' },
    { v: 'C-34|All Members',                   l: 'C-34: Won the Awards from CII (Jury Challenger)' },
  ];

  private get authHeaders() {
    const token = sessionStorage.getItem('jwt_token') || '';
    return { headers: { 'Authorization': `Bearer ${token}` } };
  }

  constructor(
    private router: Router,
    private http: HttpClient,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.generateKaizenNo();
    this.loadExistingThemes();
    this.kaizenForm = new FormGroup({
      emp_id:          new FormControl('', [Validators.required, Validators.pattern('^[0-9]+$')]),
      emp_name:        new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z ]+$')]),
      unit:            new FormControl('', Validators.required),
      department:      new FormControl('', Validators.required),
      section:         new FormControl('', Validators.required),
      machine_no:      new FormControl('', Validators.required),
      kaizen_type:     new FormControl('', Validators.required),
      pqcdsm:          new FormControl('', Validators.required),
      kaizen_category: new FormControl('', Validators.required),
      theme:           new FormControl('', Validators.required),
      problem_status:  new FormControl('', Validators.required),
      idea:            new FormControl('', Validators.required),
      countermeasure:  new FormControl('', Validators.required),
      pillar:          new FormControl('', Validators.required),
      why1:            new FormControl('', Validators.required),
      why2:            new FormControl('', Validators.required),
      why3:            new FormControl('', Validators.required),
      why4:            new FormControl(''),
      why5:            new FormControl(''),
      root_cause:      new FormControl('', Validators.required),
      analysis:        new FormControl(''),
      benchmark:       new FormControl(''),
      target:          new FormControl(''),
      start_date:      new FormControl('', Validators.required),
      end_date:        new FormControl('', Validators.required),
      final_result:    new FormControl('', Validators.required),
      before_desc:     new FormControl('', Validators.required),
      after_desc:      new FormControl('', Validators.required),
      benefits_pqcdsm: new FormControl('1.', Validators.required),
      team_members:    new FormControl('1. ', Validators.required),
      deployments:     new FormArray([this.createRow()])
    });
  }

  /* ══════════════════════════════════
     TOASTER METHODS
  ══════════════════════════════════ */
  showToast(type: 'success' | 'error' | 'warning', title: string, message: string) {
    const id = ++this.toastCounter;
    const toast: Toast = { id, type, title, message, visible: false };
    this.toasts.push(toast);
    this.cdr.detectChanges();

    requestAnimationFrame(() => {
      toast.visible = true;
      this.cdr.detectChanges();
    });

    setTimeout(() => this.dismissToast(id), 4000);
  }

  dismissToast(id: number) {
    const toast = this.toasts.find(t => t.id === id);
    if (!toast) return;
    toast.visible = false;
    this.cdr.detectChanges();
    setTimeout(() => {
      this.toasts = this.toasts.filter(t => t.id !== id);
      this.cdr.detectChanges();
    }, 400);
  }

  /* ── Step field map for validation ── */
  private readonly stepRequiredFields: string[][] = [
    ['emp_id','emp_name','unit','department','section','machine_no','pqcdsm','kaizen_category','theme'],
    ['why1','why2','why3','root_cause','problem_status','idea','countermeasure'],
    ['start_date','end_date','final_result','before_desc','after_desc','benefits_pqcdsm','team_members'],
  ];

  isCurrentStepValid(): boolean {
    const fields = this.stepRequiredFields[this.currentStep] || [];
    const allValid = fields.every(f => {
      const ctrl = this.kaizenForm.get(f);
      return ctrl && ctrl.valid && (ctrl.value !== '' && ctrl.value !== null);
    });
    if (this.currentStep === 0 && this.isDuplicate) return false;
    return allValid;
  }

  /* ── Step navigation ── */
  nextStep() {
    if (!this.isCurrentStepValid()) {
      const fields = this.stepRequiredFields[this.currentStep] || [];
      fields.forEach(f => this.kaizenForm.get(f)?.markAsTouched());
      this.showToast('warning', 'Incomplete Fields', 'Please fill all required fields before proceeding.');
      return;
    }
    if (this.currentStep < this.steps.length - 1) this.currentStep++;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  prevStep() {
    if (this.currentStep > 0) this.currentStep--;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  /* ── Plant / Dept cascades ── */
  onPlantChange() {
    const plant = this.kaizenForm.get('unit')?.value;
    this.departmentOptions = plant ? (this.plantDeptMap[plant] || []) : [];
    this.sectionOptions = [];
    this.kaizenForm.patchValue({ department: '', section: '' });
  }

  onDepartmentChange() {
    const dept = this.kaizenForm.get('department')?.value;
    this.sectionOptions = dept ? (this.deptSectionMap[dept] || []) : [];
    this.kaizenForm.patchValue({ section: '' });
  }

  generateKaizenNo() {
    const currentYear = new Date().getFullYear();
    this.http.get<any>(environment.apiUrl + '/api/manager?action=count', this.authHeaders).subscribe(res => {
      const nextId = (res.count + 1).toString().padStart(3, '0');
      this.kaizenNo = `MG-${currentYear}-${nextId}`;
    });
  }

  loadExistingThemes() {
    this.http.get<any[]>(environment.apiUrl + '/api/kaizen/my-kaizens', this.authHeaders).subscribe({
      next: (res) => { this.allThemes = res.map(k => (k.theme || '').toLowerCase().trim()); },
      error: () => { this.allThemes = []; }
    });
  }

  /* ── Deployment table ── */
  createRow() {
    return new FormGroup({
      area:   new FormControl(''),
      resp:   new FormControl(''),
      target: new FormControl(''),
      status: new FormControl('Pending')
    });
  }

  get deploymentRows() { return this.kaizenForm.get('deployments') as FormArray; }
  addRow()              { this.deploymentRows.push(this.createRow()); }
  removeRow(i: number)  { this.deploymentRows.removeAt(i); }

  /* ── Input guards ── */
  allowNumbersOnly(e: KeyboardEvent): boolean {
    return e.charCode >= 48 && e.charCode <= 57;
  }

  allowAlphabetsOnly(e: KeyboardEvent): boolean {
    const c = e.charCode;
    return (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c === 32;
  }

  allowTeamInput(e: KeyboardEvent): boolean {
    const c = e.charCode;
    return (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c === 32 || c === 46 || (c >= 48 && c <= 57);
  }

  checkDuplicateTheme() {
    const theme = this.kaizenForm.get('theme')?.value?.toLowerCase().trim();
    this.isDuplicate = theme && theme.length > 2 ? this.allThemes.includes(theme) : false;
  }

  /* ── File / image handling ── */
  onFileChange(event: any, field: string) {
    const file = event.target.files[0];
    if (!file) return;
    if (file.size <= 512000) {
      this.fileErrors[field] = false;
      this.compressInfo[field] = `✓ ${Math.round(file.size / 1024)}KB — ready`;
      this.files[field] = file;
      this.cdr.detectChanges();
      return;
    }
    this.compressing[field] = true;
    this.cdr.detectChanges();
    this.compressImage(file, 500).then(compressed => {
      this.compressing[field] = false;
      this.fileErrors[field] = false;
      this.files[field] = compressed;
      this.compressInfo[field] = `✓ Compressed: ${Math.round(file.size / 1024)}KB → ${Math.round(compressed.size / 1024)}KB`;
      this.cdr.detectChanges();
    }).catch(() => {
      this.compressing[field] = false;
      this.fileErrors[field] = true;
      this.showToast('error', 'Compression Failed', 'Image compress karne mein error aaya. Dobara try karein.');
      this.cdr.detectChanges();
    });
  }

  compressImage(file: File, maxSizeKB: number): Promise<File> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (e: any) => {
        const img = new Image();
        img.src = e.target.result;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let w = img.width, h = img.height;
          const MAX = 1200;
          if (w > MAX || h > MAX) {
            if (w > h) { h = Math.round(h * MAX / w); w = MAX; }
            else        { w = Math.round(w * MAX / h); h = MAX; }
          }
          canvas.width = w;
          canvas.height = h;
          canvas.getContext('2d')!.drawImage(img, 0, 0, w, h);
          let quality = 0.9;
          const tryCompress = () => {
            const dataUrl = canvas.toDataURL('image/jpeg', quality);
            const sizeKB = Math.round(dataUrl.length * 3 / 4 / 1024);
            if (sizeKB <= maxSizeKB || quality <= 0.3) {
              const arr = dataUrl.split(',');
              const bstr = atob(arr[1]);
              let n = bstr.length;
              const u8 = new Uint8Array(n);
              while (n--) u8[n] = bstr.charCodeAt(n);
              resolve(new File([u8], file.name, { type: 'image/jpeg' }));
            } else {
              quality -= 0.1;
              tryCompress();
            }
          };
          tryCompress();
        };
        img.onerror = () => reject();
      };
      reader.onerror = () => reject();
    });
  }

  isAnyCompressing(): boolean { return Object.values(this.compressing).some(v => v); }
  hasFileError():     boolean { return Object.values(this.fileErrors).some(v => v); }

  handleTeamNumbering(e: any) {
    if (e.key === 'Enter') {
      const val = e.target.value;
      const lines = val.split('\n');
      if (lines[lines.length - 1].trim().length > 3) {
        e.preventDefault();
        this.kaizenForm.patchValue({ team_members: val + '\n' + (lines.length + 1) + '. ' });
      }
    }
  }

  handleBenefitsNumbering(e: KeyboardEvent) {
    if (e.key === 'Enter') {
      const val = (e.target as HTMLTextAreaElement).value;
      const lines = val.split('\n');
      if (lines[lines.length - 1].trim().length > 3) {
        e.preventDefault();
        this.kaizenForm.patchValue({ benefits_pqcdsm: val + '\n' + (lines.length + 1) + '. ' });
      }
    }
  }

  onPreSubmit() {
    Object.keys(this.kaizenForm.controls).forEach(k => this.kaizenForm.get(k)?.markAsTouched());

    if (!this.files['before_img'] || !this.files['after_img']) {
      this.showToast('warning', 'Images Missing', 'Before aur After dono images upload karein.');
      return;
    }
    if (this.hasFileError()) {
      this.showToast('error', 'File Error', 'Kuch files mein error hai. Dobara upload karein.');
      return;
    }
    if (this.isDuplicate) {
      this.showToast('warning', 'Duplicate Theme', 'Yeh theme pehle se exist karti hai. Unique theme use karein.');
      return;
    }
    if (this.isAnyCompressing()) {
      this.showToast('warning', 'Please Wait', 'Files abhi compress ho rahi hain. Thoda wait karein.');
      return;
    }
    if (this.kaizenForm.invalid) {
      this.showToast('error', 'Form Incomplete', 'Saare required fields fill karein phir submit karein.');
      return;
    }

    this.showConfirmModal = true;
  }

  finalSubmit() {
    this.showConfirmModal = false;
    const formData = new FormData();
    Object.keys(this.kaizenForm.value).forEach(key => {
      if (key !== 'deployments') formData.append(key, this.kaizenForm.value[key]);
    });
    formData.append('deployments', JSON.stringify(this.kaizenForm.value.deployments));
    formData.append('kaizen_id', this.kaizenNo);
    formData.append('depo', this.kaizenForm.value.department);
    if (this.files['before_img']) formData.append('before_img', this.files['before_img']!);
    if (this.files['after_img'])  formData.append('after_img',  this.files['after_img']!);

    this.http.post(environment.apiUrl + '/api/manager/save', formData).subscribe({
      next: (res: any) => {
        if (res && res.status === 'success') {
          this.lastSubmittedNo = this.kaizenNo;
          this.showSuccessModal = true;
          this.showToast('success', 'Kaizen Registered!', `${this.kaizenNo} successfully submit ho gaya.`);
          this.currentStep = 0;
          this.kaizenForm.reset({
            unit: '', department: '', section: '',
            kaizen_type: 'Innovative', pillar: 'KK', team_members: '1. '
          });
          this.departmentOptions = [];
          this.sectionOptions = [];
          while (this.deploymentRows.length !== 0) this.deploymentRows.removeAt(0);
          this.addRow();
          this.files = { before_img: null, after_img: null };
          this.fileErrors = { before_img: false, after_img: false };
          this.compressing = { before_img: false, after_img: false };
          this.compressInfo = { before_img: '', after_img: '' };
          document.querySelectorAll<HTMLInputElement>('input[type="file"]').forEach(i => i.value = '');
          this.generateKaizenNo();
          this.loadExistingThemes();
        } else {
          this.showToast('error', 'Backend Error', res?.message || 'Server se unknown error aaya.');
        }
      },
      error: () => this.showToast('error', 'Connection Failed', 'Backend se connect nahi ho paya. Server check karein.')
    });
  }

  logout() {
    sessionStorage.clear();
    localStorage.clear();
    window.history.replaceState(null, '', '/');
    window.location.replace('/');
  }
}