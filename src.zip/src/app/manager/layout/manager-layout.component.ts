import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector:    'app-manager-layout',
  standalone:  true,
  imports:     [CommonModule],
  templateUrl: './manager-layout.component.html',
  styleUrls:   ['./manager-layout.component.css']
})
export class ManagerLayoutComponent implements OnInit {

  // ── Inputs from parent ──────────────────────────────
  @Input() currentView:   string = 'insights';
  @Input() pendingCount:  number = 0;
  @Input() userName:      string = '';
  @Input() userDetail:    string = '';

  // ── Outputs to parent ───────────────────────────────
  @Output() viewChange  = new EventEmitter<string>();
  @Output() syncClick   = new EventEmitter<void>();
  @Output() logoutClick = new EventEmitter<void>();

  sidebarClosed = false;
  userInitial   = 'M';

  ngOnInit() {
    const name = this.userName
              || sessionStorage.getItem('emp_name')
              || sessionStorage.getItem('user_id')
              || 'Manager';
    this.userName    = name;
    this.userInitial = name.charAt(0).toUpperCase();

    if (!this.userDetail) {
      const empId  = sessionStorage.getItem('user_id')  || '';
      const plant  = sessionStorage.getItem('plant')    || '';
      const sect   = sessionStorage.getItem('section')  || '';
      this.userDetail = [empId, plant, sect].filter(Boolean).join(' · ');
    }
  }

  onViewChange(view: string) { this.viewChange.emit(view); }
  onSync()                   { this.syncClick.emit(); }
  onLogout()                 { this.logoutClick.emit(); }
}