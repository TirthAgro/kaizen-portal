import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector:    'app-hod-layout',
  standalone:  true,
  imports:     [CommonModule],
  templateUrl: './hod-layout.component.html',
  styleUrls:   ['./hod-layout.component.css']
})
export class HodLayoutComponent implements OnInit {

  @Input() currentView:  string = '';
  @Input() pendingCount: number = 0;
  @Input() userName:     string = '';
  @Input() userDetail:   string = '';

  @Output() viewChange   = new EventEmitter<string>();
  @Output() logoutClick  = new EventEmitter<void>();
  

  sidebarClosed = false;
  userInitial   = '';

  ngOnInit() {
    const name = this.userName
              || sessionStorage.getItem('emp_name')
              || sessionStorage.getItem('user_id')
              || 'User';
    this.userName    = name;
    this.userInitial = name.charAt(0).toUpperCase();

    if (!this.userDetail) {
      const uid   = sessionStorage.getItem('user_id')  || '';
      const plant = sessionStorage.getItem('plant')    || '';
      const sec   = sessionStorage.getItem('section')  || '';
      this.userDetail = [uid, plant, sec].filter(Boolean).join(' · ');
    }
  }

  onViewChange(view: string) { this.viewChange.emit(view); }
  onLogout()                 { this.logoutClick.emit(); }
  
}