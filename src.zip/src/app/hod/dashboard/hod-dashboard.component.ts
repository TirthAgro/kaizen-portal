import { environment } from '../../../environments/environment';
import { Component, OnInit, ChangeDetectorRef, NgZone } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { HodLayoutComponent } from '../layout/hod-layout.component';
import { Router } from '@angular/router';

/* ── Toast model ───────────────────────────────────────────── */
interface Toast {
  id: number;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message: string;
  visible: boolean;
}

@Component({
  selector: 'app-hod-dashboard',
  templateUrl: './hod-dashboard.component.html',
  styleUrls:   ['./hod-dashboard.component.css'],
  standalone: true,
  imports: [CommonModule, HodLayoutComponent]
})
export class HodDashboardComponent implements OnInit {



  public plantId: string = '';
  public plant: string = '';
  public emp_id: string = '';
  public currentView: string = 'dashboard';
  public isSidebarClosed: boolean = false;
  public kaizens: any[] = [];
  public selectedKaizen: any = null;
  public counts = { op: 0, sup: 0, man: 0, pending: 0 };
  public impactData: any = { Productivity: 0, Quality: 0, Cost: 0, Delivery: 0, Safety: 0, Morale: 0 };
  public impactTotal: number = 0;
  private isLoading: boolean = false;

  /* ── Toast state ───────────────────────────────── */
  public toasts: Toast[] = [];
  private toastCounter = 0;


  private get authHeaders() {
    const token = sessionStorage.getItem('jwt_token') || '';
    return { headers: { 'Authorization': `Bearer ${token}` } };
  }
  constructor(
    private http: HttpClient,
    private cdr: ChangeDetectorRef,
    private router: Router,
    private ngZone: NgZone
  ) {}

  ngOnInit() {
    this.emp_id  = sessionStorage.getItem('emp_id') || '';
    this.plant   = sessionStorage.getItem('plant')  || '';
    this.plantId = sessionStorage.getItem('plant')  || 'Unit 1';
    this.loadData();
  }

  /* ── Toast helpers ─────────────────────────────── */
  showToast(
    type: Toast['type'],
    title: string,
    message: string,
    duration = 4000
  ): void {
    const id = ++this.toastCounter;
    const toast: Toast = { id, type, title, message, visible: false };
    this.toasts.push(toast);
    this.cdr.detectChanges();

    // Trigger slide-in on next tick
    setTimeout(() => {
      toast.visible = true;
      this.cdr.detectChanges();
    }, 20);

    // Auto-dismiss
    setTimeout(() => this.dismissToast(id), duration);
  }

  dismissToast(id: number): void {
    const t = this.toasts.find(x => x.id === id);
    if (!t) return;
    t.visible = false;
    this.cdr.detectChanges();
    // Remove from array after slide-out animation
    setTimeout(() => {
      this.toasts = this.toasts.filter(x => x.id !== id);
      this.cdr.detectChanges();
    }, 400);
  }

  /* ── Rest of logic ─────────────────────────────── */
  getPageTitle(): string {
    const map: any = {
      dashboard: 'Intelligence Dashboard',
      pending:   'Decision Queue',
      history:   'Approval History',
      master:    'Master Configuration'
    };
    return map[this.currentView] || 'Dashboard';
  }

  openKaizen(k: any) {
    this.selectedKaizen = { ...k };
    this.cdr.detectChanges();

    const role = k.role_type || 'Manager';
    this.http.get<any>(
      `${environment.apiUrl}/api/kaizen/detail?id=${k.id}&role=${role}`
    ).subscribe({
      next: (detail) => {
        this.selectedKaizen = { ...k, ...detail };
        this.cdr.detectChanges();
      },
      error: () => {}
    });
  }

  loadData() {
    if (this.isLoading) return;
    this.isLoading = true;

    const url = `${environment.apiUrl}/api/kaizen?plant_id=${encodeURIComponent(this.plantId)}`;
    this.http.get(url).subscribe({
      next: (res: any) => {
        if (!res) { this.isLoading = false; return; }
        this.kaizens = res.list || [];
        this.counts  = res.counts
          ? { ...res.counts }
          : { op: 0, sup: 0, man: 0, pending: 0 };
        if (res.impact) {
          this.impactData  = { ...res.impact };
          this.impactTotal = Object.values(res.impact)
            .reduce((a: any, b: any) => Number(a) + Number(b), 0) as number;
        } else {
          this.impactTotal = 0;
        }
        this.isLoading = false;
        this.cdr.markForCheck();
        this.cdr.detectChanges();
      },
      error: () => { this.isLoading = false; }
    });
  }

  getPendingList() {
    return this.kaizens.filter(k => !k.hod_status || k.hod_status === 'Pending');
  }

  safeImgSrc(imgData: any): string | null {
    if (!imgData) return null;
    const str = String(imgData).trim();
    if (!str) return null;
    if (str.startsWith('http://') || str.startsWith('https://')) return str;
    if (str.startsWith('data:')) return str;
    if (/\.(jpg|jpeg|png|gif|webp)/.test(str)) {
      return '${environment.apiUrl}/uploads/' + str;
    }
    if (str.length > 100) return 'data:image/jpeg;base64,' + str;
    return null;
  }

  getW(key: string): number {
    if (this.impactTotal === 0 || !this.impactData[key]) return 0;
    return (Number(this.impactData[key]) / this.impactTotal) * 100;
  }

  process(k: any, status: string, remark: string) {
    if (!remark.trim()) {
      this.showToast(
        'warning',
        'Remarks Required',
        'Please provide feedback before modifying this decision.'
      );
      return;
    }

    this.http.post(environment.apiUrl + '/api/kaizen/update', {
      id:          k.id,
      action:      status,
      hod_remarks: remark,
      role_type:   k.role_type
    }).subscribe({
      next: (res: any) => {
        if (res?.error) {
          this.showToast('error', 'Update Failed', res.error);
        } else {
          const label = status === 'Approved' ? 'Approved' : 'Rejected';
          this.showToast(
            status === 'Approved' ? 'success' : 'error',
            `Kaizen ${label}`,
            `${k.kaizen_id} has been successfully ${label.toLowerCase()}.`
          );
          this.selectedKaizen = null;
          this.loadData();
        }
      },
      error: () =>
        this.showToast('error', 'Network Error', 'Action failed. Please try again.')
    });
  }

  logout() {
    sessionStorage.clear();
    localStorage.clear();
    window.history.replaceState(null, '', '/');
    window.location.replace('/');
  }
}