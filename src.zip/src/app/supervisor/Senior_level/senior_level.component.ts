import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { environment } from '../../../environments/environment';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-senior-level',
  standalone: true,
  templateUrl: './senior-level.component.html',
  styleUrls:   ['./senior-level.component.css'],
  imports: [CommonModule, ReactiveFormsModule, RouterModule]
})
export class SeniorLevelComponent implements OnInit {

  public steps = ['Basic & Classification', 'Analysis & Solution', 'Results & Deployment'];
  public currentStep = 0;

  public kaizenNo        = '';
  public today           = new Date();
  public kaizenForm!: FormGroup;
  public showConfirmModal  = false;
  public showSuccessModal  = false;
  public lastSubmittedNo   = '';
  public isDuplicate       = false;

  public compressing:  { [key: string]: boolean } = { before_img: false, after_img: false };
  public compressInfo: { [key: string]: string  } = { before_img: '', after_img: '' };
  public fileErrors:   { [key: string]: boolean } = { before_img: false, after_img: false };
  private files:       { [key: string]: File | null } = { before_img: null, after_img: null };
  private allThemes:   string[] = [];

  public departmentOptions: string[] = [];
  public sectionOptions:    string[] = [];

  private readonly plantDeptMap: { [plant: string]: string[] } = {
    'Unit 1': ['Production','Maintenance','Quality','Stores','HR & Admin'],
    'Unit 2': ['Production','Maintenance','Quality','Stores','HR & Admin'],
    'Unit 3': ['Production','Maintenance','Quality','Stores','HR & Admin'],
    'Unit 4': ['Production','Maintenance','Quality','Stores','HR & Admin'],
    'Unit 5': ['Production','Maintenance','Quality','Stores','HR & Admin'],
  };
  private readonly deptSectionMap: { [dept: string]: string[] } = {
    'Production':  ['Assembly','Welding','Machining','Painting','Packing'],
    'Maintenance': ['Electrical','Mechanical','Civil','Utilities'],
    'Quality':     ['Incoming','In-Process','Final Inspection','Lab'],
    'Stores':      ['Raw Material','Finished Goods','Spare Parts'],
    'HR & Admin':  ['Recruitment','Training','Payroll','Administration'],
  };

  public pillars = ['KK','JH','PM','QM','NEDM','NPDM','DM','E&T','SHE','LM'];
  public categories = [
    { v: 'C-1|Restorative (TPM)',           l: 'C-1: Restorative (Using TPM Methodology)' },
    { v: 'C-2|Renovative (TPM)',            l: 'C-2: Renovative (Using TPM Methodology)' },
    { v: 'C-3|Innovative (TPM)',            l: 'C-3: Innovative (Using TPM Methodology)' },
    { v: 'C-4|Breakthrough (TPM)',          l: 'C-4: Breakthrough (Using TPM Methodology)' },
    { v: 'C-5|Poka Yoke (TPM)',             l: 'C-5: Poka Yoke (Using TPM Methodology)' },
    { v: 'C-6|KARAKURI & YUTORI',          l: 'C-6: KARAKURI & YUTORI' },
    { v: 'C-7|JH Shop Floor Visualization', l: 'C-7: JH - Shop Floor Visualization' },
    { v: 'C-22|NEDM Low Cost Automation',   l: 'C-22: NEDM: Low Cost Automation' },
    { v: 'C-25|SHE Near Miss',              l: 'C-25: SHE: Near Miss & Unsafe Condition' },
    { v: 'C-30|5S Zone Space Saved',        l: 'C-30: 5S: Zone wise space saved' },
  ];


  private get authHeaders() {
    const token = sessionStorage.getItem('jwt_token') || '';
    return { headers: { 'Authorization': `Bearer ${token}` } };
  }
  constructor(
    private router: Router,
    private http: HttpClient,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.generateKaizenNo();
    this.loadExistingThemes();
    this.kaizenForm = new FormGroup({
      emp_id:          new FormControl('', [Validators.required, Validators.pattern('^[0-9]+$')]),
      emp_name:        new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z ]+$')]),
      unit:            new FormControl('', Validators.required),
      department:      new FormControl('', Validators.required),
      section:         new FormControl('', Validators.required),
      machine_no:      new FormControl('', Validators.required),
      kaizen_type:     new FormControl('', Validators.required),
      pqcdsm:          new FormControl('', Validators.required),
      kaizen_category: new FormControl('', Validators.required),
      theme:           new FormControl('', Validators.required),
      problem_status:  new FormControl('', Validators.required),
      idea:            new FormControl('', Validators.required),
      countermeasure:  new FormControl('', Validators.required),
      pillar:          new FormControl('', Validators.required),
      why1:            new FormControl('', Validators.required),
      why2:            new FormControl('', Validators.required),
      why3:            new FormControl('', Validators.required),
      why4:            new FormControl(''),
      why5:            new FormControl(''),
      root_cause:      new FormControl('', Validators.required),
      analysis:        new FormControl(''),
      benchmark:       new FormControl(''),
      target:          new FormControl(''),
      start_date:      new FormControl('', Validators.required),
      end_date:        new FormControl('', Validators.required),
      final_result:    new FormControl('', Validators.required),
      before_desc:     new FormControl('', Validators.required),
      after_desc:      new FormControl('', Validators.required),
      benefits_pqcdsm: new FormControl('1.', Validators.required),
      team_members:    new FormControl('1. ', Validators.required),
      deployments:     new FormArray([this.createRow()])
    });
  }

  /* ── Step field map for validation ── */
  private readonly stepRequiredFields: string[][] = [
    // Step 0 — Basic & Classification
    ['emp_id','emp_name','unit','department','section','machine_no','pqcdsm','kaizen_category','theme'],
    // Step 1 — Analysis & Solution
    ['why1','why2','why3','root_cause','problem_status','idea','countermeasure'],
    // Step 2 — Results & Deployment
    ['start_date','end_date','final_result','before_desc','after_desc','benefits_pqcdsm','team_members'],
  ];

  isCurrentStepValid(): boolean {
    const fields = this.stepRequiredFields[this.currentStep] || [];
    const allValid = fields.every(f => {
      const ctrl = this.kaizenForm.get(f);
      return ctrl && ctrl.valid && (ctrl.value !== '' && ctrl.value !== null);
    });
    // Also block step 0 if theme is duplicate
    if (this.currentStep === 0 && this.isDuplicate) return false;
    return allValid;
  }

  /* ── Step navigation ── */
  nextStep() {
    if (!this.isCurrentStepValid()) {
      // Mark all current-step fields as touched to show errors
      const fields = this.stepRequiredFields[this.currentStep] || [];
      fields.forEach(f => this.kaizenForm.get(f)?.markAsTouched());
      return;
    }
    if (this.currentStep < this.steps.length - 1) this.currentStep++;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  prevStep() {
    if (this.currentStep > 0) this.currentStep--;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  /* ── Plant / Dept cascades ── */
  onPlantChange() {
    const plant = this.kaizenForm.get('unit')?.value;
    this.departmentOptions = plant ? (this.plantDeptMap[plant] || []) : [];
    this.sectionOptions = [];
    this.kaizenForm.patchValue({ department: '', section: '' });
  }
  onDepartmentChange() {
    const dept = this.kaizenForm.get('department')?.value;
    this.sectionOptions = dept ? (this.deptSectionMap[dept] || []) : [];
    this.kaizenForm.patchValue({ section: '' });
  }

  generateKaizenNo() {
    const currentYear = new Date().getFullYear();
    this.http.get<any>(environment.apiUrl + '/api/manager?action=count', this.authHeaders).subscribe(res => {
      const nextId = (res.count + 1).toString().padStart(3, '0');
      this.kaizenNo = `MG-${currentYear}-${nextId}`;
    });
  }

  loadExistingThemes() {
    this.http.get<any[]>(environment.apiUrl + '/api/kaizen/my-kaizens', this.authHeaders).subscribe({
      next: (res) => { this.allThemes = res.map(k => (k.theme || '').toLowerCase().trim()); },
      error: () => { this.allThemes = []; }
    });
  }

  /* ── Deployment table ── */
  createRow() {
    return new FormGroup({
      area:   new FormControl(''),
      resp:   new FormControl(''),
      target: new FormControl(''),
      status: new FormControl('Pending')
    });
  }
  get deploymentRows() { return this.kaizenForm.get('deployments') as FormArray; }
  addRow()              { this.deploymentRows.push(this.createRow()); }
  removeRow(i: number)  { this.deploymentRows.removeAt(i); }

  /* ── Input guards ── */
  allowNumbersOnly(e: KeyboardEvent): boolean   { return e.charCode >= 48 && e.charCode <= 57; }
  allowAlphabetsOnly(e: KeyboardEvent): boolean {
    const c = e.charCode;
    return (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c === 32;
  }
  allowTeamInput(e: KeyboardEvent): boolean {
    const c = e.charCode;
    return (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c === 32 || c === 46 || (c >= 48 && c <= 57);
  }

  checkDuplicateTheme() {
    const theme = this.kaizenForm.get('theme')?.value?.toLowerCase().trim();
    this.isDuplicate = theme && theme.length > 2 ? this.allThemes.includes(theme) : false;
  }

  /* ── File / image handling ── */
  onFileChange(event: any, field: string) {
    const file = event.target.files[0];
    if (!file) return;
    if (file.size <= 512000) {
      this.fileErrors[field] = false;
      this.compressInfo[field] = `✓ ${Math.round(file.size/1024)}KB — ready`;
      this.files[field] = file;
      this.cdr.detectChanges(); return;
    }
    this.compressing[field] = true; this.cdr.detectChanges();
    this.compressImage(file, 500).then(compressed => {
      this.compressing[field] = false; this.fileErrors[field] = false;
      this.files[field] = compressed;
      this.compressInfo[field] = `✓ Compressed: ${Math.round(file.size/1024)}KB → ${Math.round(compressed.size/1024)}KB`;
      this.cdr.detectChanges();
    }).catch(() => { this.compressing[field] = false; this.fileErrors[field] = true; this.cdr.detectChanges(); });
  }

  compressImage(file: File, maxSizeKB: number): Promise<File> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (e: any) => {
        const img = new Image(); img.src = e.target.result;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let w = img.width, h = img.height; const MAX = 1200;
          if (w > MAX || h > MAX) {
            if (w > h) { h = Math.round(h * MAX / w); w = MAX; }
            else        { w = Math.round(w * MAX / h); h = MAX; }
          }
          canvas.width = w; canvas.height = h;
          canvas.getContext('2d')!.drawImage(img, 0, 0, w, h);
          let quality = 0.9;
          const tryCompress = () => {
            const dataUrl = canvas.toDataURL('image/jpeg', quality);
            const sizeKB = Math.round(dataUrl.length * 3 / 4 / 1024);
            if (sizeKB <= maxSizeKB || quality <= 0.3) {
              const arr = dataUrl.split(','); const bstr = atob(arr[1]);
              let n = bstr.length; const u8 = new Uint8Array(n);
              while (n--) u8[n] = bstr.charCodeAt(n);
              resolve(new File([u8], file.name, { type: 'image/jpeg' }));
            } else { quality -= 0.1; tryCompress(); }
          };
          tryCompress();
        };
        img.onerror = () => reject();
      };
      reader.onerror = () => reject();
    });
  }

  isAnyCompressing(): boolean { return Object.values(this.compressing).some(v => v); }
  hasFileError():     boolean { return Object.values(this.fileErrors).some(v => v); }

  handleTeamNumbering(e: any) {
    if (e.key === 'Enter') {
      const val = e.target.value; const lines = val.split('\n');
      if (lines[lines.length - 1].trim().length > 3) {
        e.preventDefault();
        this.kaizenForm.patchValue({ team_members: val + '\n' + (lines.length + 1) + '. ' });
      }
    }
  }
  handleBenefitsNumbering(e: KeyboardEvent) {
  if (e.key === 'Enter') {
    const val = (e.target as HTMLTextAreaElement).value;
    const lines = val.split('\n');

    if (lines[lines.length - 1].trim().length > 3) {
      e.preventDefault();

      this.kaizenForm.patchValue({
        benefits_pqcdsm: val + '\n' + (lines.length + 1) + '. '
      });
    }
  }
}

  onPreSubmit() {
    Object.keys(this.kaizenForm.controls).forEach(k => this.kaizenForm.get(k)?.markAsTouched());
    if (this.kaizenForm.valid && !this.hasFileError() && !this.isDuplicate &&
        !this.isAnyCompressing() && this.files['before_img'] && this.files['after_img']) {
      this.showConfirmModal = true;
    } else {
      alert('Please fill all required fields and select both images.');
    }
  }

  finalSubmit() {
    this.showConfirmModal = false;
    const formData = new FormData();
    Object.keys(this.kaizenForm.value).forEach(key => {
      if (key !== 'deployments') formData.append(key, this.kaizenForm.value[key]);
    });
    formData.append('deployments', JSON.stringify(this.kaizenForm.value.deployments));
    formData.append('kaizen_id', this.kaizenNo);
    formData.append('depo', this.kaizenForm.value.department);
    if (this.files['before_img']) formData.append('before_img', this.files['before_img']!);
    if (this.files['after_img'])  formData.append('after_img',  this.files['after_img']!);

    this.http.post(environment.apiUrl + '/api/senior/submit', formData).subscribe({
      next: (res: any) => {
        if (res && res.status === 'success') {
          this.lastSubmittedNo = this.kaizenNo;
          this.showSuccessModal = true;
          this.currentStep = 0;
          this.kaizenForm.reset({ unit: '', department: '', section: '', kaizen_type: 'Innovative', pillar: 'KK', team_members: '1. ' });
          this.departmentOptions = []; this.sectionOptions = [];
          while (this.deploymentRows.length !== 0) this.deploymentRows.removeAt(0);
          this.addRow();
          this.files = { before_img: null, after_img: null };
          this.fileErrors = { before_img: false, after_img: false };
          this.compressing = { before_img: false, after_img: false };
          this.compressInfo = { before_img: '', after_img: '' };
          document.querySelectorAll<HTMLInputElement>('input[type="file"]').forEach(i => i.value = '');
          this.generateKaizenNo(); this.loadExistingThemes();
        } else {
          alert('Backend Error: ' + (res?.message || 'Unknown Error'));
        }
      },
      error: () => alert('Submission failed. Check backend connection.')
    });
  }

  goBack() {
  window.history.back();
}

  logout() { sessionStorage.clear();
    localStorage.clear();
    window.history.replaceState(null, '', '/');
    window.location.replace('/'); }
}