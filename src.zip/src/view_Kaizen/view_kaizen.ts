import { environment } from '../environments/environment';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import jsPDF from 'jspdf';

@Component({
  selector: 'app-view-kaizen',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  template: `
<div class="vk-app">

  <!-- TOP NAVBAR -->
  <header class="vk-navbar">
    <div class="vk-brand-wrap">
      <div class="vk-logo-wrap">
        <img src="assets/shaktiman_logo.png" alt="logo">
      </div>

      <div>
        <h1>SHAKTIMAN KAIZEN PORTAL</h1>
        <p>Innovation • Improvement • Excellence</p>
      </div>
    </div>

    <div class="vk-navbar-right">
      <div class="vk-mini-card total">
        <span>Total</span>
        <strong>{{totalKaizens}}</strong>
      </div>

      <div class="vk-mini-card approved">
        <span>Approved</span>
        <strong>{{approvedCount}}</strong>
      </div>

      <div class="vk-mini-card pending">
        <span>Pending</span>
        <strong>{{pendingCount}}</strong>
      </div>

      <div class="vk-mini-card rejected">
        <span>Rejected</span>
        <strong>{{rejectedCount}}</strong>
      </div>
    </div>

    <!-- Login / Dashboard button -->
    <div class="vk-nav-actions">
      <a routerLink="/" class="vk-login-btn" *ngIf="!isLoggedIn">
        🔐 Login
      </a>
      <a [routerLink]="getDashboardRoute()" class="vk-login-btn vk-dash-btn" *ngIf="isLoggedIn">
        ← Dashboard
      </a>
    </div>
  </header>

  <!-- MAIN -->
  <main class="vk-main">

    <!-- HERO -->
    <section class="vk-hero">
      <div class="vk-hero-content">
        <h2>Kaizen Innovation Gallery</h2>
        <p>
          Explore submitted improvements, process optimizations,and innovation ideas across all departments.
          
        </p>
      </div>

      <div class="vk-hero-glow"></div>
    </section>

    <!-- FILTER BAR -->
    <section class="vk-toolbar">

      <div class="vk-search">
        <svg width="18" height="18" viewBox="0 0 24 24"
          fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="11" cy="11" r="8"/>
          <path d="m21 21-4.3-4.3"/>
        </svg>

        <input
          type="text"
          [(ngModel)]="searchTerm"
          (input)="filterKaizens()"
          placeholder="Search Kaizen..."
        >
      </div>

      <div class="vk-filters">

        <select [(ngModel)]="statusFilter" (change)="filterKaizens()">
          <option value="" class= "muted" >All Status</option>
          <option value="Approved">Approved</option>
          <option value="Pending">Pending</option>
          <option value="Rejected">Rejected</option>
        </select>

        <select [(ngModel)]="sourceFilter" (change)="filterKaizens()">
          <option value="" class= "muted">All Levels</option>
          <option value="operator">Operator</option>
          <option value="supervisor">Supervisor</option>
          <option value="manager">Manager</option>
        </select>

      </div>
    </section>

    <!-- LOADER -->
    <div class="vk-loader" *ngIf="isLoading">
      <div class="vk-loader-ring"></div>
      <span>Loading Kaizen Records...</span>
    </div>

    <!-- TABLE -->
    <section class="vk-table-wrapper" *ngIf="!isLoading">

      <table class="vk-table">

        <thead>
          <tr>
            <th>ID</th>
            <th>Employee</th>
            <th>Level</th>
            <th>Theme</th>
            <th>Unit</th>
            <th>Date</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>

        <tbody>

          <tr *ngFor="let k of pagedKaizens">

            <td>
              <div class="vk-id">{{k.kaizen_id}}</div>
            </td>

            <td>
              <div class="vk-user">
                <div class="vk-avatar">
                  {{(k.emp_name || 'U').charAt(0)}}
                </div>

                <div>
                  <h4>{{k.emp_name}}</h4>
                  <p>{{k.emp_id}}</p>
                </div>
              </div>
            </td>

            <td>
              <span class="vk-level" [ngClass]="k.source">
                {{k.source}}
              </span>
            </td>

            <td class="vk-theme-cell">
              {{k.theme}}
            </td>

            <td>
              <div class="vk-unit">{{k.unit}}</div>
              <div class="vk-section">{{k.section}}</div>
            </td>

            <td>
              {{k.created_at | date:'dd MMM yyyy'}}
            </td>

            <td>
              <span class="vk-status" [ngClass]="k.status?.toLowerCase()">
                {{k.status || 'Pending'}}
              </span>
            </td>

            <td>
              <div class="vk-actions">

                <button class="vk-btn view"
                  (click)="openFullDetails(k)">
                  View
                </button>

                <button class="vk-btn pdf"
                  (click)="downloadKaizenPdf(k)">
                  PDF
                </button>

              </div>
            </td>

          </tr>

        </tbody>
      </table>

      <!-- PAGINATION -->
      <div class="vk-pagination">

        <div class="vk-page-text">
          Showing
          {{(currentPage-1)*itemsPerPage+1}}
          -
          {{Math.min(currentPage*itemsPerPage, filteredKaizens.length)}}
          of
          {{filteredKaizens.length}}
        </div>

        <div class="vk-page-controls">

          <button
            (click)="prevPage()"
            [disabled]="currentPage===1">
            Prev
          </button>

          <span>{{currentPage}} / {{totalPages}}</span>

          <button
            (click)="nextPage()"
            [disabled]="currentPage===totalPages">
            Next
          </button>

        </div>
      </div>

    </section>
  </main>

  <!-- MODAL -->
  <div class="vk-modal-overlay"
    *ngIf="selectedKaizen"
    (click)="selectedKaizen=null">

    <div class="vk-modal"
      (click)="$event.stopPropagation()">

      <div class="vk-modal-header">

        <div>
          <h2>{{selectedKaizen.theme}}</h2>
          <p>{{selectedKaizen.kaizen_id}}</p>
        </div>

        <button class="vk-close"
          (click)="selectedKaizen=null">
          ✕
        </button>
      </div>

      <div class="vk-modal-body">

        <div class="vk-detail-grid">

          <div class="vk-detail-card">
            <label>Employee</label>
            <strong>{{selectedKaizen.emp_name}}</strong>
          </div>

          <div class="vk-detail-card">
            <label>Department</label>
            <strong>{{selectedKaizen.unit}}</strong>
          </div>

          <div class="vk-detail-card">
            <label>Status</label>
            <strong>{{selectedKaizen.status}}</strong>
          </div>

          <div class="vk-detail-card">
            <label>Category</label>
            <strong>{{selectedKaizen.kaizen_category}}</strong>
          </div>

        </div>

        <!-- BEFORE AFTER -->
        <div class="vk-before-after">

          <div class="vk-image-card">

            <div class="vk-image-title before">
              BEFORE
            </div>

            <div class="vk-image-box">
              <img
                *ngIf="selectedKaizen.before_img"
                [src]="selectedKaizen.before_img">

              <div class="vk-no-image"
                *ngIf="!selectedKaizen.before_img">
                No Image
              </div>
            </div>

            <div class="vk-desc">
              {{selectedKaizen.before_desc}}
            </div>
          </div>

          <div class="vk-image-card">

            <div class="vk-image-title after">
              AFTER
            </div>

            <div class="vk-image-box">
              <img
                *ngIf="selectedKaizen.after_img"
                [src]="selectedKaizen.after_img">

              <div class="vk-no-image"
                *ngIf="!selectedKaizen.after_img">
                No Image
              </div>
            </div>

            <div class="vk-desc">
              {{selectedKaizen.after_desc}}
            </div>

          </div>

        </div>

        <div class="vk-modal-actions">

          <button class="vk-download-main"
            (click)="downloadKaizenPdf(selectedKaizen)">
            Download PDF
          </button>

        </div>

      </div>
    </div>
  </div>

</div>
`,
styles: [`

@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

:host{
  --bg:#f4f7fb;
  --surface:#ffffff;
  --surface-2:#f8fafc;

  --text:#0f172a;
  --text-light:#64748b;

  --border:#e2e8f0;

  --primary:#ff7a00;
  --primary-dark:#ff4d00;

  --success:#16a34a;
  --warning:#f59e0b;
  --danger:#ef4444;

  --shadow:
    0 10px 30px rgba(15,23,42,.08);

  font-family:'Inter',sans-serif;
  display:block;
}

*{
  margin:0;
  padding:0;
  box-sizing:border-box;
}

body{
  background:var(--bg);
}

/* APP */

.vk-app{
  min-height:100vh;
  background:
    radial-gradient(circle at top left,
      rgba(255,122,0,.10),
      transparent 24%),

    radial-gradient(circle at bottom right,
      rgba(59,130,246,.10),
      transparent 20%),

    linear-gradient(180deg,#f8fbff 0%,#eef4ff 100%);
}

/* NAVBAR */

.vk-nav-actions { display: flex; align-items: center; gap: 10px; margin-left: 16px; }
    .vk-login-btn {
      padding: 8px 18px; border-radius: 8px; font-size: 13px; font-weight: 700;
      text-decoration: none; background: #ff7f27; color: #000; cursor: pointer;
      transition: 0.2s; white-space: nowrap;
    }
    .vk-dash-btn { background: #0d1117; color: #fff; }
    .vk-login-btn:hover { opacity: 0.85; transform: translateY(-1px); }

    .vk-navbar{
  height:90px;
  padding:0 34px;
  display:flex;
  align-items:center;
  justify-content:space-between;

  position:sticky;
  top:0;
  z-index:1000;

  backdrop-filter:blur(18px);

  background:rgba(255,255,255,.72);

  border-bottom:1px solid rgba(255,255,255,.8);

  box-shadow:
    0 8px 30px rgba(15,23,42,.05);
}

.vk-brand-wrap{
  display:flex;
  align-items:center;
  gap:18px;
}

.vk-logo-wrap{
  width:60px;
  height:60px;
  border-radius:20px;

  background:#fff;

  display:flex;
  align-items:center;
  justify-content:center;

  box-shadow:
    0 10px 24px rgba(0,0,0,.08);
}

.vk-logo-wrap img{
  width:42px;
}

.vk-brand-wrap h1{
  color:var(--text);
  font-size:1.1rem;
  font-weight:800;
  letter-spacing:.4px;
}

.vk-brand-wrap p{
  color:var(--text-light);
  font-size:.82rem;
  margin-top:4px;
}

/* STATS */

.vk-navbar-right{
  display:flex;
  gap:14px;
}

.vk-mini-card{
  min-width:115px;
  padding:12px 16px;
  border-radius:20px;

  background:#fff;

  border:1px solid var(--border);

  box-shadow:var(--shadow);

  transition:.25s;
}

.vk-mini-card:hover{
  transform:translateY(-3px);
}

.vk-mini-card span{
  display:block;
  font-size:.72rem;
  color:var(--text-light);
  margin-bottom:6px;
}

.vk-mini-card strong{
  font-size:1.4rem;
  color:var(--text);
  font-weight:800;
}

.vk-mini-card.total{
  border-left:5px solid #3b82f6;
}

.vk-mini-card.approved{
  border-left:5px solid var(--success);
}

.vk-mini-card.pending{
  border-left:5px solid var(--warning);
}

.vk-mini-card.rejected{
  border-left:5px solid var(--danger);
}

/* MAIN */

.vk-main{
  padding:34px;
}

/* HERO */

.vk-hero{
  position:relative;
  height:120px;

  overflow:hidden;

  padding:20px;

  border-radius:32px;

  margin-bottom:32px;

  background:
    linear-gradient(135deg,
      #ff7a00,
      #ff4d00);

  box-shadow:
    0 20px 50px rgba(255,122,0,.28);
}

.vk-hero-content{
  position:relative;
  z-index:2;
}

.vk-hero-content h2{
  font-size:1.6rem;
  color:#fff;
  font-weight:800;
  margin-bottom:14px;
}

.vk-hero-content p{
  max-width:780px;
  line-height:1.8;
  color:rgba(255,255,255,.92);
  font-size:1rem;
}

.vk-hero-glow{
  position:absolute;
  width:300px;
  height:300px;
  border-radius:50%;

  background:
    rgba(255,255,255,.18);

  filter:blur(70px);

  right:-60px;
  top:-70px;
}

/* TOOLBAR */

.vk-toolbar{
  display:flex;
  justify-content:space-between;
  align-items:center;

  gap:20px;

  margin-bottom:28px;

  flex-wrap:wrap;
}

.vk-search{
  flex:1;
  min-width:280px;
  max-width:500px;

  height:60px;

  padding:0 18px;

  border-radius:18px;

  background:#fff;

  border:1px solid var(--border);

  box-shadow:var(--shadow);

  display:flex;
  align-items:center;
  gap:12px;
}

.vk-search svg{
  color:var(--text-light);
}

.vk-search input{
  flex:1;
  border:none;
  outline:none;
  background:none;

  color:var(--text);

  font-size:.95rem;
  font-weight:500;
}

.vk-search input::placeholder{
  color:#94a3b8;
}

.vk-filters{
  display:flex;
  gap:14px;
}

.vk-filters select{
  height:60px;

  padding:0 18px;

  border-radius:18px;

  border:1px solid var(--border);

  background:#fff;

  color:var(--text);

  font-weight:600;

  box-shadow:var(--shadow);

  outline:none;

  cursor:pointer;
}

/* TABLE */

.vk-table-wrapper{
  background:#fff;

  border-radius:30px;

  overflow:hidden;

  border:1px solid #eef2f7;

  box-shadow:
    0 18px 40px rgba(15,23,42,.08);
}

.vk-table{
  width:100%;
  border-collapse:collapse;
}

.vk-table thead{
  background:#f8fafc;
}

.vk-table th{
  padding:22px 20px;

  color:#64748b;

  font-size:.75rem;

  font-weight:700;

  letter-spacing:.6px;

  text-transform:uppercase;
}

.vk-table td{
  padding:18px 20px;

  border-top:1px solid #f1f5f9;

  color:var(--text);

  font-size:.92rem;
}

.vk-table tbody tr{
  transition:.25s;
}

.vk-table tbody tr:hover{
  background:#f8fbff;
}

/* ID */

.vk-id{
  font-weight:800;
  color:var(--primary);
}

/* USER */

.vk-user{
  display:flex;
  align-items:center;
  gap:14px;
}

.vk-avatar{
  width:48px;
  height:48px;

  border-radius:16px;

  background:
    linear-gradient(135deg,
      var(--primary),
      var(--primary-dark));

  color:#fff;

  font-weight:800;

  display:flex;
  align-items:center;
  justify-content:center;

  box-shadow:
    0 10px 20px rgba(255,122,0,.28);
}

.vk-user h4{
  font-size:.92rem;
  font-weight:700;
  color:var(--text);
}

.vk-user p{
  margin-top:4px;
  font-size:.75rem;
  color:var(--text-light);
}

/* BADGES */

.vk-level,
.vk-status{
  padding:8px 16px;
  border-radius:999px;

  font-size:.72rem;
  font-weight:700;

  display:inline-flex;
  align-items:center;
  justify-content:center;
}

.vk-level.operator{
  background:#dcfce7;
  color:#166534;
}

.vk-level.supervisor{
  background:#fef3c7;
  color:#92400e;
}

.vk-level.manager{
  background:#ede9fe;
  color:#6d28d9;
}

.vk-status.approved{
  background:#dcfce7;
  color:#166534;
}

.vk-status.pending{
  background:#fef3c7;
  color:#92400e;
}

.vk-status.rejected{
  background:#fee2e2;
  color:#991b1b;
}

/* BUTTONS */

.vk-actions{
  display:flex;
  gap:10px;
}

.vk-btn{
  border:none;

  height:42px;

  padding:0 18px;

  border-radius:14px;

  font-weight:700;

  cursor:pointer;

  transition:.25s;
}

.vk-btn:hover{
  transform:translateY(-2px);
}

.vk-btn.view{
  background:#0f172a;
  color:#fff;
}

.vk-btn.pdf{
  background:
    linear-gradient(135deg,
      var(--primary),
      var(--primary-dark));

  color:#fff;
}

/* PAGINATION */

.vk-pagination{
  padding:22px 28px;

  display:flex;
  justify-content:space-between;
  align-items:center;
}

.vk-page-text{
  color:var(--text-light);
  font-weight:500;
}

.vk-page-controls{
  display:flex;
  align-items:center;
  gap:14px;
}

.vk-page-controls button{
  border:none;

  background:#f1f5f9;

  height:42px;

  padding:0 18px;

  border-radius:12px;

  font-weight:700;

  cursor:pointer;

  transition:.2s;
}

.vk-page-controls button:hover{
  background:#e2e8f0;
}

/* MODAL */

.vk-modal-overlay{
  position:fixed;
  inset:0;

  background:rgba(15,23,42,.65);

  backdrop-filter:blur(8px);

  display:flex;
  align-items:center;
  justify-content:center;

  padding:24px;

  z-index:3000;
}

.vk-modal{
  width:100%;
  max-width:1150px;

  border-radius:30px;

  overflow:hidden;

  background:#fff;

  box-shadow:
    0 30px 80px rgba(0,0,0,.25);
}

.vk-modal-header{
  padding:24px 30px;

  display:flex;
  justify-content:space-between;
  align-items:center;

  border-bottom:1px solid #eef2f7;
}

.vk-modal-header h2{
  color:var(--text);
  font-size:1.5rem;
  font-weight:800;
}

.vk-modal-header p{
  margin-top:6px;
  color:var(--text-light);
}

.vk-close{
  width:44px;
  height:44px;

  border:none;

  border-radius:14px;

  background:#f1f5f9;

  cursor:pointer;

  font-size:1rem;

  transition:.2s;
}

.vk-close:hover{
  background:#e2e8f0;
}

/* DETAIL CARDS */

.vk-modal-body{
  padding:30px;
}

.vk-detail-grid{
  display:grid;
  grid-template-columns:repeat(4,1fr);

  gap:18px;

  margin-bottom:28px;
}

.vk-detail-card{
  padding:20px;

  border-radius:22px;

  background:#f8fafc;

  border:1px solid #eef2f7;
}

.vk-detail-card label{
  display:block;

  font-size:.74rem;

  color:var(--text-light);

  margin-bottom:10px;
}

.vk-detail-card strong{
  color:var(--text);
  font-size:1rem;
}

/* BEFORE AFTER */

.vk-before-after{
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:24px;
}

.vk-image-card{
  overflow:hidden;

  border-radius:24px;

  background:#fff;

  border:1px solid #eef2f7;

  box-shadow:var(--shadow);
}

.vk-image-title{
  padding:16px;

  text-align:center;

  color:#fff;

  font-weight:800;
}

.vk-image-title.before{
  background:#ef4444;
}

.vk-image-title.after{
  background:#10b981;
}

.vk-image-box{
  height:320px;
  background:#f1f5f9;
}

.vk-image-box img{
  width:100%;
  height:100%;
  object-fit:cover;
}

.vk-desc{
  padding:18px;

  line-height:1.8;

  color:#334155;

  font-size:.92rem;
}

.vk-no-image{
  width:100%;
  height:100%;

  display:flex;
  align-items:center;
  justify-content:center;

  color:#94a3b8;
}

/* DOWNLOAD */

.vk-modal-actions{
  margin-top:28px;

  display:flex;
  justify-content:flex-end;
}

.vk-download-main{
  border:none;

  height:54px;

  padding:0 28px;

  border-radius:18px;

  background:
    linear-gradient(135deg,
      var(--primary),
      var(--primary-dark));

  color:#fff;

  font-size:.95rem;
  font-weight:800;

  cursor:pointer;

  transition:.25s;
}

.vk-download-main:hover{
  transform:translateY(-2px);
}

/* LOADER */

.vk-loader{
  height:300px;

  display:flex;
  flex-direction:column;
  align-items:center;
  justify-content:center;

  gap:20px;
}

.vk-loader-ring{
  width:58px;
  height:58px;

  border:4px solid #e2e8f0;
  border-top-color:var(--primary);

  border-radius:50%;

  animation:spin .8s linear infinite;
}

.vk-loader span{
  color:var(--text-light);
  font-weight:600;
}

@keyframes spin{
  to{
    transform:rotate(360deg);
  }
}

/* RESPONSIVE */

@media(max-width:1100px){

  .vk-detail-grid{
    grid-template-columns:repeat(2,1fr);
  }

  .vk-before-after{
    grid-template-columns:1fr;
  }
}

@media(max-width:768px){

  .vk-navbar{
    height:auto;

    padding:20px;

    flex-direction:column;

    gap:20px;
  }

  .vk-navbar-right{
    width:100%;

    overflow:auto;
    padding-bottom:4px;
  }

  .vk-main{
    padding:18px;
  }

  .vk-hero{
    padding:28px;
  }

  .vk-hero-content h2{
    font-size:1.7rem;
  }

  .vk-detail-grid{
    grid-template-columns:1fr;
  }

  .vk-pagination{
    flex-direction:column;
    gap:16px;
  }

  .vk-table-wrapper{
    overflow:auto;
  }

  .vk-table{
    min-width:900px;
  }
}

`]
})
export class ViewKaizenComponent implements OnInit {
  allKaizens: any[] = [];
  filteredKaizens: any[] = [];
  pagedKaizens: any[] = [];
  totalKaizens = 0;
  approvedCount = 0;
  pendingCount = 0;
  rejectedCount = 0;
  selectedKaizen: any = null;
  searchTerm = '';
  statusFilter = '';
  sourceFilter = '';
  previewImg = '';
  isLoading   = true;
  isLoggedIn  = !!sessionStorage.getItem('jwt_token');
  currentPage = 1;
  itemsPerPage = 10;
  totalPages = 1;
  Math = Math;


  private get authHeaders() {
    const token = sessionStorage.getItem('jwt_token') || '';
    return { headers: { 'Authorization': `Bearer ${token}` } };
  }
  constructor(private http: HttpClient, private cdr: ChangeDetectorRef) {}

  ngOnInit() { this.loadMyKaizens(); }

  getDashboardRoute(): string {
    const r = (sessionStorage.getItem('role') || '').toLowerCase();
    if (r === 'manager')           return '/manager-dashboard';
    if (r === 'hod')               return '/hod-dashboard';
    if (r === 'business excellence') return '/bex-dashboard';
    return '/dashboard';
  }

  loadMyKaizens() {
    this.isLoading = true;
    // Public view — token नाही, सगळे approved kaizens
    // Login असल्यास token add करतो (optional)
    const token = sessionStorage.getItem('jwt_token') || '';
    const headers = token
      ? new HttpHeaders({ 'Authorization': `Bearer ${token}` })
      : new HttpHeaders();
    this.http.get<any[]>(
      `${environment.apiUrl}/api/kaizen/all`,
      { headers }
    ).subscribe({
      next: (res) => {
        this.allKaizens      = Array.isArray(res) ? res : [];
        this.filteredKaizens = [...this.allKaizens];
        this.currentPage     = 1;
        this.calculateAnalytics();
        this.updatePagination();
        this.isLoading = false;
        this.cdr.detectChanges();
      },
      error: () => { this.isLoading = false; this.cdr.detectChanges(); }
    });
  }

  filterKaizens() {
    const term = this.searchTerm.toLowerCase().trim();
    this.filteredKaizens = this.allKaizens.filter(k => {
      const matchSearch = !term ||
        (k.kaizen_id      || '').toLowerCase().includes(term) ||
        (k.emp_name       || '').toLowerCase().includes(term) ||
        (k.emp_id         || '').toLowerCase().includes(term) ||
        (k.source         || '').toLowerCase().includes(term) ||
        (k.theme          || '').toLowerCase().includes(term) ||
        (k.unit           || '').toLowerCase().includes(term) ||
        (k.section        || '').toLowerCase().includes(term) ||
        (k.status         || '').toLowerCase().includes(term);
      const matchStatus = !this.statusFilter || k.status  === this.statusFilter;
      const matchSource = !this.sourceFilter || k.source  === this.sourceFilter;
      return matchSearch && matchStatus && matchSource;
    });
    this.currentPage = 1;
    this.updatePagination();
  }

  updatePagination() {
    this.totalPages = Math.max(1, Math.ceil(this.filteredKaizens.length / this.itemsPerPage));
    const start     = (this.currentPage - 1) * this.itemsPerPage;
    this.pagedKaizens = this.filteredKaizens.slice(start, start + this.itemsPerPage);
  }

  calculateAnalytics() {
    this.totalKaizens  = this.allKaizens.length;
    this.approvedCount = this.allKaizens.filter(k => k.status?.toLowerCase() === 'approved').length;
    this.pendingCount  = this.allKaizens.filter(k => k.status?.toLowerCase() === 'pending').length;
    this.rejectedCount = this.allKaizens.filter(k => k.status?.toLowerCase() === 'rejected').length;
  }

  nextPage()  { if (this.currentPage < this.totalPages) { this.currentPage++; this.updatePagination(); } }
  prevPage()  { if (this.currentPage > 1)               { this.currentPage--; this.updatePagination(); } }
  openFullDetails(k: any) { this.selectedKaizen = k; }
  previewImage(img: string) { if (img) this.previewImg = img; }

  downloadKaizenPdf(k: any) {
    const source = (k.source || '').toLowerCase();
    if (source === 'operator') this.downloadOperatorPdf(k);
    else                       this.downloadSupervisorManagerPdf(k);
  }

  private loadImg(url: string): Promise<string | null> {
    return new Promise(resolve => {
      if (!url) { resolve(null); return; }
      const img    = new Image();
      img.crossOrigin = 'anonymous';
      img.onload  = () => {
        const c = document.createElement('canvas');
        c.width  = img.naturalWidth;
        c.height = img.naturalHeight;
        c.getContext('2d')!.drawImage(img, 0, 0);
        resolve(c.toDataURL('image/jpeg', 0.85));
      };
      img.onerror = () => resolve(null);
      img.src = url;
    });
  }

  private fmtDate(val: unknown): string {
    if (!val) return '';
    try {
      const d = new Date(String(val));
      if (isNaN(d.getTime())) return String(val);
      return `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${d.getFullYear()}`;
    } catch { return String(val); }
  }

  // ── TEMPLATE 1: Kaizen Idea Sheet — Operator Level ────────────────────────
  private async downloadOperatorPdf(k: any) {
    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

    const setTC = (r: number, g: number, b: number) => doc.setTextColor(r, g, b);
    const setFC = (r: number, g: number, b: number) => doc.setFillColor(r, g, b);
    const setDC = (r: number, g: number, b: number) => doc.setDrawColor(r, g, b);

    const ML = 10, MT = 8, CW = 190, HALF = CW / 2;

    const fsr = (x: number, y: number, w: number, h: number,
                 fr: number, fg: number, fb: number) => {
      setFC(fr, fg, fb); setDC(0, 0, 0);
      doc.setLineWidth(0.4);
      doc.rect(x, y, w, h, 'FD');
    };

    const sr = (x: number, y: number, w: number, h: number) => {
      setFC(255, 255, 255); setDC(0, 0, 0);
      doc.setLineWidth(0.4);
      doc.rect(x, y, w, h, 'FD');
    };

    const txt = (
      s: string, x: number, y: number, size: number, style: string,
      tr: number, tg: number, tb: number,
      align: 'left' | 'center' | 'right' = 'left', maxW?: number
    ) => {
      doc.setFontSize(size);
      doc.setFont('helvetica', style);
      setTC(tr, tg, tb);
      const opts: { align: 'left'|'center'|'right'; maxWidth?: number } = { align };
      if (maxW !== undefined) opts.maxWidth = maxW;
      doc.text(String(s ?? ''), x, y, opts);
    };

    const [beforeData, afterData, logoData] = await Promise.all([
      this.loadImg(k.before_img),
      this.loadImg(k.after_img),
      this.loadImg('assets/shaktiman_logo.png')
    ]);

    let y = MT;

    // ROW 1: Company header
    const hdrH = 14;
    fsr(ML, y, CW, hdrH, 208, 228, 240);
    txt('TIRTH AGRO TECHNOLOGY PVT LTD', ML + CW / 2, y + 6,  12, 'bold',   0, 0, 0, 'center');
    txt('(SHAKTIMAN)',                   ML + CW / 2, y + 11,  9, 'normal', 0, 0, 0, 'center');
    if (logoData) {
      const lh = 12, lw = 20;
      doc.addImage(logoData, 'JPEG', ML + CW - lw - 2, y + 1, lw, lh);
    }
    y += hdrH;

    // ROW 2: Sheet title
    sr(ML, y, CW, 8);
    txt('Kaizen Idea Sheet-Opertor Level', ML + CW / 2, y + 5.5, 10, 'bold', 0, 0, 0, 'center');
    y += 8;

    // ROW 3: Doc code
    sr(ML,        y, HALF, 6);
    txt('Document Code : TA/QMS/KIS-OL', ML + 2,        y + 4, 7, 'normal', 0, 0, 0);
    sr(ML + HALF, y, HALF, 6);
    txt('Rev. 00/01.06.2018',             ML + HALF + 2, y + 4, 7, 'normal', 0, 0, 0);
    y += 6;

    // ROW 4: Theme
    sr(ML, y, CW, 8);
    txt('Theme :-', ML + 2,  y + 5, 7, 'bold',   0, 0, 0);
    txt(k.theme || '', ML + 22, y + 5, 7, 'normal', 0, 0, 0, 'left', CW - 26);
    y += 8;

    // ROW 5: Department  ← uses k.depo (now returned by backend)
    sr(ML, y, CW, 8);
    txt('Department :-', ML + 2,  y + 5, 7, 'bold',   0, 0, 0);
    txt(k.depo || k.unit || '', ML + 30, y + 5, 7, 'normal', 0, 0, 0, 'left', CW - 34);
    y += 8;

    // ROW 6: Section | Machine No
    sr(ML,        y, HALF, 8);
    txt('Section :-',    ML + 2,        y + 5, 7, 'bold',   0, 0, 0);
    txt(k.section || '', ML + 22,       y + 5, 7, 'normal', 0, 0, 0, 'left', HALF - 26);
    sr(ML + HALF, y, HALF, 8);
    txt('Machine No. :-',    ML + HALF + 2,  y + 5, 7, 'bold',   0, 0, 0);
    txt(k.machine_no || '',  ML + HALF + 30, y + 5, 7, 'normal', 0, 0, 0, 'left', HALF - 34);
    y += 8;

    // ROW 7: Kaizen Sr No
    sr(ML, y, CW, 8);
    txt('Kaizen Sr No :-', ML + 2,  y + 5, 7, 'bold',   0, 0, 0);
    txt(k.kaizen_id || '', ML + 32, y + 5, 7, 'normal', 0, 0, 0);
    y += 8;

    // ROW 8: Start Date | End Date  ← FIXED: k.start_date / k.end_date
    sr(ML,        y, HALF, 8);
    txt('Kaizen Start Date :-', ML + 2,  y + 5, 7, 'bold',   0, 0, 0);
    txt(this.fmtDate(k.start_date || k.created_at), ML + 40, y + 5, 7, 'normal', 0, 0, 0);
    sr(ML + HALF, y, HALF, 8);
    txt('Kaizen End Date :-', ML + HALF + 2,  y + 5, 7, 'bold',   0, 0, 0);
    txt(this.fmtDate(k.end_date),             ML + HALF + 37, y + 5, 7, 'normal', 0, 0, 0);
    y += 8;

    // ROW 9a: Before/After headers
    sr(ML,        y, HALF, 7);
    txt('Before: (Illustration with sketch & Date)', ML + HALF / 2,         y + 4.5, 7, 'bold', 0, 0, 0, 'center');
    sr(ML + HALF, y, HALF, 7);
    txt('After: (Illustration with sketch & Date)',  ML + HALF + HALF / 2,  y + 4.5, 7, 'bold', 0, 0, 0, 'center');
    y += 7;

    // ROW 9b: Images
    const imgH = 60;
    sr(ML,        y, HALF, imgH);
    sr(ML + HALF, y, HALF, imgH);
    if (beforeData) {
      doc.addImage(beforeData, 'JPEG', ML + 1,        y + 1, HALF - 2, imgH - 2);
    } else {
      txt('No Image Available', ML + HALF / 2,        y + imgH / 2, 7, 'italic', 160, 160, 160, 'center');
    }
    if (afterData) {
      doc.addImage(afterData,  'JPEG', ML + HALF + 1, y + 1, HALF - 2, imgH - 2);
    } else {
      txt('No Image Available', ML + HALF + HALF / 2, y + imgH / 2, 7, 'italic', 160, 160, 160, 'center');
    }
    y += imgH;

    // ROW 9c: Date placeholders
    sr(ML,        y, HALF, 8);
    txt('Date :-', ML + 2,        y + 5, 7, 'bold', 0, 0, 0);
    sr(ML + HALF, y, HALF, 8);
    txt('Date :-', ML + HALF + 2, y + 5, 7, 'bold', 0, 0, 0);
    y += 8;

    // ROW 10: Before/After Condition
    sr(ML,        y, HALF, 20);
    txt('Before Condition :-', ML + 2,        y + 5, 7, 'bold', 0, 0, 0);
    doc.setFontSize(7); doc.setFont('helvetica', 'normal'); setTC(0, 0, 0);
    doc.text(doc.splitTextToSize(k.before_desc || '', HALF - 4), ML + 2,        y + 10, { maxWidth: HALF - 4 });
    sr(ML + HALF, y, HALF, 20);
    txt('After Condition :-',  ML + HALF + 2, y + 5, 7, 'bold', 0, 0, 0);
    doc.setFontSize(7); doc.setFont('helvetica', 'normal'); setTC(0, 0, 0);
    doc.text(doc.splitTextToSize(k.after_desc  || '', HALF - 4), ML + HALF + 2, y + 10, { maxWidth: HALF - 4 });
    y += 20;

    // ROW 11: Team Members | Reviewed By
    const TW = CW * 0.55, RW = CW - TW;
    sr(ML, y, TW, 22);
    txt('Team Members :-', ML + 2, y + 5, 7, 'bold', 0, 0, 0);
    // ← FIXED: use k.team_members (now returned by backend); fallback to emp_name
    const teamVal = k.team_members || k.team || k.emp_name || '';
    doc.setFontSize(7); doc.setFont('helvetica', 'normal'); setTC(0, 0, 0);
    doc.text(doc.splitTextToSize(teamVal, TW - 4), ML + 2, y + 10, { maxWidth: TW - 4 });

    sr(ML + TW, y, RW, 22);
    txt('Kaizen Reviewed by: (KK Team)', ML + TW + 2, y + 5,  7,   'bold',   0, 0, 0);
    txt('Sign : _______________________', ML + TW + 2, y + 11, 7,   'normal', 0, 0, 0);
    txt('Date : _______________________', ML + TW + 2, y + 17, 7,   'normal', 0, 0, 0);
    y += 22;

    // Outer border
    setDC(0, 0, 0); doc.setLineWidth(0.8);
    doc.rect(ML, MT, CW, y - MT, 'S');

    doc.save(`Kaizen_${k.kaizen_id || 'download'}_Operator.pdf`);
  }

  // ── TEMPLATE 2: Kaizen Idea Sheet — Senior Level ──────────────────────────
  private async downloadSupervisorManagerPdf(k: any) {
    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

    const setTC = (r: number, g: number, b: number) => doc.setTextColor(r, g, b);
    const setFC = (r: number, g: number, b: number) => doc.setFillColor(r, g, b);
    const setDC = (r: number, g: number, b: number) => doc.setDrawColor(r, g, b);

    const ML = 8, MT = 6, CW = 194, HALF = CW / 2;

    const fsr = (x: number, y: number, w: number, h: number,
                 fr: number, fg: number, fb: number) => {
      setFC(fr, fg, fb); setDC(0, 0, 0);
      doc.setLineWidth(0.35);
      doc.rect(x, y, w, h, 'FD');
    };

    const sr = (x: number, y: number, w: number, h: number) => {
      setFC(255, 255, 255); setDC(0, 0, 0);
      doc.setLineWidth(0.35);
      doc.rect(x, y, w, h, 'FD');
    };

    const txt = (
      s: string, x: number, y: number, size: number, style: string,
      tr: number, tg: number, tb: number,
      align: 'left' | 'center' | 'right' = 'left', maxW?: number
    ) => {
      doc.setFontSize(size); doc.setFont('helvetica', style); setTC(tr, tg, tb);
      const opts: { align: 'left'|'center'|'right'; maxWidth?: number } = { align };
      if (maxW !== undefined) opts.maxWidth = maxW;
      doc.text(String(s ?? ''), x, y, opts);
    };

    const source     = (k.source || '').toLowerCase();
    const levelLabel = source === 'supervisor' ? 'Supervisor' : 'Manager';

    const [beforeData, afterData, logoData] = await Promise.all([
      this.loadImg(k.before_img),
      this.loadImg(k.after_img),
      this.loadImg('assets/shaktiman_logo.png')
    ]);

    let y = MT;

    // ROW 1: Company header
    fsr(ML, y, CW, 14, 208, 228, 240);
    txt('TIRTH AGRO TECHNOLOGY PVT LTD', ML + CW / 2, y + 6,  12, 'bold',   0, 0, 0, 'center');
    txt('(SHAKTIMAN)',                   ML + CW / 2, y + 11,  9, 'normal', 0, 0, 0, 'center');
    if (logoData) {
      const lh = 12, lw = 20;
      doc.addImage(logoData, 'JPEG', ML + CW - lw - 2, y + 1, lw, lh);
    }
    y += 14;

    // ROW 2: Sheet title
    sr(ML, y, CW, 8);
    txt('Kaizen Idea Sheet-Senior Level', ML + CW / 2, y + 5.5, 10, 'bold', 0, 0, 0, 'center');
    y += 8;

    // ROW 3: Doc code
    sr(ML,        y, HALF, 6);
    txt('Document Code : TA/QMS/KIS-SL', ML + 2,        y + 4, 7, 'normal', 0, 0, 0);
    sr(ML + HALF, y, HALF, 6);
    txt('Rev. 00/01.06.2018',             ML + HALF + 2, y + 4, 7, 'normal', 0, 0, 0);
    y += 6;

    // ROW 4: Activity header
    const actLabW = 28;
    const actCols = ['KK', 'JH', 'QM', 'PM', 'SHE', 'OTPM', 'DM', 'ET', '5S'];
    const actCW   = (CW - actLabW) / actCols.length;
    sr(ML, y, actLabW, 6);
    txt('Activity', ML + actLabW / 2, y + 4, 7, 'bold', 0, 0, 0, 'center');
    actCols.forEach((col, i) => {
      const cx = ML + actLabW + i * actCW;
      sr(cx, y, actCW, 6);
      txt(col, cx + actCW / 2, y + 4, 7, 'bold', 0, 0, 0, 'center');
    });
    y += 6;

    // ROW 5: Loss No./Step
    sr(ML, y, actLabW, 6);
    txt('Loss No./ Step', ML + actLabW / 2, y + 4, 6.5, 'bold', 0, 0, 0, 'center');
    actCols.forEach((_, i) => { sr(ML + actLabW + i * actCW, y, actCW, 6); });
    y += 6;

    // ROW 6: Result Area — highlight matched PQCDSM cells green  ← FIXED
    const raVals  = ['P', 'Q', 'C', 'D', 'S', 'M', '', '', ''];
    const pqcdsm  = (k.pqcdsm || '').toUpperCase();
    sr(ML, y, actLabW, 6);
    txt('Result Area', ML + actLabW / 2, y + 4, 6.5, 'bold', 0, 0, 0, 'center');
    raVals.forEach((val, i) => {
      const cx      = ML + actLabW + i * actCW;
      const matched = val !== '' && pqcdsm.includes(val);
      if (matched) {
        fsr(cx, y, actCW, 6, 144, 238, 144);  // light green fill
      } else {
        sr(cx, y, actCW, 6);
      }
      if (val) txt(val, cx + actCW / 2, y + 4, 7, 'bold', 0, 0, 0, 'center');
    });
    y += 6;

    // ROW 7: Plant | Machine | Kaizen Sr No
    const C3 = CW / 3;
    sr(ML,          y, C3, 8);
    txt('Plant :',          ML + 2,           y + 5, 7, 'bold',   0, 0, 0);
    txt(k.unit || '',       ML + 17,          y + 5, 7, 'normal', 0, 0, 0, 'left', C3 - 20);
    sr(ML + C3,     y, C3, 8);
    txt('Machine :',        ML + C3 + 2,      y + 5, 7, 'bold',   0, 0, 0);
    txt(k.machine_no || '', ML + C3 + 20,     y + 5, 7, 'normal', 0, 0, 0, 'left', C3 - 23);
    sr(ML + C3 * 2, y, C3, 8);
    txt('Kaizen Sr. No. :', ML + C3 * 2 + 2,  y + 5, 7, 'bold',   0, 0, 0);
    txt(k.kaizen_id || '',  ML + C3 * 2 + 30, y + 5, 7, 'normal', 0, 0, 0, 'left', C3 - 33);
    y += 8;

    // ROW 8: Kaizen Theme
    const lblW = CW * 0.30, valW = CW - lblW;
    sr(ML,        y, lblW, 8);
    txt('Kaizen theme :', ML + 2,        y + 5, 7, 'bold',   0, 0, 0);
    sr(ML + lblW, y, valW, 8);
    txt(k.theme || '',   ML + lblW + 2,  y + 5, 7, 'normal', 0, 0, 0, 'left', valW - 4);
    y += 8;

    // THREE-COLUMN BODY
    const LCW = Math.round(CW * 0.28);
    const MCW = Math.round(CW * 0.40);
    const RCW = CW - LCW - MCW;
    const LCX = ML;
    const MCX = ML + LCW;
    const RCX = ML + LCW + MCW;

    let lY = y, mY = y, rY = y;

    // ── LEFT COLUMN ──────────────────────────────────────────────────────────

    sr(LCX, lY, LCW, 6);
    txt('Problem/present status : Description', LCX + 2, lY + 4, 6.5, 'bold', 0, 0, 0, 'left', LCW - 4);
    lY += 6;

    sr(LCX, lY, LCW, 20);
    doc.setFontSize(7); doc.setFont('helvetica', 'normal'); setTC(0, 0, 0);
    // ← FIXED: k.analysis (now returned by backend)
    doc.text(doc.splitTextToSize(k.analysis || '', LCW - 4), LCX + 2, lY + 4, { maxWidth: LCW - 4 });
    lY += 20;

    sr(LCX, lY, LCW, 6);
    txt('Present status sketch/photo', LCX + LCW / 2, lY + 4, 6.5, 'bold', 0, 0, 0, 'center');
    lY += 6;

    sr(LCX, lY, LCW, 25);
    lY += 25;

    sr(LCX, lY, LCW, 6);
    txt('Why - why analysis : / Problem Phenomenon :', LCX + 2, lY + 4, 6.5, 'bold', 0, 0, 0, 'left', LCW - 4);
    lY += 6;

    // ← FIXED: k.why1 … k.why4 (now returned by backend)
    const whys: [string, string][] = [
      ['Why 1 :', String(k.why1 || '')],
      ['Why 2 :', String(k.why2 || '')],
      ['Why 3 :', String(k.why3 || '')],
      ['Why 4 :', String(k.why4 || '')]
    ];
    whys.forEach(([label, val]) => {
      sr(LCX, lY, LCW, 7);
      txt(label, LCX + 2,  lY + 4.5, 7, 'bold',   0, 0, 0);
      txt(val,   LCX + 16, lY + 4.5, 7, 'normal', 0, 0, 0, 'left', LCW - 20);
      lY += 7;
    });

    sr(LCX, lY, LCW, 10);
    txt('Root Cause :', LCX + 2, lY + 4, 7, 'bold', 0, 0, 0);
    doc.setFontSize(7); doc.setFont('helvetica', 'normal'); setTC(0, 0, 0);
    // ← FIXED: k.root_cause (now returned by backend)
    doc.text(doc.splitTextToSize(k.root_cause || '', LCW - 4), LCX + 2, lY + 8, { maxWidth: LCW - 4 });
    lY += 10;

    // ── MIDDLE COLUMN ────────────────────────────────────────────────────────

    sr(MCX, mY, MCW, 6);
    txt('Countermeasure(Engineering solution):', MCX + 2, mY + 4, 6.5, 'bold', 0, 0, 0, 'left', MCW - 4);
    mY += 6;

    sr(MCX, mY, MCW, 18);
    doc.setFontSize(7); doc.setFont('helvetica', 'normal'); setTC(0, 0, 0);
    // ← FIXED: k.countermeasure (now returned by backend)
    doc.text(doc.splitTextToSize(k.countermeasure || '', MCW - 4), MCX + 2, mY + 4, { maxWidth: MCW - 4 });
    mY += 18;

    const MH = MCW / 2;
    sr(MCX,      mY, MH, 6);
    txt('Before :', MCX + MH / 2,         mY + 4, 7, 'bold', 0, 0, 0, 'center');
    sr(MCX + MH, mY, MH, 6);
    txt('After :',  MCX + MH + MH / 2,    mY + 4, 7, 'bold', 0, 0, 0, 'center');
    mY += 6;

    const imgRowH2 = 42;
    sr(MCX,      mY, MH, imgRowH2);
    sr(MCX + MH, mY, MH, imgRowH2);
    if (beforeData) {
      doc.addImage(beforeData, 'JPEG', MCX + 1,      mY + 1, MH - 2, imgRowH2 - 2);
    } else {
      txt('No Image Available', MCX + MH / 2,        mY + imgRowH2 / 2, 6.5, 'italic', 160, 160, 160, 'center');
    }
    if (afterData) {
      doc.addImage(afterData,  'JPEG', MCX + MH + 1, mY + 1, MH - 2, imgRowH2 - 2);
    } else {
      txt('No Image Available', MCX + MH + MH / 2,   mY + imgRowH2 / 2, 6.5, 'italic', 160, 160, 160, 'center');
    }
    mY += imgRowH2;

    sr(MCX,      mY, MH, 12);
    txt('Brief Description :', MCX + 2,      mY + 4, 6.5, 'bold', 0, 0, 0);
    doc.setFontSize(6.5); doc.setFont('helvetica', 'normal'); setTC(0, 0, 0);
    doc.text(doc.splitTextToSize(k.before_desc || '', MH - 4), MCX + 2,      mY + 8, { maxWidth: MH - 4 });
    sr(MCX + MH, mY, MH, 12);
    txt('Brief Description :', MCX + MH + 2, mY + 4, 6.5, 'bold', 0, 0, 0);
    doc.setFontSize(6.5); doc.setFont('helvetica', 'normal'); setTC(0, 0, 0);
    doc.text(doc.splitTextToSize(k.after_desc  || '', MH - 4), MCX + MH + 2, mY + 8, { maxWidth: MH - 4 });
    mY += 12;

    sr(MCX, mY, MCW, 6);
    txt('Results :', MCX + 2, mY + 4, 7, 'bold', 0, 0, 0);
    mY += 6;

    sr(MCX, mY, MCW, 14);
    doc.setFontSize(7); doc.setFont('helvetica', 'normal'); setTC(0, 0, 0);
    // ← FIXED: k.benefits_pqcdsm (now returned by backend)
    doc.text(doc.splitTextToSize(k.benefits_pqcdsm || '', MCW - 4), MCX + 2, mY + 4, { maxWidth: MCW - 4 });
    mY += 14;

    sr(MCX, mY, MCW, 6);
    txt('Illustration with line chart/ graph :', MCX + 2, mY + 4, 6.5, 'bold', 0, 0, 0);
    mY += 6;

    sr(MCX, mY, MCW, 18);
    mY += 18;

    sr(MCX, mY, MCW, 7);
    txt('Note: Use separate sheet for better understanding, if needed', MCX + 2, mY + 4.5, 6.5, 'italic', 80, 80, 80);
    mY += 7;

    // ── RIGHT COLUMN ─────────────────────────────────────────────────────────
    const RLW = RCW * 0.45;
    const RVW = RCW - RLW;

    // ← FIXED: k.start_date / k.end_date (correct field names)
    const rLvRows: [string, string][] = [
      ['Bench mark',    k.benchmark  || ''],
      ['Target',        k.target     || ''],
      ['Kaizen start',  this.fmtDate(k.start_date || k.created_at)],
      ['Kaizen Finish', this.fmtDate(k.end_date)]
    ];
    rLvRows.forEach(([label, val]) => {
      sr(RCX,        rY, RLW, 7);
      txt(label, RCX + 2,        rY + 4.5, 7, 'bold',   0, 0, 0, 'left', RLW - 4);
      sr(RCX + RLW,  rY, RVW, 7);
      txt(val,   RCX + RLW + 2,  rY + 4.5, 7, 'normal', 0, 0, 0, 'left', RVW - 4);
      rY += 7;
    });

    sr(RCX, rY, RCW, 6);
    txt('Team members :', RCX + 2, rY + 4, 7, 'bold', 0, 0, 0);
    rY += 6;

    sr(RCX, rY, RCW, 22);
    // ← FIXED: k.team_members (now returned by backend)
    const tmVal = k.team_members || k.team || k.emp_name || '';
    doc.setFontSize(7); doc.setFont('helvetica', 'normal'); setTC(0, 0, 0);
    doc.text(doc.splitTextToSize(tmVal, RCW - 4), RCX + 2, rY + 4, { maxWidth: RCW - 4 });
    rY += 22;

    sr(RCX, rY, RCW, 6);
    txt('Benefits: (P,Q,C,D,S,M)', RCX + 2, rY + 4, 7, 'bold', 0, 0, 0);
    rY += 6;

    sr(RCX, rY, RCW, 12);
    doc.setFontSize(7); doc.setFont('helvetica', 'normal'); setTC(0, 0, 0);
    doc.text(doc.splitTextToSize(k.benefits_pqcdsm || '', RCW - 4), RCX + 2, rY + 4, { maxWidth: RCW - 4 });
    rY += 12;

    sr(RCX, rY, RCW, 6);
    txt('Scope & plan for Horizontal Deployment', RCX + 2, rY + 4, 6.5, 'bold', 0, 0, 0, 'left', RCW - 4);
    rY += 6;

    const hdCols: [string, number][] = [
      ['Sr.no.', 0.10], ['M/c.', 0.18], ['Target date', 0.22], ['Responsibility', 0.28], ['Status', 0.22]
    ];
    let hx = RCX;
    hdCols.forEach(([label, ratio]) => {
      const cw = RCW * ratio;
      fsr(hx, rY, cw, 5, 230, 230, 230);
      txt(label, hx + cw / 2, rY + 3.5, 6, 'bold', 0, 0, 0, 'center');
      hx += cw;
    });
    rY += 5;

    for (let ri = 0; ri < 5; ri++) {
      hx = RCX;
      hdCols.forEach(([, ratio]) => {
        const cw = RCW * ratio;
        sr(hx, rY, cw, 5);
        hx += cw;
      });
      rY += 5;
    }

    sr(RCX, rY, RCW, 10);
    txt('Reviewed By :',                     RCX + 2, rY + 4,   7,   'bold',   0, 0, 0);
    txt('Sign : __________ Date : __________', RCX + 2, rY + 8.5, 6.5, 'normal', 0, 0, 0);
    rY += 10;

    // Sync columns
    const endY = Math.max(lY, mY, rY);
    if (lY < endY) { sr(LCX, lY, LCW, endY - lY); }
    if (mY < endY) { sr(MCX, mY, MCW, endY - mY); }
    if (rY < endY) { sr(RCX, rY, RCW, endY - rY); }

    // Outer border
    setDC(0, 0, 0); doc.setLineWidth(0.8);
    doc.rect(ML, MT, CW, endY - MT, 'S');

    doc.save(`Kaizen_${k.kaizen_id || 'download'}_${levelLabel}.pdf`);
  }
}