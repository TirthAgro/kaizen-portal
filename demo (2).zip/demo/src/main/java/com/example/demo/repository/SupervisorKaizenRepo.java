package com.example.demo.repository;

import com.example.demo.model.SupervisorKaizen;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface SupervisorKaizenRepo extends JpaRepository<SupervisorKaizen, Long> {

    List<SupervisorKaizen> findByUnit(String unit);
    List<SupervisorKaizen> findByUnitAndSection(String unit, String section);
    List<SupervisorKaizen> findByUnitAndSectionAndStatus(String unit, String section, String status);

    long countByUnit(String unit);

    @Query("SELECT COUNT(s) FROM SupervisorKaizen s WHERE s.unit=:unit AND s.section=:section AND s.status='Pending'")
    long countPendingByUnitAndSection(@Param("unit") String unit, @Param("section") String section);

    @Query("SELECT COUNT(s) FROM SupervisorKaizen s WHERE s.unit=:unit AND s.section=:section AND s.status='Approved'")
    long countApprovedByUnitAndSection(@Param("unit") String unit, @Param("section") String section);

    @Query("SELECT COUNT(s) FROM SupervisorKaizen s WHERE s.unit=:unit AND s.section=:section")
    long countByUnitAndSection(@Param("unit") String unit, @Param("section") String section);

    SupervisorKaizen findByKaizenId(String kaizenId);
}