package com.example.demo.controller;

import com.example.demo.model.SupervisorKaizen;
import com.example.demo.repository.SupervisorKaizenRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;

@RestController
@RequestMapping("/api/supervisor")
public class SupervisorController {

    @Autowired private SupervisorKaizenRepo supervisorRepo;

    @Value("${app.upload.dir}")
    private String uploadDir;

    @GetMapping
    public ResponseEntity<?> getCount(
            @RequestParam(required = false, defaultValue = "Supervisor") String level) {
        long count = supervisorRepo.count();
        return ResponseEntity.ok(count);
    }

    @PostMapping("/save")
    public ResponseEntity<?> saveSupervisor(
            @RequestParam(required = false) String kaizen_id,
            @RequestParam(required = false) String emp_id,
            @RequestParam(required = false) String emp_name,
            @RequestParam(required = false) String unit,
            @RequestParam(required = false) String department,   // ← NEW
            @RequestParam(required = false) String section,
            @RequestParam(required = false) String machine_no,
            @RequestParam(required = false) String kaizen_type,
            @RequestParam(required = false) String pqcdsm,
            @RequestParam(required = false) String kaizen_category,
            @RequestParam(required = false) String theme,
            @RequestParam(required = false) String problem_status,
            @RequestParam(required = false) String idea,
            @RequestParam(required = false) String countermeasure,
            @RequestParam(required = false) String why1,
            @RequestParam(required = false) String why2,
            @RequestParam(required = false) String why3,
            @RequestParam(required = false) String why4,
            @RequestParam(required = false) String why5,
            @RequestParam(required = false) String root_cause,
            @RequestParam(required = false) String final_result,
            @RequestParam(required = false) String analysis,
            @RequestParam(required = false) String start_date,
            @RequestParam(required = false) String end_date,
            @RequestParam(required = false) String before_desc,
            @RequestParam(required = false) String after_desc,
            @RequestParam(required = false) String benefits,
            @RequestParam(required = false) String team,
            @RequestParam(required = false) String deployment_data,
            @RequestParam(required = false) MultipartFile before_img_file,
            @RequestParam(required = false) MultipartFile after_img_file,
            @RequestParam(required = false) MultipartFile problem_img_file,
            @RequestParam(required = false) MultipartFile result_img_file) {

        SupervisorKaizen k = new SupervisorKaizen();
        k.setKaizenId(kaizen_id);
        k.setEmpId(emp_id);
        k.setEmpName(emp_name);
        k.setUnit(unit);
        k.setDepo(department);   // ← NEW
        k.setSection(section);
        k.setMachineNo(machine_no);
        k.setKaizenType(kaizen_type);
        k.setPqcdsm(pqcdsm);
        k.setKaizenCategory(kaizen_category);
        k.setTheme(theme);
        k.setProblemStatus(problem_status);
        k.setIdea(idea);
        k.setCountermeasure(countermeasure);
        k.setWhy1(why1);
        k.setWhy2(why2);
        k.setWhy3(why3);
        k.setWhy4(why4);
        k.setWhy5(why5);
        k.setRootCause(root_cause);
        k.setFinalResult(final_result);
        k.setAnalysis(analysis);
        k.setStartDate(start_date);
        k.setEndDate(end_date);
        k.setBeforeDesc(before_desc);
        k.setAfterDesc(after_desc);
        k.setBenefitsPqcdsm(benefits);
        k.setTeamMembers(team);
        k.setDeployments(deployment_data);
        k.setStatus("Pending");

        try {
            File uploadFolder = new File(uploadDir);
            if (!uploadFolder.exists()) uploadFolder.mkdirs();

            if (before_img_file != null && !before_img_file.isEmpty()) {
                String fileName = System.currentTimeMillis() + "_B_" + before_img_file.getOriginalFilename();
                Files.write(Paths.get(uploadDir + fileName), before_img_file.getBytes());
                k.setBeforeImg(fileName.getBytes());
            }
            if (after_img_file != null && !after_img_file.isEmpty()) {
                String fileName = System.currentTimeMillis() + "_A_" + after_img_file.getOriginalFilename();
                Files.write(Paths.get(uploadDir + fileName), after_img_file.getBytes());
                k.setAfterImg(fileName.getBytes());
            }
            if (problem_img_file != null && !problem_img_file.isEmpty()) {
                String fileName = System.currentTimeMillis() + "_P_" + problem_img_file.getOriginalFilename();
                Files.write(Paths.get(uploadDir + fileName), problem_img_file.getBytes());
                k.setAnalysis((analysis != null ? analysis : "") + " [prob_img:" + fileName + "]");
            }
            if (result_img_file != null && !result_img_file.isEmpty()) {
                String fileName = System.currentTimeMillis() + "_R_" + result_img_file.getOriginalFilename();
                Files.write(Paths.get(uploadDir + fileName), result_img_file.getBytes());
                k.setFinalResult((final_result != null ? final_result : "") + " [res_img:" + fileName + "]");
            }
        } catch (IOException e) {
            return ResponseEntity.internalServerError()
                .body(Map.of("error", "Image upload failed: " + e.getMessage()));
        }

        supervisorRepo.save(k);
        return ResponseEntity.ok(Map.of("status", "success"));
    }
}