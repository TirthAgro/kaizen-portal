package com.example.demo.controller;

import com.example.demo.model.KaizenItem;
import com.example.demo.model.ManagerKaizen;
import com.example.demo.model.SupervisorKaizen;
import com.example.demo.model.OperatorKaizen;
import com.example.demo.repository.ManagerKaizenRepo;
import com.example.demo.repository.SupervisorKaizenRepo;
import com.example.demo.repository.OperatorKaizenRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/kaizen")
public class KaizenController {

    @Autowired private ManagerKaizenRepo    managerRepo;
    @Autowired private SupervisorKaizenRepo supervisorRepo;
    @Autowired private OperatorKaizenRepo   operatorRepo;

    // ── helper: get depo from any KaizenItem subtype ──────────────────────
    private String getDepo(KaizenItem k) {
        if (k instanceof ManagerKaizen)    return ((ManagerKaizen)    k).getDepo();
        if (k instanceof SupervisorKaizen) return ((SupervisorKaizen) k).getDepo();
        if (k instanceof OperatorKaizen)   return ((OperatorKaizen)   k).getDepo();
        return null;
    }

    @GetMapping
    public ResponseEntity<?> getData(@RequestParam("plant_id") String plantId) {

        long pending = managerRepo.countByUnitAndHodStatusIsNull(plantId)
                     + managerRepo.countByUnitAndHodStatus(plantId, "Pending");

        Map<String, Object> counts = new HashMap<>();
        counts.put("op",      operatorRepo.countByUnit(plantId));
        counts.put("sup",     supervisorRepo.countByUnit(plantId));
        counts.put("man",     managerRepo.countByUnit(plantId));
        counts.put("pending", pending);

        List<Map<String, Object>> list = new ArrayList<>();
        managerRepo.findByUnit(plantId).forEach(k    -> list.add(toMapNoImage(k, "Manager")));
        supervisorRepo.findByUnit(plantId).forEach(k -> list.add(toMapNoImage(k, "Supervisor")));
        operatorRepo.findByUnit(plantId).forEach(k   -> list.add(toMapNoImage(k, "Operator")));

        Map<String, Integer> impact = calcImpact(plantId);

        Map<String, Object> response = new HashMap<>();
        response.put("counts", counts);
        response.put("list",   list);
        response.put("impact", impact);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/detail")
    public ResponseEntity<?> getDetail(
            @RequestParam("id") Long id,
            @RequestParam("role") String role) {

        KaizenItem item = null;
        if (role.equals("Manager"))         item = managerRepo.findById(id).orElse(null);
        else if (role.equals("Supervisor")) item = supervisorRepo.findById(id).orElse(null);
        else                                item = operatorRepo.findById(id).orElse(null);

        if (item == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(toMap(item, role));
    }

    @GetMapping("/my-kaizens")
    public ResponseEntity<?> getMyKaizens(
            @RequestParam(required = false) String emp_id,
            @RequestParam(required = false) String role) {

        List<Map<String, Object>> list = new ArrayList<>();

        managerRepo.findAll().forEach(k    -> list.add(toViewMap(k, "manager")));
        supervisorRepo.findAll().forEach(k -> list.add(toViewMap(k, "supervisor")));
        operatorRepo.findAll().forEach(k   -> list.add(toViewMap(k, "operator")));

        list.sort((a, b) -> {
            String ca = a.get("created_at") != null ? a.get("created_at").toString() : "";
            String cb = b.get("created_at") != null ? b.get("created_at").toString() : "";
            return cb.compareTo(ca);
        });

        return ResponseEntity.ok(list);
    }

    // ── FIXED: toViewMap now returns ALL fields needed by the PDF ─────────
    private Map<String, Object> toViewMap(KaizenItem k, String source) {
        Map<String, Object> m = new HashMap<>();
        // identity
        m.put("id",              k.getId());
        m.put("kaizen_id",       k.getKaizenId());
        m.put("emp_id",          k.getEmpId());
        m.put("emp_name",        k.getEmpName());
        m.put("source",          source);
        // basic info
        m.put("unit",            k.getUnit());
        m.put("depo",            getDepo(k));                          // ← FIX
        m.put("section",         k.getSection());
        m.put("machine_no",      k.getMachineNo());                    // ← FIX
        m.put("kaizen_type",     k.getKaizenType());                   // ← FIX
        m.put("kaizen_category", k.getKaizenCategory());
        m.put("theme",           k.getTheme());
        m.put("pqcdsm",          k.getPqcdsm());                       // ← FIX
        m.put("status",          k.getStatus());
        m.put("hod_remarks",     k.getHodRemarks());
        m.put("manager_remarks", k.getManagerRemarks());               // ← FIX
        // dates
        m.put("start_date",      k.getStartDate());                    // ← FIX
        m.put("end_date",        k.getEndDate());                      // ← FIX
        m.put("created_at",      k.getCreatedAt() != null ? k.getCreatedAt().toString() : null);
        // descriptions
        m.put("before_desc",     k.getBeforeDesc());                   // ← FIX
        m.put("after_desc",      k.getAfterDesc());                    // ← FIX
        // analysis / why-why
        m.put("analysis",        k.getAnalysis());                     // ← FIX
        m.put("why1",            k.getWhy1());                         // ← FIX
        m.put("why2",            k.getWhy2());                         // ← FIX
        m.put("why3",            k.getWhy3());                         // ← FIX
        m.put("why4",            k.getWhy4());                         // ← FIX
        m.put("why5",            k.getWhy5());                         // ← FIX
        m.put("root_cause",      k.getRootCause());                    // ← FIX
        m.put("problem_status",  k.getProblemStatus());                // ← FIX
        // countermeasure / solution
        m.put("idea",            k.getIdea());                         // ← FIX
        m.put("countermeasure",  k.getCountermeasure());               // ← FIX
        m.put("benchmark",       k.getBenchmark());                    // ← FIX
        m.put("target",          k.getTarget());                       // ← FIX
        m.put("final_result",    k.getFinalResult());                  // ← FIX
        // benefits / team
        m.put("benefits_pqcdsm", k.getBenefitsPqcdsm());              // ← FIX
        m.put("team_members",    k.getTeamMembers());                  // ← FIX
        m.put("deployments",     k.getDeployments());                  // ← FIX
        m.put("pillar",          k.getPillar());                       // ← FIX

        // images — full URL
        if (k.getBeforeImg() != null) {
            String imgStr = new String(k.getBeforeImg(),
                java.nio.charset.StandardCharsets.UTF_8).trim();
            m.put("before_img", "http://localhost/kaizen-backend/uploads/" + imgStr);
        } else { m.put("before_img", null); }

        if (k.getAfterImg() != null) {
            String imgStr = new String(k.getAfterImg(),
                java.nio.charset.StandardCharsets.UTF_8).trim();
            m.put("after_img", "http://localhost/kaizen-backend/uploads/" + imgStr);
        } else { m.put("after_img", null); }

        return m;
    }

    @PostMapping("/update")
    public ResponseEntity<?> update(@RequestBody Map<String, Object> body) {

        Long   id       = Long.valueOf(body.get("id").toString());
        String action   = body.get("action").toString();
        String remarks  = body.get("hod_remarks").toString();
        String roleType = body.get("role_type").toString().toLowerCase();

        if (roleType.equals("manager")) {
            managerRepo.findById(id).ifPresent(k -> {
                k.setHodStatus(action);
                k.setHodRemarks(remarks);
                k.setStatus(action);
                managerRepo.save(k);
            });
        } else if (roleType.equals("supervisor")) {
            supervisorRepo.findById(id).ifPresent(k -> {
                k.setHodStatus(action);
                k.setHodRemarks(remarks);
                k.setStatus(action);
                supervisorRepo.save(k);
            });
        } else {
            operatorRepo.findById(id).ifPresent(k -> {
                k.setHodStatus(action);
                k.setHodRemarks(remarks);
                k.setStatus(action);
                operatorRepo.save(k);
            });
        }

        Map<String, Object> result = new HashMap<>();
        result.put("status", "success");
        return ResponseEntity.ok(result);
    }

    private Map<String, Object> toMap(KaizenItem k, String roleType) {
        Map<String, Object> m = new HashMap<>();
        m.put("id",              k.getId());
        m.put("kaizen_id",       k.getKaizenId());
        m.put("emp_name",        k.getEmpName());
        m.put("theme",           k.getTheme());
        m.put("section",         k.getSection());
        m.put("created_at",      k.getCreatedAt() != null ? k.getCreatedAt().toString() : null);
        m.put("hod_status",      k.getHodStatus() != null ? k.getHodStatus() : k.getStatus());
        m.put("hod_remarks",     k.getHodRemarks());
        m.put("role_type",       roleType);
        m.put("before_desc",     k.getBeforeDesc());
        m.put("kaizen_category", k.getKaizenCategory());
        m.put("status",          k.getStatus());
        m.put("depo",            getDepo(k));

        if (k.getBeforeImg() != null) {
            String imgStr = new String(k.getBeforeImg(),
                java.nio.charset.StandardCharsets.UTF_8).trim();
            m.put("before_img", "http://localhost/kaizen-backend/uploads/" + imgStr);
        } else { m.put("before_img", null); }

        if (k.getAfterImg() != null) {
            String imgStr = new String(k.getAfterImg(),
                java.nio.charset.StandardCharsets.UTF_8).trim();
            m.put("after_img", "http://localhost/kaizen-backend/uploads/" + imgStr);
        } else { m.put("after_img", null); }

        return m;
    }

    private Map<String, Integer> calcImpact(String plantId) {
        String[] keys  = {"Productivity", "Quality", "Cost", "Delivery", "Safety", "Morale"};
        String[] chars = {"P", "Q", "C", "D", "S", "M"};

        List<KaizenItem> all = new ArrayList<>();
        all.addAll(managerRepo.findByUnit(plantId));
        all.addAll(supervisorRepo.findByUnit(plantId));
        all.addAll(operatorRepo.findByUnit(plantId));

        Map<String, Integer> impact = new LinkedHashMap<>();
        for (int i = 0; i < keys.length; i++) {
            int count = 0;
            for (KaizenItem item : all) {
                if (item.getPqcdsm() != null && item.getPqcdsm().contains(chars[i])) count++;
            }
            impact.put(keys[i], count);
        }
        return impact;
    }

    private Map<String, Object> toMapNoImage(KaizenItem k, String roleType) {
        Map<String, Object> m = new HashMap<>();
        m.put("id",              k.getId());
        m.put("kaizen_id",       k.getKaizenId());
        m.put("emp_name",        k.getEmpName());
        m.put("theme",           k.getTheme());
        m.put("section",         k.getSection());
        m.put("created_at",      k.getCreatedAt() != null ? k.getCreatedAt().toString() : null);
        m.put("hod_status",      k.getHodStatus() != null ? k.getHodStatus() : k.getStatus());
        m.put("hod_remarks",     k.getHodRemarks());
        m.put("role_type",       roleType);
        m.put("before_desc",     k.getBeforeDesc());
        m.put("kaizen_category", k.getKaizenCategory());
        m.put("status",          k.getStatus());
        m.put("depo",            getDepo(k));
        m.put("before_img",      null);
        m.put("after_img",       null);
        return m;
    }
}