package com.example.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "supervisor_kaizen")
public class SupervisorKaizen extends KaizenItem {

    @Column(name = "team")
    private String team;

    @Column(name = "depo")
    private String depo;

    @Override
    public String getTeam() { return team; }

    @Override
    public void setTeam(String v) { this.team = v; }

    public String getDepo() { return depo; }
    public void setDepo(String depo) { this.depo = depo; }
}