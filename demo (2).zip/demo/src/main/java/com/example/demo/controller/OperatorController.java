package com.example.demo.controller;

import com.example.demo.model.OperatorKaizen;
import com.example.demo.repository.OperatorKaizenRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;

@RestController
@RequestMapping("/api/operator")
public class OperatorController {

    @Autowired private OperatorKaizenRepo operatorRepo;

    @Value("${app.upload.dir}")
    private String uploadDir;

    // ── GET /api/operator?level=Operator ─────────────────────────────────
    // Returns count for kaizen ID generation
    @GetMapping
    public ResponseEntity<?> getCount(
            @RequestParam(required = false, defaultValue = "Operator") String level) {
        long count = operatorRepo.count();
        return ResponseEntity.ok(count);
    }

    // ── POST /api/operator/save ───────────────────────────────────────────
    @PostMapping("/save")
    public ResponseEntity<?> saveOperator(
            @RequestParam(required = false) String kaizen_id,
            @RequestParam(required = false) String emp_id,
            @RequestParam(required = false) String emp_name,
            @RequestParam(required = false) String unit,
            @RequestParam(required = false) String department,   // ← NEW
            @RequestParam(required = false) String zone,
            @RequestParam(required = false) String section,
            @RequestParam(required = false) String other_section,
            @RequestParam(required = false) String theme,
            @RequestParam(required = false) String pqcdsm,
            @RequestParam(required = false) String kaizen_category,
            @RequestParam(required = false) String start_date,
            @RequestParam(required = false) String end_date,
            @RequestParam(required = false) String before_desc,
            @RequestParam(required = false) String after_desc,
            @RequestParam(required = false) String benefits,
            @RequestParam(required = false) String team,
            @RequestParam(required = false) MultipartFile before_img_file,
            @RequestParam(required = false) MultipartFile after_img_file) {

        OperatorKaizen k = new OperatorKaizen();
        k.setKaizenId(kaizen_id);
        k.setEmpId(emp_id);
        k.setEmpName(emp_name);
        k.setUnit(unit);
        k.setDepo(department);   // ← NEW — saves selected department into depo column

        // Use other_section if section is "Other"
        String finalSection = "Other".equals(section) && other_section != null
            ? other_section : section;
        k.setSection(finalSection);
        k.setZone(zone);

        k.setTheme(theme);
        k.setPqcdsm(pqcdsm);
        k.setKaizenCategory(kaizen_category);
        k.setStartDate(start_date);
        k.setEndDate(end_date);
        k.setBeforeDesc(before_desc);
        k.setAfterDesc(after_desc);
        k.setBenefitsPqcdsm(benefits);
        k.setTeamMembers(team);
        k.setStatus("Pending");

        try {
            File uploadFolder = new File(uploadDir);
            if (!uploadFolder.exists()) uploadFolder.mkdirs();

            if (before_img_file != null && !before_img_file.isEmpty()) {
                String fileName = System.currentTimeMillis() + "_B_" + before_img_file.getOriginalFilename();
                Files.write(Paths.get(uploadDir + fileName), before_img_file.getBytes());
                k.setBeforeImg(fileName.getBytes());
            }
            if (after_img_file != null && !after_img_file.isEmpty()) {
                String fileName = System.currentTimeMillis() + "_A_" + after_img_file.getOriginalFilename();
                Files.write(Paths.get(uploadDir + fileName), after_img_file.getBytes());
                k.setAfterImg(fileName.getBytes());
            }
        } catch (IOException e) {
            return ResponseEntity.internalServerError()
                .body(Map.of("error", "Image upload failed: " + e.getMessage()));
        }

        operatorRepo.save(k);
        return ResponseEntity.ok(Map.of("status", "success"));
    }
}