package com.example.demo.repository;

import com.example.demo.model.ManagerKaizen;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface ManagerKaizenRepo extends JpaRepository<ManagerKaizen, Long> {

    List<ManagerKaizen> findByUnit(String unit);
    List<ManagerKaizen> findByUnitAndSection(String unit, String section);
    List<ManagerKaizen> findByUnitAndSectionAndStatus(String unit, String section, String status);

    long countByUnit(String unit);
    long countByUnitAndHodStatusIsNull(String unit);
    long countByUnitAndHodStatus(String unit, String s);

    @Query("SELECT COUNT(m) FROM ManagerKaizen m WHERE m.unit=:unit AND m.section=:section")
    long countByUnitAndSection(@Param("unit") String unit, @Param("section") String section);

    @Query("SELECT COUNT(m) FROM ManagerKaizen m WHERE m.unit=:unit AND m.section=:section AND m.status='Pending'")
    long countPendingByUnitAndSection(@Param("unit") String unit, @Param("section") String section);

    @Query("SELECT COUNT(m) FROM ManagerKaizen m WHERE m.unit=:unit AND m.section=:section AND m.status='Approved'")
    long countApprovedByUnitAndSection(@Param("unit") String unit, @Param("section") String section);

    ManagerKaizen findByKaizenId(String kaizenId);
}