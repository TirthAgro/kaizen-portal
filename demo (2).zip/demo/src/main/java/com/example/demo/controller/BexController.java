package com.example.demo.controller;

import com.example.demo.model.*;
import com.example.demo.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@RestController
@RequestMapping("/api/bex")
public class BexController {

    @Autowired private ManagerKaizenRepo    managerRepo;
    @Autowired private SupervisorKaizenRepo supervisorRepo;
    @Autowired private OperatorKaizenRepo   operatorRepo;
    @Autowired private UserRepository       userRepo;
    @Autowired private BCryptPasswordEncoder passwordEncoder;

    @GetMapping
    public ResponseEntity<?> handleGet(
            @RequestParam String action,
            @RequestParam(required = false) String unit,
            @RequestParam(required = false) String role,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String from,
            @RequestParam(required = false) String to) {

        switch (action) {

            case "dashboard": {
                List<Map<String, Object>> result = new ArrayList<>();
                for (int i = 1; i <= 5; i++) {
                    String u = "Unit " + i;
                    long total = managerRepo.countByUnit(u)
                               + supervisorRepo.countByUnit(u)
                               + operatorRepo.countByUnit(u);
                    Map<String, Object> m = new HashMap<>();
                    m.put("unit", u);
                    m.put("total", total);
                    result.add(m);
                }
                return ResponseEntity.ok(result);
            }

            case "master_list": {
                List<Map<String, Object>> list = new ArrayList<>();

                if (role == null || role.isEmpty() || role.equals("Manager")) {
                    managerRepo.findAll().forEach(k -> {
                        if (matchesFilter(k, unit, status, search) && matchesDateFilter(k, from, to))
                            list.add(toMasterMap(k, "Manager"));
                    });
                }
                if (role == null || role.isEmpty() || role.equals("Supervisor")) {
                    supervisorRepo.findAll().forEach(k -> {
                        if (matchesFilter(k, unit, status, search) && matchesDateFilter(k, from, to))
                            list.add(toMasterMap(k, "Supervisor"));
                    });
                }
                if (role == null || role.isEmpty() || role.equals("Operator")) {
                    operatorRepo.findAll().forEach(k -> {
                        if (matchesFilter(k, unit, status, search) && matchesDateFilter(k, from, to))
                            list.add(toMasterMap(k, "Operator"));
                    });
                }

                list.sort((a, b) -> {
                    String ca = a.get("created_at") != null ? a.get("created_at").toString() : "";
                    String cb = b.get("created_at") != null ? b.get("created_at").toString() : "";
                    return cb.compareTo(ca);
                });
                return ResponseEntity.ok(list);
            }

            case "get_users": {
                List<Map<String, Object>> users = new ArrayList<>();
                userRepo.findAllByOrderByIdDesc().forEach(u -> {
                    Map<String, Object> m = new HashMap<>();
                    m.put("user_id",  u.getUserId());
                    m.put("password", u.getPassword());
                    m.put("role",     u.getRole());
                    m.put("plant_id", u.getPlantId());
                    m.put("section",  u.getSection());
                    users.add(m);
                });
                return ResponseEntity.ok(users);
            }

            default:
                return ResponseEntity.badRequest().body(Map.of("error", "Invalid action"));
        }
    }

    @PostMapping("/final-update")
    public ResponseEntity<?> finalUpdate(@RequestBody Map<String, Object> body) {
        Long   id     = Long.valueOf(body.get("id").toString());
        String role   = body.get("role").toString();
        String status = body.get("status").toString();
        String remark = body.getOrDefault("remark", "").toString();

        if (role.equals("Operator")) {
            operatorRepo.findById(id).ifPresent(k -> {
                k.setStatus(status); k.setHodStatus(status);
                k.setManagerRemarks(remark); operatorRepo.save(k);
            });
        } else if (role.equals("Supervisor")) {
            supervisorRepo.findById(id).ifPresent(k -> {
                k.setStatus(status); k.setHodStatus(status);
                k.setManagerRemarks(remark); supervisorRepo.save(k);
            });
        } else {
            managerRepo.findById(id).ifPresent(k -> {
                k.setStatus(status); k.setHodStatus(status);
                k.setManagerRemarks(remark); managerRepo.save(k);
            });
        }
        return ResponseEntity.ok(Map.of("status", "updated"));
    }

    @PostMapping("/save-user")
    public ResponseEntity<?> saveUser(@RequestBody Map<String, Object> body) {
        String userId   = body.getOrDefault("user_id", "").toString();
        String password = body.getOrDefault("password", "").toString();
        String role     = body.getOrDefault("role", "").toString();
        String plantId  = body.getOrDefault("plant_id", "").toString();
        String section  = body.getOrDefault("section", "").toString();
        String oldId    = body.getOrDefault("old_user_id", "").toString();

        if (!oldId.isEmpty()) {
            User existing = userRepo.findByUserId(oldId);
            if (existing != null) {
                existing.setUserId(userId);
                existing.setPassword(passwordEncoder.encode(password));
                existing.setRole(role);
                existing.setPlantId(plantId);
                existing.setSection(section);
                userRepo.save(existing);
            }
        } else {
            User existing = userRepo.findByUserId(userId);
            if (existing != null) {
                existing.setPassword(passwordEncoder.encode(password));
                existing.setRole(role);
                existing.setPlantId(plantId);
                existing.setSection(section);
                userRepo.save(existing);
            } else {
                User newUser = new User();
                newUser.setUserId(userId);
                newUser.setPassword(passwordEncoder.encode(password));
                newUser.setRole(role);
                newUser.setPlantId(plantId);
                newUser.setSection(section);
                userRepo.save(newUser);
            }
        }
        return ResponseEntity.ok(Map.of("status", "success"));
    }

    @PostMapping("/delete-user")
    public ResponseEntity<?> deleteUser(@RequestBody Map<String, Object> body) {
        String userId = body.get("user_id").toString();
        User user = userRepo.findByUserId(userId);
        if (user != null) userRepo.delete(user);
        return ResponseEntity.ok(Map.of("status", "success"));
    }

    // ── HELPERS ───────────────────────────────────────────────────────────

    private boolean matchesFilter(KaizenItem k, String unit, String status, String search) {
        if (unit != null && !unit.isEmpty() && !unit.equals(k.getUnit())) return false;
        if (status != null && !status.isEmpty() && !status.equals(k.getStatus())) return false;
        if (search != null && !search.isEmpty()) {
            String s = search.toLowerCase();
            boolean match = (k.getKaizenId() != null && k.getKaizenId().toLowerCase().contains(s))
                         || (k.getTheme()    != null && k.getTheme().toLowerCase().contains(s))
                         || (k.getSection()  != null && k.getSection().toLowerCase().contains(s));
            if (!match) return false;
        }
        return true;
    }

    private boolean matchesDateFilter(KaizenItem k, String from, String to) {
        if ((from == null || from.isEmpty()) && (to == null || to.isEmpty())) return true;
        if (k.getCreatedAt() == null) return true;
        try {
            java.time.LocalDate createdDate = k.getCreatedAt().toLocalDate();
            if (from != null && !from.isEmpty()) {
                java.time.LocalDate fromDate = java.time.LocalDate.parse(from);
                if (createdDate.isBefore(fromDate)) return false;
            }
            if (to != null && !to.isEmpty()) {
                java.time.LocalDate toDate = java.time.LocalDate.parse(to);
                if (createdDate.isAfter(toDate)) return false;
            }
        } catch (Exception e) {
            return true;
        }
        return true;
    }

    // ── Strip leading numbering like "1. " or "2. " from a string ────────
    private String stripNumbering(String s) {
        if (s == null) return "";
        return s.trim().replaceAll("^\\d+\\.\\s*", "");
    }

    private Map<String, Object> toMasterMap(KaizenItem k, String role) {
        Map<String, Object> m = new HashMap<>();

        m.put("id",              k.getId());
        m.put("kaizen_id",       k.getKaizenId());
        m.put("role",            role);
        m.put("unit",            k.getUnit());
        m.put("section",         k.getSection());
        m.put("theme",           k.getTheme());
        m.put("kaizen_type",     k.getKaizenType());
        m.put("kaizen_category", k.getKaizenCategory());
        m.put("pqcdsm",          k.getPqcdsm());
        m.put("emp_id",          k.getEmpId());
        m.put("machine_no",      k.getMachineNo());
        m.put("status",          k.getStatus());
        m.put("hod_status",      k.getHodStatus());
        m.put("before_desc",     k.getBeforeDesc());
        m.put("after_desc",      k.getAfterDesc());
        m.put("benefits_pqcdsm", k.getBenefitsPqcdsm());
        m.put("idea",            k.getIdea());
        m.put("root_cause",      k.getRootCause());
        m.put("manager_remarks", k.getManagerRemarks());
        m.put("created_at",      k.getCreatedAt() != null ? k.getCreatedAt().toString() : null);
        m.put("category_code",   k.getCategoryCode());
        m.put("advantage_desc",  k.getAdvantageDesc());
        m.put("kmi",             k.getKmi());
        m.put("kpi",             k.getKpi());
        m.put("certified_by",    k.getCertifiedBy());
        m.put("cft_verification",k.getCftVerification());
        m.put("approved_by",     k.getApprovedBy());

        // ── depo — only present on OperatorKaizen ────────────────────────
        if (k instanceof OperatorKaizen) {
            m.put("depo", ((OperatorKaizen) k).getDepo());
        } else if (k instanceof SupervisorKaizen) {
            m.put("depo", ((SupervisorKaizen) k).getDepo());
        }     
        else {
            m.put("depo", null);
        }

        // ── Build "Kaizen Performed By" list ──────────────────────────────
        String empName = (k.getEmpName() != null) ? k.getEmpName().trim() : "";
        String team    = (k.getTeam()    != null) ? k.getTeam().trim()    : "";
        String teamMem = (k.getTeamMembers() != null) ? k.getTeamMembers().trim() : "";

        List<String> members = new ArrayList<>();

        String cleanEmp = stripNumbering(empName);
        if (!cleanEmp.isEmpty()) members.add(cleanEmp);

        for (String t : team.split("[,\n]+")) {
            String name = stripNumbering(t);
            if (!name.isEmpty() && !members.contains(name)) members.add(name);
        }

        for (String t : teamMem.split("[,\n]+")) {
            String name = stripNumbering(t);
            if (!name.isEmpty() && !members.contains(name)) members.add(name);
        }

        StringBuilder pb = new StringBuilder();
        for (int i = 0; i < members.size(); i++) {
            if (i > 0) pb.append("\n");
            pb.append(i + 1).append(". ").append(members.get(i));
        }

        m.put("emp_name",     cleanEmp);
        m.put("performed_by", pb.toString());
        m.put("emp_count",    members.size());

        // ── Image URLs ────────────────────────────────────────────────────
        if (k.getBeforeImg() != null) {
            String imgStr = new String(k.getBeforeImg(),
                java.nio.charset.StandardCharsets.UTF_8).trim();
            m.put("before_img", "http://localhost/kaizen-backend/uploads/" + imgStr);
        } else {
            m.put("before_img", null);
        }
        if (k.getAfterImg() != null) {
            String imgStr = new String(k.getAfterImg(),
                java.nio.charset.StandardCharsets.UTF_8).trim();
            m.put("after_img", "http://localhost/kaizen-backend/uploads/" + imgStr);
        } else {
            m.put("after_img", null);
        }

        return m;
    }
}