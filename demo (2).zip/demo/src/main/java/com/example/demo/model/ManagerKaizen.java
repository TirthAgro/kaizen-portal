package com.example.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "manager_kaizen")
public class ManagerKaizen extends KaizenItem {

    @Column(name = "depo")
    private String depo;

    public String getDepo() { return depo; }
    public void setDepo(String depo) { this.depo = depo; }
}