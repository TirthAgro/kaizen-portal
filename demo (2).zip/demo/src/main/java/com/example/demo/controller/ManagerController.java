package com.example.demo.controller;

import com.example.demo.model.*;
import com.example.demo.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.beans.factory.annotation.Value;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;
import java.util.*;

@RestController
@RequestMapping("/api/manager")
public class ManagerController {

    @Value("${app.upload.dir}")
    private String uploadDir;

    @Autowired private ManagerKaizenRepo    managerRepo;
    @Autowired private SupervisorKaizenRepo supervisorRepo;
    @Autowired private OperatorKaizenRepo   operatorRepo;

    @GetMapping
    public ResponseEntity<?> handleGet(
            @RequestParam String action,
            @RequestParam(required = false) String unit,
            @RequestParam(required = false) String section) {

        switch (action) {
            case "count": {
                return ResponseEntity.ok(Map.of("count", managerRepo.count()));
            }
            case "stats": {
                long total    = managerRepo.countByUnitAndSection(unit, section)
                              + supervisorRepo.countByUnitAndSection(unit, section)
                              + operatorRepo.countByUnitAndSection(unit, section);
                long pending  = managerRepo.countPendingByUnitAndSection(unit, section)
                              + supervisorRepo.countPendingByUnitAndSection(unit, section)
                              + operatorRepo.countPendingByUnitAndSection(unit, section);
                long approved = managerRepo.countApprovedByUnitAndSection(unit, section)
                              + supervisorRepo.countApprovedByUnitAndSection(unit, section)
                              + operatorRepo.countApprovedByUnitAndSection(unit, section);
                return ResponseEntity.ok(Map.of(
                    "total", total, "pending", pending, "approved", approved));
            }
            case "pending": {
                List<Map<String, Object>> list = new ArrayList<>();
                operatorRepo.findByUnitAndSectionAndStatus(unit, section, "Pending")
                    .forEach(k -> list.add(toMap(k, "Operator")));
                supervisorRepo.findByUnitAndSectionAndStatus(unit, section, "Pending")
                    .forEach(k -> list.add(toMap(k, "Supervisor")));
                managerRepo.findByUnitAndSectionAndStatus(unit, section, "Pending")
                    .forEach(k -> list.add(toMap(k, "Manager")));
                return ResponseEntity.ok(list);
            }
            case "tracker": {
                List<Map<String, Object>> list = new ArrayList<>();
                operatorRepo.findByUnitAndSection(unit, section)
                    .forEach(k -> list.add(toTrackerMap(k, "Operator")));
                supervisorRepo.findByUnitAndSection(unit, section)
                    .forEach(k -> list.add(toTrackerMap(k, "Supervisor")));
                managerRepo.findByUnitAndSection(unit, section)
                    .forEach(k -> list.add(toTrackerMap(k, "Manager")));
                list.sort((a, b) -> {
                    String ca = a.get("created_at") != null ? a.get("created_at").toString() : "";
                    String cb = b.get("created_at") != null ? b.get("created_at").toString() : "";
                    return cb.compareTo(ca);
                });
                return ResponseEntity.ok(list);
            }
            default:
                return ResponseEntity.badRequest().body(Map.of("error", "Invalid action"));
        }
    }

    @PostMapping("/save")
    public ResponseEntity<?> saveKaizen(
            @RequestParam(required = false) String kaizen_id,
            @RequestParam(required = false) String emp_id,
            @RequestParam(required = false) String emp_name,
            @RequestParam(required = false) String unit,
            @RequestParam(required = false) String depo,          // ← NEW
            @RequestParam(required = false) String section,
            @RequestParam(required = false) String machine_no,
            @RequestParam(required = false) String kaizen_type,
            @RequestParam(required = false) String pqcdsm,
            @RequestParam(required = false) String kaizen_category,
            @RequestParam(required = false) String theme,
            @RequestParam(required = false) String why1,
            @RequestParam(required = false) String why2,
            @RequestParam(required = false) String why3,
            @RequestParam(required = false) String why4,
            @RequestParam(required = false) String why5,
            @RequestParam(required = false) String pillar,
            @RequestParam(required = false) String root_cause,
            @RequestParam(required = false) String problem_status,
            @RequestParam(required = false) String idea,
            @RequestParam(required = false) String countermeasure,
            @RequestParam(required = false) String benchmark,
            @RequestParam(required = false) String target,
            @RequestParam(required = false) String analysis,
            @RequestParam(required = false) String start_date,
            @RequestParam(required = false) String end_date,
            @RequestParam(required = false) String final_result,
            @RequestParam(required = false) String before_desc,
            @RequestParam(required = false) String after_desc,
            @RequestParam(required = false) String benefits_pqcdsm,
            @RequestParam(required = false) String team_members,
            @RequestParam(required = false) String deployments,
            @RequestParam(required = false) MultipartFile before_img,
            @RequestParam(required = false) MultipartFile after_img) {

        ManagerKaizen k = new ManagerKaizen();
        k.setKaizenId(kaizen_id);
        k.setEmpId(emp_id);
        k.setEmpName(emp_name);
        k.setUnit(unit);
        k.setDepo(depo);                    // ← NEW
        k.setSection(section);
        k.setMachineNo(machine_no);
        k.setKaizenType(kaizen_type);
        k.setPqcdsm(pqcdsm);
        k.setKaizenCategory(kaizen_category);
        k.setTheme(theme);
        k.setWhy1(why1); k.setWhy2(why2); k.setWhy3(why3);
        k.setWhy4(why4); k.setWhy5(why5);
        k.setPillar(pillar);
        k.setRootCause(root_cause);
        k.setProblemStatus(problem_status);
        k.setIdea(idea);
        k.setCountermeasure(countermeasure);
        k.setBenchmark(benchmark);
        k.setTarget(target);
        k.setAnalysis(analysis);
        k.setStartDate(start_date);
        k.setEndDate(end_date);
        k.setFinalResult(final_result);
        k.setBeforeDesc(before_desc);
        k.setAfterDesc(after_desc);
        k.setBenefitsPqcdsm(benefits_pqcdsm);
        k.setTeamMembers(team_members);
        k.setDeployments(deployments);
        k.setStatus("Pending");

        try {
            File uploadFolder = new File(uploadDir);
            if (!uploadFolder.exists()) uploadFolder.mkdirs();

            if (before_img != null && !before_img.isEmpty()) {
                String beforeFileName = System.currentTimeMillis() + "_B_" + before_img.getOriginalFilename();
                Path beforePath = Paths.get(uploadDir + beforeFileName);
                Files.write(beforePath, before_img.getBytes());
                k.setBeforeImg(beforeFileName.getBytes());
            }

            if (after_img != null && !after_img.isEmpty()) {
                String afterFileName = System.currentTimeMillis() + "_A_" + after_img.getOriginalFilename();
                Path afterPath = Paths.get(uploadDir + afterFileName);
                Files.write(afterPath, after_img.getBytes());
                k.setAfterImg(afterFileName.getBytes());
            }
        } catch (IOException e) {
            return ResponseEntity.internalServerError()
                .body(Map.of("error", "Image upload failed: " + e.getMessage()));
        }

        managerRepo.save(k);
        return ResponseEntity.ok(Map.of("status", "success"));
    }

    @PostMapping("/update-status")
    public ResponseEntity<?> updateStatus(@RequestBody Map<String, Object> body) {
        String kaizenId = body.get("kaizen_id").toString();
        String roleType = body.get("role_type").toString();
        String status   = body.get("status").toString();
        String remarks  = body.getOrDefault("manager_remark", "").toString();

        if (roleType.equals("Operator")) {
            OperatorKaizen ok = operatorRepo.findByKaizenId(kaizenId);
            if (ok != null) { ok.setStatus(status); ok.setManagerRemarks(remarks); operatorRepo.save(ok); }
        } else if (roleType.equals("Supervisor")) {
            SupervisorKaizen sk = supervisorRepo.findByKaizenId(kaizenId);
            if (sk != null) { sk.setStatus(status); sk.setManagerRemarks(remarks); supervisorRepo.save(sk); }
        } else {
            ManagerKaizen mk = managerRepo.findByKaizenId(kaizenId);
            if (mk != null) { mk.setStatus(status); mk.setManagerRemarks(remarks); managerRepo.save(mk); }
        }
        return ResponseEntity.ok(Map.of("status", "updated"));
    }

    // ── helper: cast to ManagerKaizen safely to read depo ────────
    private String getDepo(KaizenItem k) {
    if (k instanceof ManagerKaizen)    return ((ManagerKaizen)    k).getDepo();
    if (k instanceof SupervisorKaizen) return ((SupervisorKaizen) k).getDepo();
    if (k instanceof OperatorKaizen)   return ((OperatorKaizen)   k).getDepo();
    return null;
}

    private Map<String, Object> toMap(KaizenItem k, String roleType) {
        Map<String, Object> m = new HashMap<>();
        m.put("kaizen_id",       k.getKaizenId());
        m.put("emp_name",        k.getEmpName());
        m.put("theme",           k.getTheme());
        m.put("kaizen_category", k.getKaizenCategory());
        m.put("status",          k.getStatus());
        m.put("before_desc",     k.getBeforeDesc());
        m.put("after_desc",      k.getAfterDesc());
        m.put("team_members",    k.getTeamMembers());
        m.put("pqcdsm",          k.getPqcdsm());
        m.put("problem_status",  k.getProblemStatus());
        m.put("countermeasure",  k.getCountermeasure());
        m.put("analysis",        k.getAnalysis());
        m.put("deployments",     k.getDeployments());
        m.put("role_type",       roleType);
        m.put("depo",            getDepo(k));               // ← NEW
        m.put("created_at",      k.getCreatedAt() != null ? k.getCreatedAt().toString() : null);

        if (k.getBeforeImg() != null) {
            String imgStr = new String(k.getBeforeImg(), java.nio.charset.StandardCharsets.UTF_8).trim();
            m.put("before_img", "http://localhost/kaizen-backend/uploads/" + imgStr);
        } else { m.put("before_img", null); }

        if (k.getAfterImg() != null) {
            String imgStr = new String(k.getAfterImg(), java.nio.charset.StandardCharsets.UTF_8).trim();
            m.put("after_img", "http://localhost/kaizen-backend/uploads/" + imgStr);
        } else { m.put("after_img", null); }

        return m;
    }

    private Map<String, Object> toTrackerMap(KaizenItem k, String roleType) {
        Map<String, Object> m = new HashMap<>();
        m.put("kaizen_id",       k.getKaizenId());
        m.put("emp_name",        k.getEmpName());
        m.put("theme",           k.getTheme());
        m.put("status",          k.getStatus());
        m.put("manager_remarks", k.getManagerRemarks());
        m.put("hod_remarks",     k.getHodRemarks());
        m.put("role_type",       roleType);
        m.put("depo",            getDepo(k));               // ← NEW
        m.put("created_at",      k.getCreatedAt() != null ? k.getCreatedAt().toString() : null);
        return m;
    }
}