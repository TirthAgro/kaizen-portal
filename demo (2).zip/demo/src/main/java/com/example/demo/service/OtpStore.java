package com.example.demo.service;

import org.springframework.stereotype.Component;
import java.util.HashMap;
import java.util.Map;

@Component
public class OtpStore {
    // userId -> {otp, expiry}
    private final Map<String, long[]> store = new HashMap<>();

    public void saveOtp(String userId, String otp) {
        long expiry = System.currentTimeMillis() + (10 * 60 * 1000); // 10 min
        store.put(userId, new long[]{Long.parseLong(otp), expiry});
    }

    public boolean verifyOtp(String userId, String otp) {
        if (!store.containsKey(userId)) return false;
        long[] data = store.get(userId);
        boolean valid = data[0] == Long.parseLong(otp) &&
                        System.currentTimeMillis() < data[1];
        if (valid) store.remove(userId);
        return valid;
    }

    public void clearOtp(String userId) {
        store.remove(userId);
    }
}