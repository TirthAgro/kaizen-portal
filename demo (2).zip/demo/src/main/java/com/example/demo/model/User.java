package com.example.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id")
    private String userId;

    private String password;
    private String role;
    private String plant;

    @Column(name = "plant_id")
    private String plantId;

    private String section;
    private String name;

    @Column(name = "email")
    private String email;

    public Long getId()               { return id; }
    public void setId(Long v)         { this.id = v; }
    public String getUserId()         { return userId; }
    public void setUserId(String v)   { this.userId = v; }
    public String getPassword()       { return password; }
    public void setPassword(String v) { this.password = v; }
    public String getRole()           { return role; }
    public void setRole(String v)     { this.role = v; }
    public String getPlant()          { return plant; }
    public void setPlant(String v)    { this.plant = v; }
    public String getPlantId()        { return plantId; }
    public void setPlantId(String v)  { this.plantId = v; }
    public String getSection()        { return section; }
    public void setSection(String v)  { this.section = v; }
    public String getName()           { return name; }
    public void setName(String v)     { this.name = v; }
    public String getEmail()       { return email; }
    public void setEmail(String v) { this.email = v; }
}