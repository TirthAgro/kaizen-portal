package com.example.demo.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@MappedSuperclass
public class KaizenItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "kaizen_id")        private String kaizenId;
    @Column(name = "emp_id")           private String empId;
    @Column(name = "emp_name")         private String empName;
    @Column(name = "before_desc")      private String beforeDesc;
    @Column(name = "after_desc")       private String afterDesc;
    @Column(name = "kaizen_category")  private String kaizenCategory;
    @Column(name = "hod_status")       private String hodStatus;
    @Column(name = "hod_remarks")      private String hodRemarks;
    @Column(name = "manager_remarks")  private String managerRemarks;
    @Column(name = "machine_no")       private String machineNo;
    @Column(name = "kaizen_type")      private String kaizenType;
    @Column(name = "problem_status")   private String problemStatus;
    @Column(name = "root_cause")       private String rootCause;
    @Column(name = "countermeasure")   private String countermeasure;
    @Column(name = "final_result")     private String finalResult;
    @Column(name = "benefits_pqcdsm")  private String benefitsPqcdsm;
    @Column(name = "team_members")     private String teamMembers;
    @Column(name = "deployments")      private String deployments;
    @Column(name = "start_date")       private String startDate;
    @Column(name = "end_date")         private String endDate;
    @Column(name = "created_at")       private LocalDateTime createdAt;
    @Column(name = "before_img", columnDefinition = "LONGBLOB") private byte[] beforeImg;
    @Column(name = "after_img",  columnDefinition = "LONGBLOB") private byte[] afterImg;

    private String theme, section, unit, pqcdsm, pillar, status;
    private String why1, why2, why3, why4, why5;
    private String idea, benchmark, target, analysis;

    // Fields that exist in operator/supervisor but NOT in manager — subclasses handle these
    @Transient private String team;

    // Fields that exist in NO table — always transient
    @Transient private String zone;
    @Transient private String advantageDesc;
    @Transient private String categoryCode;
    @Transient private String certifiedBy;
    @Transient private String cftVerification;
    @Transient private String approvedBy;
    @Transient private String kmi;
    @Transient private String kpi;

    // Getters and setters
    public Long getId()                        { return id; }
    public void setId(Long id)                 { this.id = id; }
    public String getKaizenId()                { return kaizenId; }
    public void setKaizenId(String v)          { this.kaizenId = v; }
    public String getEmpId()                   { return empId; }
    public void setEmpId(String v)             { this.empId = v; }
    public String getEmpName()                 { return empName; }
    public void setEmpName(String v)           { this.empName = v; }
    public String getTheme()                   { return theme; }
    public void setTheme(String v)             { this.theme = v; }
    public String getSection()                 { return section; }
    public void setSection(String v)           { this.section = v; }
    public String getUnit()                    { return unit; }
    public void setUnit(String v)              { this.unit = v; }
    public String getPqcdsm()                  { return pqcdsm; }
    public void setPqcdsm(String v)            { this.pqcdsm = v; }
    public String getPillar()                  { return pillar; }
    public void setPillar(String v)            { this.pillar = v; }
    public String getStatus()                  { return status; }
    public void setStatus(String v)            { this.status = v; }
    public String getBeforeDesc()              { return beforeDesc; }
    public void setBeforeDesc(String v)        { this.beforeDesc = v; }
    public String getAfterDesc()               { return afterDesc; }
    public void setAfterDesc(String v)         { this.afterDesc = v; }
    public String getKaizenCategory()          { return kaizenCategory; }
    public void setKaizenCategory(String v)    { this.kaizenCategory = v; }
    public String getHodStatus()               { return hodStatus; }
    public void setHodStatus(String v)         { this.hodStatus = v; }
    public String getHodRemarks()              { return hodRemarks; }
    public void setHodRemarks(String v)        { this.hodRemarks = v; }
    public String getManagerRemarks()          { return managerRemarks; }
    public void setManagerRemarks(String v)    { this.managerRemarks = v; }
    public String getMachineNo()               { return machineNo; }
    public void setMachineNo(String v)         { this.machineNo = v; }
    public String getKaizenType()              { return kaizenType; }
    public void setKaizenType(String v)        { this.kaizenType = v; }
    public String getProblemStatus()           { return problemStatus; }
    public void setProblemStatus(String v)     { this.problemStatus = v; }
    public String getRootCause()               { return rootCause; }
    public void setRootCause(String v)         { this.rootCause = v; }
    public String getCountermeasure()          { return countermeasure; }
    public void setCountermeasure(String v)    { this.countermeasure = v; }
    public String getFinalResult()             { return finalResult; }
    public void setFinalResult(String v)       { this.finalResult = v; }
    public String getBenefitsPqcdsm()          { return benefitsPqcdsm; }
    public void setBenefitsPqcdsm(String v)    { this.benefitsPqcdsm = v; }
    public String getTeam()                    { return team; }
    public void setTeam(String v)              { this.team = v; }
    public String getTeamMembers()             { return teamMembers; }
    public void setTeamMembers(String v)       { this.teamMembers = v; }
    public String getDeployments()             { return deployments; }
    public void setDeployments(String v)       { this.deployments = v; }
    public String getStartDate()               { return startDate; }
    public void setStartDate(String v)         { this.startDate = v; }
    public String getEndDate()                 { return endDate; }
    public void setEndDate(String v)           { this.endDate = v; }
    public String getWhy1()                    { return why1; }
    public void setWhy1(String v)              { this.why1 = v; }
    public String getWhy2()                    { return why2; }
    public void setWhy2(String v)              { this.why2 = v; }
    public String getWhy3()                    { return why3; }
    public void setWhy3(String v)              { this.why3 = v; }
    public String getWhy4()                    { return why4; }
    public void setWhy4(String v)              { this.why4 = v; }
    public String getWhy5()                    { return why5; }
    public void setWhy5(String v)              { this.why5 = v; }
    public String getIdea()                    { return idea; }
    public void setIdea(String v)              { this.idea = v; }
    public String getBenchmark()               { return benchmark; }
    public void setBenchmark(String v)         { this.benchmark = v; }
    public String getTarget()                  { return target; }
    public void setTarget(String v)            { this.target = v; }
    public String getAnalysis()                { return analysis; }
    public void setAnalysis(String v)          { this.analysis = v; }
    public byte[] getBeforeImg()               { return beforeImg; }
    public void setBeforeImg(byte[] v)         { this.beforeImg = v; }
    public byte[] getAfterImg()                { return afterImg; }
    public void setAfterImg(byte[] v)          { this.afterImg = v; }
    public LocalDateTime getCreatedAt()        { return createdAt; }
    public void setCreatedAt(LocalDateTime v)  { this.createdAt = v; }
    public String getZone()                    { return zone; }
    public void setZone(String v)              { this.zone = v; }
    public String getAdvantageDesc()           { return advantageDesc; }
    public void setAdvantageDesc(String v)     { this.advantageDesc = v; }
    public String getCategoryCode()            { return categoryCode; }
    public void setCategoryCode(String v)      { this.categoryCode = v; }
    public String getCertifiedBy()             { return certifiedBy; }
    public void setCertifiedBy(String v)       { this.certifiedBy = v; }
    public String getCftVerification()         { return cftVerification; }
    public void setCftVerification(String v)   { this.cftVerification = v; }
    public String getApprovedBy()              { return approvedBy; }
    public void setApprovedBy(String v)        { this.approvedBy = v; }
    public String getKmi()                     { return kmi; }
    public void setKmi(String v)               { this.kmi = v; }
    public String getKpi()                     { return kpi; }
    public void setKpi(String v)               { this.kpi = v; }
}