package com.example.demo.repository;

import com.example.demo.model.OperatorKaizen;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface OperatorKaizenRepo extends JpaRepository<OperatorKaizen, Long> {
    List<OperatorKaizen> findByUnit(String unit);
    List<OperatorKaizen> findByUnitAndSection(String unit, String section);
    List<OperatorKaizen> findByUnitAndSectionAndStatus(String unit, String section, String status);
    long countByUnit(String unit);

    @Query("SELECT COUNT(o) FROM OperatorKaizen o WHERE o.unit=:unit AND o.section=:section AND o.status='Pending'")
    long countPendingByUnitAndSection(@Param("unit") String unit, @Param("section") String section);

    @Query("SELECT COUNT(o) FROM OperatorKaizen o WHERE o.unit=:unit AND o.section=:section AND o.status='Approved'")
    long countApprovedByUnitAndSection(@Param("unit") String unit, @Param("section") String section);

    @Query("SELECT COUNT(o) FROM OperatorKaizen o WHERE o.unit=:unit AND o.section=:section")
    long countByUnitAndSection(@Param("unit") String unit, @Param("section") String section);

    OperatorKaizen findByKaizenId(String kaizenId);
}