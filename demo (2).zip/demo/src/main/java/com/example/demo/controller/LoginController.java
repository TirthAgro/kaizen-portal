package com.example.demo.controller;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.demo.service.OtpStore;
import org.springframework.beans.factory.annotation.Autowired;
import com.example.demo.service.EmailService;
import java.util.Random;

import java.util.HashMap;
import java.util.Map;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@RestController
@RequestMapping("/api/auth")
public class LoginController {

    @Autowired
    private OtpStore otpStore;

    @Autowired
    private EmailService emailService;

    @Autowired private UserRepository userRepo;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, Object> body) {
    String userId   = body.getOrDefault("user_id", "").toString().trim();
    String password = body.getOrDefault("password", "").toString().trim();

    if (userId.isEmpty() || password.isEmpty()) {
        return ResponseEntity.ok(Map.of("status", "error", "message", "Invalid Request"));
    }

    User user = userRepo.findByUserId(userId);

    if (user == null) {
        return ResponseEntity.ok(Map.of("status", "error", "message", "User not found"));
    }

    boolean passwordMatch = false;
String storedPassword = user.getPassword().trim();

// Check if password is BCrypt encrypted (starts with $2a$)
if (storedPassword.startsWith("$2a$")) {
    passwordMatch = passwordEncoder.matches(password, storedPassword);
} else {
    // Plain text comparison for old passwords
    passwordMatch = password.equals(storedPassword);
}

if (!passwordMatch) {
    return ResponseEntity.ok(Map.of("status", "error", "message", "Incorrect Password"));
}

    Map<String, Object> userMap = new HashMap<>();
    userMap.put("user_id",  user.getUserId());
    userMap.put("role",     user.getRole());
    userMap.put("plant",    user.getPlant());
    userMap.put("plant_id", user.getPlantId() != null ? user.getPlantId() : "");
    userMap.put("section",  user.getSection() != null ? user.getSection() : "");

    return ResponseEntity.ok(Map.of("status", "success", "user", userMap));
}


    @PostMapping("/admin-login")
    public ResponseEntity<?> adminLogin(@RequestBody Map<String, Object> body) {

        String adminId  = body.getOrDefault("admin_id", "").toString().trim();
        String password = body.getOrDefault("password", "").toString().trim();
        String role     = body.getOrDefault("role", "").toString().trim();

        if (adminId.isEmpty() || password.isEmpty() || role.isEmpty()) {
            return ResponseEntity.ok(Map.of(
                "status", "error",
                "message", "Incomplete data received"
            ));
        }

        User user = userRepo.findByUserIdAndRole(adminId, role);

        if (user == null) {
            return ResponseEntity.ok(Map.of(
                "status", "error",
                "message", "Account not found for " + role
            ));
        }

        boolean adminPasswordMatch = false;
String storedAdminPassword = user.getPassword().trim();

if (storedAdminPassword.startsWith("$2a$")) {
    adminPasswordMatch = passwordEncoder.matches(password, storedAdminPassword);
} else {
    adminPasswordMatch = password.equals(storedAdminPassword);
}

if (!adminPasswordMatch) {
    return ResponseEntity.ok(Map.of(
        "status", "error",
        "message", "Incorrect Password"
    ));
}

        String displayName = (user.getName() != null && !user.getName().isEmpty())
            ? user.getName()
            : role + " User";

        Map<String, Object> userMap = new HashMap<>();
        userMap.put("user_id", user.getUserId());
        userMap.put("role",    user.getRole());
        userMap.put("name",    displayName);

        // Business Excellence gets global access
        if (role.equals("Business Excellence")) {
            userMap.put("plant_id", "ALL");
            userMap.put("section",  "ALL");
        } else {
            userMap.put("plant_id", user.getPlantId() != null ? user.getPlantId() : "");
            userMap.put("section",  user.getSection() != null ? user.getSection() : "");
        }

        return ResponseEntity.ok(Map.of(
            "status", "success",
            "user", userMap
        ));
    }

    // Step 1 — Send OTP to email
@PostMapping("/forgot-password")
public ResponseEntity<?> forgotPassword(@RequestBody Map<String, Object> body) {
    String userId = body.getOrDefault("user_id", "").toString().trim();

    if (userId.isEmpty())
        return ResponseEntity.ok(Map.of("status", "error", "message", "User ID is required"));

    User user = userRepo.findByUserId(userId);
    if (user == null)
        return ResponseEntity.ok(Map.of("status", "error", "message", "User ID not found"));

    if (user.getEmail() == null || user.getEmail().isEmpty())
        return ResponseEntity.ok(Map.of("status", "error",
            "message", "No email registered. Contact admin."));

    // Generate OTP
    String otp = String.format("%06d", new java.util.Random().nextInt(999999));
    otpStore.saveOtp(userId, otp);

    // Mask email: ab****@gmail.com
    String email  = user.getEmail();
    String masked = email.substring(0, 2) + "****" + email.substring(email.indexOf('@'));

    // Send email ASYNC in background — API responds immediately
    emailService.sendOtpEmail(email, userId, otp);

    // Respond immediately — don't wait for email
    return ResponseEntity.ok(Map.of(
        "status",       "success",
        "masked_email", masked,
        "dev_otp",      otp  // REMOVE this line when SMTP confirmed working
    ));
}

// Step 2 — Verify OTP
@PostMapping("/verify-otp")
public ResponseEntity<?> verifyOtp(@RequestBody Map<String, Object> body) {
    String userId = body.getOrDefault("user_id", "").toString().trim();
    String otp    = body.getOrDefault("otp", "").toString().trim();

    if (userId.isEmpty() || otp.isEmpty())
        return ResponseEntity.ok(Map.of("status", "error", "message", "All fields required"));

    if (!otpStore.verifyOtp(userId, otp))
        return ResponseEntity.ok(Map.of("status", "error", "message", "Invalid or expired OTP"));

    return ResponseEntity.ok(Map.of("status", "success"));
}

// Step 3 — Set new password after OTP verified
@PostMapping("/set-new-password")
public ResponseEntity<?> setNewPassword(@RequestBody Map<String, Object> body) {
    String userId      = body.getOrDefault("user_id", "").toString().trim();
    String newPassword = body.getOrDefault("new_password", "").toString().trim();

    if (userId.isEmpty() || newPassword.isEmpty())
        return ResponseEntity.ok(Map.of("status", "error", "message", "All fields required"));

    User user = userRepo.findByUserId(userId);
    if (user == null)
        return ResponseEntity.ok(Map.of("status", "error", "message", "User not found"));

    user.setPassword(passwordEncoder.encode(newPassword));
    userRepo.save(user);
    return ResponseEntity.ok(Map.of("status", "success"));
}
}