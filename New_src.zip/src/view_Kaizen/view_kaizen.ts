import { environment } from '../environments/environment';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import jsPDF from 'jspdf';

@Component({
  selector: 'app-view-kaizen',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  template: `
<div class="vk-app">

  <!-- NAVBAR -->
  <header class="vk-navbar">
    <div class="vk-brand-wrap">
      <div class="vk-logo-wrap">
        <img src="assets/shaktiman_logo.png" alt="logo">
      </div>
      <div>
        <h1>SHAKTI<span class="mgr-topbar-accent">पथ</span></h1>
        <p>Every Step Towards Success</p>
      </div>
    </div>

    <div class="vk-nav-actions">
      <a routerLink="/" class="vk-login-btn" *ngIf="!isLoggedIn">🔐 Login</a>
      <a [routerLink]="getDashboardRoute()" class="vk-login-btn vk-dash-btn" *ngIf="isLoggedIn">← Dashboard</a>
    </div>
  </header>

  <!-- MAIN -->
  <main class="vk-main">

    <!-- HERO -->
    <section class="vk-hero">
      <div class="vk-hero-deco-1"></div>
      <div class="vk-hero-deco-2"></div>
      <div class="vk-hero-content">
        <div class="vk-hero-badge">Kaizen Gallery</div>
        <h2>Innovation & Improvement Hub</h2>
        <p>Explore submitted improvements, process optimizations and innovation ideas across all departments.</p>
      </div>
      <div class="vk-hero-stats">
        <div class="hs-item"><div class="hs-num">{{totalKaizens}}</div><div class="hs-lbl">Total Kaizens</div></div>
        <div class="hs-sep"></div>
        <div class="hs-item"><div class="hs-num hs-green">{{approvedCount}}</div><div class="hs-lbl">Approved</div></div>
        <div class="hs-sep"></div>
        <div class="hs-item"><div class="hs-num hs-amber">{{pendingCount}}</div><div class="hs-lbl">Pending</div></div>
        <div class="hs-sep"></div>
        <div class="hs-item"><div class="hs-num hs-red">{{rejectedCount}}</div><div class="hs-lbl">Rejected</div></div>
      </div>
    </section>

    <!-- FILTER BAR -->
    <section class="vk-toolbar">
      <!-- Search -->
      <div class="vk-search">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
        <input type="text" [(ngModel)]="searchTerm" (input)="filterKaizens()" placeholder="Search by name, ID, theme…">
      </div>

      <!-- Filters group -->
      <div class="vk-filters">
        <div class="filter-item">
          <label>Status</label>
          <select [(ngModel)]="statusFilter" (change)="filterKaizens()">
            <option value="">All Status</option>
            <option value="Approved">Approved</option>
            <option value="Pending">Pending</option>
            <option value="Rejected">Rejected</option>
          </select>
        </div>

        <div class="filter-item">
          <label>Level</label>
          <select [(ngModel)]="sourceFilter" (change)="filterKaizens()">
            <option value="">All Levels</option>
            <option value="operator">Operator</option>
            <option value="supervisor">Supervisor</option>
            <option value="manager">Manager</option>
          </select>
        </div>

        <!-- Date inputs + error wrapped together -->

       <div class="vk-date-row">
  <div class="filter-item">
    <label>From Date</label>

    <input
      type="date"
      [(ngModel)]="dateFrom"
      (change)="filterKaizens()"
      class="date-input">
  </div>

  <div class="filter-item">
    <label>To Date</label>

    <input
      type="date"
      [(ngModel)]="dateTo"
      (change)="filterKaizens()"
      class="date-input">
  </div>

  <div
    class="date-error-side"
    *ngIf="dateError">

    <svg width="12"
         height="12"
         viewBox="0 0 24 24"
         fill="none"
         stroke="currentColor"
         stroke-width="2.5"
         stroke-linecap="round">

      <circle cx="12" cy="12" r="10"/>

      <line x1="12" y1="8"
            x2="12" y2="12"/>

      <line x1="12" y1="16"
            x2="12.01"
            y2="16"/>
    </svg>

    {{dateError}}

  </div>

</div>

        <button class="clear-btn" (click)="clearFilters()" *ngIf="hasActiveFilter()">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          Clear
        </button>
      </div>

      <div class="vk-result-count" *ngIf="!isLoading">
        <span>{{filteredKaizens.length}} records</span>
      </div>
    </section>

    <!-- LOADER -->
    <div class="vk-loader" *ngIf="isLoading">
      <div class="vk-loader-ring"></div>
      <span>Loading Kaizen Records…</span>
    </div>

    <!-- TABLE -->
    <section class="vk-table-wrapper" *ngIf="!isLoading">
      <table class="vk-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Employee</th>
            <th>Level</th>
            <th>Theme</th>
            <th>Unit / Section</th>
            <th>Date</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let k of pagedKaizens">
            <td><div class="vk-id">{{k.kaizen_id}}</div></td>
            <td>
              <div class="vk-user">
                <div class="vk-avatar">{{(k.emp_name || 'U').charAt(0)}}</div>
                <div>
                  <h4>{{k.emp_name}}</h4>
                  <p>{{k.emp_id}}</p>
                </div>
              </div>
            </td>
            <td><span class="vk-level" [ngClass]="k.source">{{k.source}}</span></td>
            <td class="vk-theme-cell">{{k.theme}}</td>
            <td>
              <div class="vk-unit">{{k.unit}}</div>
              <div class="vk-section-txt">{{k.section}}</div>
            </td>
            <td class="vk-date-cell">{{k.created_at | date:'dd MMM yyyy'}}</td>
            <td><span class="vk-status" [ngClass]="k.status?.toLowerCase()">{{k.status || 'Pending'}}</span></td>
            <td>
              <div class="vk-actions">
                <button class="vk-btn view" (click)="openFullDetails(k)">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                  View
                </button>
                <button class="vk-btn pdf" (click)="downloadKaizenPdf(k)">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                  PDF
                </button>
              </div>
            </td>
          </tr>
          <tr *ngIf="pagedKaizens.length === 0">
            <td colspan="8" class="vk-empty-row">
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" opacity=".3"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
              <p>No records found matching your filters.</p>
            </td>
          </tr>
        </tbody>
      </table>

      <!-- PAGINATION -->
      <div class="vk-pagination">
        <div class="vk-page-text">
          Showing {{(currentPage-1)*itemsPerPage+1}}–{{Math.min(currentPage*itemsPerPage, filteredKaizens.length)}} of {{filteredKaizens.length}}
        </div>
        <div class="vk-page-controls">
          <button (click)="prevPage()" [disabled]="currentPage===1">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="15 18 9 12 15 6"/></svg>
          </button>
          <div class="vk-page-nums">
            <button *ngFor="let p of pageNumbers()" (click)="goToPage(p)"
              [class.active]="p===currentPage" class="pg-num">{{p}}</button>
          </div>
          <button (click)="nextPage()" [disabled]="currentPage===totalPages">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="9 18 15 12 9 6"/></svg>
          </button>
        </div>
      </div>
    </section>
  </main>

  <!-- MODAL -->
  <div class="vk-modal-overlay" *ngIf="selectedKaizen" (click)="selectedKaizen=null">
    <div class="vk-modal" (click)="$event.stopPropagation()">

      <div class="vk-modal-header">
        <div class="modal-title-wrap">
          <span class="modal-badge">{{selectedKaizen.source | titlecase}}</span>
          <h2>{{selectedKaizen.theme}}</h2>
          <p>{{selectedKaizen.kaizen_id}} &nbsp;·&nbsp; {{selectedKaizen.unit}} &nbsp;·&nbsp; {{selectedKaizen.created_at | date:'dd MMM yyyy'}}</p>
        </div>
        <div class="modal-hdr-right">
          <span class="vk-status" [ngClass]="selectedKaizen.status?.toLowerCase()">{{selectedKaizen.status || 'Pending'}}</span>
          <button class="vk-close" (click)="selectedKaizen=null">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>
      </div>

      <div class="vk-modal-body">
        <!-- Meta chips -->
        <div class="vk-detail-grid">
          <div class="vk-detail-card">
            <label>Employee</label>
            <strong>{{selectedKaizen.emp_name}}</strong>
          </div>
          <div class="vk-detail-card">
            <label>Department</label>
            <strong>{{selectedKaizen.unit}}</strong>
          </div>
          <div class="vk-detail-card">
            <label>Category</label>
            <strong>{{selectedKaizen.kaizen_category || '—'}}</strong>
          </div>
          <div class="vk-detail-card">
            <label>Section</label>
            <strong>{{selectedKaizen.section || '—'}}</strong>
          </div>
        </div>

        <!-- Before / After -->
        <div class="vk-before-after">
          <div class="vk-image-card">
            <div class="vk-image-title before">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
              BEFORE
            </div>
            <div class="vk-image-box">
              <img *ngIf="selectedKaizen.before_img" [src]="selectedKaizen.before_img">
              <div class="vk-no-image" *ngIf="!selectedKaizen.before_img">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                No Image
              </div>
            </div>
            <div class="vk-desc" *ngIf="selectedKaizen.before_desc">{{selectedKaizen.before_desc}}</div>
          </div>

          <div class="vk-image-card">
            <div class="vk-image-title after">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
              AFTER
            </div>
            <div class="vk-image-box">
              <img *ngIf="selectedKaizen.after_img" [src]="selectedKaizen.after_img">
              <div class="vk-no-image" *ngIf="!selectedKaizen.after_img">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                No Image
              </div>
            </div>
            <div class="vk-desc" *ngIf="selectedKaizen.after_desc">{{selectedKaizen.after_desc}}</div>
          </div>
        </div>

        <div class="vk-modal-actions">
          <button class="vk-download-main" (click)="downloadKaizenPdf(selectedKaizen)">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            Download PDF
          </button>
        </div>
      </div>
    </div>
  </div>

</div>
`,
  styles: [`
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

:host {
  --brand: #E85D04;
  --brand-dark: #c74e03;
  --brand-dim: rgba(232,93,4,0.1);
  --navy: #0F172A;
  --bg: #F0F4F9;
  --card: #FFFFFF;
  --muted: #F8FAFC;
  --t1: #0F172A; --t2: #475569; --t3: #94A3B8;
  --bdr: #E2E8F0;
  --blue: #2563EB; --blue-bg: #EFF6FF;
  --green: #059669; --green-bg: #ECFDF5;
  --amber: #B45309; --amber-bg: #FFFBEB;
  --red: #DC2626; --red-bg: #FEF2F2;
  --violet: #7C3AED; --violet-bg: #F5F3FF;
  font-family: 'Plus Jakarta Sans', sans-serif;
  display: block;
}
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

.vk-app { min-height: 100vh; background: var(--bg); }

/* ══ NAVBAR ══ */
.vk-navbar {
  height: 72px; padding: 0 28px;
  display: flex; align-items: center; justify-content: space-between; gap: 16px;
  position: sticky; top: 0; z-index: 100;
  background: rgba(255,255,255,0.9); backdrop-filter: blur(16px);
  border-bottom: 1px solid var(--bdr);
  box-shadow: 0 2px 16px rgba(15,23,42,0.06);
}
.vk-brand-wrap { display: flex; align-items: center; gap: 14px; }
.vk-logo-wrap {
  width: 48px; height: 48px; border-radius: 14px;
  background: #fff; display: flex; align-items: center; justify-content: center;
  box-shadow: 0 4px 14px rgba(0,0,0,0.1); flex-shrink: 0;
}
.vk-logo-wrap img { width: 34px; object-fit: contain; }
.vk-brand-wrap h1 { font-size: 14px; font-weight: 800; color: var(--t1); letter-spacing: 0.5px; }
.vk-brand-wrap p  { font-size: 11px; color: var(--t3); margin-top: 2px; }

.vk-nav-actions { display: flex; align-items: center; gap: 10px; flex-shrink: 0; }
.vk-login-btn {
  padding: 8px 16px; border-radius: 9px; font-size: 12.5px; font-weight: 700;
  text-decoration: none; background: var(--brand); color: #fff;
  transition: background 0.15s, transform 0.15s; white-space: nowrap;
}
.vk-login-btn:hover { background: var(--brand-dark); transform: translateY(-1px); }
.vk-dash-btn { background: var(--navy); }
.vk-dash-btn:hover { background: #1E293B; }

/* ══ MAIN ══ */
.vk-main { padding: 24px 28px; display: flex; flex-direction: column; gap: 18px; }

/* ══ HERO ══ */
.vk-hero {
  background: linear-gradient(135deg, #0F172A 0%, #1a2744 60%, #162032 100%);
  border-radius: 20px; padding: 24px 28px;
  position: relative; overflow: hidden;
  display: flex; align-items: center; justify-content: space-between; gap: 20px;
}
.mgr-topbar-accent { color: var(--brand); }
.vk-hero-deco-1 { position: absolute; right: -40px; top: -40px; width: 200px; height: 200px; border-radius: 50%; background: rgba(232,93,4,0.08); pointer-events: none; }
.vk-hero-deco-2 { position: absolute; left: 30%; bottom: -60px; width: 160px; height: 160px; border-radius: 50%; background: rgba(99,102,241,0.07); pointer-events: none; }
.vk-hero-badge { display: inline-block; background: rgba(232,93,4,0.2); color: #FB923C; font-size: 10px; font-weight: 700; padding: 3px 10px; border-radius: 20px; text-transform: uppercase; letter-spacing: 0.07em; margin-bottom: 10px; border: 1px solid rgba(232,93,4,0.3); }
.vk-hero-content { position: relative; z-index: 1; }
.vk-hero-content h2 { font-size: 20px; font-weight: 800; color: #F1F5F9; letter-spacing: -0.4px; margin-bottom: 7px; }
.vk-hero-content p  { font-size: 12.5px; color: #475569; line-height: 1.65; max-width: 460px; }
.vk-hero-stats { position: relative; z-index: 1; display: flex; align-items: center; gap: 24px; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1); border-radius: 14px; padding: 14px 22px; flex-shrink: 0; }
.hs-item { text-align: center; }
.hs-num { font-size: 22px; font-weight: 800; color: #F1F5F9; line-height: 1; }
.hs-green { color: #34D399; }
.hs-amber { color: #FBBF24; }
.hs-red   { color: #e41d1d; }
.hs-lbl { font-size: 10px; color: #64748B; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; margin-top: 3px; }
.hs-sep { width: 1px; height: 32px; background: rgba(255,255,255,0.1); }

/* ══ FILTER BAR ══ */
.vk-toolbar {
  display: flex; align-items: flex-end; gap: 12px; flex-wrap: wrap;
  background: var(--card); border: 1px solid var(--bdr);
  border-radius: 16px; padding: 14px 18px;
  box-shadow: 0 2px 10px rgba(15,23,42,0.05);
}
.vk-search {
  flex: 1; min-width: 220px; max-width: 340px;
  height: 42px; padding: 0 14px;
  border-radius: 10px; background: var(--muted);
  border: 1px solid var(--bdr);
  display: flex; align-items: center; gap: 9px;
  transition: border-color 0.15s;
  /* Keep search vertically centered even when date error shows below filters */
  align-self: flex-start;
  margin-top: 20px; /* matches label height so inputs align */
}
.vk-search:focus-within { border-color: var(--brand); background: #fff; }
.vk-search svg { color: var(--t3); flex-shrink: 0; }
.vk-search input { flex: 1; border: none; outline: none; background: none; color: var(--t1); font-size: 13px; font-weight: 500; font-family: inherit; }
.vk-search input::placeholder { color: var(--t3); }

.vk-filters { display: flex; align-items: flex-end; gap: 10px; flex-wrap: wrap; }
.filter-item { display: flex; flex-direction: column; gap: 4px; }
.filter-item label { font-size: 10px; font-weight: 700; color: var(--t3); text-transform: uppercase; letter-spacing: 0.06em; }
.filter-item select,
.filter-item .date-input {
  height: 42px; padding: 0 12px;
  border-radius: 10px; border: 1px solid var(--bdr);
  background: var(--muted); color: var(--t1);
  font-size: 12.5px; font-weight: 600; font-family: inherit;
  outline: none; cursor: pointer;
  transition: border-color 0.15s, background 0.15s;
}
.filter-item select:focus,
.filter-item .date-input:focus { border-color: var(--brand); background: #fff; }
.filter-item .date-input { padding: 0 10px; min-width: 130px; }

/* ── Date group: inputs side-by-side, error below — no layout shift ── */
/* ===== DATE ROW ===== */

.vk-date-row{
  display:flex;
  align-items:flex-end;
  gap:10px;
}


/* ===== ERROR RIGHT SIDE ===== */

.date-error-side{

  display:flex;
  align-items:center;
  gap:6px;

  height:42px;

  padding:0 12px;

  border-radius:9px;

  background:#FEF2F2;

  border:1px solid rgba(220,38,38,.20);

  color:#DC2626;

  font-size:11px;
  font-weight:600;

  white-space:nowrap;

  margin-bottom:0;
}


.date-error-side svg{

  flex-shrink:0;

  color:#DC2626;
}
.date-error svg { flex-shrink: 0; color: #DC2626; }

.clear-btn {
  display: inline-flex; align-items: center; gap: 5px;
  height: 42px; padding: 0 14px;
  border-radius: 10px; border: 1.5px solid var(--red);
  background: var(--red-bg); color: var(--red);
  font-size: 12px; font-weight: 700; font-family: inherit; cursor: pointer;
  transition: all 0.15s;
}
.clear-btn:hover { background: var(--red); color: #fff; }

.vk-result-count {
  margin-left: auto;
  font-size: 11.5px; font-weight: 600; color: var(--t3);
  background: var(--muted); border: 1px solid var(--bdr);
  padding: 5px 12px; border-radius: 8px;
  align-self: flex-start;
  margin-top: 20px;
}

/* ══ TABLE ══ */
.vk-table-wrapper {
  background: var(--card); border-radius: 18px;
  border: 1px solid var(--bdr);
  box-shadow: 0 4px 20px rgba(15,23,42,0.06);
  overflow: hidden;
}
.vk-table { width: 100%; border-collapse: collapse; }
.vk-table thead { background: var(--muted); }
.vk-table th {
  padding: 13px 18px; text-align: left;
  font-size: 10.5px; font-weight: 700; color: var(--t3);
  text-transform: uppercase; letter-spacing: 0.07em;
  border-bottom: 1px solid var(--bdr); white-space: nowrap;
}
.vk-table td { padding: 12px 18px; border-bottom: 1px solid #F8FAFC; vertical-align: middle; }
.vk-table tbody tr:last-child td { border-bottom: none; }
.vk-table tbody tr { transition: background 0.15s; }
.vk-table tbody tr:hover td { background: #F8FBFF; }

.vk-id { font-size: 11.5px; font-weight: 800; font-family: monospace; color: var(--brand); background: var(--brand-dim); padding: 3px 9px; border-radius: 6px; display: inline-block; }

.vk-user { display: flex; align-items: center; gap: 10px; white-space: nowrap; }
.vk-avatar {
  width: 34px; height: 34px; border-radius: 10px;
  background: linear-gradient(135deg, var(--brand), var(--brand-dark));
  color: #fff; font-weight: 800; font-size: 13px;
  display: grid; place-items: center; flex-shrink: 0;
  box-shadow: 0 4px 10px rgba(232,93,4,0.25);
}
.vk-user h4 { font-size: 12.5px; font-weight: 700; color: var(--t1); }
.vk-user p  { font-size: 10.5px; color: var(--t3); margin-top: 1px; }

.vk-level, .vk-status {
  display: inline-flex; align-items: center; justify-content: center;
  padding: 4px 11px; border-radius: 20px;
  font-size: 10.5px; font-weight: 700; white-space: nowrap; text-transform: capitalize;
}
.vk-level.operator  { background: #ECFDF5; color: #065F46; }
.vk-level.supervisor{ background: var(--amber-bg); color: #92400E; }
.vk-level.manager   { background: var(--violet-bg); color: #5B21B6; }
.vk-status.approved { background: #ECFDF5; color: #059669; }
.vk-status.pending  { background: var(--amber-bg); color: #B45309; }
.vk-status.rejected { background: var(--red-bg); color: var(--red); }

.vk-theme-cell { max-width: 220px; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; font-size: 12.5px; color: var(--t2); }
.vk-unit        { font-size: 12.5px; font-weight: 600; color: var(--t1); }
.vk-section-txt { font-size: 11px; color: var(--t3); margin-top: 2px; }
.vk-date-cell   { font-size: 12px; color: var(--t2); white-space: nowrap; }

.vk-actions { display: flex; gap: 7px; }
.vk-btn {
  display: inline-flex; align-items: center; gap: 5px;
  height: 34px; padding: 0 13px; border-radius: 8px; border: none;
  font-family: inherit; font-size: 11.5px; font-weight: 700;
  cursor: pointer; transition: all 0.15s; white-space: nowrap;
}
.vk-btn:hover { transform: translateY(-1px); }
.vk-btn.view { background: var(--navy); color: #fff; }
.vk-btn.view:hover { background: #1E293B; }
.vk-btn.pdf  { background: var(--brand); color: #fff; }
.vk-btn.pdf:hover { background: var(--brand-dark); }

.vk-empty-row { text-align: center; padding: 48px 20px; color: var(--t3); }
.vk-empty-row p { margin-top: 10px; font-size: 13.5px; }

/* ══ PAGINATION ══ */
.vk-pagination {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 22px; border-top: 1px solid var(--bdr); background: var(--muted);
}
.vk-page-text { font-size: 12px; color: var(--t3); font-weight: 500; }
.vk-page-controls { display: flex; align-items: center; gap: 6px; }
.vk-page-controls > button {
  width: 34px; height: 34px; border-radius: 9px;
  border: 1px solid var(--bdr); background: var(--card);
  display: grid; place-items: center; cursor: pointer; color: var(--t2);
  transition: all 0.15s;
}
.vk-page-controls > button:hover:not(:disabled) { border-color: var(--brand); color: var(--brand); }
.vk-page-controls > button:disabled { opacity: 0.35; cursor: not-allowed; }
.vk-page-nums { display: flex; gap: 4px; }
.pg-num {
  width: 34px; height: 34px; border-radius: 9px;
  border: 1px solid var(--bdr); background: var(--card);
  font-family: inherit; font-size: 12.5px; font-weight: 600; color: var(--t2);
  cursor: pointer; transition: all 0.15s;
}
.pg-num:hover { border-color: var(--brand); color: var(--brand); }
.pg-num.active { background: var(--brand); border-color: var(--brand); color: #fff; }

/* ══ LOADER ══ */
.vk-loader { height: 260px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 16px; }
.vk-loader-ring { width: 48px; height: 48px; border: 4px solid #E2E8F0; border-top-color: var(--brand); border-radius: 50%; animation: spin 0.8s linear infinite; }
.vk-loader span { color: var(--t3); font-weight: 600; font-size: 13px; }
@keyframes spin { to { transform: rotate(360deg); } }

/* ══ MODAL ══ */
.vk-modal-overlay {
  position: fixed; inset: 0;
  background: rgba(15,23,42,0.55); backdrop-filter: blur(6px);
  display: flex; align-items: center; justify-content: center;
  padding: 20px; z-index: 3000;
}
.vk-modal {
  width: 100%; max-width: 860px; max-height: 88vh;
  border-radius: 20px; overflow: hidden;
  background: var(--card);
  box-shadow: 0 24px 70px rgba(0,0,0,0.22);
  display: flex; flex-direction: column;
  animation: modalIn 0.22s cubic-bezier(0.34,1.4,0.64,1) forwards;
}
@keyframes modalIn { from { opacity:0; transform: scale(0.95) translateY(12px); } to { opacity:1; transform: scale(1) translateY(0); } }

.vk-modal-header {
  display: flex; align-items: flex-start; justify-content: space-between; gap: 14px;
  padding: 16px 22px; border-bottom: 1px solid var(--bdr); flex-shrink: 0;
  background: linear-gradient(135deg, #0F172A 0%, #1a2744 100%);
}
.modal-title-wrap { min-width: 0; }
.modal-badge { display: inline-block; background: rgba(232,93,4,0.25); color: #FB923C; font-size: 9.5px; font-weight: 700; padding: 2px 9px; border-radius: 20px; text-transform: uppercase; letter-spacing: 0.07em; margin-bottom: 5px; border: 1px solid rgba(232,93,4,0.3); }
.vk-modal-header h2 { font-size: 17px; font-weight: 800; color: #F1F5F9; letter-spacing: -0.3px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 520px; }
.vk-modal-header p  { font-size: 11px; color: #475569; margin-top: 3px; }
.modal-hdr-right { display: flex; align-items: center; gap: 10px; flex-shrink: 0; }

.vk-close {
  width: 32px; height: 32px; border-radius: 9px;
  border: 1px solid rgba(255,255,255,0.15); background: rgba(255,255,255,0.08);
  display: grid; place-items: center; cursor: pointer; color: #94A3B8;
  transition: all 0.15s;
}
.vk-close:hover { background: rgba(255,255,255,0.15); color: #F1F5F9; }

.vk-modal-body { overflow-y: auto; padding: 18px 22px; display: flex; flex-direction: column; gap: 14px; }

.vk-detail-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 10px; }
.vk-detail-card { padding: 11px 14px; border-radius: 12px; background: var(--muted); border: 1px solid var(--bdr); }
.vk-detail-card label { display: block; font-size: 9.5px; color: var(--t3); font-weight: 700; text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 4px; }
.vk-detail-card strong { font-size: 13px; font-weight: 700; color: var(--t1); }

.vk-before-after { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.vk-image-card { border-radius: 14px; overflow: hidden; border: 1px solid var(--bdr); background: var(--card); box-shadow: 0 2px 10px rgba(15,23,42,0.05); }
.vk-image-title {
  display: flex; align-items: center; gap: 7px;
  padding: 9px 14px; font-size: 11px; font-weight: 700; color: #fff;
  text-transform: uppercase; letter-spacing: 0.06em;
}
.vk-image-title.before { background: #DC2626; }
.vk-image-title.after  { background: #059669; }
.vk-image-box { height: 180px; background: #F1F5F9; overflow: hidden; }
.vk-image-box img { width: 100%; height: 100%; object-fit: cover; }
.vk-no-image { width: 100%; height: 100%; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 8px; color: var(--t3); font-size: 12px; }
.vk-desc { padding: 10px 14px; font-size: 11.5px; color: var(--t2); line-height: 1.6; border-top: 1px solid var(--bdr); }

.vk-modal-actions { display: flex; justify-content: flex-end; padding-top: 4px; }
.vk-download-main {
  display: inline-flex; align-items: center; gap: 7px;
  height: 42px; padding: 0 22px; border-radius: 11px; border: none;
  background: linear-gradient(135deg, var(--brand), var(--brand-dark));
  color: #fff; font-family: inherit; font-size: 13px; font-weight: 700;
  cursor: pointer; transition: all 0.15s;
  box-shadow: 0 4px 14px rgba(232,93,4,0.3);
}
.vk-download-main:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(232,93,4,0.4); }
  `]
})
export class ViewKaizenComponent implements OnInit {
  allKaizens: any[] = [];
  filteredKaizens: any[] = [];
  pagedKaizens: any[] = [];
  totalKaizens = 0;
  approvedCount = 0;
  pendingCount = 0;
  rejectedCount = 0;
  selectedKaizen: any = null;
  searchTerm = '';
  statusFilter = '';
  sourceFilter = '';
  dateFrom = '';
  dateTo = '';
  dateError = '';
  isLoading = true;
  isLoggedIn = !!sessionStorage.getItem('jwt_token');
  currentPage = 1;
  itemsPerPage = 10;
  totalPages = 1;
  Math = Math;

  constructor(private http: HttpClient, private cdr: ChangeDetectorRef) {}

  ngOnInit() { this.loadMyKaizens(); }

  getDashboardRoute(): string {
    const r = (sessionStorage.getItem('role') || '').toLowerCase();
    if (r === 'manager') return '/manager-dashboard';
    if (r === 'hod') return '/hod-dashboard';
    if (r === 'business excellence') return '/bex-dashboard';
    return '/dashboard';
  }

  loadMyKaizens() {
    this.isLoading = true;
    const token = sessionStorage.getItem('jwt_token') || '';
    const headers = token ? new HttpHeaders({ 'Authorization': `Bearer ${token}` }) : new HttpHeaders();
    this.http.get<any[]>(`${environment.apiUrl}/api/kaizen/all`, { headers }).subscribe({
      next: (res) => {
        this.allKaizens = Array.isArray(res) ? res : [];
        this.filteredKaizens = [...this.allKaizens];
        this.currentPage = 1;
        this.calculateAnalytics();
        this.updatePagination();
        this.isLoading = false;
        this.cdr.detectChanges();
      },
      error: () => { this.isLoading = false; this.cdr.detectChanges(); }
    });
  }

  hasActiveFilter(): boolean {
    return !!(this.searchTerm || this.statusFilter || this.sourceFilter || this.dateFrom || this.dateTo);
  }

  clearFilters() {
    this.searchTerm = '';
    this.statusFilter = '';
    this.sourceFilter = '';
    this.dateFrom = '';
    this.dateTo = '';
    this.filterKaizens();
  }

  filterKaizens() {
    this.dateError = '';

    if (this.dateFrom && this.dateTo) {
      const fromDate = new Date(this.dateFrom).getTime();
      const toDate   = new Date(this.dateTo).getTime();
      if (fromDate > toDate) {
        this.dateError = 'From Date cannot be later than To Date';
        this.filteredKaizens = [];
        this.updatePagination();
        return;
      }
    }

    const term = this.searchTerm.toLowerCase().trim();
    const from = this.dateFrom ? new Date(this.dateFrom).getTime() : null;
    const to   = this.dateTo   ? new Date(this.dateTo + 'T23:59:59').getTime() : null;

    this.filteredKaizens = this.allKaizens.filter(k => {
      const matchSearch =
        !term ||
        (k.kaizen_id || '').toLowerCase().includes(term) ||
        (k.emp_name  || '').toLowerCase().includes(term) ||
        (k.emp_id    || '').toLowerCase().includes(term) ||
        (k.source    || '').toLowerCase().includes(term) ||
        (k.theme     || '').toLowerCase().includes(term) ||
        (k.unit      || '').toLowerCase().includes(term) ||
        (k.section   || '').toLowerCase().includes(term) ||
        (k.status    || '').toLowerCase().includes(term);

      const matchStatus = !this.statusFilter || k.status === this.statusFilter;
      const matchSource = !this.sourceFilter || k.source === this.sourceFilter;

      let matchDate = true;
      if (from || to) {
        const d = k.created_at ? new Date(k.created_at).getTime() : null;
        if (!d) { matchDate = false; }
        else {
          if (from && d < from) matchDate = false;
          if (to   && d > to)   matchDate = false;
        }
      }

      return matchSearch && matchStatus && matchSource && matchDate;
    });

    this.currentPage = 1;
    this.updatePagination();
  }

  updatePagination() {
    this.totalPages = Math.max(1, Math.ceil(this.filteredKaizens.length / this.itemsPerPage));
    const start = (this.currentPage - 1) * this.itemsPerPage;
    this.pagedKaizens = this.filteredKaizens.slice(start, start + this.itemsPerPage);
  }

  calculateAnalytics() {
    this.totalKaizens  = this.allKaizens.length;
    this.approvedCount = this.allKaizens.filter(k => k.status?.toLowerCase() === 'approved').length;
    this.pendingCount  = this.allKaizens.filter(k => k.status?.toLowerCase() === 'pending').length;
    this.rejectedCount = this.allKaizens.filter(k => k.status?.toLowerCase() === 'rejected').length;
  }

  pageNumbers(): number[] {
    const total = this.totalPages;
    const cur   = this.currentPage;
    if (total <= 5) return Array.from({ length: total }, (_, i) => i + 1);
    const pages: number[] = [];
    if (cur > 2)           pages.push(1);
    if (cur > 3)           pages.push(-1);
    for (let i = Math.max(1, cur - 1); i <= Math.min(total, cur + 1); i++) pages.push(i);
    if (cur < total - 2)   pages.push(-1);
    if (cur < total - 1)   pages.push(total);
    return [...new Set(pages)];
  }

  goToPage(p: number) { if (p > 0) { this.currentPage = p; this.updatePagination(); } }
  nextPage() { if (this.currentPage < this.totalPages) { this.currentPage++; this.updatePagination(); } }
  prevPage() { if (this.currentPage > 1)               { this.currentPage--; this.updatePagination(); } }
  openFullDetails(k: any) { this.selectedKaizen = k; }

  downloadKaizenPdf(k: any) {
    const source = (k.source || '').toLowerCase();
    if (source === 'operator') this.downloadOperatorPdf(k);
    else                       this.downloadSupervisorManagerPdf(k);
  }

  private loadImg(url: string): Promise<string | null> {
    return new Promise(resolve => {
      if (!url) { resolve(null); return; }
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload  = () => {
        const c = document.createElement('canvas');
        c.width = img.naturalWidth; c.height = img.naturalHeight;
        c.getContext('2d')!.drawImage(img, 0, 0);
        resolve(c.toDataURL('image/jpeg', 0.85));
      };
      img.onerror = () => resolve(null);
      img.src = url;
    });
  }

  private fmtDate(val: unknown): string {
    if (!val) return '';
    try {
      const d = new Date(String(val));
      if (isNaN(d.getTime())) return String(val);
      return `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${d.getFullYear()}`;
    } catch { return String(val); }
  }

  private async downloadOperatorPdf(k: any) {
    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
    const setTC = (r:number,g:number,b:number) => doc.setTextColor(r,g,b);
    const setFC = (r:number,g:number,b:number) => doc.setFillColor(r,g,b);
    const setDC = (r:number,g:number,b:number) => doc.setDrawColor(r,g,b);
    const ML=10,MT=8,CW=190,HALF=CW/2;
    const fsr=(x:number,y:number,w:number,h:number,fr:number,fg:number,fb:number)=>{setFC(fr,fg,fb);setDC(0,0,0);doc.setLineWidth(0.4);doc.rect(x,y,w,h,'FD');};
    const sr=(x:number,y:number,w:number,h:number)=>{setFC(255,255,255);setDC(0,0,0);doc.setLineWidth(0.4);doc.rect(x,y,w,h,'FD');};
    const txt=(s:string,x:number,y:number,size:number,style:string,tr:number,tg:number,tb:number,align:'left'|'center'|'right'='left',maxW?:number)=>{doc.setFontSize(size);doc.setFont('helvetica',style);setTC(tr,tg,tb);const opts:any={align};if(maxW!==undefined)opts.maxWidth=maxW;doc.text(String(s??''),x,y,opts);};
    const [beforeData,afterData,logoData]=await Promise.all([this.loadImg(k.before_img),this.loadImg(k.after_img),this.loadImg('assets/shaktiman_logo.png')]);
    let y=MT;
    const hdrH=14;fsr(ML,y,CW,hdrH,208,228,240);txt('TIRTH AGRO TECHNOLOGY PVT LTD',ML+CW/2,y+6,12,'bold',0,0,0,'center');txt('(SHAKTIMAN)',ML+CW/2,y+11,9,'normal',0,0,0,'center');if(logoData){doc.addImage(logoData,'JPEG',ML+CW-22,y+1,20,12);}y+=hdrH;
    sr(ML,y,CW,8);txt('Kaizen Idea Sheet-Opertor Level',ML+CW/2,y+5.5,10,'bold',0,0,0,'center');y+=8;
    sr(ML,y,HALF,6);txt('Document Code : TA/QMS/KIS-OL',ML+2,y+4,7,'normal',0,0,0);sr(ML+HALF,y,HALF,6);txt('Rev. 00/01.06.2018',ML+HALF+2,y+4,7,'normal',0,0,0);y+=6;
    sr(ML,y,CW,8);txt('Theme :-',ML+2,y+5,7,'bold',0,0,0);txt(k.theme||'',ML+22,y+5,7,'normal',0,0,0,'left',CW-26);y+=8;
    sr(ML,y,CW,8);txt('Department :-',ML+2,y+5,7,'bold',0,0,0);txt(k.depo||k.unit||'',ML+30,y+5,7,'normal',0,0,0,'left',CW-34);y+=8;
    sr(ML,y,HALF,8);txt('Section :-',ML+2,y+5,7,'bold',0,0,0);txt(k.section||'',ML+22,y+5,7,'normal',0,0,0,'left',HALF-26);sr(ML+HALF,y,HALF,8);txt('Machine No. :-',ML+HALF+2,y+5,7,'bold',0,0,0);txt(k.machine_no||'',ML+HALF+30,y+5,7,'normal',0,0,0,'left',HALF-34);y+=8;
    sr(ML,y,CW,8);txt('Kaizen Sr No :-',ML+2,y+5,7,'bold',0,0,0);txt(k.kaizen_id||'',ML+32,y+5,7,'normal',0,0,0);y+=8;
    sr(ML,y,HALF,8);txt('Kaizen Start Date :-',ML+2,y+5,7,'bold',0,0,0);txt(this.fmtDate(k.start_date||k.created_at),ML+40,y+5,7,'normal',0,0,0);sr(ML+HALF,y,HALF,8);txt('Kaizen End Date :-',ML+HALF+2,y+5,7,'bold',0,0,0);txt(this.fmtDate(k.end_date),ML+HALF+37,y+5,7,'normal',0,0,0);y+=8;
    sr(ML,y,HALF,7);txt('Before: (Illustration with sketch & Date)',ML+HALF/2,y+4.5,7,'bold',0,0,0,'center');sr(ML+HALF,y,HALF,7);txt('After: (Illustration with sketch & Date)',ML+HALF+HALF/2,y+4.5,7,'bold',0,0,0,'center');y+=7;
    const imgH=60;sr(ML,y,HALF,imgH);sr(ML+HALF,y,HALF,imgH);if(beforeData){doc.addImage(beforeData,'JPEG',ML+1,y+1,HALF-2,imgH-2);}else{txt('No Image Available',ML+HALF/2,y+imgH/2,7,'italic',160,160,160,'center');}if(afterData){doc.addImage(afterData,'JPEG',ML+HALF+1,y+1,HALF-2,imgH-2);}else{txt('No Image Available',ML+HALF+HALF/2,y+imgH/2,7,'italic',160,160,160,'center');}y+=imgH;
    sr(ML,y,HALF,8);txt('Date :-',ML+2,y+5,7,'bold',0,0,0);sr(ML+HALF,y,HALF,8);txt('Date :-',ML+HALF+2,y+5,7,'bold',0,0,0);y+=8;
    sr(ML,y,HALF,20);txt('Before Condition :-',ML+2,y+5,7,'bold',0,0,0);doc.setFontSize(7);doc.setFont('helvetica','normal');setTC(0,0,0);doc.text(doc.splitTextToSize(k.before_desc||'',HALF-4),ML+2,y+10,{maxWidth:HALF-4});sr(ML+HALF,y,HALF,20);txt('After Condition :-',ML+HALF+2,y+5,7,'bold',0,0,0);doc.setFontSize(7);doc.setFont('helvetica','normal');setTC(0,0,0);doc.text(doc.splitTextToSize(k.after_desc||'',HALF-4),ML+HALF+2,y+10,{maxWidth:HALF-4});y+=20;
    const TW=CW*0.55,RW=CW-TW;sr(ML,y,TW,22);txt('Team Members :-',ML+2,y+5,7,'bold',0,0,0);const teamVal=k.team_members||k.team||k.emp_name||'';doc.setFontSize(7);doc.setFont('helvetica','normal');setTC(0,0,0);doc.text(doc.splitTextToSize(teamVal,TW-4),ML+2,y+10,{maxWidth:TW-4});sr(ML+TW,y,RW,22);txt('Kaizen Reviewed by: (KK Team)',ML+TW+2,y+5,7,'bold',0,0,0);txt('Sign : _______________________',ML+TW+2,y+11,7,'normal',0,0,0);txt('Date : _______________________',ML+TW+2,y+17,7,'normal',0,0,0);y+=22;
    setDC(0,0,0);doc.setLineWidth(0.8);doc.rect(ML,MT,CW,y-MT,'S');
    doc.save(`Kaizen_${k.kaizen_id||'download'}_Operator.pdf`);
  }

  private async downloadSupervisorManagerPdf(k: any) {
    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
    const setTC=(r:number,g:number,b:number)=>doc.setTextColor(r,g,b);
    const setFC=(r:number,g:number,b:number)=>doc.setFillColor(r,g,b);
    const setDC=(r:number,g:number,b:number)=>doc.setDrawColor(r,g,b);
    const ML=8,MT=6,CW=194,HALF=CW/2;
    const fsr=(x:number,y:number,w:number,h:number,fr:number,fg:number,fb:number)=>{setFC(fr,fg,fb);setDC(0,0,0);doc.setLineWidth(0.35);doc.rect(x,y,w,h,'FD');};
    const sr=(x:number,y:number,w:number,h:number)=>{setFC(255,255,255);setDC(0,0,0);doc.setLineWidth(0.35);doc.rect(x,y,w,h,'FD');};
    const txt=(s:string,x:number,y:number,size:number,style:string,tr:number,tg:number,tb:number,align:'left'|'center'|'right'='left',maxW?:number)=>{doc.setFontSize(size);doc.setFont('helvetica',style);setTC(tr,tg,tb);const opts:any={align};if(maxW!==undefined)opts.maxWidth=maxW;doc.text(String(s??''),x,y,opts);};
    const [beforeData,afterData,logoData]=await Promise.all([this.loadImg(k.before_img),this.loadImg(k.after_img),this.loadImg('assets/shaktiman_logo.png')]);
    let y=MT;
    fsr(ML,y,CW,14,208,228,240);txt('TIRTH AGRO TECHNOLOGY PVT LTD',ML+CW/2,y+6,12,'bold',0,0,0,'center');txt('(SHAKTIMAN)',ML+CW/2,y+11,9,'normal',0,0,0,'center');if(logoData){doc.addImage(logoData,'JPEG',ML+CW-22,y+1,20,12);}y+=14;
    sr(ML,y,CW,8);txt('Kaizen Idea Sheet-Senior Level',ML+CW/2,y+5.5,10,'bold',0,0,0,'center');y+=8;
    sr(ML,y,HALF,6);txt('Document Code : TA/QMS/KIS-SL',ML+2,y+4,7,'normal',0,0,0);sr(ML+HALF,y,HALF,6);txt('Rev. 00/01.06.2018',ML+HALF+2,y+4,7,'normal',0,0,0);y+=6;
    const actLabW=28;const actCols=['KK','JH','QM','PM','SHE','OTPM','DM','ET','5S'];const actCW=(CW-actLabW)/actCols.length;
    sr(ML,y,actLabW,6);txt('Activity',ML+actLabW/2,y+4,7,'bold',0,0,0,'center');actCols.forEach((col,i)=>{const cx=ML+actLabW+i*actCW;sr(cx,y,actCW,6);txt(col,cx+actCW/2,y+4,7,'bold',0,0,0,'center');});y+=6;
    sr(ML,y,actLabW,6);txt('Loss No./ Step',ML+actLabW/2,y+4,6.5,'bold',0,0,0,'center');actCols.forEach((_,i)=>{sr(ML+actLabW+i*actCW,y,actCW,6);});y+=6;
    const raVals=['P','Q','C','D','S','M','','',''];const pqcdsm=(k.pqcdsm||'').toUpperCase();
    sr(ML,y,actLabW,6);txt('Result Area',ML+actLabW/2,y+4,6.5,'bold',0,0,0,'center');
    raVals.forEach((val,i)=>{const cx=ML+actLabW+i*actCW;const matched=val!==''&&pqcdsm.includes(val);if(matched){fsr(cx,y,actCW,6,144,238,144);}else{sr(cx,y,actCW,6);}if(val)txt(val,cx+actCW/2,y+4,7,'bold',0,0,0,'center');});y+=6;
    const C3=CW/3;sr(ML,y,C3,8);txt('Plant :',ML+2,y+5,7,'bold',0,0,0);txt(k.unit||'',ML+17,y+5,7,'normal',0,0,0,'left',C3-20);sr(ML+C3,y,C3,8);txt('Machine :',ML+C3+2,y+5,7,'bold',0,0,0);txt(k.machine_no||'',ML+C3+20,y+5,7,'normal',0,0,0,'left',C3-23);sr(ML+C3*2,y,C3,8);txt('Kaizen Sr. No. :',ML+C3*2+2,y+5,7,'bold',0,0,0);txt(k.kaizen_id||'',ML+C3*2+30,y+5,7,'normal',0,0,0,'left',C3-33);y+=8;
    const lblW=CW*0.30,valW=CW-lblW;sr(ML,y,lblW,8);txt('Kaizen theme :',ML+2,y+5,7,'bold',0,0,0);sr(ML+lblW,y,valW,8);txt(k.theme||'',ML+lblW+2,y+5,7,'normal',0,0,0,'left',valW-4);y+=8;
    const LCW=Math.round(CW*0.28),MCW=Math.round(CW*0.40),RCW=CW-LCW-MCW;
    const LCX=ML,MCX=ML+LCW,RCX=ML+LCW+MCW;
    let lY=y,mY=y,rY=y;
    sr(LCX,lY,LCW,6);txt('Problem/present status : Description',LCX+2,lY+4,6.5,'bold',0,0,0,'left',LCW-4);lY+=6;
    sr(LCX,lY,LCW,20);doc.setFontSize(7);doc.setFont('helvetica','normal');setTC(0,0,0);doc.text(doc.splitTextToSize(k.analysis||'',LCW-4),LCX+2,lY+4,{maxWidth:LCW-4});lY+=20;
    sr(LCX,lY,LCW,6);txt('Present status sketch/photo',LCX+LCW/2,lY+4,6.5,'bold',0,0,0,'center');lY+=6;sr(LCX,lY,LCW,25);lY+=25;
    sr(LCX,lY,LCW,6);txt('Why - why analysis : / Problem Phenomenon :',LCX+2,lY+4,6.5,'bold',0,0,0,'left',LCW-4);lY+=6;
    const whys:any[]=[['Why 1 :',String(k.why1||'')],['Why 2 :',String(k.why2||'')],['Why 3 :',String(k.why3||'')],['Why 4 :',String(k.why4||'')]];
    whys.forEach(([label,val]:any)=>{sr(LCX,lY,LCW,7);txt(label,LCX+2,lY+4.5,7,'bold',0,0,0);txt(val,LCX+16,lY+4.5,7,'normal',0,0,0,'left',LCW-20);lY+=7;});
    sr(LCX,lY,LCW,10);txt('Root Cause :',LCX+2,lY+4,7,'bold',0,0,0);doc.setFontSize(7);doc.setFont('helvetica','normal');setTC(0,0,0);doc.text(doc.splitTextToSize(k.root_cause||'',LCW-4),LCX+2,lY+8,{maxWidth:LCW-4});lY+=10;
    sr(MCX,mY,MCW,6);txt('Countermeasure(Engineering solution):',MCX+2,mY+4,6.5,'bold',0,0,0,'left',MCW-4);mY+=6;
    sr(MCX,mY,MCW,18);doc.setFontSize(7);doc.setFont('helvetica','normal');setTC(0,0,0);doc.text(doc.splitTextToSize(k.countermeasure||'',MCW-4),MCX+2,mY+4,{maxWidth:MCW-4});mY+=18;
    const MH=MCW/2;sr(MCX,mY,MH,6);txt('Before :',MCX+MH/2,mY+4,7,'bold',0,0,0,'center');sr(MCX+MH,mY,MH,6);txt('After :',MCX+MH+MH/2,mY+4,7,'bold',0,0,0,'center');mY+=6;
    const imgRowH2=42;sr(MCX,mY,MH,imgRowH2);sr(MCX+MH,mY,MH,imgRowH2);if(beforeData){doc.addImage(beforeData,'JPEG',MCX+1,mY+1,MH-2,imgRowH2-2);}else{txt('No Image Available',MCX+MH/2,mY+imgRowH2/2,6.5,'italic',160,160,160,'center');}if(afterData){doc.addImage(afterData,'JPEG',MCX+MH+1,mY+1,MH-2,imgRowH2-2);}else{txt('No Image Available',MCX+MH+MH/2,mY+imgRowH2/2,6.5,'italic',160,160,160,'center');}mY+=imgRowH2;
    sr(MCX,mY,MH,12);txt('Brief Description :',MCX+2,mY+4,6.5,'bold',0,0,0);doc.setFontSize(6.5);doc.setFont('helvetica','normal');setTC(0,0,0);doc.text(doc.splitTextToSize(k.before_desc||'',MH-4),MCX+2,mY+8,{maxWidth:MH-4});sr(MCX+MH,mY,MH,12);txt('Brief Description :',MCX+MH+2,mY+4,6.5,'bold',0,0,0);doc.setFontSize(6.5);doc.setFont('helvetica','normal');setTC(0,0,0);doc.text(doc.splitTextToSize(k.after_desc||'',MH-4),MCX+MH+2,mY+8,{maxWidth:MH-4});mY+=12;
    sr(MCX,mY,MCW,6);txt('Results :',MCX+2,mY+4,7,'bold',0,0,0);mY+=6;sr(MCX,mY,MCW,14);doc.setFontSize(7);doc.setFont('helvetica','normal');setTC(0,0,0);doc.text(doc.splitTextToSize(k.benefits_pqcdsm||'',MCW-4),MCX+2,mY+4,{maxWidth:MCW-4});mY+=14;
    sr(MCX,mY,MCW,6);txt('Illustration with line chart/ graph :',MCX+2,mY+4,6.5,'bold',0,0,0);mY+=6;sr(MCX,mY,MCW,18);mY+=18;sr(MCX,mY,MCW,7);txt('Note: Use separate sheet for better understanding, if needed',MCX+2,mY+4.5,6.5,'italic',80,80,80);mY+=7;
    const RLW=RCW*0.45,RVW=RCW-RLW;
    const rLvRows:any[]=[['Bench mark',k.benchmark||''],['Target',k.target||''],['Kaizen start',this.fmtDate(k.start_date||k.created_at)],['Kaizen Finish',this.fmtDate(k.end_date)]];
    rLvRows.forEach(([label,val]:any)=>{sr(RCX,rY,RLW,7);txt(label,RCX+2,rY+4.5,7,'bold',0,0,0,'left',RLW-4);sr(RCX+RLW,rY,RVW,7);txt(val,RCX+RLW+2,rY+4.5,7,'normal',0,0,0,'left',RVW-4);rY+=7;});
    sr(RCX,rY,RCW,6);txt('Team members :',RCX+2,rY+4,7,'bold',0,0,0);rY+=6;sr(RCX,rY,RCW,22);const tmVal=k.team_members||k.team||k.emp_name||'';doc.setFontSize(7);doc.setFont('helvetica','normal');setTC(0,0,0);doc.text(doc.splitTextToSize(tmVal,RCW-4),RCX+2,rY+4,{maxWidth:RCW-4});rY+=22;
    sr(RCX,rY,RCW,6);txt('Benefits: (P,Q,C,D,S,M)',RCX+2,rY+4,7,'bold',0,0,0);rY+=6;sr(RCX,rY,RCW,12);doc.setFontSize(7);doc.setFont('helvetica','normal');setTC(0,0,0);doc.text(doc.splitTextToSize(k.benefits_pqcdsm||'',RCW-4),RCX+2,rY+4,{maxWidth:RCW-4});rY+=12;
    sr(RCX,rY,RCW,6);txt('Scope & plan for Horizontal Deployment',RCX+2,rY+4,6.5,'bold',0,0,0,'left',RCW-4);rY+=6;
    const hdCols:any[]=[['Sr.no.',0.10],['M/c.',0.18],['Target date',0.22],['Responsibility',0.28],['Status',0.22]];
    let hx=RCX;hdCols.forEach(([label,ratio]:any)=>{const cw=RCW*ratio;fsr(hx,rY,cw,5,230,230,230);txt(label,hx+cw/2,rY+3.5,6,'bold',0,0,0,'center');hx+=cw;});rY+=5;
    for(let ri=0;ri<5;ri++){hx=RCX;hdCols.forEach(([,ratio]:any)=>{const cw=RCW*ratio;sr(hx,rY,cw,5);hx+=cw;});rY+=5;}
    sr(RCX,rY,RCW,10);txt('Reviewed By :',RCX+2,rY+4,7,'bold',0,0,0);txt('Sign : __________ Date : __________',RCX+2,rY+8.5,6.5,'normal',0,0,0);rY+=10;
    const endY=Math.max(lY,mY,rY);if(lY<endY){sr(LCX,lY,LCW,endY-lY);}if(mY<endY){sr(MCX,mY,MCW,endY-mY);}if(rY<endY){sr(RCX,rY,RCW,endY-rY);}
    setDC(0,0,0);doc.setLineWidth(0.8);doc.rect(ML,MT,CW,endY-MT,'S');
    doc.save(`Kaizen_${k.kaizen_id||'download'}_Senior.pdf`);
  }
}