import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';

@Component({
  selector: 'app-bex-layout',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './bex-layout.component.html',
  styleUrls: ['./bex-layout.component.css']
})
export class BexLayoutComponent implements OnInit {

  sidebarClosed   = false;
  showLogoutModal = false;

  userName    = 'Admin';
  userRole    = 'Business Excellence';
  userInitial = 'A';

  constructor(private router: Router) {}

  ngOnInit(): void {
    const name = sessionStorage.getItem('user_id')
              || sessionStorage.getItem('username')
              || sessionStorage.getItem('name')
              || 'Admin';
    const role = sessionStorage.getItem('role') || 'Business Excellence';
    this.userName    = name;
    this.userRole    = role;
    this.userInitial = name.charAt(0).toUpperCase();
  }

  toggleSidebar(): void {
    this.sidebarClosed = !this.sidebarClosed;
  }

  /** Opens the logout confirmation modal */
  openLogoutModal(): void {
    this.showLogoutModal = true;
  }

  /** Closes the modal without logging out */
  closeLogoutModal(): void {
    this.showLogoutModal = false;
  }

  /** Called when user confirms Sign Out in the modal */
  confirmLogout(): void {
    this.showLogoutModal = false;
    sessionStorage.clear();
    localStorage.clear();
    window.history.replaceState(null, '', '/');
    window.location.replace('/');
  }
}