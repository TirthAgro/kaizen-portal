import { environment } from '../../../environments/environment';
import { Component, OnInit, ChangeDetectorRef, ViewChild, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

// ══════════════════════════════════════════
// TOAST COMPONENT
// ══════════════════════════════════════════
@Component({
  selector: 'app-mu-toast',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="mu-toast-stack">
      <div *ngFor="let t of toasts" class="mu-toast" [ngClass]="t.type" [class.show]="t.show">
        <div class="mu-toast-icon">{{ icons[t.type] }}</div>
        <div class="mu-toast-body">
          <span class="mu-toast-title">{{ titles[t.type] }}</span>
          <span class="mu-toast-msg">{{ t.message }}</span>
        </div>
        <button class="mu-toast-close" (click)="remove(t)">✕</button>
        <div class="mu-toast-bar" [ngClass]="t.type"></div>
      </div>
    </div>
  `,
  styles: [`
    .mu-toast-stack {
      position: fixed; bottom: 28px; right: 28px; z-index: 99999;
      display: flex; flex-direction: column; gap: 12px; pointer-events: none;
    }
    .mu-toast {
      pointer-events: all;
      display: flex; align-items: center; gap: 13px;
      min-width: 310px; max-width: 400px;
      padding: 15px 18px; border-radius: 16px;
      background: #1e1e2e;
      box-shadow: 0 10px 36px rgba(0,0,0,.38);
      border-left: 4px solid transparent;
      transform: translateX(115%); opacity: 0;
      transition: transform 0.38s cubic-bezier(0.34,1.56,0.64,1), opacity 0.38s ease;
      overflow: hidden; position: relative;
    }
    .mu-toast.show { transform: translateX(0); opacity: 1; }
    .mu-toast.success { border-color: #4ade80; }
    .mu-toast.error   { border-color: #f87171; }
    .mu-toast.warning { border-color: #fbbf24; }
    .mu-toast.info    { border-color: #60a5fa; }
    .mu-toast-icon { font-size: 22px; flex-shrink: 0; }
    .mu-toast-body { display: flex; flex-direction: column; gap: 2px; flex: 1; }
    .mu-toast-title { font-size: 11px; font-weight: 800; letter-spacing: 0.7px; text-transform: uppercase; color: #e2e8f0; }
    .mu-toast-msg { font-size: 13px; color: #94a3b8; line-height: 1.4; }
    .mu-toast-close { background: none; border: none; color: #475569; cursor: pointer; font-size: 12px; padding: 2px 4px; flex-shrink: 0; transition: color .2s; }
    .mu-toast-close:hover { color: #e2e8f0; }
    .mu-toast-bar { position: absolute; bottom: 0; left: 0; height: 3px; width: 100%; animation: mu-shrink 3.5s linear forwards; }
    .mu-toast-bar.success { background: #4ade80; }
    .mu-toast-bar.error   { background: #f87171; }
    .mu-toast-bar.warning { background: #fbbf24; }
    .mu-toast-bar.info    { background: #60a5fa; }
    @keyframes mu-shrink { from { width: 100%; } to { width: 0%; } }
  `]
})
export class MuToastComponent {
  toasts: { id: number; message: string; type: string; show: boolean }[] = [];
  private counter = 0;
  icons:  Record<string, string> = { success: '✅', error: '🚫', warning: '⚠️', info: 'ℹ️' };
  titles: Record<string, string> = { success: 'Success', error: 'Error', warning: 'Warning', info: 'Info' };

  show(message: string, type: 'success' | 'error' | 'warning' | 'info' = 'info', duration = 3500) {
    const toast = { id: ++this.counter, message, type, show: false };
    this.toasts.push(toast);
    setTimeout(() => toast.show = true, 20);
    setTimeout(() => this.remove(toast), duration);
  }

  remove(toast: any) {
    toast.show = false;
    setTimeout(() => this.toasts = this.toasts.filter(t => t.id !== toast.id), 420);
  }
}

// ══════════════════════════════════════════
// CONFIRM DIALOG COMPONENT
// ══════════════════════════════════════════
@Component({
  selector: 'app-mu-confirm',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="mu-overlay" [class.show]="visible" (click)="onBg($event)">
      <div class="mu-box" [class.show]="visible">
        <div class="mu-box-icon">🗑️</div>
        <div class="mu-box-title">{{ title }}</div>
        <div class="mu-box-msg">{{ message }}</div>
        <div class="mu-box-actions">
          <button class="mu-box-cancel" (click)="respond(false)">Cancel</button>
          <button class="mu-box-ok"     (click)="respond(true)">Delete</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .mu-overlay {
      position: fixed; inset: 0; z-index: 99998;
      background: rgba(15,23,42,0.55); backdrop-filter: blur(5px);
      display: flex; align-items: center; justify-content: center;
      opacity: 0; pointer-events: none; transition: opacity .3s ease;
    }
    .mu-overlay.show { opacity: 1; pointer-events: all; }
    .mu-box {
      background: #ffffff; border-radius: 24px;
      padding: 36px 32px 28px; min-width: 320px; max-width: 400px;
      text-align: center; box-shadow: 0 24px 64px rgba(15,23,42,.22);
      transform: scale(0.88) translateY(20px);
      transition: transform 0.35s cubic-bezier(0.34,1.56,0.64,1);
    }
    .mu-box.show { transform: scale(1) translateY(0); }
    .mu-box-icon  { font-size: 44px; margin-bottom: 16px; }
    .mu-box-title { font-size: 18px; font-weight: 800; color: #0f172a; margin-bottom: 10px; }
    .mu-box-msg   { font-size: 14px; color: #64748b; line-height: 1.5; margin-bottom: 28px; }
    .mu-box-actions { display: flex; gap: 12px; }
    .mu-box-cancel { flex: 1; height: 46px; border-radius: 14px; border: 1px solid #e2e8f0; background: #fff; font-size: 13px; font-weight: 700; color: #64748b; cursor: pointer; transition: .2s ease; }
    .mu-box-cancel:hover { background: #f8fafc; border-color: #cbd5e1; }
    .mu-box-ok { flex: 1; height: 46px; border-radius: 14px; border: none; background: linear-gradient(135deg, #ef4444, #f87171); font-size: 13px; font-weight: 700; color: #fff; cursor: pointer; transition: .2s ease; box-shadow: 0 8px 20px rgba(239,68,68,.28); }
    .mu-box-ok:hover { transform: translateY(-2px); box-shadow: 0 12px 28px rgba(239,68,68,.36); }
  `]
})
export class MuConfirmComponent {
  visible = false;
  title   = 'Confirm Delete';
  message = 'Are you sure? This action cannot be undone.';
  private resolveFn: ((v: boolean) => void) | null = null;

  open(title: string, message: string): Promise<boolean> {
    this.title = title; this.message = message; this.visible = true;
    return new Promise(r => this.resolveFn = r);
  }

  respond(val: boolean) {
    this.visible = false;
    this.resolveFn?.(val);
    this.resolveFn = null;
  }

  onBg(e: MouseEvent) {
    if ((e.target as HTMLElement).classList.contains('mu-overlay')) this.respond(false);
  }
}

// ══════════════════════════════════════════
// MANAGE USERS COMPONENT
// ══════════════════════════════════════════
@Component({
  selector: 'app-manage-users',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, MuToastComponent, MuConfirmComponent],
  templateUrl: './manage-users.component.html',
  styleUrls:   ['./manage-users.component.css'],
})
export class ManageUsersComponent implements OnInit, AfterViewInit {
  api = environment.apiUrl + '/api/bex';
  editMode = false;
  searchTerm: string = '';
  showPwd: boolean = false;
  units = ['Unit 1', 'Unit 2', 'Unit 3', 'Unit 4', 'Unit 5'];
  users: any[] = [];
  form: any = { user_id: '', password: '', role: '', plant_id: '', section: '', old_user_id: '', email: '' };
  passwordErrors: string[] = [];
  passwordValid: boolean = false;

  @ViewChild('toast')      toast!: MuToastComponent;
  @ViewChild('confirmDlg') confirmDlg!: MuConfirmComponent;


  private get authHeaders() {
    const token = sessionStorage.getItem('jwt_token') || '';
    return { headers: { 'Authorization': `Bearer ${token}` } };
  }
  constructor(private router: Router, private http: HttpClient, private cdr: ChangeDetectorRef) {}

  ngOnInit() { this.loadUsers(); }
  ngAfterViewInit() {}

  filteredUsers() {
    if (!this.searchTerm) return this.users;
    const term = this.searchTerm.toLowerCase();
    return this.users.filter(u =>
      u.user_id.toLowerCase().includes(term) ||
      u.role.toLowerCase().includes(term) ||
      (u.plant_id && u.plant_id.toLowerCase().includes(term)) ||
      (u.section  && u.section.toLowerCase().includes(term))
    );
  }

  loadUsers() {
    this.http.get<any[]>(`${this.api}?action=get_users&t=${Date.now()}`, this.authHeaders).subscribe(res => {
      this.users = [...res];
      this.cdr.detectChanges();
    });
  }

  saveUser() {
    if (!this.form.role) {
      this.toast.show('Please select a role before saving.', 'warning');
      return;
    }
    this.validatePassword(this.form.password);
    if (!this.passwordValid) {
      this.toast.show('Password issue: ' + this.passwordErrors.join(' | '), 'error');
      return;
    }
    this.http.post(`${this.api}/save-user`, this.form, this.authHeaders).subscribe(() => {
      this.toast.show(this.editMode ? 'User updated successfully!' : 'User enrolled successfully!', 'success');
      this.resetForm();
      this.loadUsers();
    });
  }

  editUser(user: any) {
    this.editMode = true;
    this.form = { ...user, old_user_id: user.user_id };
    window.scrollTo(0, 0);
  }

  async deleteUser(user: any) {
    const ok = await this.confirmDlg.open(
      'Delete User',
      `Are you sure you want to delete "${user.user_id}"? This action cannot be undone.`
    );
    if (ok) {
      this.http.post(`${this.api}/delete-user`, { user_id: user.user_id }).subscribe(() => {
        this.toast.show(`User "${user.user_id}" deleted.`, 'error');
        this.loadUsers();
      });
    }
  }

  validatePassword(pwd: string) {
    const errors: string[] = [];
    const letters = (pwd.match(/[a-zA-Z]/g) || []).length;
    const numbers = (pwd.match(/[0-9]/g)    || []).length;
    const special = (pwd.match(/[^a-zA-Z0-9]/g) || []).length;
    if (letters < 6) errors.push(`Min 6 alphabets (${letters}/6)`);
    if (numbers < 1) errors.push('At least 1 number required');
    if (special < 1) errors.push('At least 1 special character required');
    this.passwordErrors = errors;
    this.passwordValid  = errors.length === 0;
  }

  getPwdStrength(): number {
    const pwd = this.form.password || '';
    let s = 0;
    if ((pwd.match(/[a-zA-Z]/g)     || []).length >= 6) s += 34;
    if ((pwd.match(/[0-9]/g)        || []).length >= 1) s += 33;
    if ((pwd.match(/[^a-zA-Z0-9]/g) || []).length >= 1) s += 33;
    return s;
  }

  getPwdStrengthColor(): string {
    const s = this.getPwdStrength();
    if (s <= 33) return '#ef4444';
    if (s <= 66) return '#f59e0b';
    return '#10b981';
  }

  getPwdStrengthLabel(): string {
    const s = this.getPwdStrength();
    if (s <= 33) return 'Weak';
    if (s <= 66) return 'Medium';
    return 'Strong ✓';
  }

  resetForm() {
    this.editMode = false;
    this.showPwd  = false;
    this.form = { user_id: '', password: '', role: '', plant_id: '', section: '', old_user_id: '', email: '' };
    this.searchTerm    = '';
    this.passwordErrors = [];
    this.passwordValid  = false;
    this.cdr.detectChanges();
  }
}