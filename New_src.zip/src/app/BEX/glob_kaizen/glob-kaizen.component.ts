import { environment } from '../../../environments/environment';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

// ── Toast model ──────────────────────────────────────────────
interface Toast {
  id: number;
  message: string;
  type: 'success' | 'error' | 'warning' | 'info';
}

@Component({
  selector: 'app-glob-kaizen',
  templateUrl: './glob-kaizen.component.html',
  styleUrls:   ['./glob-kaizen.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule],
})
export class GlobKaizenComponent implements OnInit {
  apiBase = environment.apiUrl + '/api/bex';
  isLoading = true;
  allKaizens: any[] = [];
  filteredKaizens: any[] = [];

  filters = {
    unit: '',
    role: '',
    status: '',
    search: '',
    dateFrom: '',
    dateTo: ''
  };

  showModal = false;
  selectedKaizen: any = null;
  bexRemark = '';

  // ── Toast state ────────────────────────────────────────────
  public toasts: Toast[] = [];
  private toastCounter = 0;

  private get authHeaders() {
    const token = sessionStorage.getItem('jwt_token') || '';
    return { headers: { 'Authorization': `Bearer ${token}` } };
  }

  constructor(private http: HttpClient, private cdr: ChangeDetectorRef) {}

  ngOnInit() {
    // Set default date range: last 1 month
    const today = new Date();
    const oneMonthAgo = new Date();
    oneMonthAgo.setMonth(today.getMonth() - 1);

    this.filters.dateTo   = this.formatDate(today);
    this.filters.dateFrom = this.formatDate(oneMonthAgo);

    this.fetchAllKaizens();
  }

  // ── Helpers ───────────────────────────────────────────────
  formatDate(d: Date): string {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  // ── Toast helpers ─────────────────────────────────────────
  showToast(message: string, type: Toast['type'] = 'info', duration = 4000) {
    const id = ++this.toastCounter;
    this.toasts.push({ id, message, type });
    this.cdr.detectChanges();
    setTimeout(() => this.dismissToast(id), duration);
  }

  dismissToast(id: number) {
    this.toasts = this.toasts.filter(t => t.id !== id);
    this.cdr.detectChanges();
  }

  // ── Data methods ──────────────────────────────────────────
  fetchAllKaizens() {
    this.isLoading = true;
    this.http.get<any[]>(`${this.apiBase}?action=get_all`, this.authHeaders).subscribe({
      next: (res) => {
        this.allKaizens = Array.isArray(res) ? res : [];
        this.applyFilters();
        this.isLoading = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.isLoading = false;
        this.cdr.detectChanges();
      }
    });
  }

  applyFilters() {
    this.filteredKaizens = this.allKaizens.filter(k => {
      const matchUnit   = !this.filters.unit   || k.unit   === this.filters.unit;
      const matchRole   = !this.filters.role   || k.role   === this.filters.role;
      const matchStatus = !this.filters.status || k.status === this.filters.status;
      const matchSearch = !this.filters.search ||
        k.theme?.toLowerCase().includes(this.filters.search.toLowerCase()) ||
        k.kaizen_id?.toLowerCase().includes(this.filters.search.toLowerCase());

      // Date filter
      let matchDate = true;
      if (this.filters.dateFrom || this.filters.dateTo) {
        const created = k.created_at ? new Date(k.created_at) : null;
        if (created) {
          if (this.filters.dateFrom) {
            matchDate = matchDate && created >= new Date(this.filters.dateFrom);
          }
          if (this.filters.dateTo) {
            // include full day of dateTo
            const toDate = new Date(this.filters.dateTo);
            toDate.setHours(23, 59, 59, 999);
            matchDate = matchDate && created <= toDate;
          }
        } else {
          matchDate = false;
        }
      }

      return matchUnit && matchRole && matchStatus && matchSearch && matchDate;
    });
  }

  clearAllFilters() {
    const today = new Date();
    const oneMonthAgo = new Date();
    oneMonthAgo.setMonth(today.getMonth() - 1);

    this.filters = {
      unit: '',
      role: '',
      status: '',
      search: '',
      dateFrom: this.formatDate(oneMonthAgo),
      dateTo:   this.formatDate(today)
    };
    this.applyFilters();
  }

  safeImgSrc(imgData: any): string | null {
    if (!imgData) return null;
    const str = String(imgData).trim();
    if (!str) return null;
    if (str.startsWith('http://') || str.startsWith('https://')) return str;
    if (str.startsWith('data:')) return str;
    if (/\.(jpg|jpeg|png|gif|webp)/i.test(str)) {
      return `${environment.apiUrl}/uploads/` + str;
    }
    if (str.length > 100) return 'data:image/jpeg;base64,' + str;
    return null;
  }

  openAudit(kaizen: any) {
    this.selectedKaizen = kaizen;
    this.bexRemark = kaizen.admin_remark || '';
    this.showModal = true;
  }

  updateStatus(newStatus: string) {
    if (!this.bexRemark && newStatus === 'Rejected') {
      this.showToast('A remark is required before rejecting a Kaizen.', 'warning');
      return;
    }

    const payload = {
      id:     this.selectedKaizen.id,
      role:   this.selectedKaizen.role,
      status: newStatus,
      remark: this.bexRemark
    };

    this.http.post(`${this.apiBase}/final-update`, payload, this.authHeaders).subscribe({
      next: (res: any) => {
        if (res.status === 'updated') {
          this.showToast(
            `Kaizen ${this.selectedKaizen.kaizen_id} ${newStatus === 'Approved' ? 'approved' : 'rejected'} successfully.`,
            newStatus === 'Approved' ? 'success' : 'error'
          );
          this.showModal = false;
          this.fetchAllKaizens();
        } else {
          this.showToast('Update failed: ' + (res.message || 'Unknown error'), 'error');
        }
      },
      error: () => this.showToast('Server error during update. Please try again.', 'error')
    });
  }
}