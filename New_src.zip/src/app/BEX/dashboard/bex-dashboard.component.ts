import { environment } from '../../../environments/environment';
import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { RouterModule, Router } from '@angular/router';

@Component({
  selector: 'app-bex-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  encapsulation: ViewEncapsulation.None,
  templateUrl: './bex-dashboard.component.html',
  styleUrls: ['./bex-dashboard.component.css']
})
export class BexDashboardComponent implements OnInit {

  api = environment.apiUrl + '/api/bex';

  unitData: number[] = [0, 0, 0, 0, 0];
  grandTotal = 0;
  selectedUnit: number | null = null;

  unitColors = ['#E8541A', '#7C3AED', '#0891B2', '#16A34A', '#D97706'];

  unitSections = [
    {
      target: 80, approved: 52, pending: 8, saving: '₹18.4L',
      sections: [
        { name: 'Assembly Line A', count: 24, color: '#E8541A' },
        { name: 'Quality Check',   count: 18, color: '#F97316' },
        { name: 'Packaging',       count: 14, color: '#FBBF24' },
        { name: 'Logistics',       count: 10, color: '#F87171' },
        { name: 'Maintenance',     count: 6,  color: '#FCA5A5' }
      ]
    },
    {
      target: 60, approved: 38, pending: 5, saving: '₹11.2L',
      sections: [
        { name: 'Paint Shop',      count: 20, color: '#7C3AED' },
        { name: 'Body Welding',    count: 16, color: '#8B5CF6' },
        { name: 'Engine Assembly', count: 12, color: '#A78BFA' },
        { name: 'Trim Line',       count: 5,  color: '#C4B5FD' },
        { name: 'Inspection',      count: 3,  color: '#DDD6FE' }
      ]
    },
    {
      target: 55, approved: 32, pending: 4, saving: '₹7.9L',
      sections: [
        { name: 'SCM Hub',     count: 18, color: '#0891B2' },
        { name: 'Warehouse A', count: 14, color: '#06B6D4' },
        { name: 'Procurement', count: 9,  color: '#22D3EE' },
        { name: 'Dispatch',    count: 5,  color: '#67E8F9' },
        { name: 'Returns',     count: 2,  color: '#A5F3FC' }
      ]
    },
    {
      target: 70, approved: 45, pending: 6, saving: '₹9.3L',
      sections: [
        { name: 'Quality Lab',    count: 22, color: '#16A34A' },
        { name: 'R&D',            count: 18, color: '#22C55E' },
        { name: 'Process Eng.',   count: 15, color: '#4ADE80' },
        { name: 'Testing',        count: 7,  color: '#86EFAC' },
        { name: 'Calibration',    count: 3,  color: '#BBF7D0' }
      ]
    },
    {
      target: 50, approved: 28, pending: 3, saving: '₹5.6L',
      sections: [
        { name: 'Innovation Hub', count: 16, color: '#D97706' },
        { name: 'Kaizen Circle',  count: 13, color: '#F59E0B' },
        { name: '5S Team',        count: 8,  color: '#FBBF24' },
        { name: 'Safety',         count: 4,  color: '#FCD34D' },
        { name: 'HR Initiatives', count: 2,  color: '#FDE68A' }
      ]
    }
  ];

  deptData = [
    { name: 'Assembly',   plant: 'Plant 1',   kaizens: 126, saving: '₹18.4L', efficiency: 92 },
    { name: 'Paint Shop', plant: 'Plant 2',   kaizens: 84,  saving: '₹11.2L', efficiency: 88 },
    { name: 'SCM',        plant: 'Corporate', kaizens: 56,  saving: '₹7.9L',  efficiency: 81 },
    { name: 'Quality',    plant: 'Plant 3',   kaizens: 72,  saving: '₹9.3L',  efficiency: 89 }
  ];

  monthBars = [
    { month: 'Jan', pct: 55 },
    { month: 'Feb', pct: 70 },
    { month: 'Mar', pct: 60 },
    { month: 'Apr', pct: 82 },
    { month: 'May', pct: 100 },
    { month: 'Jun', pct: 65 }
  ];

  deployData = [
    { name: 'Horizontal Deployment',   hint: 'Implemented across departments',  pct: 74, color: '#E8541A' },
    { name: 'Vertical Implementation', hint: 'Rolled out at management levels', pct: 61, color: '#7C3AED' },
    { name: 'Replication Success',     hint: 'Successfully reused Kaizens',     pct: 89, color: '#16A34A' }
  ];

  private get authHeaders() {
    const token = sessionStorage.getItem('jwt_token') || '';
    return { headers: { 'Authorization': `Bearer ${token}` } };
  }

  constructor(
    private http: HttpClient,
    private router: Router,
    private cd: ChangeDetectorRef
  ) {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
  }

  ngOnInit(): void {
    this.loadDashboard();
  }

  getTopUnit(): number {
    const max = Math.max(...this.unitData);
    return this.unitData.indexOf(max) + 1;
  }

  getAverage(): number {
    if (this.unitData.length === 0) return 0;
    const total = this.unitData.reduce((a, b) => a + b, 0);
    return Math.round(total / this.unitData.length);
  }

  getRank(index: number): string {
    const sorted = [...this.unitData].sort((a, b) => b - a);
    const rank = sorted.indexOf(this.unitData[index]) + 1;
    return rank <= 1 ? 'top' : rank <= 3 ? 'mid' : 'low';
  }

  getAchievement(idx: number): number {
    return Math.round(this.unitData[idx] / this.unitSections[idx].target * 100);
  }

  getSecBarWidth(unitIdx: number, count: number): number {
    const max = Math.max(...this.unitSections[unitIdx].sections.map(s => s.count));
    return Math.round(count / max * 100);
  }

  getSecPct(unitIdx: number, count: number): number {
    return Math.round(count / this.unitData[unitIdx] * 100);
  }

  openUnitDetail(index: number): void {
    this.selectedUnit = index;
  }

  closeModal(): void {
    this.selectedUnit = null;
  }

  closeDetail(event: MouseEvent): void {
    if ((event.target as HTMLElement).classList.contains('bex-modal-overlay')) {
      this.selectedUnit = null;
    }
  }

  loadDashboard(): void {
    this.http.get<any[]>(`${this.api}?action=dashboard`, this.authHeaders)
      .subscribe({
        next: (res) => {
          this.unitData = res.map(r => Number(r.total));
          this.grandTotal = this.unitData.reduce((a, b) => a + b, 0);
          this.cd.detectChanges();
        },
        error: () => {}
      });
  }

  logout(): void {
    sessionStorage.clear();
    localStorage.clear();
    window.history.replaceState(null, '', '/');
    window.location.replace('/');
  }
}