import { environment } from '../../../environments/environment';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx-js-style';

@Component({
  selector: 'app-download-report',
  templateUrl: './download-report.component.html',
  styleUrls:   ['./download-report.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],})
export class DownloadReportComponent implements OnInit {
  api = environment.apiUrl + '/api/bex';
  units = ['Unit 1', 'Unit 2', 'Unit 3', 'Unit 4', 'Unit 5'];
  filteredData: any[] = [];

  filters = {
    search:    '',
    unit:      '',
    role:      '',
    status:    '',
    fromDate:  '',
    toDate:    ''
  };


  private get authHeaders() {
    const token = sessionStorage.getItem('jwt_token') || '';
    return { headers: { 'Authorization': `Bearer ${token}` } };
  }
  constructor(
    private http: HttpClient,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() { this.fetchReportData(); }

  fetchReportData() {
    const params = new URLSearchParams({
      action:  'get_all',
      unit:    this.filters.unit,
      role:    this.filters.role,
      status:  this.filters.status,
      search:  this.filters.search,
      from:    this.filters.fromDate,
      to:      this.filters.toDate
    });
    this.http.get<any[]>(`${this.api}?${params.toString()}`, this.authHeaders).subscribe({
      next: (res) => { this.filteredData = res ?? []; this.cdr.detectChanges(); },
      error: () => {}
    });
  }

  hasActiveFilters(): boolean {
    return !!(this.filters.unit || this.filters.role || this.filters.status
           || this.filters.fromDate || this.filters.toDate);
  }

  clearFilters() {
    this.filters = { search: '', unit: '', role: '', status: '', fromDate: '', toDate: '' };
    this.fetchReportData();
  }

  viewKaizen(row: any) {
    const role = (row.role || '').toLowerCase();
    const type = role === 'operator'   ? 'operator_kaizen'
               : role === 'supervisor' ? 'supervisor_kaizen'
               :                        'manager_kaizen';
    this.router.navigate(['/glob-kaizen'], { queryParams: { id: row.id, type } });
  }

  getStatusClass(status: string): string {
    if (status === 'Approved') return 'status-approved';
    if (status === 'Rejected') return 'status-rejected';
    return 'status-pending';
  }

  // ─────────────────────────────────────────────────────────────
  // EXCEL EXPORT
  // ─────────────────────────────────────────────────────────────
  exportExcel() {
    const wb = XLSX.utils.book_new();
    const ws: any = {};

    const titleStyle = {
      font: { bold: true, sz: 16, color: { rgb: '000000' } },
      alignment: { horizontal: 'center', vertical: 'center', wrapText: true }
    };
    const formatStyle = {
      font: { sz: 9 },
      alignment: { horizontal: 'left', vertical: 'center', wrapText: true }
    };
    const headerStyle = {
      font: { bold: true, sz: 9, color: { rgb: '000000' } },
      fill: { fgColor: { rgb: 'F2F2F2' } },
      alignment: { horizontal: 'center', vertical: 'center', wrapText: true },
      border: {
        top:    { style: 'thin', color: { rgb: '000000' } },
        bottom: { style: 'thin', color: { rgb: '000000' } },
        left:   { style: 'thin', color: { rgb: '000000' } },
        right:  { style: 'thin', color: { rgb: '000000' } }
      }
    };
    const dataStyle = {
      font: { sz: 9 },
      alignment: { horizontal: 'center', vertical: 'center', wrapText: true },
      border: {
        top:    { style: 'thin', color: { rgb: 'CCCCCC' } },
        bottom: { style: 'thin', color: { rgb: 'CCCCCC' } },
        left:   { style: 'thin', color: { rgb: 'CCCCCC' } },
        right:  { style: 'thin', color: { rgb: 'CCCCCC' } }
      }
    };
    const dataLeftStyle = {
      ...dataStyle,
      alignment: { horizontal: 'left', vertical: 'center', wrapText: true }
    };

    const C = (v: any, t: string, s: any) => ({ v, t, s });

    ws['!cols'] = [
      { wch: 5 }, { wch: 9 }, { wch: 12 }, { wch: 14 }, { wch: 32 },
      { wch: 20 }, { wch: 20 }, { wch: 12 }, { wch: 12 }, { wch: 28 },
      { wch: 26 }, { wch: 26 }, { wch: 30 }, { wch: 8 }, { wch: 18 },
      { wch: 28 }, { wch: 18 }
    ];
    ws['!rows'] = [{ hpt: 45 }, { hpt: 80 }];
    ws['!merges'] = [
      { s: { r: 0, c: 0  }, e: { r: 0, c: 1  } },
      { s: { r: 0, c: 2  }, e: { r: 0, c: 12 } },
      { s: { r: 0, c: 13 }, e: { r: 0, c: 16 } }
    ];

    ws['A1'] = C('SHAKTIMAN', 's', {
      font: { bold: true, sz: 10, color: { rgb: 'E85D04' } },
      alignment: { horizontal: 'center', vertical: 'center' }
    });
    ws['C1'] = C('KAIZEN Registration', 's', titleStyle);
    ws['N1'] = C('Format No. : TA/QMS/KR\nRevision : 00   04.04.2026', 's', formatStyle);

    const headers: [string, string][] = [
      ['A2','Sr\nNo'], ['B2','Month\n/\nYear'], ['C2','Business\nUnit'],
      ['D2','Deptt. /\nSection'], ['E2','KAIZEN THEME'],
      ['F2','Kaizen Type\nRestorative /\nRenovative /\nInnovative /\nBreakthrough /\nRoutine'],
      ['G2','Kaizen Category\nSee at Sheet NO. 2'], ['H2','Category\ncode\nSee at Sheet\nNO. 2'],
      ['I2','Group\nPQCDSME\n- 5S'],
      ['J2','Advantage description\nPQCDSME – 5S\n(Measurable Achievement)'],
      ['K2','KMI\n(Update relavant KMI\nExclusively for Best\nKaizens)'],
      ['L2','KPI\n(Update relavant KPI\nExclusively for\nBest Kaizens)'],
      ['M2','Kaizen\nPerformed\nby'], ['N2','Count'],
      ['O2','Certified by\nProcess\nOwner'],
      ['P2','CFT Verification\n(applicable in case\nof Critical change\nrelated to\nProcess / Product)'],
      ['Q2','Approved by\nHOD / BU\nHead']
    ];
    headers.forEach(([addr, val]) => { ws[addr] = C(val, 's', headerStyle); });

    const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    this.filteredData.forEach((row, i) => {
      const r = i + 3;
      const dateObj = new Date(row.created_at);
      const monthYear = isNaN(dateObj.getTime())
        ? '' : `${months[dateObj.getMonth()]} / ${dateObj.getFullYear()}`;
      const perf: string = row.performed_by || row.emp_name || '';

      const cols: [string, any, string][] = [
        [`A${r}`, i+1, 'n'], [`B${r}`, monthYear, 's'],
        [`C${r}`, row.unit || '', 's'], [`D${r}`, row.section || '', 's'],
        [`E${r}`, row.theme || '', 's'], [`F${r}`, row.kaizen_type || '', 's'],
        [`G${r}`, row.kaizen_category || '', 's'], [`H${r}`, row.category_code || '', 's'],
        [`I${r}`, row.pqcdsm || '', 's'], [`J${r}`, row.advantage_desc || '', 's'],
        [`K${r}`, row.kmi || '', 's'], [`L${r}`, row.kpi || '', 's'],
        [`M${r}`, perf, 's'], [`N${r}`, row.emp_count ?? 0, 'n'],
        [`O${r}`, row.certified_by || '', 's'], [`P${r}`, row.cft_verification || '', 's'],
        [`Q${r}`, row.approved_by || '', 's']
      ];
      cols.forEach(([addr, val, type]) => {
        const style = (addr.startsWith('E') || addr.startsWith('J') || addr.startsWith('M'))
          ? dataLeftStyle : dataStyle;
        ws[addr] = C(val, type, style);
      });
      if (!ws['!rows']) ws['!rows'] = [];
      ws['!rows'][r - 1] = { hpt: Math.max(25, perf.split('\n').length * 15) };
    });

    ws['!ref'] = `A1:Q${Math.max(this.filteredData.length + 2, 2)}`;
    XLSX.utils.book_append_sheet(wb, ws, 'Kaizen Registration');
    XLSX.writeFile(wb, `Kaizen_Registration_${Date.now()}.xlsx`);
  }

  // ─────────────────────────────────────────────────────────────
  // PDF EXPORT
  // ─────────────────────────────────────────────────────────────
  exportPDF() {
    const doc: any = new jsPDF('l', 'mm', 'a4');
    const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text('KAIZEN Registration', 148, 12, { align: 'center' });
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text('Format No. : TA/QMS/KR  |  Revision : 00   04.04.2026', 270, 10, { align: 'right' });

    const headers = [[
      'Sr\nNo','Month/\nYear','Unit','Section','KAIZEN THEME',
      'Kaizen\nType','Category','Cat.\nCode','Group\nPQCDSME',
      'Advantage\nDesc.','KMI','KPI','Performed\nby','Count',
      'Certified\nby','CFT\nVerify','Approved\nby'
    ]];

    const body = this.filteredData.map((row, i) => {
      const dateObj = new Date(row.created_at);
      const monthYear = isNaN(dateObj.getTime())
        ? '' : `${months[dateObj.getMonth()]}/${dateObj.getFullYear()}`;
      return [
        i+1, monthYear, row.unit||'', row.section||'',
        (row.theme||'').substring(0,35), row.kaizen_type||'',
        row.kaizen_category||'', row.category_code||'', row.pqcdsm||'',
        (row.advantage_desc||'').substring(0,20), row.kmi||'', row.kpi||'',
        row.performed_by || row.emp_name || '', row.emp_count??0,
        row.certified_by||'', row.cft_verification||'', row.approved_by||''
      ];
    });

    (doc as any).autoTable({
      head: headers, body,
      startY: 18, theme: 'grid',
      styles: { fontSize: 7, cellPadding: 2, valign: 'middle', halign: 'center' },
      headStyles: { fillColor: [242,242,242], textColor: [0,0,0], fontStyle: 'bold', fontSize: 7 },
      columnStyles: {
        0:{cellWidth:8}, 1:{cellWidth:13}, 2:{cellWidth:13}, 3:{cellWidth:13},
        4:{cellWidth:28,halign:'left'}, 5:{cellWidth:16}, 6:{cellWidth:16},
        7:{cellWidth:11}, 8:{cellWidth:13}, 9:{cellWidth:18,halign:'left'},
        10:{cellWidth:14}, 11:{cellWidth:14}, 12:{cellWidth:16,halign:'left'},
        13:{cellWidth:8}, 14:{cellWidth:14}, 15:{cellWidth:16}, 16:{cellWidth:14}
      }
    });

    doc.save(`Kaizen_Registration_${Date.now()}.pdf`);
  }
}