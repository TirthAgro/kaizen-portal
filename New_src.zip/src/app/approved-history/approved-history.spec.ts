import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApprovedHistoryComponent } from './approved-history';

describe('ApprovedHistory', () => {
  let component: ApprovedHistoryComponent;
  let fixture: ComponentFixture<ApprovedHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ApprovedHistoryComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ApprovedHistoryComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
