import { environment } from '../../environments/environment';
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-approved-history',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './approved-history.html',
  styleUrls: ['./approved-history.css']
})
export class ApprovedHistoryComponent implements OnInit {
  isSidebarClosed = false;
  adminName = ''; adminPlant = ''; adminSection = '';
  approvedList: any[] = [];
  loading = false;


  private get authHeaders() {
    const token = sessionStorage.getItem('jwt_token') || '';
    return { headers: { 'Authorization': `Bearer ${token}` } };
  }
  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit() {
    const user = JSON.parse(localStorage.getItem('admin_user') || '{}');
    this.adminName = user.name || 'Manager';
    this.adminPlant = user.unit || '';
    this.adminSection = user.section || '';
    this.fetchHistory();
  }

  toggleSidebar() {
    this.isSidebarClosed = !this.isSidebarClosed;
  }

  fetchHistory() {
    this.loading = true;
    const payload = { unit: this.adminPlant, section: this.adminSection, status: 'Approved' };
    
    this.http.post('http://localhost/kaizen-backend/demo/get_history_kaizens.php', payload)
      .subscribe((res: any) => {
        this.approvedList = res;
        this.loading = false;
      }, () => this.loading = false);
  }

  logout() {
    localStorage.clear();
    sessionStorage.clear();
    localStorage.clear();
    window.history.replaceState(null, '', '/');
    window.location.replace('/');
  }
}