// ════════════════════════════════════════════════════════════
//  manager-dashboard.component.ts
//  ✅ Enterprise Kaizen Platform UI — Full Redesign v2
//  ✅ Matches image: sidebar + hero KPIs + plan/actual + metrics + chart + dept table + deployment analytics
// ════════════════════════════════════════════════════════════

import { environment } from '../../../environments/environment';
import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManagerLayoutComponent } from '../layout/manager-layout.component';
import { Router, RouterModule } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

interface Toast {
  id: number;
  message: string;
  type: 'success' | 'error' | 'warning' | 'info';
}

@Component({
  selector: 'app-manager-dashboard',
  templateUrl: './manager_dashboard.html',
  styleUrls:   ['./manager_dashboard.css'],
  standalone: true,
  imports: [CommonModule, ManagerLayoutComponent, RouterModule, FormsModule]
})
export class ManagerDashboardComponent implements OnInit {
  public currentView: string = 'insights';
  public sidebarClosed: boolean = false;
  public plantId: string = '';
  public emp_id: string = '';
  public plant: string = '';
  public section: string = '';
  public myTotalCount: number = 0;
  public pendingApprovalCount: number = 0;
  public approvedCount: number = 0;
  public breakthroughCount: number = 0;
  public pendingKaizens: any[] = [];
  public history: any[] = [];
  public filteredHistory: any[] = [];
  public selectedKaizen: any = null;
  public managerRemark: string = '';
  public searchTerm: string = '';
  public selectedDivision: string = 'All Divisions';
  public goalTarget: number = 240;
 

  public deployStats = {
    horizontal: 74,
    
    replication: 89
  };

  public divisions = ['All Divisions', 'Assembly', 'Paint Shop', 'SCM', 'Quality', 'Weld'];

  public chartData = [
    { month: 'Jan', val: 40 }, { month: 'Feb', val: 70 },
    { month: 'Mar', val: 50 }, { month: 'Apr', val: 90 },
    { month: 'May', val: 60 }, { month: 'Jun', val: 85 }
  ];

  public planMetrics = [
    { label: 'Kaizen Submission',      plan: '320',    actual: '243',      pct: 89, color: '#10B981' },
    { label: 'Horizontal Deployment',  plan: '140',    actual: '118',      pct: 84, color: '#E85D04' },
    
  ];

  public deptData = [
    { dept: 'Assembly',   plant: 'Plant 1',   kaizens: 126, cost: '₹18.4L', eff: 52 },
    { dept: 'Paint Shop', plant: 'Plant 2',   kaizens: 84,  cost: '₹11.2L', eff: 83 },
    { dept: 'SCM',        plant: 'Corporate', kaizens: 56,  cost: '₹7.9L',  eff: 81 },
    { dept: 'Quality',    plant: 'Plant 3',   kaizens: 72,  cost: '₹9.3L',  eff: 85 },
    { dept: 'Weld',       plant: 'Plant 1',   kaizens: 48,  cost: '₹6.1L',  eff: 67 },
  ];

  public toasts: Toast[] = [];
  private toastCounter = 0;
  public confirmDialog = { visible: false, title: '', message: '', okLabel: 'Confirm', danger: false, callback: () => {} };


  private get authHeaders() {
    const token = sessionStorage.getItem('jwt_token') || '';
    return { headers: { 'Authorization': `Bearer ${token}` } };
  }
  constructor(
    private router: Router,
    private http: HttpClient,
    private cdr: ChangeDetectorRef,
    private route: ActivatedRoute
  ) {}

  showToast(message: string, type: Toast['type'] = 'info', duration = 4000) {
    const id = ++this.toastCounter;
    this.toasts.push({ id, message, type });
    this.cdr.detectChanges();
    setTimeout(() => this.dismissToast(id), duration);
  }
  dismissToast(id: number) { this.toasts = this.toasts.filter(t => t.id !== id); this.cdr.detectChanges(); }

  showConfirm(opts: { title: string; message: string; okLabel?: string; danger?: boolean; callback: () => void; }) {
    this.confirmDialog = { visible: true, title: opts.title, message: opts.message, okLabel: opts.okLabel ?? 'Confirm', danger: opts.danger ?? false, callback: opts.callback };
    this.cdr.detectChanges();
  }
  onConfirmOk() { this.confirmDialog.visible = false; this.confirmDialog.callback(); this.cdr.detectChanges(); }

  ngOnInit(): void {
    this.emp_id  = sessionStorage.getItem('emp_id')   || '';
    this.plant   = sessionStorage.getItem('plant')    || '';
    this.plantId = sessionStorage.getItem('plant_id') || '';
    this.section = sessionStorage.getItem('section')  || '';

    if (!this.plantId || !this.section) {
      this.showToast('Session expired. Please login again.', 'error', 6000);
      setTimeout(() => this.router.navigate(['/admin-login']), 1500);
      return;
    }
    this.route.queryParams.subscribe(params => { if (params['view']) this.currentView = params['view']; });
    this.refreshAllData();
  }

  refreshAllData() {
    this.fetchDbStats();
    this.fetchPendingData();
    this.fetchTrackerData();
  }

  fetchDbStats() {
    const url = `${environment.apiUrl}/api/manager?action=stats&unit=${encodeURIComponent(this.plant)}&section=${encodeURIComponent(this.section)}`;
    this.http.get<any>(url).subscribe({
      next: (res) => {
        if (!res) return;
        this.myTotalCount         = res.total        ?? 0;
        this.pendingApprovalCount = res.pending       ?? 0;
        this.approvedCount        = res.approved      ?? 0;
        this.breakthroughCount    = res.breakthrough  ?? 0;
        
        if (res.deploy_horizontal)  this.deployStats.horizontal  = res.deploy_horizontal;
        
        if (res.deploy_replication) this.deployStats.replication = res.deploy_replication;
        this.cdr.detectChanges();
      },
      error: () => {}
    });
  }

  fetchPendingData() {
    const url = `${environment.apiUrl}/api/manager?action=pending&unit=${encodeURIComponent(this.plant)}&section=${encodeURIComponent(this.section)}`;
    this.http.get<any[]>(url).subscribe({
      next: (res) => { this.pendingKaizens = res ?? []; this.pendingApprovalCount = this.pendingKaizens.length; this.cdr.detectChanges(); },
      error: () => {}
    });
  }

  fetchTrackerData() {
    const url = `${environment.apiUrl}/api/manager?action=tracker&unit=${encodeURIComponent(this.plant)}&section=${encodeURIComponent(this.section)}`;
    this.http.get<any[]>(url).subscribe({
      next: (res) => { this.history = res ?? []; this.filteredHistory = res ?? []; this.cdr.detectChanges(); },
      error: () => {}
    });
  }

  openReview(kaizen: any) {
  // Debug: pehle dekho kya aa raha hai
  console.log('Kaizen object:', kaizen);

  // ✅ numeric id use karo, kaizen_id (string) nahi
  const numericId = kaizen.id ?? kaizen.db_id;
  const role      = kaizen.role_type || kaizen.role || 'Operator';

  if (!numericId || numericId === 'undefined') {
    this.showToast('Kaizen ID missing. Please refresh.', 'error');
    return;
  }

  this.selectedKaizen = kaizen;
  this.managerRemark  = '';

  this.http.get<any>(
    `${environment.apiUrl}/api/kaizen/detail?id=${numericId}&role=${role}`,
    this.authHeaders
  ).subscribe({
    next:  (detail) => { this.selectedKaizen = { ...kaizen, ...detail }; this.cdr.detectChanges(); },
    error: (err)    => { this.showToast('Failed to load details.', 'error'); console.error(err); }
  });
}

  updateStatus(status: string) {
    if (!this.selectedKaizen) return;
    if (status === 'Rejected' && !this.managerRemark.trim()) { this.showToast('Rejection requires a manager remark.', 'warning'); return; }
    const payload = { kaizen_id: this.selectedKaizen.kaizen_id, role_type: this.selectedKaizen.role_type, status, manager_remark: this.managerRemark };
    this.http.post(environment.apiUrl + '/api/manager/update-status', payload).subscribe({
      next: () => {
        this.pendingKaizens = this.pendingKaizens.filter(k => k.kaizen_id !== this.selectedKaizen.kaizen_id);
        this.selectedKaizen = null;
        this.refreshAllData();
        this.showToast(`Kaizen ${status === 'Approved' ? 'approved' : 'rejected'} successfully.`, status === 'Approved' ? 'success' : 'error');
      },
      error: () => this.showToast('Update failed. Please try again.', 'error')
    });
  }

  safeImgSrc(imgData: any): string | null {
    if (!imgData) return null;
    const str = String(imgData).trim();
    if (!str) return null;
    if (str.startsWith('http://') || str.startsWith('https://')) return str;
    if (str.startsWith('data:')) return str;
    if (/\.(jpg|jpeg|png|gif|webp)/i.test(str)) return `${environment.apiUrl}/uploads/` + str;
    if (str.length > 100) return 'data:image/jpeg;base64,' + str;
    return null;
  }

  filterTrackerData() {
    const term = this.searchTerm.toLowerCase();
    this.filteredHistory = this.history.filter(k =>
      k.emp_name?.toLowerCase().includes(term) ||
      k.theme?.toLowerCase().includes(term) ||
      k.kaizen_id?.toLowerCase().includes(term)
    );
  }

  getPercentage(): number {
    if (!this.approvedCount || !this.goalTarget) return 0;
    return Math.min(100, Math.round((this.approvedCount / this.goalTarget) * 100));
  }

  toggleSidebar() { this.sidebarClosed = !this.sidebarClosed; }

  logout() {
    this.showConfirm({
      title: 'Sign Out', message: 'Are you sure you want to sign out of the portal?',
      okLabel: 'Sign Out', danger: true,
      callback: () => { sessionStorage.clear();
    localStorage.clear();
    window.history.replaceState(null, '', '/');
    window.location.replace('/'); }
    });
  }
}