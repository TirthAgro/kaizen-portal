import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector:    'app-manager-layout',
  standalone:  true,
  imports:     [CommonModule],
  templateUrl: './manager-layout.component.html',
  styleUrls:   ['./manager-layout.component.css']
})


export class ManagerLayoutComponent implements OnInit {
constructor(private router: Router) {}

  // ── Inputs from parent ──────────────────────────────
  @Input() currentView:   string = 'insights';
  @Input() pendingCount:  number = 0;
  @Input() userName:      string = '';
  @Input() userDetail:    string = '';

  // ── Outputs to parent ───────────────────────────────
  @Output() viewChange  = new EventEmitter<string>();
  @Output() syncClick   = new EventEmitter<void>();
  @Output() logoutClick = new EventEmitter<void>();

  sidebarClosed = false;
  userInitial   = 'M';

  ngOnInit() {
    const name = this.userName
              || sessionStorage.getItem('emp_name')
              || sessionStorage.getItem('user_id')
              || 'Manager';
    this.userName    = name;
    this.userInitial = name.charAt(0).toUpperCase();

    if (!this.userDetail) {
      const empId  = sessionStorage.getItem('user_id')  || '';
      const plant  = sessionStorage.getItem('plant')    || '';
      const sect   = sessionStorage.getItem('section')  || '';
      this.userDetail = [empId, plant, sect].filter(Boolean).join(' · ');
    }
  }

  onViewChange(view: string) {
  this.currentView = view; // ✅ local state hamesha update karo

  if (view === 'registration') {
    this.router.navigate(['/manager-registration']);
    return;
  }

  // ✅ agar abhi /manager-registration pe hain, toh wapas main route pe jao
  const currentUrl = this.router.url;
  if (currentUrl.includes('manager-registration')) {
    // replace 'manager-dashboard' with your actual main route
    this.router.navigate(['/manager-dashboard'], {
      queryParams: { view }          // parent ko view pass karo
    });
    return;
  }

  this.viewChange.emit(view);
}
  onSync()                   { this.syncClick.emit(); }
  onLogout()                 { this.logoutClick.emit(); }
}