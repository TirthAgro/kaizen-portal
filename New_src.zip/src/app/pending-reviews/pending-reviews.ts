import { environment } from '../../environments/environment';
import { Component, OnInit, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Router, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-pending-reviews',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './pending-reviews.html',
  styleUrls: ['./pending-reviews.css']
})
export class PendingReviewsComponent implements OnInit {
  isSidebarClosed = false; // Controls the hamburger state
  adminName = ''; adminPlant = ''; adminSection = '';
  pendingList: any[] = [];
  loading = false;


  private get authHeaders() {
    const token = sessionStorage.getItem('jwt_token') || '';
    return { headers: { 'Authorization': `Bearer ${token}` } };
  }
  constructor(private http: HttpClient, private router: Router) {}
  toggleSidebar() {
    this.isSidebarClosed = !this.isSidebarClosed;
  }

  ngOnInit() {
    const user = JSON.parse(localStorage.getItem('admin_user') || '{}');
    this.adminName = user.name || 'Manager';
    this.adminPlant = user.unit || '';
    this.adminSection = user.section || '';
    this.refreshData();
  }

  refreshData() {
    this.loading = true;
    const payload = { unit: this.adminPlant, section: this.adminSection };
    // Fetching from your backend
    this.http.post('http://localhost/kaizen-backend/demo/get_pending_kaizens.php', payload)
      .subscribe((res: any) => {
        // We add a 'remark' property to each kaizen for the input field
        this.pendingList = res.map((k: any) => ({ ...k, remark: '' }));
        this.loading = false;
      }, () => this.loading = false);
  }

  updateStatus(kaizen: any, newStatus: string) {
    if (!kaizen.remark && newStatus === 'Rejected') {
      alert('Please enter a remark for rejection.');
      return;
    }

    const payload = {
      id: kaizen.id,
      status: newStatus,
      remark: kaizen.remark,
      manager: this.adminName
    };

    this.http.post('http://localhost/kaizen-backend/demo/update_kaizen_status.php', payload)
      .subscribe((res: any) => {
        alert(`Kaizen #${kaizen.id} ${newStatus} successfully.`);
        this.refreshData(); // Auto-refresh list
      });
  }

  logout() {
    localStorage.clear();
    sessionStorage.clear();
    localStorage.clear();
    window.history.replaceState(null, '', '/');
    window.location.replace('/');
  } 
}