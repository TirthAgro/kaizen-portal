import { environment } from '../../../environments/environment';
import { Component, OnInit, ChangeDetectorRef, NgZone } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { HodLayoutComponent } from '../layout/hod-layout.component';
import { Router } from '@angular/router';

/* ── Toast model ───────────────────────────────────────────── */
interface Toast {
  id: number;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message: string;
  visible: boolean;
}

@Component({
  selector: 'app-hod-dashboard',
  templateUrl: './hod-dashboard.component.html',
  styleUrls:   ['./hod-dashboard.component.css'],
  standalone: true,
  imports: [CommonModule, HodLayoutComponent]
})
export class HodDashboardComponent implements OnInit {

  /* ── Session / identity ────────────────────────────────── */
  public plantId:  string = '';
  public plant:    string = '';
  public emp_id:   string = '';
  public empName:  string = '';

  /* ── View state ────────────────────────────────────────── */
  public currentView:     string  = 'dashboard';
  public isSidebarClosed: boolean = false;

  /* ── Kaizen data ───────────────────────────────────────── */
  public kaizens:       any[] = [];
  public selectedKaizen: any  = null;

  /* counts now includes approved + rejected for the summary row */
  public counts = {
    op:       0,
    sup:      0,
    man:      0,
    pending:  0,
    approved: 0,
    rejected: 0
  };

  public impactData: any = {
    Productivity: 0, Quality: 0, Cost: 0,
    Delivery: 0, Safety: 0, Morale: 0
  };
  public impactTotal: number = 0;
  private isLoading:  boolean = false;

  /* ── Toast state ───────────────────────────────────────── */
  public toasts: Toast[] = [];
  private toastCounter = 0;

  /* ── Analytics: Plan vs Actual ─────────────────────────── */
  public planVsActual = {
    submission: { plan: 320, actual: 243 },
    deployment: { plan: 140, actual: 118 }
  };

  /* ── Analytics: Special Kaizen counts ─────────────────── */
  public specialKaizens = {
    breakthrough: 0,
    innovation:   12,
    horizontal:   3
  };

  /* ── Analytics: Department performance table ───────────── */
  public deptData: any[] = [
    { name: 'Assembly',   plant: 'Plant 1',   kaizens: 126, cost: '₹18.4L', eff: 52, effColor: '#f97316' },
    { name: 'Paint Shop', plant: 'Plant 2',   kaizens: 84,  cost: '₹11.2L', eff: 83, effColor: '#22c55e' },
    { name: 'SCM',        plant: 'Corporate', kaizens: 56,  cost: '₹7.9L',  eff: 81, effColor: '#22c55e' },
    { name: 'Quality',    plant: 'Plant 3',   kaizens: 72,  cost: '₹9.3L',  eff: 85, effColor: '#22c55e' },
    { name: 'Weld',       plant: 'Plant 1',   kaizens: 48,  cost: '₹6.1L',  eff: 67, effColor: '#f97316' }
  ];

  /* ── Analytics: Monthly submission trend ──────────────── */
  public monthlyTrend = [
    { month: 'Jan', val: 28 },
    { month: 'Feb', val: 45 },
    { month: 'Mar', val: 38 },
    { month: 'Apr', val: 72 },
    { month: 'May', val: 55 },
    { month: 'Jun', val: 78 }
  ];

  /* ── Auth header helper ────────────────────────────────── */
  private get authHeaders() {
    const token = sessionStorage.getItem('jwt_token') || '';
    return { headers: { 'Authorization': `Bearer ${token}` } };
  }

  constructor(
    private http:   HttpClient,
    private cdr:    ChangeDetectorRef,
    private router: Router,
    private ngZone: NgZone
  ) {}

  /* ══════════════════════════════════════════════════════════
     LIFECYCLE
  ══════════════════════════════════════════════════════════ */
  ngOnInit() {
    this.emp_id  = sessionStorage.getItem('emp_id')   || '';
    this.plant   = sessionStorage.getItem('plant')    || '';
    this.plantId = sessionStorage.getItem('plant')    || 'Unit 1';
    this.empName = sessionStorage.getItem('emp_name') || 'HOD';
    this.loadData();
  }

  /* ══════════════════════════════════════════════════════════
     TOAST HELPERS
  ══════════════════════════════════════════════════════════ */
  showToast(
    type: Toast['type'],
    title: string,
    message: string,
    duration = 4000
  ): void {
    const id = ++this.toastCounter;
    const toast: Toast = { id, type, title, message, visible: false };
    this.toasts.push(toast);
    this.cdr.detectChanges();

    setTimeout(() => {
      toast.visible = true;
      this.cdr.detectChanges();
    }, 20);

    setTimeout(() => this.dismissToast(id), duration);
  }

  dismissToast(id: number): void {
    const t = this.toasts.find(x => x.id === id);
    if (!t) return;
    t.visible = false;
    this.cdr.detectChanges();
    setTimeout(() => {
      this.toasts = this.toasts.filter(x => x.id !== id);
      this.cdr.detectChanges();
    }, 400);
  }

  /* ══════════════════════════════════════════════════════════
     NAVIGATION
  ══════════════════════════════════════════════════════════ */
  getPageTitle(): string {
    const map: any = {
      dashboard: 'Intelligence Dashboard',
      pending:   'Decision Queue',
      history:   'Approval History',
      master:    'Master Configuration'
    };
    return map[this.currentView] || 'Dashboard';
  }

  /* ══════════════════════════════════════════════════════════
     KAIZEN DETAIL MODAL
  ══════════════════════════════════════════════════════════ */
  openKaizen(k: any) {
    this.selectedKaizen = { ...k };
    this.cdr.detectChanges();

    const role = k.role_type || 'Manager';
    this.http.get<any>(
      `${environment.apiUrl}/api/kaizen/detail?id=${k.id}&role=${role}`
    ).subscribe({
      next: (detail) => {
        this.selectedKaizen = { ...k, ...detail };
        this.cdr.detectChanges();
      },
      error: () => {}
    });
  }

  /* ══════════════════════════════════════════════════════════
     DATA LOADING
  ══════════════════════════════════════════════════════════ */
  loadData() {
    if (this.isLoading) return;
    this.isLoading = true;

    const url = `${environment.apiUrl}/api/kaizen?plant_id=${encodeURIComponent(this.plantId)}`;
    this.http.get(url).subscribe({
      next: (res: any) => {
        if (!res) { this.isLoading = false; return; }

        this.kaizens = res.list || [];

        /* merge API counts; compute approved/rejected from list if API
           doesn't supply them yet                                        */
        if (res.counts) {
          this.counts = {
            op:       res.counts.op       ?? 0,
            sup:      res.counts.sup      ?? 0,
            man:      res.counts.man      ?? 0,
            pending:  res.counts.pending  ?? 0,
            approved: res.counts.approved ?? this.kaizens.filter(k => k.hod_status === 'Approved').length,
            rejected: res.counts.rejected ?? this.kaizens.filter(k => k.hod_status === 'Rejected').length
          };
        } else {
          this.counts = {
            op:       0,
            sup:      0,
            man:      0,
            pending:  this.kaizens.filter(k => !k.hod_status || k.hod_status === 'Pending').length,
            approved: this.kaizens.filter(k => k.hod_status === 'Approved').length,
            rejected: this.kaizens.filter(k => k.hod_status === 'Rejected').length
          };
        }

        if (res.impact) {
          this.impactData  = { ...res.impact };
          this.impactTotal = Object.values(res.impact)
            .reduce((a: any, b: any) => Number(a) + Number(b), 0) as number;
        } else {
          this.impactTotal = 0;
        }

        /* optional analytics overrides from API */
        if (res.planVsActual)   this.planVsActual   = res.planVsActual;
        if (res.specialKaizens) this.specialKaizens = res.specialKaizens;
        if (res.deptData)       this.deptData       = res.deptData;
        if (res.monthlyTrend)   this.monthlyTrend   = res.monthlyTrend;

        this.isLoading = false;
        this.cdr.markForCheck();
        this.cdr.detectChanges();
      },
      error: () => { this.isLoading = false; }
    });
  }

  /* ══════════════════════════════════════════════════════════
     KAIZEN LIST HELPERS
  ══════════════════════════════════════════════════════════ */
  getPendingList() {
    return this.kaizens.filter(k => !k.hod_status || k.hod_status === 'Pending');
  }

  safeImgSrc(imgData: any): string | null {
    if (!imgData) return null;
    const str = String(imgData).trim();
    if (!str) return null;
    if (str.startsWith('http://') || str.startsWith('https://')) return str;
    if (str.startsWith('data:')) return str;
    if (/\.(jpg|jpeg|png|gif|webp)/.test(str)) {
      return `${environment.apiUrl}/uploads/` + str;
    }
    if (str.length > 100) return 'data:image/jpeg;base64,' + str;
    return null;
  }

  /* ══════════════════════════════════════════════════════════
     IMPACT BAR HELPERS
  ══════════════════════════════════════════════════════════ */
  getW(key: string): number {
    if (this.impactTotal === 0 || !this.impactData[key]) return 0;
    return (Number(this.impactData[key]) / this.impactTotal) * 100;
  }

  /* ══════════════════════════════════════════════════════════
     PLAN VS ACTUAL HELPERS
  ══════════════════════════════════════════════════════════ */
  getAchievePct(actual: number, plan: number): number {
    if (!plan) return 0;
    return Math.round((actual / plan) * 100);
  }

  getBarWidth(actual: number, plan: number): string {
    if (!plan) return '0%';
    return Math.min(Math.round((actual / plan) * 100), 100) + '%';
  }

  getBarColor(actual: number, plan: number): string {
    const pct = plan ? (actual / plan) * 100 : 0;
    if (pct >= 90) return '#22c55e';
    if (pct >= 70) return '#f97316';
    return '#ef4444';
  }

  /* ══════════════════════════════════════════════════════════
     MONTHLY TREND HELPER
  ══════════════════════════════════════════════════════════ */
  getMaxTrend(): number {
    return Math.max(...this.monthlyTrend.map(m => m.val));
  }

  /* ══════════════════════════════════════════════════════════
     APPROVE / REJECT
  ══════════════════════════════════════════════════════════ */
  process(k: any, status: string, remark: string) {
    if (!remark.trim()) {
      this.showToast(
        'warning',
        'Remarks Required',
        'Please provide feedback before modifying this decision.'
      );
      return;
    }

    this.http.post(environment.apiUrl + '/api/kaizen/update', {
      id:          k.id,
      action:      status,
      hod_remarks: remark,
      role_type:   k.role_type
    }).subscribe({
      next: (res: any) => {
        if (res?.error) {
          this.showToast('error', 'Update Failed', res.error);
        } else {
          const label = status === 'Approved' ? 'Approved' : 'Rejected';
          this.showToast(
            status === 'Approved' ? 'success' : 'error',
            `Kaizen ${label}`,
            `${k.kaizen_id} has been successfully ${label.toLowerCase()}.`
          );
          this.selectedKaizen = null;
          this.loadData();
        }
      },
      error: () =>
        this.showToast('error', 'Network Error', 'Action failed. Please try again.')
    });
  }

  /* ══════════════════════════════════════════════════════════
     LOGOUT
  ══════════════════════════════════════════════════════════ */
  logout() {
    sessionStorage.clear();
    localStorage.clear();
    window.history.replaceState(null, '', '/');
    window.location.replace('/');
  }
}