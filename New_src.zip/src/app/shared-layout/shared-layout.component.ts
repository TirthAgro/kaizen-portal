import { Component, OnInit, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

export interface NavItem {
  label:   string;
  route:   string;
  svgPath: string;
}

@Component({
  selector:    'app-shared-layout',
  standalone:  true,
  imports:     [CommonModule, RouterModule],
  templateUrl: './shared-layout.component.html',
  styleUrls:   ['./shared-layout.component.css']
})
export class SharedLayoutComponent implements OnInit {
  @Input() navItems: NavItem[] = [];

  sidebarClosed = false;
  userName      = '';
  userRole      = '';
  userInitial   = '?';

  ngOnInit() {
    const name       = sessionStorage.getItem('emp_name')
                    || sessionStorage.getItem('user_id')
                    || 'User';
    this.userName    = name;
    this.userRole    = sessionStorage.getItem('role') || '';
    this.userInitial = name.charAt(0).toUpperCase();
  }

  logout() {
    sessionStorage.clear();
    localStorage.clear();
    window.history.replaceState(null, '', '/');
    window.location.replace('/');
  }
}