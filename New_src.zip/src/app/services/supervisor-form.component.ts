import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { Router } from '@angular/router';
// Use './' because the service is in the same folder as this component
import { KaizenService } from './kaizen.service';// Double check this path matches your folder

@Component({
  selector: 'app-supervisor-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  encapsulation: ViewEncapsulation.None,
  template: `
    <div class="shaktiman-ribbon"></div>

    <div class="custom-overlay" *ngIf="showConfirmModal">
      <div class="modern-modal">
        <div class="modal-icon">?</div>
        <h3>Confirm Registration</h3>
        <p>Are you sure you want to submit this Supervisor Kaizen?</p>
        <div class="modal-preview-box">
          <strong>Kaizen ID:</strong> {{ kaizenNo }}<br>
          <strong>Theme:</strong> {{ kaizenForm.value.theme }}
        </div>
        <div class="modal-actions">
          <button class="btn-cancel" (click)="showConfirmModal = false">Review</button>
          <button class="btn-confirm" (click)="finalSubmit()">Submit Now</button>
        </div>
      </div>
    </div>

    <div class="custom-overlay" *ngIf="showSuccessModal">
      <div class="modern-modal success-style">
        <div class="modal-icon check">✔</div>
        <h3>Success!</h3>
        <p>Kaizen <strong>{{ lastSubmittedNo }}</strong> has been registered.</p>
        <button class="btn-confirm" (click)="showSuccessModal = false">Great!</button>
      </div>
    </div>

    <div class="container-main">
      <div class="form-card">
        <header class="form-header">
          <div class="header-left">
            <span class="brand-label">SHAKTIMAN KAIZEN PORTAL</span>
            <h2>Supervisor Level Entry</h2>
          </div>
          <div class="header-right header-flex">
            <div class="meta-group">
              <div class="meta-box dark">Kaizen ID: {{ kaizenNo }}</div>
              <div class="meta-box light">Reg Date: {{ today | date:'dd-MMM-yyyy hh:mm A' }}</div>
            </div>
            <button type="button" class="logout-pill" (click)="logout()">
              <span class="power-icon">⏻</span> Logout
            </button>
          </div>
        </header>

        <form [formGroup]="kaizenForm" (ngSubmit)="onPreSubmit()" class="form-content">
          <div class="row-grid">
            <div class="field"><label>Employee ID*</label><input type="text" formControlName="emp_id"></div>
            <div class="field"><label>Employee Name*</label><input type="text" formControlName="emp_name"></div>
            <div class="field">
              <label>Plant (Unit)*</label>
              <select formControlName="unit">
                <option value="">Select Unit</option>
                <option *ngFor="let i of [1,2,3,4,5]" [value]="'Unit '+i">Unit {{i}}</option>
              </select>
            </div>
          </div>

          <div class="row-grid">
            <div class="field">
              <label>Section*</label>
              <select formControlName="section">
                <option value="">Select Section</option>
                <option value="Welding">Welding</option>
                <option value="Assembly">Assembly</option>
                <option value="Paint Shop">Paint Shop</option>
                <option value="Machine Shop">Machine Shop</option>
              </select>
            </div>
            <div class="field"><label>Machine Name/No.*</label><input type="text" formControlName="machine_no"></div>
            <div class="field">
              <label>Type of Kaizen*</label>
              <select formControlName="kaizen_type">
                <option value="Innovative">Innovative</option>
                <option value="Restorative">Restorative</option>
              </select>
            </div>
          </div>

          <div class="full-row field">
            <label>Kaizen Theme*</label>
            <input type="text" formControlName="theme" placeholder="Brief title of improvement">
          </div>

          <div class="deployment-container mt-4">
            <label class="evidence-title">Horizontal Deployment Table</label>
            <table class="supervisor-lined-table">
              <thead>
                <tr><th>Sr.</th><th>M/C No</th><th>Responsibility</th><th>Target Date</th><th>Status</th></tr>
              </thead>
              <tbody formArrayName="horizontal_deployment">
                <tr *ngFor="let row of deploymentRows.controls; let i=index" [formGroupName]="i">
                  <td class="text-center">{{i+1}}</td>
                  <td><input type="text" formControlName="m_no"></td>
                  <td><input type="text" formControlName="resp"></td>
                  <td><input type="date" formControlName="target"></td>
                  <td>
                    <select formControlName="status">
                      <option value="Pending">Pending</option>
                      <option value="Done">Done</option>
                    </select>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <button type="submit" class="btn-submit" [disabled]="kaizenForm.invalid">
            ✔ SUBMIT SUPERVISOR KAIZEN
          </button>
        </form>
      </div>
    </div>
  `,
  styles: [`
    :root { --sorange: #ff7f27; --sdark: #000000; }
    body { background: #f0f2f5 !important; margin: 0; font-family: 'Segoe UI', sans-serif; }
    .shaktiman-ribbon { height: 18px; background: #ff7f27; position: fixed; top: 0; width: 100%; z-index: 1000; }
    .container-main { padding: 50px 20px; max-width: 1000px; margin: 0 auto; }
    .form-card { background: #fff; border-radius: 20px; box-shadow: 0 15px 40px rgba(0,0,0,0.12); overflow: hidden; }
    .form-header { background: #000; color: #fff; padding: 25px 35px; border-bottom: 5px solid #ff7f27; display: flex; justify-content: space-between; align-items: center; }
    .header-flex { display: flex; align-items: center; gap: 20px; }
    .meta-box { padding: 6px 15px; border-radius: 6px; font-weight: bold; font-size: 13px; margin-bottom: 5px; background: #222; }
    .logout-pill { background: #ff7f27; color: #000; border: none; padding: 10px 18px; border-radius: 50px; font-weight: 800; cursor: pointer; }
    .form-content { padding: 35px; }
    .row-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; margin-bottom: 20px; }
    .field { display: flex; flex-direction: column; gap: 6px; }
    input, select, textarea { padding: 12px; border: 2px solid #e2e8f0; border-radius: 10px; }
    .btn-submit { width: 100%; padding: 18px; background: #000; color: #fff; border: none; border-radius: 12px; font-weight: 800; cursor: pointer; margin-top: 20px;}
    .custom-overlay { position: fixed; top:0; left:0; width:100%; height:100%; background: rgba(0,0,0,0.6); z-index: 3000; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(8px); }
    .modern-modal { background: #fff; width: 420px; padding: 35px; border-radius: 25px; text-align: center; }
    .modal-preview-box { background: #f8f9fa; padding: 15px; border-radius: 12px; margin: 20px 0; text-align: left; border-left: 4px solid #ff7f27; }
    .supervisor-lined-table { width: 100%; border-collapse: collapse; border: 2px solid #e2e8f0; }
    .supervisor-lined-table th { background: #f8fafc; padding: 12px; text-align: left; }
    .supervisor-lined-table td { border: 1px solid #e2e8f0; }
    .supervisor-lined-table input { border: none; width: 100%; }
  `]
})
export class SupervisorFormComponent implements OnInit {
  // Missing variables added back here:
  public kaizenNo: string = "SV-01";
  public today: Date = new Date();
  public kaizenForm!: FormGroup;
  public showConfirmModal: boolean = false;
  public showSuccessModal: boolean = false;
  public lastSubmittedNo: string = "";

  constructor(
    private router: Router, 
    private kaizenService: KaizenService // The compiler needs the 'export class' above to understand this
  ) {}

  ngOnInit() {
    this.kaizenForm = new FormGroup({
      emp_id: new FormControl('', Validators.required),
      emp_name: new FormControl('', Validators.required),
      unit: new FormControl('', Validators.required),
      section: new FormControl('', Validators.required),
      machine_no: new FormControl('', Validators.required),
      kaizen_type: new FormControl('Innovative', Validators.required),
      theme: new FormControl('', Validators.required),
      horizontal_deployment: new FormArray([this.createRow(), this.createRow()])
    });
  }

  createRow() {
    return new FormGroup({
      m_no: new FormControl(''), resp: new FormControl(''), target: new FormControl(''), status: new FormControl('Pending')
    });
  }

  get deploymentRows() { return this.kaizenForm.get('horizontal_deployment') as FormArray; }

  onPreSubmit() { 
    if (this.kaizenForm.valid) this.showConfirmModal = true; 
  }

  finalSubmit() {
    const payload = this.kaizenForm.value;
    this.kaizenService.submitKaizen(payload).subscribe({
      next: (res: any) => {
        this.showConfirmModal = false;
        this.lastSubmittedNo = this.kaizenNo;
        
        const num = parseInt(this.kaizenNo.split('-')[1]);
        this.kaizenNo = `SV-${(num + 1).toString().padStart(2, '0')}`;
        
        this.showSuccessModal = true;
        this.kaizenForm.reset({ kaizen_type: 'Innovative' });
      },
      error: (err: any) => {
        
        alert("Submission failed. Check API.");
      }
    });
  }

  logout() {
    if (confirm("Logout?")) {
      sessionStorage.clear(); this.router.navigate(['/login']);
    }
  }
}