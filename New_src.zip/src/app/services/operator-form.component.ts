import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { KaizenService } from './kaizen.service'; // Service in same folder

@Component({
  selector: 'app-operator-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  encapsulation: ViewEncapsulation.None,
  template: `
    <div class="shaktiman-ribbon"></div>

    <div class="custom-overlay" *ngIf="showSuccessModal">
      <div class="modern-modal success-style">
        <div class="modal-icon check">✔</div>
        <h3>Operator Kaizen Saved!</h3>
        <p>Kaizen ID <strong>{{ lastSubmittedNo }}</strong> has been registered successfully.</p>
        <button class="btn-confirm" (click)="showSuccessModal = false">Done</button>
      </div>
    </div>

    <div class="container-main">
      <div class="form-card">
        <header class="form-header operator-header">
          <div class="header-left">
            <span class="brand-label">SHAKTIMAN KAIZEN PORTAL</span>
            <h2>Operator Level Entry</h2>
          </div>
          <div class="header-right">
            <div class="meta-box dark">ID: {{ kaizenNo }}</div>
            <button type="button" class="logout-pill" (click)="logout()">Logout</button>
          </div>
        </header>

        <form [formGroup]="opForm" (ngSubmit)="onSubmit()" class="form-content">
          <div class="row-grid">
            <div class="field"><label>Ticket/Emp ID*</label><input type="text" formControlName="emp_id"></div>
            <div class="field"><label>Operator Name*</label><input type="text" formControlName="emp_name"></div>
          </div>

          <div class="row-grid">
            <div class="field">
              <label>Machine/Line*</label>
              <input type="text" formControlName="machine_no">
            </div>
            <div class="field">
              <label>Section*</label>
              <select formControlName="section">
                <option value="Welding">Welding</option>
                <option value="Assembly">Assembly</option>
                <option value="Paint">Paint</option>
              </select>
            </div>
          </div>

          <div class="full-row field">
            <label>What was the problem?*</label>
            <textarea formControlName="problem" rows="3"></textarea>
          </div>

          <div class="full-row field">
            <label>What did you improve? (Idea)*</label>
            <textarea formControlName="improvement" rows="3"></textarea>
          </div>

          <button type="submit" class="btn-submit" [disabled]="opForm.invalid">
            ✔ SUBMIT OPERATOR KAIZEN
          </button>
        </form>
      </div>
    </div>
  `,
  styles: [`
    .operator-header { background: #1a1a1a !important; border-bottom: 5px solid #28a745 !important; }
    .shaktiman-ribbon { height: 18px; background: #28a745; position: fixed; top: 0; width: 100%; z-index: 1000; }
    /* Reusing your existing styles from supervisor form here */
    body { background: #f0f2f5; margin: 0; font-family: 'Segoe UI', sans-serif; }
    .container-main { padding: 50px 20px; max-width: 800px; margin: 0 auto; }
    .form-card { background: #fff; border-radius: 20px; box-shadow: 0 15px 40px rgba(0,0,0,0.1); overflow: hidden; }
    .form-header { color: #fff; padding: 25px; display: flex; justify-content: space-between; align-items: center; }
    .form-content { padding: 30px; }
    .row-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 15px; }
    .field { display: flex; flex-direction: column; gap: 5px; font-weight: bold; }
    input, select, textarea { padding: 12px; border: 2px solid #e2e8f0; border-radius: 10px; }
    .btn-submit { width: 100%; padding: 15px; background: #28a745; color: #fff; border: none; border-radius: 10px; font-weight: 800; cursor: pointer; margin-top: 15px; }
    .custom-overlay { position: fixed; top:0; left:0; width:100%; height:100%; background: rgba(0,0,0,0.6); display: flex; align-items: center; justify-content: center; z-index: 2000; }
    .modern-modal { background: #fff; padding: 30px; border-radius: 20px; text-align: center; width: 350px; }
  `]
})
export class OperatorFormComponent implements OnInit {
  public opForm!: FormGroup;
  public kaizenNo: string = "OP-01";
  public showSuccessModal: boolean = false;
  public lastSubmittedNo: string = "";

  constructor(private router: Router, private kaizenService: KaizenService) {}

  ngOnInit() {
    this.opForm = new FormGroup({
      emp_id: new FormControl('', Validators.required),
      emp_name: new FormControl('', Validators.required),
      machine_no: new FormControl('', Validators.required),
      section: new FormControl('Welding', Validators.required),
      problem: new FormControl('', Validators.required),
      improvement: new FormControl('', Validators.required)
    });
  }

  onSubmit() {
    if (this.opForm.valid) {
      this.kaizenService.submitOperatorKaizen(this.opForm.value).subscribe({
        next: (res: any) => {
          this.lastSubmittedNo = this.kaizenNo;
          this.showSuccessModal = true;
          
          // Increment ID
          const num = parseInt(this.kaizenNo.split('-')[1]);
          this.kaizenNo = `OP-${(num + 1).toString().padStart(2, '0')}`;
          
          this.opForm.reset({ section: 'Welding' });
        },
        error: (err: any) => alert("Error connecting to server")
      });
    }
  }

  logout() {
    this.router.navigate(['/login']);
  }
}