import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class KaizenService {
  private apiUrl = 'http://localhost:3000/api'; // Base API URL

  constructor(private http: HttpClient) {}

  // Existing Supervisor Method
  submitKaizen(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/kaizen`, data);
  }

  // NEW: Operator Method
  submitOperatorKaizen(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/operator-kaizen`, data);
  }
}