import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { BehaviorSubject, tap } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private userSubject = new BehaviorSubject<any>(null);

  constructor(private http: HttpClient, private router: Router) {}

  login(credentials: any) {
    return this.http.post('http://localhost:3000/api/admin/login', credentials).pipe(
      tap((res: any) => {
        // Store user info (Replacing $_SESSION)
        localStorage.setItem('user', JSON.stringify(res.user));
        this.userSubject.next(res.user);
        this.handleRedirect(res.user.role);
      })
    );
  }

  private handleRedirect(role: string) {
    const normalizedRole = role.toLowerCase().trim();
    if (normalizedRole === 'hod' || normalizedRole === 'head') {
      this.router.navigate(['/hod-dashboard']);
    } else if (normalizedRole === 'manager') {
      this.router.navigate(['/manager-dashboard']);
    } else if (normalizedRole === 'admin') {
      this.router.navigate(['/admin-dashboard']);
    } else {
      alert(`Role [${role}] not recognized.`);
    }
  }
}