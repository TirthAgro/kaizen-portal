import { environment } from '../../../environments/environment';
import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SupervisorLayoutComponent } from '../layout/supervisor-layout.component';
import { ReactiveFormsModule, FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-supervisor-form',
  templateUrl: './supervisor-form.component.html',
  styleUrls:   ['./supervisor-form.component.css'],
  standalone: true,
  imports: [CommonModule, SupervisorLayoutComponent, ReactiveFormsModule]
})
export class SupervisorFormComponent implements OnInit {
  currentView = 'sup-form';

  navItems: any[] = [
    { label: 'Dashboard',        route: '/dashboard',       svgPath: 'M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z' },
    { label: 'Operator Form',    route: '/operator-form',   svgPath: 'M12 5v14M5 12h14' },
    { label: 'Supervisor Form',  route: '/supervisor-form', svgPath: 'M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2' },
    { label: 'History',          route: '/dashboard',       svgPath: 'M12 8v4l3 3m6-3a9 9 0 1 1-18 0 9 9 0 0 1 18 0z' },
  ];


  public currentStep      = 1;
  public isSubmitting     = false;
  public kaizenNo         = 'Fetching...';
  public lastSubmittedNo  = '';
  public today            = new Date();
  public kaizenForm!: FormGroup;
  public showReviewModal = false;
  public isDuplicate      = false;
  public showConfirmModal = false;
  public showSuccessModal = false;
  public showClearModal   = false;

  // Toast system
  public toasts: { message: string; type: 'success' | 'error' | 'info'; id: number }[] = [];
  private toastId = 0;

  public availableUnits:       string[] = [];
  public availableDepartments: string[] = [];
  public availableSections:    string[] = [];

  public compressing: { [key: string]: boolean } = { before_img: false, after_img: false, problem_img: false, result_img: false };
  public compressInfo: { [key: string]: string  } = { before_img: '', after_img: '', problem_img: '', result_img: '' };
  public fileErrors:   { [key: string]: boolean } = { before_img: false, after_img: false, problem_img: false, result_img: false };
  private selectedFiles: { [key: string]: File | null } = { before_img: null, after_img: null, problem_img: null, result_img: null };
  private allThemes: string[] = [];

  // API वरून येतात — hardcoded नाही
  private allDepartments: { id: number; name: string; unit?: string }[] = [];
  private allSections:    { id: number; name: string; department?: string }[] = [];

  public categories = [
    { v: 'C-1|Restorative (TPM)',              l: 'C-1: Restorative (Using TPM Methodology)' },
    { v: 'C-2|Renovative (TPM)',               l: 'C-2: Renovative (Using TPM Methodology)' },
    { v: 'C-3|Innovative (TPM)',               l: 'C-3: Innovative (Using TPM Methodology)' },
    { v: 'C-4|Breakthrough (TPM)',             l: 'C-4: Breakthrough (Using TPM Methodology)' },
    { v: 'C-5|Poka Yoke (TPM)',                l: 'C-5: Poka Yoke (Using TPM Methodology)' },
    { v: 'C-6|KARAKURI & YUTORI',              l: 'C-6: KARAKURI (No Energy Loss) & YUTORI' },
    { v: 'C-7|JH Shop Floor Visualization',    l: 'C-7: JH - Shop Floor Visualization' },
    { v: 'C-8|KK OEE Compliance',              l: 'C-8: KK OEE Compliance' },
    { v: 'C-9|KK Bottleneck Process Solution', l: 'C-9: KK Bottleneck Process Solution' },
    { v: 'C-10|JH Circle Board Updating',      l: 'C-10: JH - Circle Board updating' },
    { v: 'C-11|JH One Point Lessons',          l: 'C-11: JH - One Point Lessons' },
    { v: 'C-12|JH White Tag Abnormality',      l: 'C-12: JH: White tag abnormality' },
    { v: 'C-13|JH (HTA / SOC / Ease for CLITA)', l: 'C-13: JH (HTA / SOC / Ease for CLITA)' },
    { v: 'C-14|JH Step 4 M-M Combination',    l: 'C-14: JH step 4 Man-Machine combination' },
    { v: 'C-15|JH Step 5 M-M Combination',    l: 'C-15: JH step 5 Man-Machine combination' },
    { v: 'C-16|JH Step 1, 2, 3 Repeat',       l: 'C-16: JH: Repeat of JH Step 1, 2, 3' },
    { v: 'C-17|JH Minor Stoppage Monitoring',  l: 'C-17: JH: Minor Stoppage Monitoring' },
    { v: 'C-18|JH RED Tag Abnormality',        l: 'C-18: JH: RED tag abnormality' },
    { v: 'C-19|QM Assembly Pokamapping',       l: 'C-19: QM: Product Assembly Pokamapping' },
    { v: 'C-20|PM MP Sheets Generation',       l: 'C-20: PM: Generation of MP sheets' },
    { v: 'C-21|NEDM MP Sheets Implementation', l: 'C-21: NEDM: Implementation of MP sheets' },
    { v: 'C-22|NEDM Low Cost Automation',      l: 'C-22: NEDM: Low Cost Automation' },
    { v: 'C-23|OTPM MAKIGAMI',                 l: 'C-23: OTPM: MAKIGAMI' },
    { v: 'C-24|OTPM Red Tag Office',           l: 'C-24: OTPM: Red tag at Office area (5S)' },
    { v: 'C-25|SHE Near Miss/Unsafe Condition',l: 'C-25: SHE: Near miss & Unsafe condition' },
    { v: 'C-26|SHE Unsafe Act',                l: 'C-26: SHE: Unsafe act' },
    { v: 'C-27|SHE Ergonomic Hazard',          l: 'C-27: SHE: Ergonomic hazard' },
    { v: 'C-28|SHE CO2 Emission Reduction',    l: 'C-28: SHE: CO2 emission reduction' },
    { v: 'C-29|SHE Micro Level HIRA',          l: 'C-29: SHE: Micro level HIRA' },
    { v: 'C-30|5S Zone Space Saved',           l: 'C-30: 5S: Zone wise space saved' },
    { v: 'C-31|5S Best 1S-3S',                 l: 'C-31: 5S: Best 1S, 2S, 3S at Zones' },
    { v: 'C-32|All Members',                   l: 'C-32: Sure Appreciation' },
    { v: 'C-33|All Members',                   l: 'C-33: Won the Awards from CII (Platinium & Gold)' },
    { v: 'C-34|All Members',                   l: 'C-34: Won the Awards from CII (Jury Challenger)' },
  ];


  private get authHeaders() {
    const token = sessionStorage.getItem('jwt_token') || '';
    return { headers: { 'Authorization': `Bearer ${token}` } };
  }
  constructor(private router: Router, private http: HttpClient, private cdr: ChangeDetectorRef) {}

  ngOnInit() { this.initForm(); this.fetchNextId(); this.loadExistingThemes(); this.loadMasterData(); }

  // ── Master Data — API वरून ────────────────────────────────────────────────
  loadMasterData() {
    // Units
    this.http.get<any[]>(environment.apiUrl + '/api/master/units').subscribe({
      next: res => {
        this.availableUnits = (res || []).map((u: any) => u.name || u.unit_name || u);
        // sessionStorage मधला plant_id preset
        const plant = sessionStorage.getItem('plant_id') || sessionStorage.getItem('plant') || '';
        if (plant && !this.kaizenForm.get('unit')?.value) {
          this.kaizenForm.patchValue({ unit: plant });
          this.onUnitChange();
        }
        this.cdr.detectChanges();
      },
      error: () => {
        // Fallback
        this.availableUnits = ['Unit 1','Unit 2','Unit 3','Unit 4','Unit 5'];
      }
    });
    // Departments
    this.http.get<any[]>(environment.apiUrl + '/api/master/departments').subscribe({
      next: res => { this.allDepartments = res || []; this.cdr.detectChanges(); },
      error: () => {}
    });
    // Sections
    this.http.get<any[]>(environment.apiUrl + '/api/master/sections').subscribe({
      next: res => { this.allSections = res || []; this.cdr.detectChanges(); },
      error: () => {}
    });
  }

  // ── Toast ──────────────────────────────────────────────────────────────────
  showToast(message: string, type: 'success' | 'error' | 'info' = 'info', duration = 3500) {
    const id = ++this.toastId;
    this.toasts.push({ message, type, id });
    this.cdr.detectChanges();
    setTimeout(() => {
      this.toasts = this.toasts.filter(t => t.id !== id);
      this.cdr.detectChanges();
    }, duration);
  }

  // ── Form init ──────────────────────────────────────────────────────────────
  initForm() {
    this.availableDepartments = []; this.availableSections = []; this.currentStep = 1;
    this.kaizenForm = new FormGroup({
      emp_id:          new FormControl('', [Validators.required]),
      emp_name:        new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z ]+$')]),
      unit:            new FormControl('', Validators.required),
      department:      new FormControl('', Validators.required),
      section:         new FormControl('', Validators.required),
      machine_no:      new FormControl('', Validators.required),
      kaizen_type:     new FormControl('Innovative', Validators.required),
      pqcdsm:          new FormControl('', Validators.required),
      kaizen_category: new FormControl('', Validators.required),
      theme:           new FormControl('', Validators.required),
      problem_status:  new FormControl('', Validators.required),
      idea:            new FormControl('', Validators.required),
      countermeasure:  new FormControl('', Validators.required),
      why1:            new FormControl('', Validators.required),
      why2:            new FormControl('', Validators.required),
      why3:            new FormControl('', Validators.required),
      why4:            new FormControl(''),
      why5:            new FormControl(''),
      root_cause:      new FormControl('', Validators.required),
      final_result:    new FormControl('', Validators.required),
      analysis:        new FormControl('', Validators.required),
      start_date:      new FormControl('', Validators.required),
      end_date:        new FormControl('', Validators.required),
      before_desc:     new FormControl('', Validators.required),
      after_desc:      new FormControl('', Validators.required),
      benefits:        new FormControl('1.', Validators.required),
      team:            new FormControl('1. ', Validators.required),
      horizontal_deployment: new FormArray([this.createRow()])
    });
  }

  createRow() {
    return new FormGroup({
      m_no:   new FormControl(''), resp: new FormControl(''),
      target: new FormControl(''), status: new FormControl('Pending')
    });
  }

  get deploymentRows() { return this.kaizenForm.get('horizontal_deployment') as FormArray; }
  addRow()    { this.deploymentRows.push(this.createRow()); }
  removeRow(i: number) { if (this.deploymentRows.length > 1) this.deploymentRows.removeAt(i); }

  // ── Step navigation ────────────────────────────────────────────────────────
  nextStep() {
    const fields: { [step: number]: string[] } = {
      1: ['emp_id','emp_name','unit','department','section','machine_no','kaizen_type','pqcdsm','kaizen_category','theme','start_date','end_date'],
      2: ['problem_status','idea','countermeasure','why1','why2','why3','root_cause','final_result','analysis']
    };
    fields[this.currentStep].forEach(k => this.kaizenForm.get(k)?.markAsTouched());
    const invalid = fields[this.currentStep].some(k => this.kaizenForm.get(k)?.invalid);
    if (invalid || (this.currentStep === 1 && this.isDuplicate)) return;
    this.currentStep++;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  prevStep() {
    if (this.currentStep > 1) { this.currentStep--; window.scrollTo({ top: 0, behavior: 'smooth' }); }
  }

  onUnitChange() {
    const u = this.kaizenForm.get('unit')?.value;
    // API departments filter by unit
    const byUnit: string[] = this.allDepartments
      .filter(d => !d.unit || d.unit === u)
      .map(d => (typeof d === 'string' ? d : d.name) as string)
      .filter(Boolean);
    this.availableDepartments = byUnit.length > 0 ? byUnit
      : ['Production', 'Quality', 'Maintenance', 'Stores'];
    this.availableSections = [];
    this.kaizenForm.patchValue({ department: '', section: '' });
    this.cdr.detectChanges();
  }

  onDepartmentChange() {
    const d = this.kaizenForm.get('department')?.value;
    // API sections filter by department
    const byDept: string[] = this.allSections
      .filter(s => !s.department || s.department === d)
      .map(s => (typeof s === 'string' ? s : s.name) as string)
      .filter(Boolean);
    this.availableSections = byDept.length > 0 ? byDept
      : ['Welding', 'Assembly', 'Paint Shop', 'Machine Shop'];
    this.kaizenForm.patchValue({ section: '' });
    this.cdr.detectChanges();
  }

  loadExistingThemes() {
    this.http.get<any[]>(environment.apiUrl + '/api/kaizen/my-kaizens', this.authHeaders).subscribe({
      next: (res) => { this.allThemes = res.map(k => (k.theme || '').toLowerCase().trim()).filter(t => t.length > 0); },
      error: () => { this.allThemes = []; }
    });
  }

  fetchNextId() {
    this.kaizenNo = 'Fetching...';
    this.http.get(environment.apiUrl + '/api/supervisor', { responseType: 'text' }).subscribe({
      next: (val) => {
        const count = val ? parseInt(val, 10) : 0;
        this.kaizenNo = `SUP-${new Date().getFullYear()}-${(count + 1).toString().padStart(3, '0')}`;
        this.cdr.detectChanges();
      },
      error: () => { this.kaizenNo = 'SUP-Error'; this.cdr.detectChanges(); }
    });
  }

  allowAlphabetsOnly(e: KeyboardEvent): boolean { const c = e.charCode; return (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c === 32; }
  allowTeamInput(e: KeyboardEvent): boolean { const c = e.charCode; return (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c === 32 || c === 46 || (c >= 48 && c <= 57); }

  onFileChange(event: any, field: string) {
    const file = event.target.files[0];
    if (!file) return;
    if (file.size <= 512000) {
      this.fileErrors[field] = false; this.compressInfo[field] = `✓ ${Math.round(file.size/1024)}KB — ready`;
      this.selectedFiles[field] = file; this.cdr.detectChanges(); return;
    }
    this.compressing[field] = true; this.compressInfo[field] = ''; this.cdr.detectChanges();
    this.compressImage(file, 500).then(compressed => {
      this.compressing[field] = false; this.fileErrors[field] = false; this.selectedFiles[field] = compressed;
      this.compressInfo[field] = `✓ Compressed: ${Math.round(file.size/1024)}KB → ${Math.round(compressed.size/1024)}KB`;
      this.cdr.detectChanges();
    }).catch(() => {
      this.compressing[field] = false; this.fileErrors[field] = true;
      this.showToast('Image compression failed. Please try another file.', 'error');
      this.cdr.detectChanges(); event.target.value = '';
    });
  }

  compressImage(file: File, maxSizeKB: number): Promise<File> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (e: any) => {
        const img = new Image(); img.src = e.target.result;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let w = img.width, h = img.height; const MAX = 1200;
          if (w > MAX || h > MAX) { if (w > h) { h = Math.round(h * MAX / w); w = MAX; } else { w = Math.round(w * MAX / h); h = MAX; } }
          canvas.width = w; canvas.height = h;
          canvas.getContext('2d')!.drawImage(img, 0, 0, w, h);
          let quality = 0.9;
          const tryCompress = () => {
            const dataUrl = canvas.toDataURL('image/jpeg', quality);
            const sizeKB = Math.round(dataUrl.length * 3 / 4 / 1024);
            if (sizeKB <= maxSizeKB || quality <= 0.3) {
              const arr = dataUrl.split(','); const bstr = atob(arr[1]); let n = bstr.length; const u8 = new Uint8Array(n);
              while (n--) u8[n] = bstr.charCodeAt(n);
              resolve(new File([u8], file.name, { type: 'image/jpeg' }));
            } else { quality -= 0.1; tryCompress(); }
          };
          tryCompress();
        };
        img.onerror = () => reject();
      };
      reader.onerror = () => reject();
    });
  }

  isAnyCompressing(): boolean { return Object.values(this.compressing).some(v => v); }
  hasFileError():     boolean { return Object.values(this.fileErrors).some(v => v); }

  checkDuplicateTheme() {
    const t = this.kaizenForm.get('theme')?.value?.toLowerCase().trim();
    this.isDuplicate = t && t.length > 2 ? this.allThemes.includes(t) : false;
  }

  handleTeamNumbering(e: KeyboardEvent) {
    if (e.key === 'Enter') {
      const val = (e.target as HTMLTextAreaElement).value;
      const lines = val.split('\n');
      if (lines[lines.length - 1].trim().length > 3) {
        e.preventDefault();
        this.kaizenForm.patchValue({ team: val + '\n' + (lines.length + 1) + '. ' });
      }
    }
  }

  handleBenefitsNumbering(e: KeyboardEvent) {
    if (e.key === 'Enter') {
      const val = (e.target as HTMLTextAreaElement).value;
      const lines = val.split('\n');
      if (lines[lines.length - 1].trim().length > 3) {
        e.preventDefault();
        this.kaizenForm.patchValue({ benefits: val + '\n' + (lines.length + 1) + '. ' });
      }
    }
  }

  // ── Clear form ─────────────────────────────────────────────────────────────
  clearForm() {
    this.showClearModal = true;
  }

  confirmClear() {
    this.showClearModal = false;
    this.initForm();
    this.resetFiles();
    this.showToast('Form cleared successfully.', 'info');
    this.cdr.detectChanges();
  }

  resetFiles() {
    this.selectedFiles = { before_img: null, after_img: null, problem_img: null, result_img: null };
    this.fileErrors    = { before_img: false, after_img: false, problem_img: false, result_img: false };
    this.compressing   = { before_img: false, after_img: false, problem_img: false, result_img: false };
    this.compressInfo  = { before_img: '', after_img: '', problem_img: '', result_img: '' };
    document.querySelectorAll<HTMLInputElement>('input[type="file"]').forEach(i => i.value = '');
  }

  // ── Submit ─────────────────────────────────────────────────────────────────
  onPreSubmit() {
  if (this.isSubmitting) return;
  Object.keys(this.kaizenForm.controls).forEach(k => this.kaizenForm.get(k)?.markAsTouched());
  if (this.kaizenForm.valid && !this.isDuplicate && !this.hasFileError() && !this.isAnyCompressing() && this.kaizenNo !== 'SUP-Error') {
    this.showReviewModal = true;   // ← changed
  } else {
    this.showToast('Please fill all required fields and ensure images are ready.', 'error', 4000);
  }
}

  finalSubmit() {
    if (this.isSubmitting) return;
    this.isSubmitting = true; this.showReviewModal = false; this.showConfirmModal = false; this.cdr.detectChanges();
    const formData = new FormData();
    const vals = this.kaizenForm.value;
    Object.keys(vals).forEach(k => { if (k !== 'horizontal_deployment') formData.append(k, vals[k]); });
    formData.append('kaizen_id',       this.kaizenNo);
    formData.append('submitted_at',    new Date().toISOString());
    formData.append('level',           'Supervisor');
    formData.append('deployment_data', JSON.stringify(vals.horizontal_deployment.filter((r: any) => r.m_no?.trim())));
    if (this.selectedFiles['before_img'])  formData.append('before_img_file',  this.selectedFiles['before_img']!);
    if (this.selectedFiles['after_img'])   formData.append('after_img_file',   this.selectedFiles['after_img']!);
    if (this.selectedFiles['problem_img']) formData.append('problem_img_file', this.selectedFiles['problem_img']!);
    if (this.selectedFiles['result_img'])  formData.append('result_img_file',  this.selectedFiles['result_img']!);

    this.http.post(environment.apiUrl + '/api/supervisor/save', formData, { responseType: 'text' }).subscribe({
      next: () => {
        this.lastSubmittedNo = this.kaizenNo;
        this.showSuccessModal = true;
        this.isSubmitting = false;
        this.initForm(); this.resetFiles(); this.fetchNextId(); this.loadExistingThemes();
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.isSubmitting = false;
        this.showToast('Submission failed: ' + (err.message || 'Unknown error'), 'error', 5000);
        this.cdr.detectChanges();
      }
    });
  }

  editStep(step: number) {
  this.showReviewModal = false;
  this.currentStep = step;
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

getFileName(field: string): string {
  return this.selectedFiles[field]?.name || '';
}

  goBack() { window.history.back(); }


  handleViewChange(view: string) {
    this.currentView = view;
    const routeMap: { [key: string]: string } = {
      'dashboard':   '/dashboard',
      'kaizens':     '/dashboard',
      'teams':       '/dashboard',
      'history':     '/dashboard',
      'op-form':     '/operator-form',
      'sup-form':    '/supervisor-form',
      'senior-form': '/senior-level',
    };
    const route = routeMap[view];
    if (route && route !== '/supervisor-form') {
      this.router.navigate([route], { state: { activeTab: view } });
    }
  }

  logout() {
    sessionStorage.clear();
    localStorage.clear();
    window.history.replaceState(null, '', '/');
    window.location.replace('/');
  }
}