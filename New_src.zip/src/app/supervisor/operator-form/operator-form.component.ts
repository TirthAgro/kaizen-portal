import { environment } from '../../../environments/environment';
import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SupervisorLayoutComponent } from '../../supervisor/layout/supervisor-layout.component';
import { ReactiveFormsModule, FormGroup, FormArray, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import JSZip from 'jszip';

/* ── Toaster ── */
interface Toast {
  id:      number;
  type:    'success' | 'error' | 'warning';
  title:   string;
  message: string;
  visible: boolean;
}

@Component({
  selector: 'app-operator-form',
  templateUrl: './operator-form.component.html',
  styleUrls:   ['./operator-form.component.css'],
  standalone: true,
  imports: [CommonModule, SupervisorLayoutComponent, ReactiveFormsModule]
})
export class OperatorFormComponent implements OnInit {
  currentView = 'op-form';

  showClearModal  = false;
  showReviewModal = false;   // ← NEW: Review Modal flag

  navItems: any[] = [
    { label: 'Dashboard',     route: '/dashboard',     svgPath: 'M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z' },
    { label: 'Operator Form', route: '/operator-form', svgPath: 'M12 5v14M5 12h14' },
    { label: 'History',       route: '/dashboard',     svgPath: 'M12 8v4l3 3m6-3a9 9 0 1 1-18 0 9 9 0 0 1 18 0z' },
  ];

  // ── State ──
  public currentStep     = 1;
  public kaizenNo        = 'Fetching...';
  public today           = new Date();
  public kaizenForm!: FormGroup;
  public isSubmitting    = false;
  public isDuplicate     = false;
  public showConfirmModal = false;
  public showSuccessModal = false;
  public lastSubmittedNo = '';

  public fileErrors:   { [key: string]: boolean } = { before_img: false, after_img: false };
  public compressing:  { [key: string]: boolean } = { before_img: false, after_img: false };
  public compressInfo: { [key: string]: string  } = { before_img: '', after_img: '' };
  public selectedFiles: { [key: string]: File | null } = { before_img: null, after_img: null };
  private allThemes: string[] = [];

  /* ── Toaster ── */
  public toasts: Toast[] = [];
  private toastCounter = 0;

  private readonly SUPPORTED_IMAGES = [
    'image/jpeg','image/png','image/gif','image/webp','image/bmp','image/svg+xml'
  ];
  private readonly SUPPORTED_DOCS = [
    'application/pdf',
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'text/plain'
  ];
  private readonly MAX_IMAGE_KB = 500;
  private readonly MAX_VIDEO_MB = 20;

  // API वरून येतात — hardcoded नाही
  public availableUnits:    string[] = [];
  public allDepartments:    { id?: number; name: string; unit?: string }[] = [];
  public allSections:       { id?: number; name: string; department?: string }[] = [];
  public currentDepartments: string[] = [];
  public currentSections:    string[] = [];

  public categories = [
    { v: 'C-1|Restorative (TPM)',              l: 'C-1: Restorative (Using TPM Methodology)' },
    { v: 'C-2|Renovative (TPM)',               l: 'C-2: Renovative (Using TPM Methodology)' },
    { v: 'C-3|Innovative (TPM)',               l: 'C-3: Innovative (Using TPM Methodology)' },
    { v: 'C-4|Breakthrough (TPM)',             l: 'C-4: Breakthrough (Using TPM Methodology)' },
    { v: 'C-5|Poka Yoke (TPM)',                l: 'C-5: Poka Yoke (Using TPM Methodology)' },
    { v: 'C-6|KARAKURI & YUTORI',              l: 'C-6: KARAKURI (No Energy Loss) & YUTORI' },
    { v: 'C-7|JH Shop Floor Visualization',    l: 'C-7: JH - Shop Floor Visualization' },
    { v: 'C-8|KK OEE Compliance',              l: 'C-8: KK OEE Compliance' },
    { v: 'C-9|KK Bottleneck Process Solution', l: 'C-9: KK Bottleneck Process Solution' },
    { v: 'C-10|JH Circle Board Updating',      l: 'C-10: JH - Circle Board updating' },
    { v: 'C-11|JH One Point Lessons',          l: 'C-11: JH - One Point Lessons' },
    { v: 'C-12|JH White Tag Abnormality',      l: 'C-12: JH: White tag abnormality' },
    { v: 'C-13|JH (HTA / SOC / Ease for CLITA)', l: 'C-13: JH (HTA / SOC / Ease for CLITA)' },
    { v: 'C-14|JH Step 4 M-M Combination',    l: 'C-14: JH step 4 Man-Machine combination' },
    { v: 'C-15|JH Step 5 M-M Combination',    l: 'C-15: JH step 5 Man-Machine combination' },
    { v: 'C-16|JH Step 1, 2, 3 Repeat',       l: 'C-16: JH: Repeat of JH Step 1, 2, 3' },
    { v: 'C-17|JH Minor Stoppage Monitoring',  l: 'C-17: JH: Minor Stoppage Monitoring' },
    { v: 'C-18|JH RED Tag Abnormality',        l: 'C-18: JH: RED tag abnormality' },
    { v: 'C-19|QM Assembly Pokamapping',       l: 'C-19: QM: Product Assembly Pokamapping' },
    { v: 'C-20|PM MP Sheets Generation',       l: 'C-20: PM: Generation of MP sheets' },
    { v: 'C-21|NEDM MP Sheets Implementation', l: 'C-21: NEDM: Implementation of MP sheets' },
    { v: 'C-22|NEDM Low Cost Automation',      l: 'C-22: NEDM: Low Cost Automation' },
    { v: 'C-23|OTPM MAKIGAMI',                 l: 'C-23: OTPM: MAKIGAMI' },
    { v: 'C-24|OTPM Red Tag Office',           l: 'C-24: OTPM: Red tag at Office area (5S)' },
    { v: 'C-25|SHE Near Miss/Unsafe Condition',l: 'C-25: SHE: Near miss & Unsafe condition' },
    { v: 'C-26|SHE Unsafe Act',                l: 'C-26: SHE: Unsafe act' },
    { v: 'C-27|SHE Ergonomic Hazard',          l: 'C-27: SHE: Ergonomic hazard' },
    { v: 'C-28|SHE CO2 Emission Reduction',    l: 'C-28: SHE: CO2 emission reduction' },
    { v: 'C-29|SHE Micro Level HIRA',          l: 'C-29: SHE: Micro level HIRA' },
    { v: 'C-30|5S Zone Space Saved',           l: 'C-30: 5S: Zone wise space saved' },
    { v: 'C-31|5S Best 1S-3S',                 l: 'C-31: 5S: Best 1S, 2S, 3S at Zones' },
    { v: 'C-32|All Members',                   l: 'C-32: Sure Appreciation' },
    { v: 'C-33|All Members',                   l: 'C-33: Won the Awards from CII (Platinium & Gold)' },
    { v: 'C-34|All Members',                   l: 'C-34: Won the Awards from CII (Jury Challenger)' },
  ];

  private get authHeaders() {
    const token = sessionStorage.getItem('jwt_token') || '';
    return { headers: { 'Authorization': `Bearer ${token}` } };
  }
  constructor(private router: Router, private http: HttpClient, private cdr: ChangeDetectorRef) {}

  ngOnInit() { this.fetchNextId(); this.loadExistingThemes(); this.initForm(); this.loadMasterData(); }

  /* ══════════════════════════════════
     TOASTER METHODS
  ══════════════════════════════════ */
  showToast(type: 'success' | 'error' | 'warning', title: string, message: string) {
    const id = ++this.toastCounter;
    const toast: Toast = { id, type, title, message, visible: false };
    this.toasts.push(toast);
    this.cdr.detectChanges();
    requestAnimationFrame(() => {
      toast.visible = true;
      this.cdr.detectChanges();
    });
    setTimeout(() => this.dismissToast(id), 4000);
  }

  dismissToast(id: number) {
    const toast = this.toasts.find(t => t.id === id);
    if (!toast) return;
    toast.visible = false;
    this.cdr.detectChanges();
    setTimeout(() => {
      this.toasts = this.toasts.filter(t => t.id !== id);
      this.cdr.detectChanges();
    }, 400);
  }

  initForm() {
    this.currentDepartments = [];
    this.currentStep = 1;
    this.kaizenForm = new FormGroup({
      emp_id:          new FormControl('', [Validators.required]),
      emp_name:        new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z ]+$')]),
      unit:            new FormControl('', Validators.required),
      department:      new FormControl('', Validators.required),
      zone:            new FormControl('', Validators.required),
      section:         new FormControl('', Validators.required),
      other_section:   new FormControl(''),
      theme:           new FormControl('', Validators.required),
      pqcdsm:          new FormControl('', Validators.required),
      kaizen_category: new FormControl('', Validators.required),
      start_date:      new FormControl('', Validators.required),
      end_date:        new FormControl('', Validators.required),
      before_desc:     new FormControl('', Validators.required),
      after_desc:      new FormControl('', Validators.required),
      benefits:        new FormControl('1.', Validators.required),
      team:            new FormControl('1. ', Validators.required),
    });
  }

  goToStep2() {
    const step1Fields = ['emp_id','emp_name','unit','department','zone','section','theme','pqcdsm','kaizen_category','start_date','end_date'];
    step1Fields.forEach(k => this.kaizenForm.get(k)?.markAsTouched());
    if (step1Fields.some(k => this.kaizenForm.get(k)?.invalid) || this.isDuplicate) {
      this.showToast('warning', 'Incomplete Fields', 'Please fill in all required fields before proceeding to the next step.');
      return;
    }
    this.currentStep = 2;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  loadMasterData() {
    this.http.get<any[]>(environment.apiUrl + '/api/master/units').subscribe({
      next: res => {
        this.availableUnits = (res || []).map((u: any) => u.name || u.unit_name || u);
        const plant = sessionStorage.getItem('plant_id') || sessionStorage.getItem('plant') || '';
        if (plant && !this.kaizenForm.get('unit')?.value) {
          this.kaizenForm.patchValue({ unit: plant });
          this.onUnitChange();
        }
        this.cdr.detectChanges();
      },
      error: () => { this.availableUnits = ['Unit 1','Unit 2','Unit 3','Unit 4','Unit 5']; }
    });
    this.http.get<any[]>(environment.apiUrl + '/api/master/departments').subscribe({
      next: res => { this.allDepartments = res || []; this.cdr.detectChanges(); },
      error: () => {}
    });
    this.http.get<any[]>(environment.apiUrl + '/api/master/sections').subscribe({
      next: res => { this.allSections = res || []; this.cdr.detectChanges(); },
      error: () => {}
    });
  }

  onUnitChange() {
    const u = this.kaizenForm.get('unit')?.value;
    const byUnit: string[] = this.allDepartments
      .filter(d => !d.unit || d.unit === u)
      .map(d => (typeof d === 'string' ? d : d.name) as string)
      .filter(Boolean);
    this.currentDepartments = byUnit.length > 0 ? byUnit
      : ['Production', 'Quality', 'Maintenance', 'Stores'];
    this.currentSections = [];
    this.kaizenForm.patchValue({ department: '', zone: '', section: '', other_section: '' });
    this.cdr.detectChanges();
  }

  onDepartmentChange() {
    const d = this.kaizenForm.get('department')?.value;
    const byDept: string[] = this.allSections
      .filter(s => !s.department || s.department === d)
      .map(s => (typeof s === 'string' ? s : s.name) as string)
      .filter(Boolean);
    this.currentSections = byDept.length > 0 ? byDept
      : ['Welding', 'Assembly', 'Paint Shop', 'Machine Shop'];
    this.kaizenForm.patchValue({ zone: '', section: '', other_section: '' });
    this.cdr.detectChanges();
  }

  onSectionChange() {
    if (this.kaizenForm.get('section')?.value !== 'Other') this.kaizenForm.patchValue({ other_section: '' });
  }

  loadExistingThemes() {
    this.http.get<any[]>(environment.apiUrl + '/api/kaizen/my-kaizens', this.authHeaders).subscribe({
      next: (res) => { this.allThemes = res.map(k => (k.theme || '').toLowerCase().trim()).filter(t => t.length > 0); },
      error: () => { this.allThemes = []; }
    });
  }

  fetchNextId() {
    this.kaizenNo = 'Fetching...';
    this.http.get(environment.apiUrl + '/api/operator', { responseType: 'text' }).subscribe({
      next: (val) => {
        const count = val ? parseInt(val, 10) : 0;
        this.kaizenNo = `OP-${new Date().getFullYear()}-${(count + 1).toString().padStart(3, '0')}`;
        this.cdr.detectChanges();
      },
      error: () => { this.kaizenNo = 'KZN-Error'; this.cdr.detectChanges(); }
    });
  }

  /* ══════════════════════════════════
     SMART FILE UPLOAD
  ══════════════════════════════════ */
  async onFileChange(event: Event, field: 'before_img' | 'after_img' | 'problem_img' | 'result_img'): Promise<void> {
    const input = event.target as HTMLInputElement;
    const file  = input.files?.[0];
    if (!file) return;

    this.fileErrors[field]    = false;
    this.compressInfo[field]  = '';
    this.selectedFiles[field] = null;
    this.compressing[field]   = false;
    this.cdr.detectChanges();

    const mime = file.type;

    try {
      if (this.SUPPORTED_IMAGES.includes(mime) || mime.startsWith('image/')) {
        await this.handleImage(file, field);
        return;
      }
      if (mime === 'video/mp4') {
        this.handleVideo(file, field, input);
        return;
      }
      if (this.SUPPORTED_DOCS.includes(mime)) {
        await this.handleDocument(file, field);
        return;
      }
      this.setError(field, input, `✗ Unsupported file type: .${file.name.split('.').pop()}`);
    } catch (err: any) {
      this.setError(field, input, `✗ ${err?.message ?? 'Upload failed. Try again.'}`);
    }
  }

  private async handleImage(file: File, field: string): Promise<void> {
    const originalKB = Math.round(file.size / 1024);
    if (file.size <= this.MAX_IMAGE_KB * 1024) {
      this.selectedFiles[field] = file;
      this.compressInfo[field]  = `✓ Image ready (${originalKB}KB)`;
      this.cdr.detectChanges();
      return;
    }
    this.compressing[field] = true;
    this.cdr.detectChanges();
    const compressed = await this.compressImage(file, this.MAX_IMAGE_KB);
    const finalKB    = Math.round(compressed.size / 1024);
    this.compressing[field]   = false;
    this.selectedFiles[field] = compressed;
    this.compressInfo[field]  = `✓ Image compressed ${originalKB}KB → ${finalKB}KB`;
    this.cdr.detectChanges();
  }

  private handleVideo(file: File, field: string, input: HTMLInputElement): void {
    const sizeMB = file.size / (1024 * 1024);
    if (sizeMB > this.MAX_VIDEO_MB) {
      this.setError(field, input, `✗ Video size exceeds limit (${sizeMB.toFixed(1)}MB). Maximum allowed size is ${this.MAX_VIDEO_MB}MB`);
      this.showToast('error', 'Video Too Large', `The selected video is ${sizeMB.toFixed(1)}MB. Maximum allowed size is ${this.MAX_VIDEO_MB}MB.`);
      return;
    }
    this.selectedFiles[field] = file;
    this.compressInfo[field]  = `✓ Video ready (${sizeMB.toFixed(1)}MB)`;
    this.cdr.detectChanges();
  }

  private async handleDocument(file: File, field: string): Promise<void> {
    this.compressing[field] = true;
    this.cdr.detectChanges();
    const originalKB = Math.round(file.size / 1024);
    const zipped     = await this.compressDocumentToZip(file);
    const zippedKB   = Math.round(zipped.size / 1024);
    this.compressing[field]   = false;
    this.selectedFiles[field] = zipped;
    this.compressInfo[field]  = `✓ Document zipped ${originalKB}KB → ${zippedKB}KB`;
    this.cdr.detectChanges();
  }

  private setError(field: string, input: HTMLInputElement, message: string): void {
    this.fileErrors[field]   = true;
    this.compressInfo[field] = message;
    this.compressing[field]  = false;
    input.value = '';
    this.cdr.detectChanges();
  }

  compressImage(file: File, maxSizeKB: number): Promise<File> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (e: ProgressEvent<FileReader>) => {
        const img = new Image();
        img.src   = e.target!.result as string;
        img.onload = () => {
          const MAX_DIM = 1400;
          let { width: w, height: h } = img;
          if (w > MAX_DIM || h > MAX_DIM) {
            if (w > h) { h = Math.round(h * MAX_DIM / w); w = MAX_DIM; }
            else        { w = Math.round(w * MAX_DIM / h); h = MAX_DIM; }
          }
          const canvas  = document.createElement('canvas');
          canvas.width  = w; canvas.height = h;
          canvas.getContext('2d')!.drawImage(img, 0, 0, w, h);
          let quality = 0.88;
          const tryCompress = (): void => {
            const dataUrl = canvas.toDataURL('image/jpeg', quality);
            const sizeKB  = Math.round((dataUrl.length * 3) / 4 / 1024);
            if (sizeKB <= maxSizeKB || quality <= 0.25) {
              const [, b64] = dataUrl.split(',');
              const binary  = atob(b64);
              const u8      = new Uint8Array(binary.length);
              for (let i = 0; i < binary.length; i++) u8[i] = binary.charCodeAt(i);
              resolve(new File([u8], file.name.replace(/\.[^.]+$/, '.jpg'), { type: 'image/jpeg' }));
            } else { quality = Math.max(0.25, quality - 0.08); tryCompress(); }
          };
          tryCompress();
        };
        img.onerror = () => reject(new Error('Image load failed'));
      };
      reader.onerror = () => reject(new Error('File read failed'));
    });
  }

  async compressDocumentToZip(file: File): Promise<File> {
    const zip    = new JSZip();
    const buffer = await file.arrayBuffer();
    zip.file(file.name, buffer, { compression: 'DEFLATE', compressionOptions: { level: 9 } });
    const blob   = await zip.generateAsync({ type: 'blob' });
    return new File([blob], file.name.replace(/\.[^.]+$/, '.zip'), { type: 'application/zip' });
  }

  hasFileError():     boolean { return Object.values(this.fileErrors).some(Boolean); }
  isAnyCompressing(): boolean { return Object.values(this.compressing).some(Boolean); }

  allowAlphabetsOnly(e: KeyboardEvent): boolean {
    const c = e.charCode;
    return (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c === 32;
  }
  allowTeamInput(e: KeyboardEvent): boolean {
    const c = e.charCode;
    return (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c === 32 || c === 46 || (c >= 48 && c <= 57);
  }

  checkDuplicateTheme() {
    const t = this.kaizenForm.get('theme')?.value?.toLowerCase().trim();
    this.isDuplicate = t && t.length > 2 ? this.allThemes.includes(t) : false;
  }

  handleTeamNumbering(e: KeyboardEvent) {
    if (e.key === 'Enter') {
      const val   = (e.target as HTMLTextAreaElement).value;
      const lines = val.split('\n');
      if (lines[lines.length - 1].trim().length > 3) {
        e.preventDefault();
        this.kaizenForm.patchValue({ team: val + '\n' + (lines.length + 1) + '. ' });
      }
    }
  }

  handleBenefitsNumbering(e: KeyboardEvent) {
    if (e.key === 'Enter') {
      const val   = (e.target as HTMLTextAreaElement).value;
      const lines = val.split('\n');
      if (lines[lines.length - 1].trim().length > 3) {
        e.preventDefault();
        this.kaizenForm.patchValue({ benefits: val + '\n' + (lines.length + 1) + '. ' });
      }
    }
  }

  /* ══════════════════════════════════
     REVIEW MODAL — open / goto step
  ══════════════════════════════════ */
  openReviewModal() {
    // Mark all fields touched to show any validation errors
    Object.keys(this.kaizenForm.controls).forEach(k => this.kaizenForm.get(k)?.markAsTouched());

    if (this.kaizenNo === 'KZN-Error') {
      this.showToast('error', 'System Offline', 'Unable to connect to the backend server. Please try again later.');
      return;
    }
    if (this.isDuplicate) {
      this.showToast('warning', 'Duplicate Theme', 'This theme already exists. Please use a unique theme.');
      return;
    }
    if (this.hasFileError()) {
      this.showToast('error', 'File Error', 'Some uploaded files contain errors. Please re-upload them.');
      return;
    }
    if (this.isAnyCompressing()) {
      this.showToast('warning', 'Please Wait', 'Files are still being processed. Please wait a moment.');
      return;
    }
    if (this.kaizenForm.invalid) {
      this.showToast('error', 'Form Incomplete', 'Please complete all required fields before submitting.');
      return;
    }
    this.showReviewModal = true;
  }

  goToEditStep(step: number) {
    this.showReviewModal = false;
    this.currentStep = step;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  /* ── helper: get category label by value ── */
  getCategoryLabel(val: string): string {
    return this.categories.find(c => c.v === val)?.l || val;
  }

  /* ── helper: get file name or fallback ── */
  getFileName(field: string): string {
    return this.selectedFiles[field]?.name || '— No file selected —';
  }

  onPreSubmit() {
    // Called from Review Modal "Submit Now" button — directly submit, no confirm modal
    this.showReviewModal = false;
    this.finalSubmit();
  }

  finalSubmit() {
    this.isSubmitting = true; this.showConfirmModal = false;
    const formData = new FormData();
    Object.keys(this.kaizenForm.value).forEach(k => formData.append(k, this.kaizenForm.value[k] ?? ''));
    formData.append('kaizen_id',    this.kaizenNo);
    formData.append('submitted_at', new Date().toISOString());
    formData.append('level',        'Operator');
    if (this.selectedFiles['before_img']) formData.append('before_img_file', this.selectedFiles['before_img']!);
    if (this.selectedFiles['after_img'])  formData.append('after_img_file',  this.selectedFiles['after_img']!);

    this.http.post(environment.apiUrl + '/api/operator/save', formData).subscribe({
      next: (res: any) => {
        if (res && res.status === 'success') {
          this.lastSubmittedNo = this.kaizenNo;
          this.showSuccessModal = true;
          this.showToast('success', 'Kaizen Registered!', `${this.kaizenNo} has been submitted successfully.`);
          this.isSubmitting = false;
          this.initForm();
          this.selectedFiles = { before_img: null, after_img: null };
          this.fileErrors    = { before_img: false, after_img: false };
          this.compressing   = { before_img: false, after_img: false };
          this.compressInfo  = { before_img: '', after_img: '' };
          document.querySelectorAll<HTMLInputElement>('input[type="file"]').forEach(i => i.value = '');
          this.fetchNextId(); this.loadExistingThemes(); this.cdr.detectChanges();
        } else {
          this.showToast('error', 'Backend Error', res?.message || 'An unknown server error occurred.');
          this.isSubmitting = false;
        }
      },
      error: (err) => {
        const msg =
          err.status === 500
            ? 'A database error occurred. Please contact the administrator.'
            : 'Submission failed. Please check your internet connection and try again.';
        this.showToast('error', 'Submission Failed', msg);
        this.isSubmitting = false;
      }
    });
  }

  goBack()  { window.history.back(); }

  confirmClear() { this.showClearModal = false; this.initForm(); }

  clearForm() { this.showClearModal = true; }

  prevStep() {
    if (this.currentStep > 1) {
      this.currentStep--;
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  nextStep() {
    if (this.currentStep < 3) {
      this.currentStep++;
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  addRow() {
    const rows = this.kaizenForm?.get('deployments') as any;
    if (rows) rows.push(this.createDeploymentRow());
  }

  removeRow(i: number) {
    const rows = this.kaizenForm?.get('deployments') as any;
    if (rows && rows.length > 1) rows.removeAt(i);
  }

  createDeploymentRow(): any {
    return new FormGroup({
      dept:   new FormControl(''),
      target: new FormControl(''),
      actual: new FormControl(''),
      status: new FormControl('')
    });
  }

  handleViewChange(view: string) {
    this.currentView = view;
    const routeMap: { [key: string]: string } = {
      'dashboard':   '/dashboard',
      'kaizens':     '/dashboard',
      'teams':       '/dashboard',
      'history':     '/dashboard',
      'op-form':     '/operator-form',
      'sup-form':    '/supervisor-form',
      'senior-form': '/senior-level',
    };
    const route = routeMap[view];
    if (route && route !== '/operator-form') {
      this.router.navigate([route], { state: { activeTab: view } });
    }
  }

  logout() {
    sessionStorage.clear();
    localStorage.clear();
    window.history.replaceState(null, '', '/');
    window.location.replace('/');
  }
}