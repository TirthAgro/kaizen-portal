import { Component, OnInit, AfterViewInit, HostListener, ElementRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { Chart, registerables } from 'chart.js';
import { SupervisorLayoutComponent } from '../layout/supervisor-layout.component';
Chart.register(...registerables);

interface UserData {
  plant_id: string;
  role:     string;
  user_id:  string;
  plant:    string;
  section:  string;
}

export interface HistoryRecord {
  id:               number;
  kaizen_id?:       string;
  theme?:           string;
  role_type?:       string;
  source?:          string;
  pqcdsm?:          string;
  status?:          string;
  created_at?:      string;
  assigned_to_name?:string;
  approved_by?:     string;
  filled_by?:       string;
  filled_for?:      string;
  form_type?:       string;
  submitted_on?:    string;
  remark?:          string;
  [key: string]:    any;
}

export interface KaizenNotification {
  id:        number;
  title:     string;
  filled_by: string;
  time_ago:  string;
  manager:   string;
  status:    'Approved' | 'Rejected' | 'Pending';
}

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, SupervisorLayoutComponent],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent implements OnInit, AfterViewInit {

  @ViewChild('pieCanvas')  pieCanvas!:  ElementRef<HTMLCanvasElement>;
  @ViewChild('barCanvas')  barCanvas!:  ElementRef<HTMLCanvasElement>;

  public user:        UserData | null = null;
  public userInitial: string          = '?';
  public profileOpen: boolean         = false;
  public activeTab:   string          = 'dashboard';
  public role:        string          = '';
  public myKaizens:       any[]       = [];
  public myKaizensLoading: boolean    = false;
  public historyData:    any[]        = [];
  public historyLoading: boolean      = false;

  private pieChart: Chart | null = null;
  private barChart: Chart | null = null;

  // ── Stats ──
  public stats = { pending: 0, approved: 0, rejected: 0, target: 0, costSaving: '₹0' };
  public empLabels: string[] = [];
  public empData:   number[] = [];

  // ── Notifications ──
  public notifications: KaizenNotification[] = [
    { id:1, title:'Line 3 Cycle Time Reduction', filled_by:'EMP001', time_ago:'2 hrs ago',  manager:'Mgr. Verma', status:'Approved' },
    { id:2, title:'Fixture Layout Change',        filled_by:'EMP003', time_ago:'5 hrs ago',  manager:'Mgr. Shah',  status:'Rejected' },
    { id:3, title:'Coolant Reuse Process',        filled_by:'EMP007', time_ago:'1 day ago',  manager:'',           status:'Pending'  },
    { id:4, title:'Tool Change Standardisation',  filled_by:'EMP002', time_ago:'2 days ago', manager:'Mgr. Verma', status:'Approved' },
    { id:5, title:'Scrap Sorting Station',        filled_by:'EMP005', time_ago:'3 days ago', manager:'Mgr. Patel', status:'Rejected' },
  ];

  // ── Deployment ──
  public deploymentData = [
    { name:'Assembly — Plant 1',    pct:92, color:'#22c55e' },
    { name:'Paint Shop — Plant 2',  pct:88, color:'#38bdf8' },
    { name:'SCM — Corporate',       pct:81, color:'#f59e0b' },
    { name:'Quality — Plant 3',     pct:83, color:'#a855f7' },
    { name:'Stores — Plant 1',      pct:67, color:'#ff6b2b' },
    { name:'Maintenance — Plant 2', pct:54, color:'#ef4444' },
  ];

  // ── History — API वरून येतो ──

  public filterStatus: string = 'All';
  public searchQuery:  string = '';

  get filteredHistory(): any[] {
    return this.historyData.filter(r => {
      const matchStatus = this.filterStatus === 'All' || r.status === this.filterStatus || (!r.status && this.filterStatus === 'Pending');
      const q = this.searchQuery.toLowerCase();
      const matchSearch = !q ||
        (r.kaizen_id || '').toLowerCase().includes(q) ||
        (r.theme     || '').toLowerCase().includes(q) ||
        (r.role_type || r.source || '').toLowerCase().includes(q);
      return matchStatus && matchSearch;
    });
  }

  constructor(private router: Router, private http: HttpClient) {}

  ngOnInit() {
    const raw = localStorage.getItem('user');
    if (raw) {
      this.user        = JSON.parse(raw) as UserData;
      this.userInitial = this.user.user_id?.charAt(0).toUpperCase() ?? '?';
    }
    this.role = (sessionStorage.getItem('role') || this.user?.role || '').toLowerCase().trim();

    // Form components se wapas aane par correct tab restore karo
    const navState = window.history.state;
    if (navState?.activeTab) {
      this.activeTab = navState.activeTab;
      if (this.activeTab === 'history') {
        this.loadHistory();
      }
    }

    this.loadStats();
    this.loadEmployeeStats();
  }

  loadStats() {
    const token = sessionStorage.getItem('jwt_token') || '';
    this.http.get<any>(
      `${environment.apiUrl}/api/supervisor-dashboard/stats`,
      { headers: { Authorization: `Bearer ${token}` } }
    ).subscribe({
      next: res => {
        this.stats.pending  = res.stats?.pending  ?? 0;
        this.stats.approved = res.stats?.approved ?? 0;
        this.stats.rejected = res.stats?.rejected ?? 0;
        this.stats.target   = res.stats?.total    ?? 0;
        if (this.activeTab === 'dashboard') {
          setTimeout(() => this.initCharts(), 100);
        }
      },
      error: () => {}
    });
  }

  loadEmployeeStats() {
    const token = sessionStorage.getItem('jwt_token') || '';
    this.http.get<any>(
      `${environment.apiUrl}/api/supervisor-dashboard/employee-stats`,
      { headers: { Authorization: `Bearer ${token}` } }
    ).subscribe({
      next: res => {
        const list = res.employees ?? [];
        this.empLabels = list.map((e: any) => e.emp_id);
        this.empData   = list.map((e: any) => e.count);
        // Bar chart refresh
        if (this.activeTab === 'dashboard') {
          setTimeout(() => this.initCharts(), 100);
        }
      },
      error: () => {}
    });
  }

  ngAfterViewInit() {
    if (this.activeTab === 'dashboard') {
      setTimeout(() => this.initCharts(), 100);
    }
  }

  initCharts() {
    this.destroyCharts();
    if (this.pieCanvas?.nativeElement) {
      this.pieChart = new Chart(this.pieCanvas.nativeElement, {
        type: 'doughnut',
        data: {
          labels: ['Approved', 'Pending', 'Rejected'],
          datasets: [{
            data: [
              this.stats.approved,
              this.stats.pending,
              this.stats.rejected
            ],
            backgroundColor: ['#22c55e', '#f59e0b', '#ef4444'],
            borderWidth: 0,
            borderRadius: 4,
            hoverOffset: 8
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          cutout: '65%',
          plugins: {
            legend: { display: false },
            tooltip: {
              callbacks: {
                label: (c) => ' ' + c.label + ': ' + c.raw
              }
            }
          }
        }
      });
    }

    if (this.barCanvas?.nativeElement) {
      this.barChart = new Chart(this.barCanvas.nativeElement, {
        type: 'bar',
        data: {
          labels: this.empLabels.length > 0 ? this.empLabels : ['No Data'],
          datasets: [{
            label: 'Kaizens',
            data: this.empData.length > 0 ? this.empData : [0],
            backgroundColor: 'rgba(56,189,248,0.18)',
            borderColor: '#38bdf8',
            borderWidth: 1.5,
            borderRadius: 5,
            borderSkipped: false
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            x: { grid: { display: false }, ticks: { color: '#64748b', font: { size: 11 } } },
            y: { grid: { color: 'rgba(0,0,0,0.04)' }, ticks: { color: '#64748b', font: { size: 11 }, stepSize: 4 }, beginAtZero: true }
          }
        }
      });
    }
  }

  destroyCharts() {
    this.pieChart?.destroy(); this.pieChart = null;
    this.barChart?.destroy(); this.barChart = null;
  }

  setTab(tab: string) {
    this.activeTab   = tab;
    this.profileOpen = false;
    if (tab === 'dashboard') {
      setTimeout(() => this.initCharts(), 150);
    } else if (tab === 'kaizens' || tab === 'op-form') {
      // op-form view — no API call needed
    } else if (tab === 'history') {
      this.loadHistory();
    }
  }

  // Called by SupervisorLayoutComponent's (viewChange) event
  onLayoutViewChange(view: string) {
    this.setTab(view);
  }

  // ── My Kaizens API ──────────────────────────────────────────
  loadMyKaizens() {
    this.myKaizensLoading = true;
    const empId = sessionStorage.getItem('emp_id')   || '';
    const token = sessionStorage.getItem('jwt_token') || '';
    this.http.get<any[]>(
      `${environment.apiUrl}/api/kaizen/my-kaizens?emp_id=${empId}`,
      { headers: { Authorization: `Bearer ${token}` } }
    ).subscribe({
      next: res => { this.myKaizens = res ?? []; this.myKaizensLoading = false; },
      error: ()  => { this.myKaizensLoading = false; }
    });
  }

  // ── History API ─────────────────────────────────────────────
  loadHistory() {
    this.historyLoading = true;
    const empId  = sessionStorage.getItem('emp_id')   || '';
    const userId = sessionStorage.getItem('user_id')  || '';
    const token  = sessionStorage.getItem('jwt_token') || '';
    const params = empId ? `?emp_id=${empId}` : userId ? `?emp_id=${userId}` : '';
    this.http.get<any[]>(
      `${environment.apiUrl}/api/kaizen/my-kaizens${params}`,
      { headers: { Authorization: `Bearer ${token}` } }
    ).subscribe({
      next: res => {
        this.historyData    = (res ?? []).map((k: any, i: number) => ({ ...k, id: i + 1 }));
        this.historyLoading = false;
      },
      error: () => { this.historyLoading = false; }
    });
  }

  getStatusCls(s: string): string {
    if (!s) return 'pending';
    const l = s.toLowerCase();
    return l.includes('approved') ? 'approved' : l.includes('rejected') ? 'rejected' : 'pending';
  }

  toggleProfile()      { this.profileOpen = !this.profileOpen; }
  closeProfile()       { this.profileOpen = false; }
  setFilter(s: string) { this.filterStatus = s; }
  onSearch(e: Event)   { this.searchQuery = (e.target as HTMLInputElement).value; }

  @HostListener('document:keydown.escape')
  onEscape() { this.profileOpen = false; }

  navigateTo(path: string) { this.profileOpen = false; this.router.navigate([path]); }

  onLogout() { localStorage.removeItem('user'); sessionStorage.clear();
    localStorage.clear();
    window.history.replaceState(null, '', '/');
    window.location.replace('/'); }
}