import { Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';
import { RoleGuard } from './guards/role.guard';

// import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
// import { AdminLoginComponent } from './admin-login/admin-login.component';
import { DashboardComponent } from './supervisor/dashboard/dashboard.component';
import { OperatorFormComponent } from './supervisor/operator-form/operator-form.component';
import { SupervisorFormComponent } from './supervisor/supervisor-form/supervisor-form.component';
import { PendingReviewsComponent } from './pending-reviews/pending-reviews';
import { ApprovedHistoryComponent } from './approved-history/approved-history';
import { ManagerDashboardComponent } from './manager/dashboard/manager_dashboard';
 import { ManagerRegistrationComponent } from './manager/registration/manager-registration.component';
import { HodDashboardComponent } from './hod/dashboard/hod-dashboard.component';
import { BexLayoutComponent } from './BEX/layout/bex-layout.component';
import { BexDashboardComponent } from './BEX/dashboard/bex-dashboard.component';
import { ManageUsersComponent } from './BEX/manage_users/manage-users.component';
import { DownloadReportComponent } from './BEX/download_report/download-report.component';
import { GlobKaizenComponent } from './BEX/glob_kaizen/glob-kaizen.component';
import { ViewKaizenComponent } from '../view_Kaizen/view_kaizen';
import { SeniorLevelComponent } from './supervisor/Senior_level/senior_level.component';

export const routes: Routes = [

  // Public routes — no login needed
  // { path: '', component: HomeComponent },
  { path: '', component: LoginComponent },
  // { path: 'admin-login', component: AdminLoginComponent },

  // Operator + Supervisor — both can access new-kaizen
  {
    path: 'new-kaizen',
    component: OperatorFormComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['OPERATOR', 'SUPERVISOR'] }
  },

  {
  path: 'operator-form',
  component: OperatorFormComponent,
  canActivate: [AuthGuard, RoleGuard],
  data: { roles: ['OPERATOR', 'SUPERVISOR'] }
},

  // Supervisor form (if separate page needed)
  {
    path: 'supervisor-form',
    component: SupervisorFormComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['SUPERVISOR'] }
  },
  {
    path: 'senior-level',
    component: SeniorLevelComponent,
  },

  // Dashboard — any logged in user
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [AuthGuard]
  },

  // View Kaizen — any logged in user
  {
    path: 'view-kaizen',
    component: ViewKaizenComponent,
    // canActivate: [AuthGuard]
  },

  // Pending reviews — any logged in user
  {
    path: 'pending-reviews',
    component: PendingReviewsComponent,
    canActivate: [AuthGuard]
  },

  // Approved history — any logged in user
  {
    path: 'approved-history',
    component: ApprovedHistoryComponent,
    canActivate: [AuthGuard]
  },

  // Manager routes
  {
    path: 'manager-dashboard',
    component: ManagerDashboardComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['MANAGER'] }
  },
  {
    path: 'manager-registration',
    component: ManagerRegistrationComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['MANAGER'] }
  },

  // HOD routes
  {
    path: 'hod-dashboard',
    component: HodDashboardComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['HOD'] }
  },

  // BEX routes
  {
    path: 'bex-dashboard',
    component: BexLayoutComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['BUSINESS_EXCELLENCE'] },
    children: [
      { path: '', component: BexDashboardComponent }
    ]
  },
  {
    path: 'manage-users',
    component: BexLayoutComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['BUSINESS_EXCELLENCE'] },
    children: [
      { path: '', component: ManageUsersComponent }
    ]
  },
  {
    path: 'report',
    component: BexLayoutComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['BUSINESS_EXCELLENCE'] },
    children: [
      { path: '', component: DownloadReportComponent }
    ]
  },
  {
    path: 'glob-kaizen',
    component: BexLayoutComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['BUSINESS_EXCELLENCE'] },
    children: [
      { path: '', component: GlobKaizenComponent }
    ]
  },

  // Catch all
  { path: '**', redirectTo: '' }
];