import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot } from '@angular/router';

@Injectable({ providedIn: 'root' })
export class RoleGuard implements CanActivate {

  constructor(private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot): boolean {
    const userRole = sessionStorage.getItem('role')?.trim().toUpperCase();
    const allowedRoles: string[] = (route.data['roles'] || [])
      .map((r: string) => r.toUpperCase());

    if (!userRole || !allowedRoles.includes(userRole)) {
      // ← was: alert('Access Denied...')
      this.showToast(
        'error',
        'Access Denied',
        'You do not have permission to view this page.'
      );
      this.router.navigate(['/login']);
      return false;
    }

    return true;
  }

  // ─────────────────────────────────────────────────
  // Self-contained toast — injects styles + DOM once,
  // no external service or component needed.
  // ─────────────────────────────────────────────────
  private showToast(
    type: 'success' | 'error' | 'warning' | 'info',
    title: string,
    message: string,
    duration = 4000
  ): void {
    this.ensureStyles();

    // ── Stack container (singleton) ──
    let stack = document.getElementById('rg-toast-stack');
    if (!stack) {
      stack = document.createElement('div');
      stack.id = 'rg-toast-stack';
      document.body.appendChild(stack);
    }

    // ── Icon SVG per type ──
    const icons: Record<string, string> = {
      success: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none"
                  stroke="currentColor" stroke-width="2.2"
                  stroke-linecap="round" stroke-linejoin="round">
                  <polyline points="20 6 9 17 4 12"/>
                </svg>`,
      error:   `<svg width="18" height="18" viewBox="0 0 24 24" fill="none"
                  stroke="currentColor" stroke-width="2.2"
                  stroke-linecap="round" stroke-linejoin="round">
                  <circle cx="12" cy="12" r="10"/>
                  <line x1="12" y1="8" x2="12" y2="12"/>
                  <line x1="12" y1="16" x2="12.01" y2="16"/>
                </svg>`,
      warning: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none"
                  stroke="currentColor" stroke-width="2.2"
                  stroke-linecap="round" stroke-linejoin="round">
                  <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94
                           a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
                  <line x1="12" y1="9"  x2="12"    y2="13"/>
                  <line x1="12" y1="17" x2="12.01" y2="17"/>
                </svg>`,
      info:    `<svg width="18" height="18" viewBox="0 0 24 24" fill="none"
                  stroke="currentColor" stroke-width="2.2"
                  stroke-linecap="round" stroke-linejoin="round">
                  <circle cx="12" cy="12" r="10"/>
                  <line x1="12" y1="16" x2="12"    y2="12"/>
                  <line x1="12" y1="8"  x2="12.01" y2="8"/>
                </svg>`
    };

    // ── Build toast element ──
    const toast = document.createElement('div');
    toast.className = `rg-toast rg-toast--${type}`;
    toast.innerHTML = `
      <div class="rg-toast__icon">${icons[type]}</div>
      <div class="rg-toast__body">
        <span class="rg-toast__title">${title}</span>
        <span class="rg-toast__msg">${message}</span>
      </div>
      <button class="rg-toast__close" aria-label="Close">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none"
          stroke="currentColor" stroke-width="2.5">
          <line x1="18" y1="6"  x2="6"  y2="18"/>
          <line x1="6"  y1="6"  x2="18" y2="18"/>
        </svg>
      </button>
      <div class="rg-toast__progress rg-toast__progress--${type}"
           style="animation-duration:${duration}ms"></div>
    `;

    stack.appendChild(toast);

    // Slide in
    requestAnimationFrame(() => {
      requestAnimationFrame(() => toast.classList.add('rg-toast--visible'));
    });

    // Dismiss helper
    const dismiss = () => {
      toast.classList.remove('rg-toast--visible');
      setTimeout(() => toast.remove(), 400);
    };

    // Close button
    toast.querySelector('.rg-toast__close')!
      .addEventListener('click', (e) => { e.stopPropagation(); dismiss(); });

    // Click anywhere on toast
    toast.addEventListener('click', dismiss);

    // Auto-dismiss
    setTimeout(dismiss, duration);
  }

  // ── Inject CSS once into <head> ──
  private ensureStyles(): void {
    if (document.getElementById('rg-toast-styles')) return;

    const style = document.createElement('style');
    style.id = 'rg-toast-styles';
    style.textContent = `
      #rg-toast-stack {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 99999;
        display: flex;
        flex-direction: column;
        gap: 10px;
        pointer-events: none;
      }

      .rg-toast {
        display: flex;
        align-items: flex-start;
        gap: 12px;
        background: #ffffff;
        border-radius: 14px;
        padding: 14px 16px 18px;
        min-width: 300px;
        max-width: 380px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.13), 0 2px 8px rgba(0,0,0,0.07);
        border: 1px solid #e4e8f0;
        position: relative;
        overflow: hidden;
        pointer-events: all;
        cursor: pointer;
        font-family: 'Poppins';

        opacity: 0;
        transform: translateX(110%);
        transition:
          opacity   0.35s cubic-bezier(0.2,1,0.3,1),
          transform 0.35s cubic-bezier(0.2,1,0.3,1);
      }

      .rg-toast--visible {
        opacity: 1;
        transform: translateX(0);
      }

      .rg-toast--success { border-left: 4px solid #10b981; }
      .rg-toast--error   { border-left: 4px solid #e53e3e; }
      .rg-toast--warning { border-left: 4px solid #d97706; }
      .rg-toast--info    { border-left: 4px solid #2d4fd6; }

      .rg-toast__icon {
        width: 34px; height: 34px;
        border-radius: 50%;
        display: grid; place-items: center;
        flex-shrink: 0;
      }
      .rg-toast--success .rg-toast__icon { background:#ecfdf5; color:#10b981; }
      .rg-toast--error   .rg-toast__icon { background:#fff5f5; color:#e53e3e; }
      .rg-toast--warning .rg-toast__icon { background:#fffbeb; color:#d97706; }
      .rg-toast--info    .rg-toast__icon { background:#eff6ff; color:#2d4fd6; }

      .rg-toast__body {
        flex: 1; display: flex;
        flex-direction: column; gap: 3px; min-width: 0;
      }
      .rg-toast__title {
        display: block; font-size: 13.5px; font-weight: 700;
        color: #1a2035; line-height: 1.2;
      }
      .rg-toast__msg {
        display: block; font-size: 12.5px;
        color: #8a93a8; line-height: 1.45;
      }

      .rg-toast__close {
        background: none; border: none; cursor: pointer;
        color: #b4bbc9; padding: 2px; border-radius: 4px;
        display: grid; place-items: center; flex-shrink: 0;
        transition: color 0.15s;
      }
      .rg-toast__close:hover { color: #1a2035; }

      .rg-toast__progress {
        position: absolute; bottom: 0; left: 0;
        height: 3px; width: 100%;
        border-radius: 0 0 14px 14px;
        animation: rg-shrink linear forwards;
      }
      .rg-toast__progress--success { background: #10b981; }
      .rg-toast__progress--error   { background: #e53e3e; }
      .rg-toast__progress--warning { background: #d97706; }
      .rg-toast__progress--info    { background: #2d4fd6; }

      @keyframes rg-shrink {
        from { width: 100%; }
        to   { width: 0%; }
      }
    `;

    document.head.appendChild(style);
  }
}