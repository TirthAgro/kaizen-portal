
export function doLogout(): void {
  sessionStorage.clear();
  localStorage.clear();
  window.history.replaceState(null, '', '/');
  window.history.pushState(null, '', '/');
  window.location.replace('/');
}