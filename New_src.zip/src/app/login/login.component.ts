import { environment } from '../../environments/environment';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { HttpClient } from '@angular/common/http';

/* ── Toast model ───────────────────────────────────────────── */
interface Toast {
  id: number;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message: string;
  visible: boolean;
}

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterModule
  ],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  // ───────────────── LOGIN ─────────────────
  userId   = '';
  password = '';
  liveTime = '';
  showPwd  = false;

  // ───────────────── LEFT PANEL ACCORDION ─────────────────
  openBox: number | null = 1;

  featureBoxes = [
    { title: 'Smart Kaizen System',     desc: 'Submit, track and manage Kaizen activities digitally with approval workflow.' },
    { title: 'Real-time Monitoring',    desc: 'Track department-wise Kaizen status, pending approvals and implementation progress.' },
    { title: 'Performance Analytics',   desc: 'View productivity improvements, savings, PQCDSM impact and team performance insights.' },
    { title: 'Enterprise Security',     desc: 'Secure role-based access system for Operator, Manager, HOD and Business Excellence teams.' }
  ];

  toggleBox(index: number) {
    this.openBox = this.openBox === index ? null : index;
  }

  // ───────────────── FORGOT PASSWORD FLOW ─────────────────
  step = 'login';

  forgotUserId = '';
  maskedEmail  = '';
  devOtp       = '';

  otp      = '';
  otpError = '';

  newPassword = '';
  confirmPwd  = '';

  pwdError    = '';
  forgotError = '';

  isLoading = false;

  // ───────────────── TOAST STATE ─────────────────
  toasts: Toast[] = [];
  private toastCounter = 0;


  private get authHeaders() {
    const token = sessionStorage.getItem('jwt_token') || '';
    return { headers: { 'Authorization': `Bearer ${token}` } };
  }
  constructor(
    private http: HttpClient,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.updateTime();
    setInterval(() => this.updateTime(), 1000);
  }

  // ───────────────── LIVE TIME ─────────────────
  updateTime() {
    this.liveTime = new Date().toLocaleTimeString('en-IN', {
      timeZone: 'Asia/Kolkata',
      hour: '2-digit', minute: '2-digit', second: '2-digit'
    });
  }

  // ───────────────── TOAST HELPERS ─────────────────
  showToast(type: Toast['type'], title: string, message: string, duration = 4000): void {
    const id = ++this.toastCounter;
    const toast: Toast = { id, type, title, message, visible: false };
    this.toasts.push(toast);
    this.cdr.detectChanges();

    // Trigger slide-in on next tick
    setTimeout(() => {
      toast.visible = true;
      this.cdr.detectChanges();
    }, 20);

    // Auto-dismiss
    setTimeout(() => this.dismissToast(id), duration);
  }

  dismissToast(id: number): void {
    const t = this.toasts.find(x => x.id === id);
    if (!t) return;
    t.visible = false;
    this.cdr.detectChanges();
    setTimeout(() => {
      this.toasts = this.toasts.filter(x => x.id !== id);
      this.cdr.detectChanges();
    }, 400);
  }

  // ───────────────── LOGIN ─────────────────
  onLogin(event: Event) {
    event.preventDefault();

    const loginData = { user_id: this.userId, password: this.password };

    this.http.post(environment.apiUrl + '/api/auth/login', loginData).subscribe({

      next: (response: any) => {

        console.log('FULL RESPONSE =>', response);

        if (response.status === 'success') {

          const user = response.user;
          console.log('Role from backend:', user.role);
          console.log('FULL USER DATA =>', user);

          // ───── SESSION STORAGE ─────
          sessionStorage.setItem('jwt_token', response.token             || '');
          sessionStorage.setItem('user_id',  user.user_id              || '');
          sessionStorage.setItem('emp_id',   user.employee_id || user.user_id || '');
          sessionStorage.setItem('emp_name', user.employee_name || user.name || '');
          sessionStorage.setItem('role',     user.role                 || '');
          sessionStorage.setItem('plant',    user.plant || user.plant_id || '');
          sessionStorage.setItem('plant_id', user.plant_id || user.plant || '');
          sessionStorage.setItem('section',  user.section              || '');
          sessionStorage.setItem('department', user.department         || '');
          sessionStorage.setItem('reporting_manager_id',   user.reporting_manager_id   || '');
          sessionStorage.setItem('reporting_manager_name', user.reporting_manager_name || '');
          sessionStorage.setItem('hod_name', user.hod_name             || '');
          localStorage.setItem('user',       JSON.stringify(user));

          // ───── ROLE BASED REDIRECT ─────
          const role = user.role;

          // window.location.href — page reload — sessionStorage fresh मिळतो
          const r = (role || '').toLowerCase().trim().replace('_', ' ');
          if      (r === 'business excellence' || r === 'business_excellence')
                                               window.location.href = '/bex-dashboard';
          else if (r === 'hod')               window.location.href = '/hod-dashboard';
          else if (r === 'manager')           window.location.href = '/manager-dashboard';
          else                                window.location.href = '/dashboard';

        } else {
          // ← was: alert(response.message)
          this.showToast('error', 'Login Failed', response.message || 'Invalid credentials. Please try again.');
        }
      },

      error: () => {
        // ← was: alert('Connection Error...')
        this.showToast(
          'error',
          'Connection Error',
          'Unable to reach the server. Make sure Spring Boot is running on port 8080.'
        );
      }

    });
  }

  // ───────────────── STEP 1 : SEND OTP ─────────────────
  sendOtp() {
    this.forgotError = '';

    if (!this.forgotUserId.trim()) {
      this.forgotError = 'Please enter your User ID';
      return;
    }

    this.isLoading = true;

    this.http.post<any>(
      environment.apiUrl + '/api/auth/forgot-password',
      { user_id: this.forgotUserId }
    ).subscribe({

      next: (res) => {
        this.isLoading = false;
        if (res.status === 'success') {
          this.maskedEmail = res.masked_email;
          this.devOtp      = res.dev_otp || '';
          this.step        = 'enter-otp';
        } else {
          this.forgotError = res.message;
        }
      },

      error: () => {
        this.isLoading   = false;
        this.forgotError = 'Connection error.';
      }

    });
  }

  // ───────────────── STEP 2 : VERIFY OTP ─────────────────
  verifyOtp() {
    this.otpError = '';

    if (!this.otp.trim()) {
      this.otpError = 'Please enter the OTP';
      return;
    }

    this.isLoading = true;

    this.http.post<any>(
      environment.apiUrl + '/api/auth/verify-otp',
      { user_id: this.forgotUserId, otp: this.otp }
    ).subscribe({

      next: (res) => {
        this.isLoading = false;
        if (res.status === 'success') {
          this.step = 'new-password';
        } else {
          this.otpError = res.message;
        }
      },

      error: () => {
        this.isLoading = false;
        this.otpError  = 'Connection error.';
      }

    });
  }

  // ───────────────── STEP 3 : NEW PASSWORD ─────────────────
  setNewPassword() {
    this.pwdError = '';

    if (!this.newPassword || !this.confirmPwd) {
      this.pwdError = 'Please fill all fields';
      return;
    }

    if (this.newPassword !== this.confirmPwd) {
      this.pwdError = 'Passwords do not match';
      return;
    }

    // ───── PASSWORD POLICY ─────
    const letters = (this.newPassword.match(/[a-zA-Z]/g)  || []).length;
    const numbers = (this.newPassword.match(/[0-9]/g)      || []).length;
    const special = (this.newPassword.match(/[^a-zA-Z0-9]/g) || []).length;

    if (letters < 6 || numbers < 1 || special < 1) {
      this.pwdError = 'Password must have min 6 letters, 1 number, 1 special character';
      return;
    }

    this.isLoading = true;

    this.http.post<any>(
      environment.apiUrl + '/api/auth/set-new-password',
      { user_id: this.forgotUserId, new_password: this.newPassword }
    ).subscribe({

      next: (res) => {
        this.isLoading = false;
        if (res.status === 'success') {
          this.step = 'done';
        } else {
          this.pwdError = res.message;
        }
      },

      error: () => {
        this.isLoading = false;
        this.pwdError  = 'Connection error.';
      }

    });
  }

  // ───────────────── RESET FLOW ─────────────────
  resetForgot() {
    this.step        = 'login';
    this.forgotUserId = '';
    this.maskedEmail  = '';
    this.devOtp       = '';
    this.otp          = '';
    this.otpError     = '';
    this.newPassword  = '';
    this.confirmPwd   = '';
    this.pwdError     = '';
    this.forgotError  = '';
  }
}