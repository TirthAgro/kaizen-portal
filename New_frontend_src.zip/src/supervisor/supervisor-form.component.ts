import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-supervisor-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule],
  encapsulation: ViewEncapsulation.None,
  template: `

  <!-- ══════ TOAST CONTAINER ══════ -->
  <div class="sf-toast-container">
    <div class="sf-toast sf-toast-{{ t.type }}" *ngFor="let t of toasts">
      <span class="sf-toast-icon">{{ t.type === 'success' ? '✔' : t.type === 'error' ? '✕' : 'ℹ' }}</span>
      <span class="sf-toast-msg">{{ t.message }}</span>
    </div>
  </div>

  <!-- ══════ CLEAR CONFIRM MODAL ══════ -->
  <div class="sf-overlay" *ngIf="showClearModal">
    <div class="sf-modal">
      <div class="sf-modal-icon orange">⚠</div>
      <h3 class="sf-modal-title">Clear Form?</h3>
      <p class="sf-modal-sub">All entered data will be lost. This action cannot be undone.</p>
      <div class="sf-modal-btns">
        <button class="sf-mbtn-cancel" (click)="showClearModal = false">Cancel</button>
        <button class="sf-mbtn-ok" (click)="confirmClear()">Yes, Clear</button>
      </div>
    </div>
  </div>

  <!-- ══════ CONFIRM MODAL ══════ -->
  <div class="sf-overlay" *ngIf="showConfirmModal">
    <div class="sf-modal">
      <div class="sf-modal-icon orange">?</div>
      <h3 class="sf-modal-title">Confirm Submission</h3>
      <p class="sf-modal-sub">Are you sure you want to submit this Supervisor Kaizen?</p>
      <div class="sf-modal-preview">
        <div class="sf-preview-row"><span class="sf-preview-lbl">Kaizen ID</span><span class="sf-preview-val">{{ kaizenNo }}</span></div>
        <div class="sf-preview-row"><span class="sf-preview-lbl">Theme</span><span class="sf-preview-val">{{ kaizenForm.value.theme }}</span></div>
      </div>
      <div class="sf-modal-btns">
        <button class="sf-mbtn-cancel" (click)="showConfirmModal = false">Review</button>
        <button class="sf-mbtn-ok" (click)="finalSubmit()" [disabled]="isSubmitting">
          {{ isSubmitting ? 'Processing...' : 'Submit Now' }}
        </button>
      </div>
    </div>
  </div>

  <!-- ══════ SUCCESS MODAL ══════ -->
  <div class="sf-overlay" *ngIf="showSuccessModal">
    <div class="sf-modal success">
      <div class="sf-modal-icon green">✔</div>
      <h3 class="sf-modal-title">Success!</h3>
      <p class="sf-modal-sub">Kaizen <strong>{{ lastSubmittedNo }}</strong> registered successfully.</p>
      <button class="sf-mbtn-ok" (click)="showSuccessModal = false">Great!</button>
    </div>
  </div>

  <!-- ══════ PAGE SHELL ══════ -->
  <div class="sf-root">

    <!-- TOP BAR -->
    <header class="sf-topbar">
      <div class="sf-topbar-left">
        <div class="sf-topbar-brand">
          <span class="sf-topbar-title">SHAKTIपथ</span>
          <span class="sf-topbar-sub">New Kaizen</span>
        </div>
      </div>
      <div class="sf-topbar-right">
        <div class="sf-live-pill">
          <span class="sf-live-dot"></span> System Live
        </div>
        <div class="sf-logo-wrap">
          <img src="assets/images/test-logo.png" alt="Shaktiman" class="sf-logo-img">
        </div>
        <button class="of-back-btn" (click)="goBack()">
          Back
        </button>
      </div>
    </header>

    <!-- CONTENT -->
    <div class="sf-content">

      <!-- PAGE HEADER -->
      <div class="sf-page-header">
        <div>
          <h1 class="sf-page-title">Supervisor Kaizen Entry</h1>
          <p class="sf-page-sub">3-step registration form</p>
        </div>
        <div class="sf-id-chip" [class.error]="kaizenNo === 'SUP-Error'">
          <span class="sf-id-label">ID</span>
          <span class="sf-id-val">{{ kaizenNo }}</span>
          <span class="sf-id-sep"></span>
          <span class="sf-id-date">{{ today | date:'dd MMM yyyy' }}</span>
          <button *ngIf="kaizenNo === 'SUP-Error'" (click)="fetchNextId()" class="sf-retry">Retry</button>
        </div>
      </div>

      <!-- STEP PROGRESS BAR -->
      <div class="sf-stepper">
        <div class="sf-step" [class.active]="currentStep >= 1" [class.done]="currentStep > 1">
          <div class="sf-step-icon">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
              <rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/>
              <rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>
            </svg>
          </div>
          <span class="sf-step-label">Basic & Classification</span>
        </div>
        <div class="sf-step-line" [class.done]="currentStep > 1"></div>
        <div class="sf-step" [class.active]="currentStep >= 2" [class.done]="currentStep > 2">
          <div class="sf-step-icon">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
              <circle cx="12" cy="12" r="10"/>
              <path d="M12 7v5l3 3"/>
            </svg>
          </div>
          <span class="sf-step-label">Analysis & Solution</span>
        </div>
        <div class="sf-step-line" [class.done]="currentStep > 2"></div>
        <div class="sf-step" [class.active]="currentStep >= 3">
          <div class="sf-step-icon">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
              <rect x="3" y="3" width="18" height="18" rx="2"/>
              <circle cx="8.5" cy="8.5" r="1.5"/>
              <polyline points="21 15 16 10 5 21"/>
            </svg>
          </div>
          <span class="sf-step-label">Evidence & Team</span>
        </div>
      </div>

      <!-- FORM -->
      <form [formGroup]="kaizenForm" (ngSubmit)="onPreSubmit()">

        <!-- ════ STEP 1: Basic & Classification ════ -->
        <ng-container *ngIf="currentStep === 1">

          <!-- Section 01: Employee Details -->
          <div class="sf-card">
            <div class="sf-card-head">
              <div class="sf-card-left">
                <div class="sf-badge">01</div>
                <span class="sf-card-title">Employee Details</span>
              </div>
              <span class="sf-card-hint">Basic identification</span>
            </div>
            <div class="sf-card-divider"></div>
            <div class="sf-row-3">
              <div class="sf-field">
                <label>Employee ID <span class="sf-req">*</span></label>
                <input type="text" formControlName="emp_id"  pattern="[A-Za-z0-9]*" oninput="this.value = this.value.replace(/[^A-Za-z0-9]/g, '')" maxlength="8" placeholder="Numbers only">
                <div class="sf-err" *ngIf="kaizenForm.get('emp_id')?.touched && kaizenForm.get('emp_id')?.errors?.['required']">Required</div>
                <div class="sf-err" *ngIf="kaizenForm.get('emp_id')?.touched && kaizenForm.get('emp_id')?.errors?.['pattern']">Numbers only</div>
              </div>
              <div class="sf-field">
                <label>Employee Name <span class="sf-req">*</span></label>
                <input type="text" formControlName="emp_name" (keypress)="allowAlphabetsOnly($event)" placeholder="Alphabets only">
                <div class="sf-err" *ngIf="kaizenForm.get('emp_name')?.touched && kaizenForm.get('emp_name')?.errors?.['required']">Required</div>
                <div class="sf-err" *ngIf="kaizenForm.get('emp_name')?.touched && kaizenForm.get('emp_name')?.errors?.['pattern']">Alphabets only</div>
              </div>
              <div class="sf-field">
                <label>Plant (Unit) <span class="sf-req">*</span></label>
                <select formControlName="unit" (change)="onUnitChange()">
                  <option value="">Select Unit</option>
                  <option *ngFor="let i of [1,2,3,4,5]" [value]="'Unit '+i">Unit {{ i }}</option>
                </select>
                <div class="sf-err" *ngIf="kaizenForm.get('unit')?.touched && kaizenForm.get('unit')?.errors?.['required']">Required</div>
              </div>
            </div>
            <div class="sf-row-3" *ngIf="kaizenForm.get('unit')?.value">
              <div class="sf-field">
                <label>Department <span class="sf-req">*</span></label>
                <select formControlName="department" (change)="onDepartmentChange()">
                  <option value="">Select Department</option>
                  <option *ngFor="let d of availableDepartments" [value]="d">{{ d }}</option>
                </select>
                <div class="sf-err" *ngIf="kaizenForm.get('department')?.touched && kaizenForm.get('department')?.errors?.['required']">Required</div>
              </div>
              <div class="sf-field" *ngIf="kaizenForm.get('department')?.value">
                <label>Section <span class="sf-req">*</span></label>
                <select formControlName="section">
                  <option value="">Select Section</option>
                  <option *ngFor="let s of availableSections" [value]="s">{{ s }}</option>
                </select>
                <div class="sf-err" *ngIf="kaizenForm.get('section')?.touched && kaizenForm.get('section')?.errors?.['required']">Required</div>
              </div>
              <div class="sf-field">
                <label>Machine Name/No. <span class="sf-req">*</span></label>
                <input type="text" formControlName="machine_no">
                <div class="sf-err" *ngIf="kaizenForm.get('machine_no')?.touched && kaizenForm.get('machine_no')?.errors?.['required']">Required</div>
              </div>
            </div>
          </div>

          <!-- Section 02: Classification -->
          <div class="sf-card">
            <div class="sf-card-head">
              <div class="sf-card-left">
                <div class="sf-badge">02</div>
                <span class="sf-card-title">Classification</span>
              </div>
              <span class="sf-card-hint">Type, group & category</span>
            </div>
            <div class="sf-card-divider"></div>

            <div class="sf-row-3">
              <div class="sf-field">
                <label>Type of Kaizen <span class="sf-req">*</span></label>
                <select formControlName="kaizen_type">
                  <option value="Innovative">Innovative</option>
                  <option value="Restorative">Restorative</option>
                  <option value="Renovative">Renovative</option>
                  <option value="Breakthrough">Breakthrough</option>
                </select>
              </div>
              <div class="sf-field">
                <label>Group (PQCDSM) <span class="sf-req">*</span></label>
                <select formControlName="pqcdsm">
                  <option value="">Select Group</option>
                  <option value="P - Productivity">P - Productivity</option>
                  <option value="Q - Quality">Q - Quality</option>
                  <option value="C - Cost">C - Cost</option>
                  <option value="D - Delivery">D - Delivery</option>
                  <option value="S - Safety">S - Safety</option>
                  <option value="M - Morale">M - Morale</option>
                </select>
                <div class="sf-err" *ngIf="kaizenForm.get('pqcdsm')?.touched && kaizenForm.get('pqcdsm')?.errors?.['required']">Required</div>
              </div>
              <div class="sf-field">
                <label>Start Date <span class="sf-req">*</span></label>
                <input type="date" formControlName="start_date">
                <div class="sf-err" *ngIf="kaizenForm.get('start_date')?.touched && kaizenForm.get('start_date')?.errors?.['required']">Required</div>
              </div>
            </div>

            <div class="sf-row-2">
              <div class="sf-field">
                <label>Kaizen Category <span class="sf-req">*</span></label>
                <select formControlName="kaizen_category">
                  <option value="">Select Category</option>
                  <option *ngFor="let cat of categories" [value]="cat.v">{{ cat.l }}</option>
                </select>
                <div class="sf-err" *ngIf="kaizenForm.get('kaizen_category')?.touched && kaizenForm.get('kaizen_category')?.errors?.['required']">Required</div>
              </div>
              <div class="sf-field">
                <label>End Date <span class="sf-req">*</span></label>
                <input type="date" formControlName="end_date">
                <div class="sf-err" *ngIf="kaizenForm.get('end_date')?.touched && kaizenForm.get('end_date')?.errors?.['required']">Required</div>
              </div>
            </div>

            <div class="sf-row-1">
              <div class="sf-field">
                <label>Kaizen Theme <span class="sf-req">*</span></label>
                <input type="text" formControlName="theme"
                       (input)="checkDuplicateTheme()"
                       [class.sf-input-error]="isDuplicate"
                       placeholder="Enter a unique theme title">
                <div class="sf-err" *ngIf="isDuplicate">⚠ This theme already exists. Use a unique title.</div>
                <div class="sf-err" *ngIf="kaizenForm.get('theme')?.touched && kaizenForm.get('theme')?.errors?.['required'] && !isDuplicate">Required</div>
              </div>
            </div>
          </div>

        </ng-container>

        <!-- ════ STEP 2: Analysis & Solution ════ -->
        <ng-container *ngIf="currentStep === 2">

          <!-- Section 03: Problem & Solution -->
          <div class="sf-card">
            <div class="sf-card-head">
              <div class="sf-card-left">
                <div class="sf-badge">03</div>
                <span class="sf-card-title">Problem & Solution</span>
              </div>
              <span class="sf-card-hint">Current status & improvement idea</span>
            </div>
            <div class="sf-card-divider"></div>

            <div class="sf-row-2">
              <div class="sf-field">
                <label>Problem / Current Status <span class="sf-req">*</span></label>
                <textarea formControlName="problem_status" rows="4" placeholder="Describe the current problem..."></textarea>
                <div class="sf-err" *ngIf="kaizenForm.get('problem_status')?.touched && kaizenForm.get('problem_status')?.errors?.['required']">Required</div>
                <input type="file" (change)="onFileChange($event, 'problem_img')" accept="image/*" class="sf-file-input">
                <p class="sf-hint">Problem image (auto-compressed)</p>
                <div class="sf-err" *ngIf="compressing['problem_img']">⏳ Compressing...</div>
                <div class="sf-ok"  *ngIf="compressInfo['problem_img']">{{ compressInfo['problem_img'] }}</div>
              </div>
              <div class="sf-field">
                <label>Idea / Concept <span class="sf-req">*</span></label>
                <textarea formControlName="idea" rows="4" placeholder="Describe the improvement idea..."></textarea>
                <div class="sf-err" *ngIf="kaizenForm.get('idea')?.touched && kaizenForm.get('idea')?.errors?.['required']">Required</div>
              </div>
            </div>

            <div class="sf-row-1">
              <div class="sf-field">
                <label>Countermeasure (Engineering Solution) <span class="sf-req">*</span></label>
                <textarea formControlName="countermeasure" rows="3" placeholder="Describe the countermeasure..."></textarea>
                <div class="sf-err" *ngIf="kaizenForm.get('countermeasure')?.touched && kaizenForm.get('countermeasure')?.errors?.['required']">Required</div>
              </div>
            </div>
          </div>

          <!-- Section 04: 5-Why Analysis -->
          <div class="sf-card sf-card-indigo">
            <div class="sf-card-head">
              <div class="sf-card-left">
                <div class="sf-badge sf-badge-indigo">04</div>
                <span class="sf-card-title sf-title-indigo">5-Why Analysis</span>
              </div>
              <span class="sf-card-hint">Root cause investigation</span>
            </div>
            <div class="sf-card-divider sf-divider-indigo"></div>

            <div class="sf-row-why">
              <div class="sf-field">
                <label>Why 1 <span class="sf-req">*</span></label>
                <input type="text" formControlName="why1" placeholder="Why did the problem occur?">
                <div class="sf-err" *ngIf="kaizenForm.get('why1')?.touched && kaizenForm.get('why1')?.errors?.['required']">Required</div>
              </div>
              <div class="sf-field">
                <label>Why 2 <span class="sf-req">*</span></label>
                <input type="text" formControlName="why2" placeholder="Why did Why 1 happen?">
                <div class="sf-err" *ngIf="kaizenForm.get('why2')?.touched && kaizenForm.get('why2')?.errors?.['required']">Required</div>
              </div>
              <div class="sf-field">
                <label>Why 3 <span class="sf-req">*</span></label>
                <input type="text" formControlName="why3" placeholder="Why did Why 2 happen?">
                <div class="sf-err" *ngIf="kaizenForm.get('why3')?.touched && kaizenForm.get('why3')?.errors?.['required']">Required</div>
              </div>
              <div class="sf-field">
                <label>Why 4 <span class="sf-opt">Optional</span></label>
                <input type="text" formControlName="why4" placeholder="Why did Why 3 happen?">
              </div>
              <div class="sf-field">
                <label>Why 5 <span class="sf-opt">Optional</span></label>
                <input type="text" formControlName="why5" placeholder="Root cause confirmation">
              </div>
            </div>
          </div>

          <!-- Section 05: Results -->
          <div class="sf-card">
            <div class="sf-card-head">
              <div class="sf-card-left">
                <div class="sf-badge">05</div>
                <span class="sf-card-title">Root Cause & Results</span>
              </div>
              <span class="sf-card-hint">Analysis & final outcome</span>
            </div>
            <div class="sf-card-divider"></div>

            <div class="sf-row-3">
              <div class="sf-field">
                <label>Root Cause <span class="sf-req">*</span></label>
                <textarea formControlName="root_cause" rows="4" placeholder="Summarize root cause..."></textarea>
                <div class="sf-err" *ngIf="kaizenForm.get('root_cause')?.touched && kaizenForm.get('root_cause')?.errors?.['required']">Required</div>
              </div>
              <div class="sf-field">
                <label>Final Result <span class="sf-req">*</span></label>
                <textarea formControlName="final_result" rows="3" placeholder="Describe the final result..."></textarea>
                <div class="sf-err" *ngIf="kaizenForm.get('final_result')?.touched && kaizenForm.get('final_result')?.errors?.['required']">Required</div>
                <input type="file" (change)="onFileChange($event, 'result_img')" accept="image/*" class="sf-file-input">
                <p class="sf-hint">Result image (auto-compressed)</p>
                <div class="sf-err" *ngIf="compressing['result_img']">⏳ Compressing...</div>
                <div class="sf-ok"  *ngIf="compressInfo['result_img']">{{ compressInfo['result_img'] }}</div>
              </div>
              <div class="sf-field">
                <label>Analysis <span class="sf-req">*</span></label>
                <textarea formControlName="analysis" rows="4" placeholder="Analysis summary..."></textarea>
                <div class="sf-err" *ngIf="kaizenForm.get('analysis')?.touched && kaizenForm.get('analysis')?.errors?.['required']">Required</div>
              </div>
            </div>
          </div>

        </ng-container>

        <!-- ════ STEP 3: Evidence & Team ════ -->
        <ng-container *ngIf="currentStep === 3">

          <!-- Section 06: Before & After Evidence -->
          <div class="sf-card">
            <div class="sf-card-head">
              <div class="sf-card-left">
                <div class="sf-badge">06</div>
                <span class="sf-card-title">Before & After Evidence</span>
              </div>
              <span class="sf-card-hint">Photos & description</span>
            </div>
            <div class="sf-card-divider"></div>

            <div class="sf-row-2">
              <div class="sf-ev-card sf-before">
                <div class="sf-ev-badge before">Before Improvement</div>
                <input type="file" (change)="onFileChange($event, 'before_img')" accept="image/*,application/pdf,video/mp4,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/plain">
                <p class="sf-hint">Any size — auto-compressed to under 500KB</p>
                <div class="sf-err" *ngIf="compressing['before_img']">⏳ Compressing...</div>
                <div class="sf-ok"  *ngIf="compressInfo['before_img']">{{ compressInfo['before_img'] }}</div>
                <label>Before Description <span class="of-req">*</span></label>
                <textarea formControlName="before_desc" rows="4" placeholder="Describe the current problem..."></textarea>
                <div class="sf-err" *ngIf="kaizenForm.get('before_desc')?.touched && kaizenForm.get('before_desc')?.errors?.['required']">Required</div>
              </div>
              <div class="sf-ev-card sf-after">
                <div class="sf-ev-badge after">After Improvement</div>
                <input type="file" (change)="onFileChange($event, 'after_img')" accept="image/*,application/pdf,video/mp4,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/plain">
                <p class="sf-hint">Any size — auto-compressed to under 500KB</p>
                <div class="sf-err" *ngIf="compressing['after_img']">⏳ Compressing...</div>
                <div class="sf-ok"  *ngIf="compressInfo['after_img']">{{ compressInfo['after_img'] }}</div>
                <label>After Description <span class="of-req">*</span></label>
                <textarea formControlName="after_desc" rows="4" placeholder="Describe the improvement made..."></textarea>
                <div class="sf-err" *ngIf="kaizenForm.get('after_desc')?.touched && kaizenForm.get('after_desc')?.errors?.['required']">Required</div>
              </div>
            </div>
          </div>

          <!-- Section 07: Horizontal Deployment -->
          <div class="sf-card">
            <div class="sf-card-head">
              <div class="sf-card-left">
                <div class="sf-badge">07</div>
                <span class="sf-card-title">Horizontal Deployment</span>
              </div>
              <button type="button" class="sf-add-btn" (click)="addRow()">+ Add Row</button>
            </div>
            <div class="sf-card-divider"></div>

            <div class="sf-table-wrap">
              <table class="sf-table" formArrayName="horizontal_deployment">
                <thead>
                  <tr>
                    <th>Sr.</th><th>M/C No</th><th>Responsibility</th>
                    <th>Target Date</th><th>Status</th><th></th>
                  </tr>
                </thead>
                <tbody>
                  <tr *ngFor="let row of deploymentRows.controls; let i=index" [formGroupName]="i" class="sf-table-row">
                    <td class="sf-td-sr">{{ i+1 }}</td>
                    <td><input type="text" formControlName="m_no"></td>
                    <td><input type="text" formControlName="resp" (keypress)="allowAlphabetsOnly($event)"></td>
                    <td><input type="date" formControlName="target"></td>
                    <td>
                      <select formControlName="status">
                        <option value="Pending">Pending</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Done">Done</option>
                      </select>
                    </td>
                    <td>
                      <button type="button" class="sf-del-btn" (click)="removeRow(i)"
                              *ngIf="deploymentRows.length > 1">✕</button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <!-- Section 08: Benefits & Team -->
          <div class="sf-card">
            <div class="sf-card-head">
              <div class="sf-card-left">
                <div class="sf-badge">08</div>
                <span class="sf-card-title">Benefits & Team</span>
              </div>
              <span class="sf-card-hint">Impact & contributors</span>
            </div>
            <div class="sf-card-divider"></div>

            <div class="sf-row-2">
              <div class="sf-field">
                <label>Benefits (PQCDSM) <span class="sf-req">*</span></label>
                <textarea
                  formControlName="benefits"
                  rows="5"
                  (keydown)="handleBenefitsNumbering($event)"
                  placeholder="1. Time saved">
                </textarea>
                <div class="sf-err" *ngIf="kaizenForm.get('benefits')?.touched && kaizenForm.get('benefits')?.errors?.['required']">Required</div>
              </div>
              <div class="sf-field">
                <label>Team Members <span class="sf-req">*</span></label>
                <textarea formControlName="team" rows="5"
                          (keypress)="allowTeamInput($event)"
                          (keydown)="handleTeamNumbering($event)"
                          placeholder="1. Member Name"></textarea>
                <p class="sf-hint">Alphabets and spaces only</p>
                <div class="sf-err" *ngIf="kaizenForm.get('team')?.touched && kaizenForm.get('team')?.errors?.['required']">Required</div>
              </div>
            </div>
          </div>

        </ng-container>

      </form>
    </div>

    <!-- ══════ BOTTOM NAV BAR ══════ -->
    <footer class="sf-footer">
      <span class="sf-footer-step">Step {{ currentStep }} of 3</span>
      <div class="sf-footer-btns">
        <button class="sf-btn-clear" *ngIf="currentStep === 1" (click)="clearForm()">
          Clear Form
        </button>
        <button class="sf-btn-back" *ngIf="currentStep > 1" (click)="prevStep()">
          ← Back
        </button>
        <button class="sf-btn-next" *ngIf="currentStep < 3" (click)="nextStep()">
          Next Step →
        </button>
        <button class="sf-btn-submit"
                *ngIf="currentStep === 3"
                (click)="onPreSubmit()"
                [disabled]="kaizenForm.invalid || isDuplicate || hasFileError() || isAnyCompressing() || isSubmitting || kaizenNo === 'SUP-Error'">
          <span *ngIf="isSubmitting">Submitting...</span>
          <span *ngIf="isAnyCompressing() && !isSubmitting">⏳ Compressing...</span>
          <span *ngIf="!isSubmitting && !isAnyCompressing() && kaizenNo === 'SUP-Error'">System Offline</span>
          <span *ngIf="!isSubmitting && !isAnyCompressing() && kaizenNo !== 'SUP-Error'">Submit Kaizen ✔</span>
        </button>
      </div>
    </footer>

  </div>
  `,
  styles: [`
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

    .sf-root {
      --orange: #f97316;
      --orange-light: #fff7ed;
      --orange-border: rgba(249,115,22,0.25);
      --indigo: #6366f1;
      --indigo-light: #eef2ff;
      --indigo-border: rgba(99,102,241,0.25);
      --bg: #f3f4f8;
      --card: #ffffff;
      --border: #e5e7eb;
      --text: #111827;
      --text-2: #4b5563;
      --text-3: #9ca3af;
      --red: #ef4444;
      --green: #10b981;
      --font: 'Plus Jakarta Sans', sans-serif;

      font-family: var(--font);
      background: var(--bg);
      min-height: 100vh;
      display: flex; flex-direction: column;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }

    /* ── TOAST ── */
    .sf-toast-container {
      position: fixed; top: 80px; right: 24px; z-index: 99999;
      display: flex; flex-direction: column; gap: 10px;
      pointer-events: none;
    }
    .sf-toast {
      display: flex; align-items: center; gap: 12px;
      padding: 14px 20px; border-radius: 14px;
      min-width: 280px; max-width: 380px;
      font-family: var(--font); font-size: 13px; font-weight: 600;
      color: #fff; box-shadow: 0 12px 32px rgba(0,0,0,.2);
      animation: sf-toast-in .35s cubic-bezier(.34,1.56,.64,1) both;
    }
    @keyframes sf-toast-in  { from{opacity:0;transform:translateX(60px)}to{opacity:1;transform:translateX(0)} }
    @keyframes sf-toast-out { from{opacity:1;transform:translateX(0)}to{opacity:0;transform:translateX(60px)} }
    .sf-toast-success { background: linear-gradient(135deg,#10b981,#059669); }
    .sf-toast-error   { background: linear-gradient(135deg,#ef4444,#dc2626); }
    .sf-toast-info    { background: linear-gradient(135deg,#f97316,#ea580c); }
    .sf-toast-icon    { font-size: 18px; font-weight: 900; flex-shrink: 0; }
    .sf-toast-msg     { line-height: 1.4; }

    /* ── TOPBAR ── */
    .sf-topbar {
      height: 60px; background: #fff;
      border-bottom: 1px solid var(--border);
      display: flex; align-items: center; justify-content: space-between;
      padding: 0 32px; position: sticky; top: 0; z-index: 100; flex-shrink: 0;
    }
    .sf-topbar-left { display: flex; align-items: center; }
    .sf-topbar-brand { display: flex; flex-direction: column; }
    .sf-topbar-title { font-size: 15px; font-weight: 800; color: var(--text); letter-spacing: 1px; line-height: 1.1; }
    .sf-topbar-sub   { font-size: 10px; color: var(--text-3); font-weight: 500; }
    .sf-topbar-right { display: flex; align-items: center; gap: 16px; }
    .sf-live-pill    { display: flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 600; color: #374151; }
    .sf-live-dot     { width: 7px; height: 7px; border-radius: 50%; background: #10b981; animation: sf-pulse 2s infinite; }
    @keyframes sf-pulse { 0%,100%{box-shadow:0 0 0 0 rgba(16,185,129,.4)}50%{box-shadow:0 0 0 4px rgba(16,185,129,0)}}
    .sf-logo-wrap { padding: 0; }
    .sf-logo-img  { height: 30px; width: auto; filter: invert(48%) sepia(79%) saturate(2476%) hue-rotate(5deg) brightness(103%) contrast(97%); }

    /* ── CONTENT ── */
    .sf-content { flex: 1; padding: 28px 32px 120px; max-width: 1100px; margin: 0 auto; width: 100%; }

    /* Page header */
    .sf-page-header { display: flex; align-items: flex-start; justify-content: space-between; margin-bottom: 28px; }
    .sf-page-title { font-size: 30px; font-weight: 800; color: var(--text); letter-spacing: -.5px; }
    .sf-page-sub   { font-size: 13px; color: var(--text-3); margin-top: 4px; font-weight: 500; }
    .sf-id-chip {
      display: flex; align-items: center; gap: 10px;
      background: var(--orange); color: #fff;
      padding: 10px 20px; border-radius: 50px;
      font-weight: 700; font-size: 14px;
      box-shadow: 0 8px 20px rgba(249,115,22,.3);
    }
    .sf-id-chip.error { background: var(--red); }
    .sf-id-label { font-size: 10px; font-weight: 800; opacity: .8; letter-spacing: 1px; }
    .sf-id-val   { font-size: 15px; font-weight: 800; }
    .sf-id-sep   { width: 1px; height: 16px; background: rgba(255,255,255,.4); }
    .sf-id-date  { font-size: 13px; font-weight: 600; opacity: .9; }
    .sf-retry    { background: rgba(255,255,255,.2); border: none; color: #fff; padding: 3px 10px; border-radius: 20px; font-size: 11px; cursor: pointer; }

    .of-back-btn {
      display: flex; align-items: center; gap: 8px;
      background: #ffffff; color: #0f172a;
      border: 1px solid #dbeafe; padding: 10px 18px;
      border-radius: 12px; cursor: pointer;
      font-size: 14px; font-weight: 700;
      transition: all 0.25s ease;
      box-shadow: 0 4px 12px rgba(0,0,0,0.06);
    }
    .of-back-btn:hover { transform: translateY(-2px); background: #eff6ff; border-color: #93c5fd; }

    /* ── STEPPER ── */
    .sf-stepper { display: flex; align-items: center; margin-bottom: 28px; }
    .sf-step    { display: flex; align-items: center; gap: 10px; opacity: .4; transition: opacity .3s; }
    .sf-step.active { opacity: 1; }
    .sf-step.done   { opacity: .7; }
    .sf-step-icon {
      width: 42px; height: 42px; border-radius: 12px;
      background: #e5e7eb; color: var(--text-2);
      display: flex; align-items: center; justify-content: center;
      transition: all .3s; flex-shrink: 0;
    }
    .sf-step.active .sf-step-icon { background: var(--orange); color: #fff; box-shadow: 0 6px 16px rgba(249,115,22,.35); }
    .sf-step.done   .sf-step-icon { background: var(--green);  color: #fff; }
    .sf-step-label  { font-size: 13px; font-weight: 600; color: var(--text); white-space: nowrap; }
    .sf-step.active .sf-step-label { color: var(--orange); }
    .sf-step-line   { flex: 1; height: 2px; background: #e5e7eb; margin: 0 16px; border-radius: 99px; transition: background .3s; }
    .sf-step-line.done { background: var(--green); }

    /* ── SECTION CARD ── */
    .sf-card {
      background: var(--orange-light);
      border: 1.5px solid var(--orange-border);
      border-radius: 18px; margin-bottom: 20px; overflow: hidden;
      animation: sf-up .4s ease both;
    }
    .sf-card:nth-child(2) { animation-delay: .07s; }
    .sf-card:nth-child(3) { animation-delay: .14s; }
    @keyframes sf-up { from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)} }

    .sf-card-indigo { background: var(--indigo-light); border-color: var(--indigo-border); }

    .sf-card-head {
      display: flex; align-items: center; justify-content: space-between;
      padding: 18px 24px 14px;
    }
    .sf-card-left  { display: flex; align-items: center; gap: 12px; }
    .sf-badge {
      width: 34px; height: 34px; border-radius: 10px;
      background: var(--orange); color: #fff;
      display: flex; align-items: center; justify-content: center;
      font-size: 12px; font-weight: 800;
      box-shadow: 0 4px 12px rgba(249,115,22,.3);
    }
    .sf-badge-indigo { background: var(--indigo); box-shadow: 0 4px 12px rgba(99,102,241,.3); }
    .sf-card-title  { font-size: 16px; font-weight: 700; color: var(--orange); }
    .sf-title-indigo { color: var(--indigo); }
    .sf-card-hint   { font-size: 12px; color: var(--text-3); font-weight: 500; }
    .sf-card-divider { height: 1px; background: var(--orange-border); margin: 0 24px; }
    .sf-divider-indigo { background: var(--indigo-border); }

    .sf-add-btn {
      height: 34px; padding: 0 14px; border: none; border-radius: 10px;
      background: var(--orange); color: #fff;
      font-family: var(--font); font-size: 12px; font-weight: 700;
      cursor: pointer; transition: .18s ease;
      box-shadow: 0 4px 12px rgba(249,115,22,.25);
    }
    .sf-add-btn:hover { transform: translateY(-1px); }

    .sf-row-1, .sf-row-2, .sf-row-3, .sf-row-why { padding: 20px 24px 4px; }
    .sf-row-1   { display: grid; grid-template-columns: 1fr; gap: 16px; }
    .sf-row-2   { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
    .sf-row-3   { display: grid; grid-template-columns: repeat(3,1fr); gap: 20px; }
    .sf-row-why { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    .sf-card > *:last-child { padding-bottom: 24px; }

    .sf-field { display: flex; flex-direction: column; gap: 7px; }
    .sf-field label { font-size: 12px; font-weight: 700; color: var(--text-2); letter-spacing: .02em; }
    .sf-req { color: var(--red); font-weight: 900; }
    .sf-opt { color: var(--text-3); font-size: 10px; font-weight: 400; }
    .sf-err  { color: var(--red);   font-size: 11px; font-weight: 600; margin-top: 2px; }
    .sf-ok   { color: var(--green); font-size: 11px; font-weight: 600; margin-top: 2px; }
    .sf-hint { color: var(--text-3); font-size: 10px; font-weight: 500; margin-top: 2px; }

    input[type="text"], input[type="date"], input[type="file"],
    select, textarea {
      width: 100%; background: #fff;
      border: 1.5px solid #e5e7eb; border-radius: 10px;
      padding: 11px 14px; font-size: 13px; font-weight: 500;
      color: var(--text); font-family: var(--font);
      transition: border-color .2s, box-shadow .2s;
      outline: none; resize: vertical;
    }
    input::placeholder, textarea::placeholder { color: var(--text-3); }
    input:focus, select:focus, textarea:focus {
      border-color: var(--orange);
      box-shadow: 0 0 0 3px rgba(249,115,22,.12);
    }
    .sf-input-error { border-color: var(--red) !important; }
    .sf-file-input  { padding: 8px 14px; }
    select { cursor: pointer; }

    .sf-ev-card { display: flex; flex-direction: column; gap: 10px; padding: 20px 24px 0; }
    .sf-ev-card label {
      display: block;
      font-size: 0.8rem;
      font-weight: 600;
      color: var(--text-secondary, #64748b);
      margin-top: 10px;
      margin-bottom: 4px;
    }
    .sf-ev-badge { width: max-content; padding: 5px 14px; border-radius: 999px; font-size: 11px; font-weight: 800; letter-spacing: .05em; text-transform: uppercase; }
    .sf-ev-badge.before { background: #fee2e2; color: #991b1b; }
    .sf-ev-badge.after  { background: #dcfce7; color: #166534; }

    .sf-table-wrap { overflow-x: auto; padding: 20px 24px 0; }
    .sf-table { width: 100%; border-collapse: collapse; }
    .sf-table thead tr { border-bottom: 1px solid var(--border); }
    .sf-table th {
      padding: 10px 12px; font-size: 10px; font-weight: 700;
      letter-spacing: 1px; text-transform: uppercase;
      color: var(--text-3); text-align: left; background: rgba(255,255,255,.6);
    }
    .sf-table-row { border-bottom: 1px solid rgba(249,115,22,.1); }
    .sf-table-row:last-child { border-bottom: none; }
    .sf-table td { padding: 8px 12px; vertical-align: middle; }
    .sf-table td input, .sf-table td select { padding: 8px 10px; border-radius: 8px; font-size: 12px; }
    .sf-td-sr { font-weight: 700; color: var(--text-3); text-align: center; width: 40px; }
    .sf-del-btn {
      width: 28px; height: 28px; border: none; border-radius: 7px;
      background: #fee2e2; color: var(--red); cursor: pointer; font-weight: 700; transition: .15s;
    }
    .sf-del-btn:hover { background: #fecaca; }

    /* ── FOOTER ── */
    .sf-footer {
      position: fixed; bottom: 0; left: 0; right: 0; height: 68px;
      background: #111827; border-top: 1px solid rgba(255,255,255,.06);
      display: flex; align-items: center; justify-content: space-between;
      padding: 0 40px; z-index: 200;
    }
    .sf-footer-step { font-size: 13px; font-weight: 600; color: rgba(255,255,255,.5); font-family: var(--font); }
    .sf-footer-btns { display: flex; gap: 12px; align-items: center; }
    .sf-btn-clear {
      padding: 10px 20px; border-radius: 10px;
      background: rgba(255,255,255,.06); border: 1px solid rgba(255,255,255,.12);
      color: rgba(255,255,255,.5); font-family: var(--font);
      font-size: 12px; font-weight: 600; cursor: pointer; transition: all .2s;
    }
    .sf-btn-clear:hover { color: var(--red); border-color: rgba(239,68,68,.4); }
    .sf-btn-back {
      padding: 11px 22px; border-radius: 10px;
      background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.15);
      color: rgba(255,255,255,.7); font-family: var(--font);
      font-size: 13px; font-weight: 600; cursor: pointer; transition: all .2s;
    }
    .sf-btn-back:hover { background: rgba(255,255,255,.14); color: #fff; }
    .sf-btn-next {
      padding: 11px 28px; border-radius: 10px;
      background: transparent; border: 1.5px solid #fff;
      color: #fff; font-family: var(--font);
      font-size: 13px; font-weight: 700; cursor: pointer; transition: all .2s;
    }
    .sf-btn-next:hover { background: rgba(255,255,255,.1); }
    .sf-btn-submit {
      padding: 11px 28px; border-radius: 10px;
      background: var(--orange); border: none; color: #ffffff;
      font-family: var(--font); font-size: 13px; font-weight: 700;
      cursor: pointer; transition: all .2s;
      box-shadow: 0 6px 16px rgba(249,115,22,.4);
    }
    .sf-btn-submit:hover:not(:disabled) { background: #ea6c0a; transform: translateY(-1px); }
    .sf-btn-submit:disabled { background: #6b7280; box-shadow: none; cursor: not-allowed; }

    /* ── MODALS ── */
    .sf-overlay {
      position: fixed; inset: 0; background: rgba(0,0,0,.5); backdrop-filter: blur(6px);
      display: flex; align-items: center; justify-content: center; z-index: 9999;
    }
    .sf-modal {
      background: #fff; border-radius: 24px; padding: 32px;
      width: 420px; max-width: 92vw; text-align: center;
      box-shadow: 0 30px 70px rgba(0,0,0,.2);
      animation: sf-pop .28s cubic-bezier(.34,1.56,.64,1);
    }
    .sf-modal.success { border-top: 5px solid var(--green); }
    @keyframes sf-pop { from{opacity:0;transform:scale(.88)}to{opacity:1;transform:scale(1)} }
    .sf-modal-icon { width: 64px; height: 64px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px; font-size: 28px; font-weight: 900; color: #f8d7b9; }
    .sf-modal-icon.orange { background: linear-gradient(135deg, #f97316, #ea580c); }
    .sf-modal-icon.green  { background: linear-gradient(135deg,#10b981,#059669); }
    .sf-modal-title { font-size: 20px; font-weight: 800; color: Black; margin-bottom: 6px; }
    .sf-modal-sub   { font-size: 13px; color: grey; line-height: 1.6; margin-bottom: 18px; }
    .sf-modal-preview { background: #6d8092; border-radius: 12px; padding: 14px; margin-bottom: 20px; text-align: left; border-left: 4px solid var(--orange); }
    .sf-preview-row { display: flex; justify-content: space-between; padding: 5px 0; }
    .sf-preview-lbl { font-size: 12px; color: var(--text-3); font-weight: 600; }
    .sf-preview-val { font-size: 12px; color: var(--text); font-weight: 700; }
    .sf-modal-btns  { display: flex; gap: 10px; }
    .sf-mbtn-cancel {
      flex: 1; height: 44px; border-radius: 10px;  background: #508fee;
      border: 1px solid var(--border); color: white;
      font-family: var(--font); font-size: 13px; font-weight: 600; cursor: pointer; transition: .2s;
    }
    .sf-mbtn-cancel:hover { border-color: var(--red); color: var(--red); }
    .sf-mbtn-ok {
      flex: 1; height: 44px; border-radius: 10px; background: var(--orange);
      border: none; color: #fff; font-family: var(--font);
      font-size: 13px; font-weight: 700; cursor: pointer; transition: .2s;
    }
    .sf-mbtn-ok:hover:not(:disabled) { background: #ea6c0a; }
    .sf-mbtn-ok:disabled { background: #9ca3af; cursor: not-allowed; }

    @media (max-width: 900px) {
      .sf-row-2, .sf-row-3, .sf-row-why { grid-template-columns: 1fr; }
      .sf-content { padding: 20px 16px 100px; }
      .sf-footer  { padding: 0 20px; }
      .sf-toast-container { right: 12px; left: 12px; }
      .sf-toast { min-width: unset; }
    }
  `]
})
export class SupervisorFormComponent implements OnInit {

  public currentStep      = 1;
  public isSubmitting     = false;
  public kaizenNo         = 'Fetching...';
  public lastSubmittedNo  = '';
  public today            = new Date();
  public kaizenForm!: FormGroup;
  public isDuplicate      = false;
  public showConfirmModal = false;
  public showSuccessModal = false;
  public showClearModal   = false;

  // Toast system
  public toasts: { message: string; type: 'success' | 'error' | 'info'; id: number }[] = [];
  private toastId = 0;

  public availableDepartments: string[] = [];
  public availableSections:    string[] = [];

  public compressing: { [key: string]: boolean } = { before_img: false, after_img: false, problem_img: false, result_img: false };
  public compressInfo: { [key: string]: string  } = { before_img: '', after_img: '', problem_img: '', result_img: '' };
  public fileErrors:   { [key: string]: boolean } = { before_img: false, after_img: false, problem_img: false, result_img: false };
  private selectedFiles: { [key: string]: File | null } = { before_img: null, after_img: null, problem_img: null, result_img: null };
  private allThemes: string[] = [];

  private plantDepartments: { [unit: string]: string[] } = {
    'Unit 1': ['Production', 'Quality', 'Maintenance', 'Stores'],
    'Unit 2': ['Production', 'Quality', 'Maintenance', 'Stores'],
    'Unit 3': ['Production', 'Quality', 'Maintenance', 'Stores'],
    'Unit 4': ['Production', 'Quality', 'Maintenance', 'Stores'],
    'Unit 5': ['Production', 'Quality', 'Maintenance', 'Stores'],
  };
  private departmentSections: { [dept: string]: string[] } = {
    'Production':  ['Welding', 'Assembly', 'Paint Shop', 'Machine Shop'],
    'Quality':     ['Incoming', 'In-Process', 'Final Inspection', 'Quality'],
    'Maintenance': ['Mechanical', 'Electrical', 'Civil', 'Maintenance'],
    'Stores':      ['Raw Material', 'Finished Goods', 'Dispatch', 'Stores'],
  };

  public categories = [
    { v: 'C-1|Restorative (TPM)',              l: 'C-1: Restorative (Using TPM Methodology)' },
    { v: 'C-2|Renovative (TPM)',               l: 'C-2: Renovative (Using TPM Methodology)' },
    { v: 'C-3|Innovative (TPM)',               l: 'C-3: Innovative (Using TPM Methodology)' },
    { v: 'C-4|Breakthrough (TPM)',             l: 'C-4: Breakthrough (Using TPM Methodology)' },
    { v: 'C-5|Poka Yoke (TPM)',                l: 'C-5: Poka Yoke (Using TPM Methodology)' },
    { v: 'C-6|KARAKURI & YUTORI',              l: 'C-6: KARAKURI (No Energy Loss) & YUTORI' },
    { v: 'C-7|JH Shop Floor Visualization',    l: 'C-7: JH - Shop Floor Visualization' },
    { v: 'C-8|KK OEE Compliance',              l: 'C-8: KK OEE Compliance' },
    { v: 'C-9|KK Bottleneck Process Solution', l: 'C-9: KK Bottleneck Process Solution' },
    { v: 'C-10|JH Circle Board Updating',      l: 'C-10: JH - Circle Board updating' },
    { v: 'C-11|JH One Point Lessons',          l: 'C-11: JH - One Point Lessons' },
    { v: 'C-12|JH White Tag Abnormality',      l: 'C-12: JH: White tag abnormality' },
    { v: 'C-13|JH (HTA / SOC / Ease for CLITA)', l: 'C-13: JH (HTA / SOC / Ease for CLITA)' },
    { v: 'C-14|JH Step 4 M-M Combination',    l: 'C-14: JH step 4 Man-Machine combination' },
    { v: 'C-15|JH Step 5 M-M Combination',    l: 'C-15: JH step 5 Man-Machine combination' },
    { v: 'C-16|JH Step 1, 2, 3 Repeat',       l: 'C-16: JH: Repeat of JH Step 1, 2, 3' },
    { v: 'C-17|JH Minor Stoppage Monitoring',  l: 'C-17: JH: Minor Stoppage Monitoring' },
    { v: 'C-18|JH RED Tag Abnormality',        l: 'C-18: JH: RED tag abnormality' },
    { v: 'C-19|QM Assembly Pokamapping',       l: 'C-19: QM: Product Assembly Pokamapping' },
    { v: 'C-20|PM MP Sheets Generation',       l: 'C-20: PM: Generation of MP sheets' },
    { v: 'C-21|NEDM MP Sheets Implementation', l: 'C-21: NEDM: Implementation of MP sheets' },
    { v: 'C-22|NEDM Low Cost Automation',      l: 'C-22: NEDM: Low Cost Automation' },
    { v: 'C-23|OTPM MAKIGAMI',                 l: 'C-23: OTPM: MAKIGAMI' },
    { v: 'C-24|OTPM Red Tag Office',           l: 'C-24: OTPM: Red tag at Office area (5S)' },
    { v: 'C-25|SHE Near Miss/Unsafe Condition',l: 'C-25: SHE: Near miss & Unsafe condition' },
    { v: 'C-26|SHE Unsafe Act',                l: 'C-26: SHE: Unsafe act' },
    { v: 'C-27|SHE Ergonomic Hazard',          l: 'C-27: SHE: Ergonomic hazard' },
    { v: 'C-28|SHE CO2 Emission Reduction',    l: 'C-28: SHE: CO2 emission reduction' },
    { v: 'C-29|SHE Micro Level HIRA',          l: 'C-29: SHE: Micro level HIRA' },
    { v: 'C-30|5S Zone Space Saved',           l: 'C-30: 5S: Zone wise space saved' },
    { v: 'C-31|5S Best 1S-3S',                 l: 'C-31: 5S: Best 1S, 2S, 3S at Zones' },
    { v: 'C-32|All Members',                   l: 'C-32: Sure Appreciation' },
    { v: 'C-33|All Members',                   l: 'C-33: Won the Awards from CII (Platinium & Gold)' },
    { v: 'C-34|All Members',                   l: 'C-34: Won the Awards from CII (Jury Challenger)' },
  ];

  constructor(private router: Router, private http: HttpClient, private cdr: ChangeDetectorRef) {}

  ngOnInit() { this.initForm(); this.fetchNextId(); this.loadExistingThemes(); }

  // ── Toast ──────────────────────────────────────────────────────────────────
  showToast(message: string, type: 'success' | 'error' | 'info' = 'info', duration = 3500) {
    const id = ++this.toastId;
    this.toasts.push({ message, type, id });
    this.cdr.detectChanges();
    setTimeout(() => {
      this.toasts = this.toasts.filter(t => t.id !== id);
      this.cdr.detectChanges();
    }, duration);
  }

  // ── Form init ──────────────────────────────────────────────────────────────
  initForm() {
    this.availableDepartments = []; this.availableSections = []; this.currentStep = 1;
    this.kaizenForm = new FormGroup({
      emp_id:          new FormControl('', [Validators.required, Validators.pattern('^[0-9]+$')]),
      emp_name:        new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z ]+$')]),
      unit:            new FormControl('', Validators.required),
      department:      new FormControl('', Validators.required),
      section:         new FormControl('', Validators.required),
      machine_no:      new FormControl('', Validators.required),
      kaizen_type:     new FormControl('Innovative', Validators.required),
      pqcdsm:          new FormControl('', Validators.required),
      kaizen_category: new FormControl('', Validators.required),
      theme:           new FormControl('', Validators.required),
      problem_status:  new FormControl('', Validators.required),
      idea:            new FormControl('', Validators.required),
      countermeasure:  new FormControl('', Validators.required),
      why1:            new FormControl('', Validators.required),
      why2:            new FormControl('', Validators.required),
      why3:            new FormControl('', Validators.required),
      why4:            new FormControl(''),
      why5:            new FormControl(''),
      root_cause:      new FormControl('', Validators.required),
      final_result:    new FormControl('', Validators.required),
      analysis:        new FormControl('', Validators.required),
      start_date:      new FormControl('', Validators.required),
      end_date:        new FormControl('', Validators.required),
      before_desc:     new FormControl('', Validators.required),
      after_desc:      new FormControl('', Validators.required),
      benefits:        new FormControl('1.', Validators.required),
      team:            new FormControl('1. ', Validators.required),
      horizontal_deployment: new FormArray([this.createRow()])
    });
  }

  createRow() {
    return new FormGroup({
      m_no:   new FormControl(''), resp: new FormControl(''),
      target: new FormControl(''), status: new FormControl('Pending')
    });
  }

  get deploymentRows() { return this.kaizenForm.get('horizontal_deployment') as FormArray; }
  addRow()    { this.deploymentRows.push(this.createRow()); }
  removeRow(i: number) { if (this.deploymentRows.length > 1) this.deploymentRows.removeAt(i); }

  // ── Step navigation ────────────────────────────────────────────────────────
  nextStep() {
    const fields: { [step: number]: string[] } = {
      1: ['emp_id','emp_name','unit','department','section','machine_no','kaizen_type','pqcdsm','kaizen_category','theme','start_date','end_date'],
      2: ['problem_status','idea','countermeasure','why1','why2','why3','root_cause','final_result','analysis']
    };
    fields[this.currentStep].forEach(k => this.kaizenForm.get(k)?.markAsTouched());
    const invalid = fields[this.currentStep].some(k => this.kaizenForm.get(k)?.invalid);
    if (invalid || (this.currentStep === 1 && this.isDuplicate)) return;
    this.currentStep++;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  prevStep() {
    if (this.currentStep > 1) { this.currentStep--; window.scrollTo({ top: 0, behavior: 'smooth' }); }
  }

  onUnitChange() {
    const u = this.kaizenForm.get('unit')?.value;
    this.availableDepartments = this.plantDepartments[u] || [];
    this.availableSections = [];
    this.kaizenForm.patchValue({ department: '', section: '' });
  }

  onDepartmentChange() {
    const d = this.kaizenForm.get('department')?.value;
    this.availableSections = this.departmentSections[d] || [];
    this.kaizenForm.patchValue({ section: '' });
  }

  loadExistingThemes() {
    this.http.get<any[]>('http://localhost:8080/api/kaizen/my-kaizens').subscribe({
      next: (res) => { this.allThemes = res.map(k => (k.theme || '').toLowerCase().trim()).filter(t => t.length > 0); },
      error: () => { this.allThemes = []; }
    });
  }

  fetchNextId() {
    this.kaizenNo = 'Fetching...';
    this.http.get('http://localhost:8080/api/supervisor', { responseType: 'text' }).subscribe({
      next: (val) => {
        const count = val ? parseInt(val, 10) : 0;
        this.kaizenNo = `SUP-${new Date().getFullYear()}-${(count + 1).toString().padStart(3, '0')}`;
        this.cdr.detectChanges();
      },
      error: () => { this.kaizenNo = 'SUP-Error'; this.cdr.detectChanges(); }
    });
  }

  allowAlphabetsOnly(e: KeyboardEvent): boolean { const c = e.charCode; return (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c === 32; }
  allowTeamInput(e: KeyboardEvent): boolean { const c = e.charCode; return (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c === 32 || c === 46 || (c >= 48 && c <= 57); }

  onFileChange(event: any, field: string) {
    const file = event.target.files[0];
    if (!file) return;
    if (file.size <= 512000) {
      this.fileErrors[field] = false; this.compressInfo[field] = `✓ ${Math.round(file.size/1024)}KB — ready`;
      this.selectedFiles[field] = file; this.cdr.detectChanges(); return;
    }
    this.compressing[field] = true; this.compressInfo[field] = ''; this.cdr.detectChanges();
    this.compressImage(file, 500).then(compressed => {
      this.compressing[field] = false; this.fileErrors[field] = false; this.selectedFiles[field] = compressed;
      this.compressInfo[field] = `✓ Compressed: ${Math.round(file.size/1024)}KB → ${Math.round(compressed.size/1024)}KB`;
      this.cdr.detectChanges();
    }).catch(() => {
      this.compressing[field] = false; this.fileErrors[field] = true;
      this.showToast('Image compression failed. Please try another file.', 'error');
      this.cdr.detectChanges(); event.target.value = '';
    });
  }

  compressImage(file: File, maxSizeKB: number): Promise<File> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (e: any) => {
        const img = new Image(); img.src = e.target.result;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let w = img.width, h = img.height; const MAX = 1200;
          if (w > MAX || h > MAX) { if (w > h) { h = Math.round(h * MAX / w); w = MAX; } else { w = Math.round(w * MAX / h); h = MAX; } }
          canvas.width = w; canvas.height = h;
          canvas.getContext('2d')!.drawImage(img, 0, 0, w, h);
          let quality = 0.9;
          const tryCompress = () => {
            const dataUrl = canvas.toDataURL('image/jpeg', quality);
            const sizeKB = Math.round(dataUrl.length * 3 / 4 / 1024);
            if (sizeKB <= maxSizeKB || quality <= 0.3) {
              const arr = dataUrl.split(','); const bstr = atob(arr[1]); let n = bstr.length; const u8 = new Uint8Array(n);
              while (n--) u8[n] = bstr.charCodeAt(n);
              resolve(new File([u8], file.name, { type: 'image/jpeg' }));
            } else { quality -= 0.1; tryCompress(); }
          };
          tryCompress();
        };
        img.onerror = () => reject();
      };
      reader.onerror = () => reject();
    });
  }

  isAnyCompressing(): boolean { return Object.values(this.compressing).some(v => v); }
  hasFileError():     boolean { return Object.values(this.fileErrors).some(v => v); }

  checkDuplicateTheme() {
    const t = this.kaizenForm.get('theme')?.value?.toLowerCase().trim();
    this.isDuplicate = t && t.length > 2 ? this.allThemes.includes(t) : false;
  }

  handleTeamNumbering(e: KeyboardEvent) {
    if (e.key === 'Enter') {
      const val = (e.target as HTMLTextAreaElement).value;
      const lines = val.split('\n');
      if (lines[lines.length - 1].trim().length > 3) {
        e.preventDefault();
        this.kaizenForm.patchValue({ team: val + '\n' + (lines.length + 1) + '. ' });
      }
    }
  }

  handleBenefitsNumbering(e: KeyboardEvent) {
    if (e.key === 'Enter') {
      const val = (e.target as HTMLTextAreaElement).value;
      const lines = val.split('\n');
      if (lines[lines.length - 1].trim().length > 3) {
        e.preventDefault();
        this.kaizenForm.patchValue({ benefits: val + '\n' + (lines.length + 1) + '. ' });
      }
    }
  }

  // ── Clear form ─────────────────────────────────────────────────────────────
  clearForm() {
    this.showClearModal = true;
  }

  confirmClear() {
    this.showClearModal = false;
    this.initForm();
    this.resetFiles();
    this.showToast('Form cleared successfully.', 'info');
    this.cdr.detectChanges();
  }

  resetFiles() {
    this.selectedFiles = { before_img: null, after_img: null, problem_img: null, result_img: null };
    this.fileErrors    = { before_img: false, after_img: false, problem_img: false, result_img: false };
    this.compressing   = { before_img: false, after_img: false, problem_img: false, result_img: false };
    this.compressInfo  = { before_img: '', after_img: '', problem_img: '', result_img: '' };
    document.querySelectorAll<HTMLInputElement>('input[type="file"]').forEach(i => i.value = '');
  }

  // ── Submit ─────────────────────────────────────────────────────────────────
  onPreSubmit() {
    if (this.isSubmitting) return;
    Object.keys(this.kaizenForm.controls).forEach(k => this.kaizenForm.get(k)?.markAsTouched());
    if (this.kaizenForm.valid && !this.isDuplicate && !this.hasFileError() && !this.isAnyCompressing() && this.kaizenNo !== 'SUP-Error') {
      this.showConfirmModal = true;
    } else {
      this.showToast('Please fill all required fields and ensure images are ready.', 'error', 4000);
    }
  }

  finalSubmit() {
    if (this.isSubmitting) return;
    this.isSubmitting = true; this.showConfirmModal = false; this.cdr.detectChanges();
    const formData = new FormData();
    const vals = this.kaizenForm.value;
    Object.keys(vals).forEach(k => { if (k !== 'horizontal_deployment') formData.append(k, vals[k]); });
    formData.append('kaizen_id',       this.kaizenNo);
    formData.append('submitted_at',    new Date().toISOString());
    formData.append('level',           'Supervisor');
    formData.append('deployment_data', JSON.stringify(vals.horizontal_deployment.filter((r: any) => r.m_no?.trim())));
    if (this.selectedFiles['before_img'])  formData.append('before_img_file',  this.selectedFiles['before_img']!);
    if (this.selectedFiles['after_img'])   formData.append('after_img_file',   this.selectedFiles['after_img']!);
    if (this.selectedFiles['problem_img']) formData.append('problem_img_file', this.selectedFiles['problem_img']!);
    if (this.selectedFiles['result_img'])  formData.append('result_img_file',  this.selectedFiles['result_img']!);

    this.http.post('http://localhost:8080/api/supervisor/save', formData, { responseType: 'text' }).subscribe({
      next: () => {
        this.lastSubmittedNo = this.kaizenNo;
        this.showSuccessModal = true;
        this.isSubmitting = false;
        this.initForm(); this.resetFiles(); this.fetchNextId(); this.loadExistingThemes();
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.isSubmitting = false;
        this.showToast('Submission failed: ' + (err.message || 'Unknown error'), 'error', 5000);
        this.cdr.detectChanges();
      }
    });
  }

  goBack() { window.history.back(); }
}