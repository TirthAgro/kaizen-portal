import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import JSZip from 'jszip';

/* ── Toaster ── */
interface Toast {
  id:      number;
  type:    'success' | 'error' | 'warning';
  title:   string;
  message: string;
  visible: boolean;
}

@Component({
  selector: 'app-operator-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule],
  encapsulation: ViewEncapsulation.None,
  template: `

  <!-- ══════════ TOASTER CONTAINER ══════════ -->
  <div class="of-toast-container">
    <div *ngFor="let t of toasts"
         class="of-toast"
         [class.of-toast--success]="t.type === 'success'"
         [class.of-toast--error]="t.type === 'error'"
         [class.of-toast--warning]="t.type === 'warning'"
         [class.of-toast--visible]="t.visible"
         (click)="dismissToast(t.id)">
      <div class="of-toast-icon">
        <svg *ngIf="t.type === 'success'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
        <svg *ngIf="t.type === 'error'"   viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        <svg *ngIf="t.type === 'warning'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
      </div>
      <div class="of-toast-body">
        <div class="of-toast-title">{{ t.title }}</div>
        <div class="of-toast-msg">{{ t.message }}</div>
      </div>
      <button class="of-toast-close" (click)="dismissToast(t.id)">✕</button>
      <div class="of-toast-bar"></div>
    </div>
  </div>

  <!-- ══════════ CONFIRM MODAL ══════════ -->
  <div class="of-overlay" *ngIf="showConfirmModal">
    <div class="of-modal">
      <div class="of-modal-icon orange">?</div>
      <h3 class="of-modal-title">Confirm Submission</h3>
      <p class="of-modal-sub">Are you sure you want to submit this Kaizen?</p>
      <div class="of-modal-preview">
        <div class="of-preview-row"><span class="of-preview-lbl">Kaizen ID</span><span class="of-preview-val">{{ kaizenNo }}</span></div>
        <div class="of-preview-row"><span class="of-preview-lbl">Theme</span><span class="of-preview-val">{{ kaizenForm.value.theme }}</span></div>
      </div>
      <div class="of-modal-btns">
        <button class="of-mbtn-cancel" (click)="showConfirmModal = false">Review</button>
        <button class="of-mbtn-ok" (click)="finalSubmit()">Submit Now</button>
      </div>
    </div>
  </div>

  <!-- ══════════ SUCCESS MODAL ══════════ -->
  <div class="of-overlay" *ngIf="showSuccessModal">
    <div class="of-modal success">
      <div class="of-modal-icon green">✔</div>
      <h3 class="of-modal-title">Success!</h3>
      <p class="of-modal-sub"> Your Kaizen <strong>{{ lastSubmittedNo }}</strong> registered successfully.</p>
      <button class="of-mbtn-ok" (click)="showSuccessModal = false">Great!</button>
    </div>
  </div>

  <!-- ══════════ PAGE SHELL ══════════ -->
  <div class="of-root">

    <!-- TOP BAR -->
    <header class="of-topbar">
      <div class="of-topbar-left">
        <div class="of-topbar-brand">
          <span class="of-topbar-title">SHAKTIपथ</span>
          <span class="of-topbar-sub">New Kaizen</span>
        </div>
      </div>
      <div class="of-topbar-right">
        <div class="of-live-pill">
          <span class="of-live-dot"></span> System Live
        </div>
        <div class="of-logo-wrap">
          <img src="assets/images/test-logo.png" alt="Shaktiman" class="of-logo-img">
        </div>
        <button class="of-back-btn" (click)="goBack()">Back</button>
      </div>
    </header>

    <!-- CONTENT AREA -->
    <div class="of-content">

      <!-- PAGE HEADER ROW -->
      <div class="of-page-header">
        <div>
          <h1 class="of-page-title">Operator Kaizen Entry</h1>
          <p class="of-page-sub">2-step registration form</p>
        </div>
        <div class="of-id-chip" [class.error]="kaizenNo === 'KZN-Error'">
          <span class="of-id-label">ID</span>
          <span class="of-id-val">{{ kaizenNo }}</span>
          <span class="of-id-sep"></span>
          <span class="of-id-date">{{ today | date:'dd MMM yyyy' }}</span>
          <button *ngIf="kaizenNo === 'KZN-Error'" (click)="fetchNextId()" class="of-retry">Retry</button>
        </div>
      </div>

      <!-- STEP PROGRESS BAR -->
      <div class="of-stepper">
        <div class="of-step" [class.active]="currentStep >= 1" [class.done]="currentStep > 1">
          <div class="of-step-icon">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
              <rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/>
              <rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>
            </svg>
          </div>
          <span class="of-step-label">Basic & Classification</span>
        </div>
        <div class="of-step-line" [class.done]="currentStep > 1"></div>
        <div class="of-step" [class.active]="currentStep >= 2">
          <div class="of-step-icon">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
              <rect x="3" y="3" width="18" height="18" rx="2"/>
              <circle cx="8.5" cy="8.5" r="1.5"/>
              <polyline points="21 15 16 10 5 21"/>
            </svg>
          </div>
          <span class="of-step-label">Evidence & Team</span>
        </div>
      </div>

      <!-- FORM -->
      <form [formGroup]="kaizenForm" (ngSubmit)="onPreSubmit()">

        <!-- ════ STEP 1 ════ -->
        <ng-container *ngIf="currentStep === 1">

          <!-- Section 01: Basic Information -->
          <div class="of-section-card">
            <div class="of-section-head">
              <div class="of-section-left">
                <div class="of-sec-badge">01</div>
                <span class="of-sec-title">Basic Information</span>
              </div>
              <span class="of-sec-hint">Employee & plant details</span>
            </div>
            <div class="of-sec-divider"></div>

            <div class="of-row-3">
              <div class="of-field">
                <label>Employee ID <span class="of-req">*</span></label>
                <input type="text" formControlName="emp_id" pattern="[A-Za-z0-9]*" oninput="this.value = this.value.replace(/[^A-Za-z0-9]/g, '')" maxlength="8" placeholder="Numbers only">
                <div class="of-err" *ngIf="kaizenForm.get('emp_id')?.touched && kaizenForm.get('emp_id')?.errors?.['required']">Required</div>
                
              </div>
              <div class="of-field">
                <label>Employee Name <span class="of-req">*</span></label>
                <input type="text" formControlName="emp_name"
                       (keypress)="allowAlphabetsOnly($event)" placeholder="Full name">
                <div class="of-err" *ngIf="kaizenForm.get('emp_name')?.touched && kaizenForm.get('emp_name')?.errors?.['required']">Required</div>
                <div class="of-err" *ngIf="kaizenForm.get('emp_name')?.touched && kaizenForm.get('emp_name')?.errors?.['pattern']">Alphabets only</div>
              </div>
              <div class="of-field">
                <label>Plant (Unit) <span class="of-req">*</span></label>
                <select formControlName="unit" (change)="onUnitChange()">
                  <option value="">Select Plant</option>
                  <option *ngFor="let i of [1,2,3,4,5]" [value]="'Unit '+i">Unit {{ i }}</option>
                </select>
                <div class="of-err" *ngIf="kaizenForm.get('unit')?.touched && kaizenForm.get('unit')?.errors?.['required']">Required</div>
              </div>
            </div>

            <div class="of-row-3" *ngIf="kaizenForm.get('unit')?.value">
              <div class="of-field">
                <label>Department <span class="of-req">*</span></label>
                <select formControlName="department" (change)="onDepartmentChange()">
                  <option value="">Select Department</option>
                  <option *ngFor="let dept of currentDepartments" [value]="dept">{{ dept }}</option>
                </select>
                <div class="of-err" *ngIf="kaizenForm.get('department')?.touched && kaizenForm.get('department')?.errors?.['required']">Required</div>
              </div>
              <div class="of-field" *ngIf="kaizenForm.get('department')?.value">
                <label>Zone / Circle <span class="of-req">*</span></label>
                <input type="text" formControlName="zone" placeholder="e.g. Zone A">
                <div class="of-err" *ngIf="kaizenForm.get('zone')?.touched && kaizenForm.get('zone')?.errors?.['required']">Required</div>
              </div>
              <div class="of-field" *ngIf="kaizenForm.get('department')?.value">
                <label>Section <span class="of-req">*</span></label>
                <select formControlName="section" (change)="onSectionChange()">
                  <option value="">Select Section</option>
                  <option value="Welding">Welding</option>
                  <option value="Cutting">Cutting</option>
                  <option value="Assembly">Assembly</option>
                  <option value="Machine Shop">Machine Shop</option>
                  <option value="Other">Other...</option>
                </select>
                <div class="of-err" *ngIf="kaizenForm.get('section')?.touched && kaizenForm.get('section')?.errors?.['required']">Required</div>
              </div>
            </div>

            <div class="of-row-1" *ngIf="kaizenForm.get('section')?.value === 'Other'">
              <div class="of-field">
                <label>Specify Section <span class="of-req">*</span></label>
                <input type="text" formControlName="other_section" placeholder="Enter Section Name">
              </div>
            </div>
          </div>

          <!-- Section 02: Classification -->
          <div class="of-section-card">
            <div class="of-section-head">
              <div class="of-section-left">
                <div class="of-sec-badge">02</div>
                <span class="of-sec-title">Classification</span>
              </div>
              <span class="of-sec-hint">Type, group & category</span>
            </div>
            <div class="of-sec-divider"></div>

            <div class="of-row-1">
              <div class="of-field">
                <label>Kaizen Theme <span class="of-req">*</span></label>
                <input type="text" formControlName="theme"
                       (input)="checkDuplicateTheme()"
                       [class.of-input-error]="isDuplicate"
                       placeholder="Enter a unique theme title">
                <div class="of-err" *ngIf="isDuplicate">⚠ This theme already exists. Use a unique title.</div>
                <div class="of-err" *ngIf="kaizenForm.get('theme')?.touched && kaizenForm.get('theme')?.errors?.['required'] && !isDuplicate">Required</div>
              </div>
            </div>

            <div class="of-row-3">
              <div class="of-field">
                <label>Group (PQCDSM) <span class="of-req">*</span></label>
                <select formControlName="pqcdsm">
                  <option value="">Select Group</option>
                  <option value="P - Productivity">P - Productivity</option>
                  <option value="Q - Quality">Q - Quality</option>
                  <option value="C - Cost">C - Cost</option>
                  <option value="D - Delivery">D - Delivery</option>
                  <option value="S - Safety">S - Safety</option>
                  <option value="M - Morale">M - Morale</option>
                </select>
                <div class="of-err" *ngIf="kaizenForm.get('pqcdsm')?.touched && kaizenForm.get('pqcdsm')?.errors?.['required']">Required</div>
              </div>
              <div class="of-field" style="grid-column: span 2">
                <label>Kaizen Category <span class="of-req">*</span></label>
                <select formControlName="kaizen_category">
                  <option value="">Select Category</option>
                  <option *ngFor="let cat of categories" [value]="cat.v">{{ cat.l }}</option>
                </select>
                <div class="of-err" *ngIf="kaizenForm.get('kaizen_category')?.touched && kaizenForm.get('kaizen_category')?.errors?.['required']">Required</div>
              </div>
            </div>

            <div class="of-row-2">
              <div class="of-field">
                <label>Start Date <span class="of-req">*</span></label>
                <input type="date" formControlName="start_date">
                <div class="of-err" *ngIf="kaizenForm.get('start_date')?.touched && kaizenForm.get('start_date')?.errors?.['required']">Required</div>
              </div>
              <div class="of-field">
                <label>End Date <span class="of-req">*</span></label>
                <input type="date" formControlName="end_date">
                <div class="of-err" *ngIf="kaizenForm.get('end_date')?.touched && kaizenForm.get('end_date')?.errors?.['required']">Required</div>
              </div>
            </div>
          </div>

        </ng-container>

        <!-- ════ STEP 2 ════ -->
        <ng-container *ngIf="currentStep === 2">

          <!-- Section 03: Before & After Evidence -->
          <div class="of-section-card">
            <div class="of-section-head">
              <div class="of-section-left">
                <div class="of-sec-badge">03</div>
                <span class="of-sec-title">Before & After Evidence</span>
              </div>
              <span class="of-sec-hint">Photos & description</span>
            </div>
            <div class="of-sec-divider"></div>

            <div class="of-row-2">
              <!-- BEFORE -->
              <div class="of-ev-card of-before">
                <div class="of-ev-badge before">Before Improvement</div>
                <input type="file"
                  (change)="onFileChange($event, 'before_img')"
                  accept="image/*,video/mp4,application/pdf,
                    application/vnd.ms-powerpoint,
                    application/vnd.openxmlformats-officedocument.presentationml.presentation,
                    application/vnd.ms-excel,
                    application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,
                    text/plain">
                <p class="of-hint">Images auto-compressed • MP4 max 20MB • PDF/PPT/XLS/TXT auto-zipped</p>
                <div class="of-processing" *ngIf="compressing['before_img']">
                  <span class="of-spinner"></span> Processing...
                </div>
                <div class="of-ok"  *ngIf="compressInfo['before_img'] && !fileErrors['before_img']">{{ compressInfo['before_img'] }}</div>
                <div class="of-err" *ngIf="fileErrors['before_img']">{{ compressInfo['before_img'] }}</div>
                <label>Before Description <span class="of-req">*</span></label>
                <textarea formControlName="before_desc" rows="4" placeholder="Describe the current problem..."></textarea>
                <div class="of-err" *ngIf="kaizenForm.get('before_desc')?.touched && kaizenForm.get('before_desc')?.errors?.['required']">Required</div>
              </div>

              <!-- AFTER -->
              <div class="of-ev-card of-after">
                <div class="of-ev-badge after">After Improvement</div>
                <input type="file"
                  (change)="onFileChange($event, 'after_img')"
                  accept="image/*,video/mp4,application/pdf,
                    application/vnd.ms-powerpoint,
                    application/vnd.openxmlformats-officedocument.presentationml.presentation,
                    application/vnd.ms-excel,
                    application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,
                    text/plain">
                <p class="of-hint">Images auto-compressed • MP4 max 20MB • PDF/PPT/XLS/TXT auto-zipped</p>
                <div class="of-processing" *ngIf="compressing['after_img']">
                  <span class="of-spinner"></span> Processing...
                </div>
                <div class="of-ok"  *ngIf="compressInfo['after_img'] && !fileErrors['after_img']">{{ compressInfo['after_img'] }}</div>
                <div class="of-err" *ngIf="fileErrors['after_img']">{{ compressInfo['after_img'] }}</div>
                <label>After Description <span class="of-req">*</span></label>
                <textarea formControlName="after_desc" rows="4" placeholder="Describe the improvement made..." maxlength="1000"></textarea>
                <div class="of-err" *ngIf="kaizenForm.get('after_desc')?.touched && kaizenForm.get('after_desc')?.errors?.['required']">Required</div>
                <div class="of-err"
  *ngIf="(kaizenForm.get('after_desc')?.value?.length || 0) >= 1000">
  Maximum character limit reached
 </div>
              </div>
            </div>
          </div>

          <!-- Section 04: Benefits & Team -->
          <div class="of-section-card">
            <div class="of-section-head">
              <div class="of-section-left">
                <div class="of-sec-badge">04</div>
                <span class="of-sec-title">Benefits & Team</span>
              </div>
              <span class="of-sec-hint">Impact & contributors</span>
            </div>
            <div class="of-sec-divider"></div>

            <div class="of-row-2">
              <div class="of-field">
                <label>Kaizen Benefits <span class="of-req">*</span></label>
                <textarea formControlName="benefits" rows="5"
                  (keydown)="handleBenefitsNumbering($event)"
                  placeholder="1. Time saved"></textarea>
                <div class="of-err" *ngIf="kaizenForm.get('benefits')?.touched && kaizenForm.get('benefits')?.errors?.['required']">Required</div>
              </div>
              <div class="of-field">
                <label>Team Members <span class="of-req">*</span></label>
                <textarea formControlName="team" rows="5"
                          (keypress)="allowTeamInput($event)"
                          (keydown)="handleTeamNumbering($event)"
                          placeholder="1. Member Name"></textarea>
                <p class="of-hint">Alphabets and spaces only</p>
                <div class="of-err" *ngIf="kaizenForm.get('team')?.touched && kaizenForm.get('team')?.errors?.['required']">Required</div>
              </div>
            </div>
          </div>

        </ng-container>

      </form>
    </div>

    <!-- ══════ BOTTOM NAV BAR ══════ -->
    <footer class="of-footer">
      <span class="of-footer-step">Step {{ currentStep }} of 2</span>
      <div class="of-footer-btns">
        <button class="of-btn-back" *ngIf="currentStep > 1" (click)="currentStep = 1">← Back</button>
        <button class="of-btn-next" *ngIf="currentStep === 1" (click)="goToStep2()">Next Step →</button>
        <button class="of-btn-submit"
                *ngIf="currentStep === 2"
                (click)="onPreSubmit()"
                [disabled]="kaizenForm.invalid || isDuplicate || hasFileError() || isAnyCompressing() || kaizenNo === 'KZN-Error'">
          <span *ngIf="isAnyCompressing()">⏳ Processing...</span>
          <span *ngIf="!isAnyCompressing() && kaizenNo === 'KZN-Error'">System Offline</span>
          <span *ngIf="!isAnyCompressing() && kaizenNo !== 'KZN-Error'">Submit Kaizen ✔</span>
        </button>
      </div>
    </footer>

  </div>
  `,
  styles: [`
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

    /* ══════════════════════════════════
       TOASTER
    ══════════════════════════════════ */
    .of-toast-container {
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 99999;
      display: flex;
      flex-direction: column;
      gap: 10px;
      pointer-events: none;
    }
    .of-toast {
      pointer-events: all;
      display: flex;
      align-items: flex-start;
      gap: 12px;
      width: 340px;
      max-width: calc(100vw - 40px);
      background: #1c1c2e;
      border: 1px solid rgba(255,255,255,.08);
      border-radius: 16px;
      padding: 14px 16px 18px;
      box-shadow: 0 20px 60px rgba(0,0,0,.45), 0 4px 16px rgba(0,0,0,.25);
      cursor: pointer;
      position: relative;
      overflow: hidden;
      opacity: 0;
      transform: translateX(120%) scale(0.9);
      transition: opacity .35s cubic-bezier(.22,1,.36,1),
                  transform .35s cubic-bezier(.22,1,.36,1);
    }
    .of-toast--visible {
      opacity: 1;
      transform: translateX(0) scale(1);
    }
    .of-toast--success { border-left: 4px solid #10b981; }
    .of-toast--error   { border-left: 4px solid #ef4444; }
    .of-toast--warning { border-left: 4px solid #f97316; }

    .of-toast-icon {
      width: 36px; height: 36px; border-radius: 10px;
      display: flex; align-items: center; justify-content: center;
      flex-shrink: 0;
    }
    .of-toast-icon svg { width: 18px; height: 18px; }
    .of-toast--success .of-toast-icon { background: rgba(16,185,129,.15); color: #10b981; }
    .of-toast--error   .of-toast-icon { background: rgba(239,68,68,.15);  color: #ef4444; }
    .of-toast--warning .of-toast-icon { background: rgba(249,115,22,.15); color: #f97316; }

    .of-toast-body { flex: 1; min-width: 0; }
    .of-toast-title {
      font-size: 13px; font-weight: 700; color: #f1f5f9;
      letter-spacing: .01em; margin-bottom: 3px;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }
    .of-toast-msg {
      font-size: 12px; color: #94a3b8; line-height: 1.5;
      word-break: break-word;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }
    .of-toast-close {
      background: none; border: none; color: #475569;
      font-size: 12px; cursor: pointer; padding: 2px 4px;
      border-radius: 4px; flex-shrink: 0; line-height: 1;
      transition: color .15s; font-family: inherit;
    }
    .of-toast-close:hover { color: #94a3b8; }

    .of-toast-bar {
      position: absolute; bottom: 0; left: 0;
      height: 3px; border-radius: 0 0 0 16px;
      animation: of-bar 4s linear forwards;
    }
    .of-toast--success .of-toast-bar { background: #10b981; }
    .of-toast--error   .of-toast-bar { background: #ef4444; }
    .of-toast--warning .of-toast-bar { background: #f97316; }
    @keyframes of-bar { from { width: 100%; } to { width: 0%; } }

    /* ══════════════════════════════════
       ROOT
    ══════════════════════════════════ */
    .of-root {
      --orange: #f97316;
      --orange-light: #fff7ed;
      --orange-border: rgba(249,115,22,0.25);
      --bg: #f3f4f8;
      --card: #ffffff;
      --border: #e5e7eb;
      --text: #111827;
      --text-2: #4b5563;
      --text-3: #9ca3af;
      --red: #ef4444;
      --green: #10b981;
      --font: 'Plus Jakarta Sans', sans-serif;
      font-family: var(--font);
      background: var(--bg);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }

    .of-topbar {
      height: 60px; background: #ffffff;
      border-bottom: 1px solid var(--border);
      display: flex; align-items: center; justify-content: space-between;
      padding: 0 32px; position: sticky; top: 0; z-index: 100; flex-shrink: 0;
    }
    .of-topbar-left { display: flex; align-items: center; gap: 12px; }
    .of-topbar-brand { display: flex; flex-direction: column; }
    .of-topbar-title { font-size: 15px; font-weight: 800; color: var(--text); letter-spacing: 1px; line-height: 1.1; }
    .of-topbar-sub   { font-size: 10px; color: var(--text-3); font-weight: 500; }
    .of-topbar-right { display: flex; align-items: center; gap: 16px; }
    .of-live-pill { display: flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 600; color: #374151; }
    .of-live-dot {
      width: 7px; height: 7px; border-radius: 50%; background: #10b981;
      animation: of-pulse 2s infinite;
    }
    @keyframes of-pulse {
      0%,100% { box-shadow: 0 0 0 0 rgba(16,185,129,.4); }
      50%      { box-shadow: 0 0 0 4px rgba(16,185,129,0); }
    }
    .of-logo-wrap { padding: 0; }
    .of-logo-img { height: 30px; width: auto; filter: invert(48%) sepia(79%) saturate(2476%) hue-rotate(5deg) brightness(103%) contrast(97%); }
    .of-back-btn {
      display: flex; align-items: center; gap: 8px;
      background: #ffffff; color: #0f172a; border: 1px solid #dbeafe;
      padding: 10px 18px; border-radius: 12px; cursor: pointer;
      font-size: 14px; font-weight: 700; transition: all 0.25s ease;
      box-shadow: 0 4px 12px rgba(0,0,0,0.06);
    }
    .of-back-btn:hover { transform: translateY(-2px); background: #eff6ff; border-color: #93c5fd; }

    .of-content { flex: 1; padding: 28px 32px 120px; max-width: 1100px; margin: 0 auto; width: 100%; }
    .of-page-header { display: flex; align-items: flex-start; justify-content: space-between; margin-bottom: 28px; }
    .of-page-title { font-size: 30px; font-weight: 800; color: var(--text); letter-spacing: -.5px; }
    .of-page-sub   { font-size: 13px; color: var(--text-3); margin-top: 4px; font-weight: 500; }

    .of-id-chip {
      display: flex; align-items: center; gap: 10px;
      background: var(--orange); color: #fff;
      padding: 10px 20px; border-radius: 50px;
      font-weight: 700; font-size: 14px;
      box-shadow: 0 8px 20px rgba(249,115,22,.3);
    }
    .of-id-chip.error { background: #ef4444; }
    .of-id-label { font-size: 10px; font-weight: 800; opacity: .8; letter-spacing: 1px; }
    .of-id-val   { font-size: 15px; font-weight: 800; }
    .of-id-sep   { width: 1px; height: 16px; background: rgba(255,255,255,.4); }
    .of-id-date  { font-size: 13px; font-weight: 600; opacity: .9; }
    .of-retry    { background: rgba(255,255,255,.2); border: none; color: #fff; padding: 3px 10px; border-radius: 20px; font-size: 11px; cursor: pointer; }

    .of-stepper { display: flex; align-items: center; gap: 0; margin-bottom: 28px; }
    .of-step { display: flex; align-items: center; gap: 10px; opacity: .4; transition: opacity .3s; }
    .of-step.active { opacity: 1; }
    .of-step.done   { opacity: .7; }
    .of-step-icon {
      width: 42px; height: 42px; border-radius: 12px;
      background: #e5e7eb; color: var(--text-2);
      display: flex; align-items: center; justify-content: center;
      transition: all .3s; flex-shrink: 0;
    }
    .of-step.active .of-step-icon { background: var(--orange); color: #fff; box-shadow: 0 6px 16px rgba(249,115,22,.35); }
    .of-step.done   .of-step-icon { background: var(--green);  color: #fff; }
    .of-step-label { font-size: 13px; font-weight: 600; color: var(--text); white-space: nowrap; }
    .of-step.active .of-step-label { color: var(--orange); }
    .of-step-line { flex: 1; height: 2px; background: #e5e7eb; margin: 0 16px; border-radius: 99px; transition: background .3s; }
    .of-step-line.done { background: var(--green); }

    .of-section-card {
      background: var(--orange-light); border: 1.5px solid var(--orange-border);
      border-radius: 18px; margin-bottom: 20px; overflow: hidden;
      animation: of-slide-up .4s ease both;
    }
    @keyframes of-slide-up {
      from { opacity: 0; transform: translateY(14px); }
      to   { opacity: 1; transform: translateY(0); }
    }
    .of-section-card:nth-child(2) { animation-delay: .06s; }
    .of-section-card:nth-child(3) { animation-delay: .12s; }

    .of-section-head { display: flex; align-items: center; justify-content: space-between; padding: 18px 24px 14px; }
    .of-section-left { display: flex; align-items: center; gap: 12px; }
    .of-sec-badge {
      width: 34px; height: 34px; border-radius: 10px;
      background: var(--orange); color: #fff;
      display: flex; align-items: center; justify-content: center;
      font-size: 12px; font-weight: 800; box-shadow: 0 4px 12px rgba(249,115,22,.3);
    }
    .of-sec-title { font-size: 16px; font-weight: 700; color: var(--orange); }
    .of-sec-hint  { font-size: 12px; color: var(--text-3); font-weight: 500; }
    .of-sec-divider { height: 1px; background: var(--orange-border); margin: 0 24px; }

    .of-section-card .of-row-1,
    .of-section-card .of-row-2,
    .of-section-card .of-row-3,
    .of-section-card .of-ev-card { padding: 0 24px; }
    .of-row-1 { display: grid; grid-template-columns: 1fr; gap: 16px; padding-top: 20px; padding-bottom: 4px; }
    .of-row-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; padding-top: 20px; padding-bottom: 4px; }
    .of-row-3 { display: grid; grid-template-columns: repeat(3,1fr); gap: 20px; padding-top: 20px; padding-bottom: 4px; }
    .of-section-card > *:last-child { padding-bottom: 24px; }

    .of-field { display: flex; flex-direction: column; gap: 7px; }
    .of-field label { font-size: 12px; font-weight: 700; color: var(--text-2); letter-spacing: .02em; }
    .of-req { color: var(--red); font-weight: 900; }
    .of-err  { color: var(--red);   font-size: 11px; font-weight: 600; margin-top: 2px; }
    .of-ok   { color: var(--green); font-size: 11px; font-weight: 600; margin-top: 2px; }
    .of-hint { color: var(--text-3); font-size: 10px; font-weight: 500; margin-top: 2px; }

    .of-processing {
      display: flex; align-items: center; gap: 8px;
      font-size: 11px; font-weight: 600; color: var(--orange);
    }
    .of-spinner {
      width: 14px; height: 14px; border-radius: 50%;
      border: 2px solid rgba(249,115,22,.25);
      border-top-color: var(--orange);
      animation: of-spin .7s linear infinite; display: inline-block;
    }
    @keyframes of-spin { to { transform: rotate(360deg); } }

    input[type="text"], input[type="date"], input[type="file"],
    select, textarea {
      width: 100%; background: #ffffff; border: 1.5px solid #e5e7eb;
      border-radius: 10px; padding: 11px 14px;
      font-size: 13px; font-weight: 500; color: var(--text);
      font-family: var(--font); transition: border-color .2s, box-shadow .2s;
      outline: none; resize: vertical;
    }
    input::placeholder, textarea::placeholder { color: var(--text-3); }
    input:focus, select:focus, textarea:focus {
      border-color: var(--orange);
      box-shadow: 0 0 0 3px rgba(249,115,22,.12);
    }
    .of-input-error { border-color: var(--red) !important; }
    select { cursor: pointer; appearance: auto; }

    .of-ev-card { display: flex; flex-direction: column; gap: 10px; padding-top: 20px !important; }
    .of-ev-badge {
      width: max-content; padding: 5px 14px; border-radius: 999px;
      font-size: 11px; font-weight: 800; letter-spacing: .05em; text-transform: uppercase;
    }

    .of-ev-card label {
      display: block;
      font-size: 0.8rem;
      font-weight: 600;
      color: var(--text-secondary, #64748b);
      margin-top: 10px;
      margin-bottom: 4px;
    }
    .of-ev-badge.before { background: #fee2e2; color: #991b1b; }
    .of-ev-badge.after  { background: #dcfce7; color: #166534; }

    .of-footer {
      position: fixed; bottom: 0; left: 0; right: 0; height: 68px;
      background: #111827; border-top: 1px solid rgba(255,255,255,.06);
      display: flex; align-items: center; justify-content: space-between;
      padding: 0 40px; z-index: 200;
    }
    .of-footer-step { font-size: 13px; font-weight: 600; color: rgba(255,255,255,.5); font-family: var(--font); }
    .of-footer-btns { display: flex; gap: 12px; align-items: center; }
    .of-btn-back {
      padding: 11px 22px; border-radius: 10px; background: rgba(255,255,255,.08);
      border: 1px solid rgba(255,255,255,.15); color: rgba(255,255,255,.7);
      font-family: var(--font); font-size: 13px; font-weight: 600; cursor: pointer; transition: all .2s;
    }
    .of-btn-back:hover { background: rgba(255,255,255,.14); color: #fff; }
    .of-btn-next {
      padding: 11px 28px; border-radius: 10px; background: transparent;
      border: 1.5px solid #fff; color: #fff;
      font-family: var(--font); font-size: 13px; font-weight: 700; cursor: pointer; transition: all .2s;
    }
    .of-btn-next:hover { background: rgba(255,255,255,.1); }
    .of-btn-submit {
      padding: 11px 28px; border-radius: 10px; background: var(--orange);
      border: none; color: #fff; font-family: var(--font); font-size: 13px; font-weight: 700;
      cursor: pointer; transition: all .2s; box-shadow: 0 6px 16px rgba(249,115,22,.4);
    }
    .of-btn-submit:hover:not(:disabled) { background: #ea6c0a; transform: translateY(-1px); }
    .of-btn-submit:disabled { background: #6b7280; box-shadow: none; cursor: not-allowed; }

    .of-overlay {
      position: fixed; inset: 0; background: rgba(0,0,0,.5); backdrop-filter: blur(6px);
      display: flex; align-items: center; justify-content: center; z-index: 9999;
    }
    .of-modal {
      background: #fff; border-radius: 24px; padding: 32px;
      width: 420px; max-width: 92vw; text-align: center;
      box-shadow: 0 30px 70px rgba(0,0,0,.2);
      animation: of-pop .28s cubic-bezier(.34,1.56,.64,1);
    }
    .of-modal.success { border-top: 5px solid var(--green); }
    @keyframes of-pop {
      from { opacity: 0; transform: scale(.88); }
      to   { opacity: 1; transform: scale(1);  }
    }
    .of-modal-icon {
      width: 64px; height: 64px; border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      margin: 0 auto 16px; font-size: 28px; font-weight: 900; color: #fff;
    }
    .of-modal-icon.orange { background: linear-gradient(135deg,#f97316,#ea580c); }
    .of-modal-icon.green  { background: linear-gradient(135deg,#10b981,#059669); }
    .of-modal-title { font-size: 20px; font-weight: 800; color: BLACK ; margin-bottom: 6px; }
    .of-modal-sub   { font-size: 13px; color: grey; line-height: 1.6; margin-bottom: 18px; }
    .of-modal-preview {
      background: #78d442; border-radius: 12px; padding: 14px;
      margin-bottom: 20px; text-align: left; border-left: 4px solid var(--orange);
    }
    .of-preview-row { display: flex; justify-content: space-between; padding: 5px 0; }
    .of-preview-lbl { font-size: 12px; color: var(--text-3); font-weight: 600; }
    .of-preview-val { font-size: 12px; color: var(--text); font-weight: 700; }
    .of-modal-btns  { display: flex; gap: 10px; }
    .of-mbtn-cancel {
      flex: 1; height: 44px; border-radius: 10px; background: #508fee;
      border: 1px solid var(--border); color: white; font-family: var(--font); 
      font-size: 13px; font-weight: 600; cursor: pointer; transition: .2s;
    }
    .of-mbtn-cancel:hover { border-color: var(--red); color: var(--red); background: #f7f7f7;}
    .of-mbtn-ok {
      flex: 1; height: 44px; width:80px; border-radius: 10px; background: #ea6c0a;;
      border: none; color: #fff; font-family: var(--font); font-size: 13px; font-weight: 700;
      cursor: pointer; transition: .2s;
    }
    .of-mbtn-ok:hover { background: #ff5100; }

    @media (max-width: 900px) {
      .of-row-2, .of-row-3 { grid-template-columns: 1fr; }
      .of-content { padding: 20px 16px 100px; }
      .of-footer  { padding: 0 20px; }
      .of-toast-container { top: 12px; right: 12px; }
      .of-toast { width: 290px; }
    }
  `]
})
export class OperatorFormComponent implements OnInit {

  // ── State ──
  public currentStep     = 1;
  public kaizenNo        = 'Fetching...';
  public today           = new Date();
  public kaizenForm!: FormGroup;
  public isSubmitting    = false;
  public isDuplicate     = false;
  public showConfirmModal = false;
  public showSuccessModal = false;
  public lastSubmittedNo = '';

  public fileErrors:   { [key: string]: boolean } = { before_img: false, after_img: false };
  public compressing:  { [key: string]: boolean } = { before_img: false, after_img: false };
  public compressInfo: { [key: string]: string  } = { before_img: '', after_img: '' };
  private selectedFiles: { [key: string]: File | null } = { before_img: null, after_img: null };
  private allThemes: string[] = [];

  /* ── Toaster ── */
  public toasts: Toast[] = [];
  private toastCounter = 0;

  private readonly SUPPORTED_IMAGES = [
    'image/jpeg','image/png','image/gif','image/webp','image/bmp','image/svg+xml'
  ];
  private readonly SUPPORTED_DOCS = [
    'application/pdf',
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'text/plain'
  ];
  private readonly MAX_IMAGE_KB = 500;
  private readonly MAX_VIDEO_MB = 20;

  public plantDepartments: { [unit: string]: string[] } = {
    'Unit 1': ['HTFE', 'FE', 'G & T'],
    'Unit 2': ['FTS'],
    'Unit 3': ['PD', 'SPED'],
    'Unit 4': ['SPARE PARTS', 'LOGISTICS'],
    'Unit 5': ['HTFE', 'FE', 'G & T'],
  };
  public currentDepartments: string[] = [];

  public categories = [
    { v: 'C-1|Restorative (TPM)',              l: 'C-1: Restorative (Using TPM Methodology)' },
    { v: 'C-2|Renovative (TPM)',               l: 'C-2: Renovative (Using TPM Methodology)' },
    { v: 'C-3|Innovative (TPM)',               l: 'C-3: Innovative (Using TPM Methodology)' },
    { v: 'C-4|Breakthrough (TPM)',             l: 'C-4: Breakthrough (Using TPM Methodology)' },
    { v: 'C-5|Poka Yoke (TPM)',                l: 'C-5: Poka Yoke (Using TPM Methodology)' },
    { v: 'C-6|KARAKURI & YUTORI',              l: 'C-6: KARAKURI (No Energy Loss) & YUTORI' },
    { v: 'C-7|JH Shop Floor Visualization',    l: 'C-7: JH - Shop Floor Visualization' },
    { v: 'C-8|KK OEE Compliance',              l: 'C-8: KK OEE Compliance' },
    { v: 'C-9|KK Bottleneck Process Solution', l: 'C-9: KK Bottleneck Process Solution' },
    { v: 'C-10|JH Circle Board Updating',      l: 'C-10: JH - Circle Board updating' },
    { v: 'C-11|JH One Point Lessons',          l: 'C-11: JH - One Point Lessons' },
    { v: 'C-12|JH White Tag Abnormality',      l: 'C-12: JH: White tag abnormality' },
    { v: 'C-13|JH (HTA / SOC / Ease for CLITA)', l: 'C-13: JH (HTA / SOC / Ease for CLITA)' },
    { v: 'C-14|JH Step 4 M-M Combination',    l: 'C-14: JH step 4 Man-Machine combination' },
    { v: 'C-15|JH Step 5 M-M Combination',    l: 'C-15: JH step 5 Man-Machine combination' },
    { v: 'C-16|JH Step 1, 2, 3 Repeat',       l: 'C-16: JH: Repeat of JH Step 1, 2, 3' },
    { v: 'C-17|JH Minor Stoppage Monitoring',  l: 'C-17: JH: Minor Stoppage Monitoring' },
    { v: 'C-18|JH RED Tag Abnormality',        l: 'C-18: JH: RED tag abnormality' },
    { v: 'C-19|QM Assembly Pokamapping',       l: 'C-19: QM: Product Assembly Pokamapping' },
    { v: 'C-20|PM MP Sheets Generation',       l: 'C-20: PM: Generation of MP sheets' },
    { v: 'C-21|NEDM MP Sheets Implementation', l: 'C-21: NEDM: Implementation of MP sheets' },
    { v: 'C-22|NEDM Low Cost Automation',      l: 'C-22: NEDM: Low Cost Automation' },
    { v: 'C-23|OTPM MAKIGAMI',                 l: 'C-23: OTPM: MAKIGAMI' },
    { v: 'C-24|OTPM Red Tag Office',           l: 'C-24: OTPM: Red tag at Office area (5S)' },
    { v: 'C-25|SHE Near Miss/Unsafe Condition',l: 'C-25: SHE: Near miss & Unsafe condition' },
    { v: 'C-26|SHE Unsafe Act',                l: 'C-26: SHE: Unsafe act' },
    { v: 'C-27|SHE Ergonomic Hazard',          l: 'C-27: SHE: Ergonomic hazard' },
    { v: 'C-28|SHE CO2 Emission Reduction',    l: 'C-28: SHE: CO2 emission reduction' },
    { v: 'C-29|SHE Micro Level HIRA',          l: 'C-29: SHE: Micro level HIRA' },
    { v: 'C-30|5S Zone Space Saved',           l: 'C-30: 5S: Zone wise space saved' },
    { v: 'C-31|5S Best 1S-3S',                 l: 'C-31: 5S: Best 1S, 2S, 3S at Zones' },
    { v: 'C-32|All Members',                   l: 'C-32: Sure Appreciation' },
    { v: 'C-33|All Members',                   l: 'C-33: Won the Awards from CII (Platinium & Gold)' },
    { v: 'C-34|All Members',                   l: 'C-34: Won the Awards from CII (Jury Challenger)' },
  ];

  constructor(private router: Router, private http: HttpClient, private cdr: ChangeDetectorRef) {}

  ngOnInit() { this.fetchNextId(); this.loadExistingThemes(); this.initForm(); }

  /* ══════════════════════════════════
     TOASTER METHODS
  ══════════════════════════════════ */
  showToast(type: 'success' | 'error' | 'warning', title: string, message: string) {
    const id = ++this.toastCounter;
    const toast: Toast = { id, type, title, message, visible: false };
    this.toasts.push(toast);
    this.cdr.detectChanges();

    requestAnimationFrame(() => {
      toast.visible = true;
      this.cdr.detectChanges();
    });

    setTimeout(() => this.dismissToast(id), 4000);
  }

  dismissToast(id: number) {
    const toast = this.toasts.find(t => t.id === id);
    if (!toast) return;
    toast.visible = false;
    this.cdr.detectChanges();
    setTimeout(() => {
      this.toasts = this.toasts.filter(t => t.id !== id);
      this.cdr.detectChanges();
    }, 400);
  }

  initForm() {
    this.currentDepartments = [];
    this.currentStep = 1;
    this.kaizenForm = new FormGroup({
      emp_id:          new FormControl('', [Validators.required]),
      emp_name:        new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z ]+$')]),
      unit:            new FormControl('', Validators.required),
      department:      new FormControl('', Validators.required),
      zone:            new FormControl('', Validators.required),
      section:         new FormControl('', Validators.required),
      other_section:   new FormControl(''),
      theme:           new FormControl('', Validators.required),
      pqcdsm:          new FormControl('', Validators.required),
      kaizen_category: new FormControl('', Validators.required),
      start_date:      new FormControl('', Validators.required),
      end_date:        new FormControl('', Validators.required),
      before_desc:     new FormControl('', Validators.required),
      after_desc:      new FormControl('', Validators.required),
      benefits:        new FormControl('1.', Validators.required),
      team:            new FormControl('1. ', Validators.required),
    });
  }

  goToStep2() {
    const step1Fields = ['emp_id','emp_name','unit','department','zone','section','theme','pqcdsm','kaizen_category','start_date','end_date'];
    step1Fields.forEach(k => this.kaizenForm.get(k)?.markAsTouched());
    if (step1Fields.some(k => this.kaizenForm.get(k)?.invalid) || this.isDuplicate) {
      this.showToast('warning', 'Incomplete Fields', 'Please fill in all required fields before proceeding to the next step.');
      return;
    }
    this.currentStep = 2;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  onUnitChange() {
    const u = this.kaizenForm.get('unit')?.value;
    this.currentDepartments = this.plantDepartments[u] || [];
    this.kaizenForm.patchValue({ department: '', zone: '', section: '', other_section: '' });
  }
  onDepartmentChange() { this.kaizenForm.patchValue({ zone: '', section: '', other_section: '' }); }
  onSectionChange() {
    if (this.kaizenForm.get('section')?.value !== 'Other') this.kaizenForm.patchValue({ other_section: '' });
  }

  loadExistingThemes() {
    this.http.get<any[]>('http://localhost:8080/api/kaizen/my-kaizens').subscribe({
      next: (res) => { this.allThemes = res.map(k => (k.theme || '').toLowerCase().trim()).filter(t => t.length > 0); },
      error: () => { this.allThemes = []; }
    });
  }

  fetchNextId() {
    this.kaizenNo = 'Fetching...';
    this.http.get('http://localhost:8080/api/operator', { responseType: 'text' }).subscribe({
      next: (val) => {
        const count = val ? parseInt(val, 10) : 0;
        this.kaizenNo = `OP-${new Date().getFullYear()}-${(count + 1).toString().padStart(3, '0')}`;
        this.cdr.detectChanges();
      },
      error: () => { this.kaizenNo = 'KZN-Error'; this.cdr.detectChanges(); }
    });
  }

  /* ══════════════════════════════════
     SMART FILE UPLOAD
  ══════════════════════════════════ */
  async onFileChange(event: Event, field: 'before_img' | 'after_img'): Promise<void> {
    const input = event.target as HTMLInputElement;
    const file  = input.files?.[0];
    if (!file) return;

    this.fileErrors[field]    = false;
    this.compressInfo[field]  = '';
    this.selectedFiles[field] = null;
    this.compressing[field]   = false;
    this.cdr.detectChanges();

    const mime = file.type;

    try {
      if (this.SUPPORTED_IMAGES.includes(mime) || mime.startsWith('image/')) {
        await this.handleImage(file, field);
        return;
      }
      if (mime === 'video/mp4') {
        this.handleVideo(file, field, input);
        return;
      }
      if (this.SUPPORTED_DOCS.includes(mime)) {
        await this.handleDocument(file, field);
        return;
      }
      this.setError(field, input, `✗ Unsupported file type: .${file.name.split('.').pop()}`);
    } catch (err: any) {
      this.setError(field, input, `✗ ${err?.message ?? 'Upload failed. Try again.'}`);
    }
  }

  private async handleImage(file: File, field: string): Promise<void> {
    const originalKB = Math.round(file.size / 1024);
    if (file.size <= this.MAX_IMAGE_KB * 1024) {
      this.selectedFiles[field] = file;
      this.compressInfo[field]  = `✓ Image ready (${originalKB}KB)`;
      this.cdr.detectChanges();
      return;
    }
    this.compressing[field] = true;
    this.cdr.detectChanges();
    const compressed = await this.compressImage(file, this.MAX_IMAGE_KB);
    const finalKB    = Math.round(compressed.size / 1024);
    this.compressing[field]   = false;
    this.selectedFiles[field] = compressed;
    this.compressInfo[field]  = `✓ Image compressed ${originalKB}KB → ${finalKB}KB`;
    this.cdr.detectChanges();
  }

  private handleVideo(file: File, field: string, input: HTMLInputElement): void {
    const sizeMB = file.size / (1024 * 1024);
    if (sizeMB > this.MAX_VIDEO_MB) {
      this.setError(field, input, `✗ Video size exceeds limit (${sizeMB.toFixed(1)}MB). Maximum allowed size is ${this.MAX_VIDEO_MB}MB`);
      this.showToast('error', 'Video Too Large', `The selected video is ${sizeMB.toFixed(1)}MB. Maximum allowed size is ${this.MAX_VIDEO_MB}MB.`);
      return;
    }
    this.selectedFiles[field] = file;
    this.compressInfo[field]  = `✓ Video ready (${sizeMB.toFixed(1)}MB)`;
    this.cdr.detectChanges();
  }

  private async handleDocument(file: File, field: string): Promise<void> {
    this.compressing[field] = true;
    this.cdr.detectChanges();
    const originalKB = Math.round(file.size / 1024);
    const zipped     = await this.compressDocumentToZip(file);
    const zippedKB   = Math.round(zipped.size / 1024);
    this.compressing[field]   = false;
    this.selectedFiles[field] = zipped;
    this.compressInfo[field]  = `✓ Document zipped ${originalKB}KB → ${zippedKB}KB`;
    this.cdr.detectChanges();
  }

  private setError(field: string, input: HTMLInputElement, message: string): void {
    this.fileErrors[field]   = true;
    this.compressInfo[field] = message;
    this.compressing[field]  = false;
    input.value = '';
    this.cdr.detectChanges();
  }

  compressImage(file: File, maxSizeKB: number): Promise<File> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (e: ProgressEvent<FileReader>) => {
        const img = new Image();
        img.src   = e.target!.result as string;
        img.onload = () => {
          const MAX_DIM = 1400;
          let { width: w, height: h } = img;
          if (w > MAX_DIM || h > MAX_DIM) {
            if (w > h) { h = Math.round(h * MAX_DIM / w); w = MAX_DIM; }
            else        { w = Math.round(w * MAX_DIM / h); h = MAX_DIM; }
          }
          const canvas  = document.createElement('canvas');
          canvas.width  = w; canvas.height = h;
          canvas.getContext('2d')!.drawImage(img, 0, 0, w, h);
          let quality = 0.88;
          const tryCompress = (): void => {
            const dataUrl = canvas.toDataURL('image/jpeg', quality);
            const sizeKB  = Math.round((dataUrl.length * 3) / 4 / 1024);
            if (sizeKB <= maxSizeKB || quality <= 0.25) {
              const [, b64] = dataUrl.split(',');
              const binary  = atob(b64);
              const u8      = new Uint8Array(binary.length);
              for (let i = 0; i < binary.length; i++) u8[i] = binary.charCodeAt(i);
              resolve(new File([u8], file.name.replace(/\.[^.]+$/, '.jpg'), { type: 'image/jpeg' }));
            } else { quality = Math.max(0.25, quality - 0.08); tryCompress(); }
          };
          tryCompress();
        };
        img.onerror = () => reject(new Error('Image load failed'));
      };
      reader.onerror = () => reject(new Error('File read failed'));
    });
  }

  async compressDocumentToZip(file: File): Promise<File> {
    const zip    = new JSZip();
    const buffer = await file.arrayBuffer();
    zip.file(file.name, buffer, { compression: 'DEFLATE', compressionOptions: { level: 9 } });
    const blob   = await zip.generateAsync({ type: 'blob' });
    return new File([blob], file.name.replace(/\.[^.]+$/, '.zip'), { type: 'application/zip' });
  }

  hasFileError():     boolean { return Object.values(this.fileErrors).some(Boolean); }
  isAnyCompressing(): boolean { return Object.values(this.compressing).some(Boolean); }

  allowAlphabetsOnly(e: KeyboardEvent): boolean {
    const c = e.charCode;
    return (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c === 32;
  }
  allowTeamInput(e: KeyboardEvent): boolean {
    const c = e.charCode;
    return (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c === 32 || c === 46 || (c >= 48 && c <= 57);
  }

  checkDuplicateTheme() {
    const t = this.kaizenForm.get('theme')?.value?.toLowerCase().trim();
    this.isDuplicate = t && t.length > 2 ? this.allThemes.includes(t) : false;
  }

  handleTeamNumbering(e: KeyboardEvent) {
    if (e.key === 'Enter') {
      const val   = (e.target as HTMLTextAreaElement).value;
      const lines = val.split('\n');
      if (lines[lines.length - 1].trim().length > 3) {
        e.preventDefault();
        this.kaizenForm.patchValue({ team: val + '\n' + (lines.length + 1) + '. ' });
      }
    }
  }

  handleBenefitsNumbering(e: KeyboardEvent) {
    if (e.key === 'Enter') {
      const val   = (e.target as HTMLTextAreaElement).value;
      const lines = val.split('\n');
      if (lines[lines.length - 1].trim().length > 3) {
        e.preventDefault();
        this.kaizenForm.patchValue({ benefits: val + '\n' + (lines.length + 1) + '. ' });
      }
    }
  }

  onPreSubmit() {
    Object.keys(this.kaizenForm.controls).forEach(k => this.kaizenForm.get(k)?.markAsTouched());

    if (this.kaizenNo === 'KZN-Error') {
      this.showToast('error', 'System Offline', 'Unable to connect to the backend server. Please try again later.');
      return;
    }
    if (this.isDuplicate) {
      this.showToast('warning', 'Duplicate Theme', 'This theme already exists. Please use a unique theme.');
      return;
    }
    if (this.hasFileError()) {
      this.showToast('error', 'File Error', 'Some uploaded files contain errors. Please re-upload them.');
      return;
    }
    if (this.isAnyCompressing()) {
      this.showToast('warning', 'Please Wait', 'Files are still being processed. Please wait a moment.');
      return;
    }
    if (this.kaizenForm.invalid) {
      this.showToast('error', 'Form Incomplete', 'Please complete all required fields before submitting.');
      return;
    }

    this.showConfirmModal = true;
  }

    finalSubmit() {
      this.isSubmitting = true; this.showConfirmModal = false;
      const formData = new FormData();
      Object.keys(this.kaizenForm.value).forEach(k => formData.append(k, this.kaizenForm.value[k] ?? ''));
      formData.append('kaizen_id',    this.kaizenNo);
      formData.append('submitted_at', new Date().toISOString());
      formData.append('level',        'Operator');
      if (this.selectedFiles['before_img']) formData.append('before_img_file', this.selectedFiles['before_img']!);
      if (this.selectedFiles['after_img'])  formData.append('after_img_file',  this.selectedFiles['after_img']!);

      this.http.post('http://localhost:8080/api/operator/save', formData).subscribe({
        next: (res: any) => {
          if (res && res.status === 'success') {
            this.lastSubmittedNo = this.kaizenNo;
            this.showSuccessModal = true;
            this.showToast('success', 'Kaizen Registered!', `${this.kaizenNo} has been submitted successfully.`);
            this.isSubmitting = false;
            this.initForm();
            this.selectedFiles = { before_img: null, after_img: null };
            this.fileErrors    = { before_img: false, after_img: false };
            this.compressing   = { before_img: false, after_img: false };
            this.compressInfo  = { before_img: '', after_img: '' };
            document.querySelectorAll<HTMLInputElement>('input[type="file"]').forEach(i => i.value = '');
            this.fetchNextId(); this.loadExistingThemes(); this.cdr.detectChanges();
          } else {
            this.showToast('error', 'Backend Error', res?.message || 'An unknown server error occurred.');
            this.isSubmitting = false;
          }
        },
      error: (err) => {

  const msg =
    err.status === 500
      ? 'A database error occurred. Please contact the administrator.'
      : 'Submission failed. Please check your internet connection and try again.';

  this.showToast(
    'error',
    'Submission Failed',
    msg
  );

  this.isSubmitting = false;
}
    });
  }

  goBack()  { window.history.back(); }
}