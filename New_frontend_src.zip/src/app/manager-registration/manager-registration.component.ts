import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';

/* ── Toaster ── */
interface Toast {
  id:      number;
  type:    'success' | 'error' | 'warning';
  title:   string;
  message: string;
  visible: boolean;
}

@Component({
  selector: 'app-manager-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule, RouterModule],
  encapsulation: ViewEncapsulation.None,
  template: `

    <!-- ═══ TOASTER CONTAINER ═══ -->
    <div class="mf-toast-container">
      <div *ngFor="let t of toasts"
           class="mf-toast"
           [class.mf-toast--success]="t.type === 'success'"
           [class.mf-toast--error]="t.type === 'error'"
           [class.mf-toast--warning]="t.type === 'warning'"
           [class.mf-toast--visible]="t.visible"
           (click)="dismissToast(t.id)">
        <div class="mf-toast-icon">
          <svg *ngIf="t.type === 'success'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
          <svg *ngIf="t.type === 'error'"   viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          <svg *ngIf="t.type === 'warning'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
        </div>
        <div class="mf-toast-body">
          <div class="mf-toast-title">{{ t.title }}</div>
          <div class="mf-toast-msg">{{ t.message }}</div>
        </div>
        <button class="mf-toast-close" (click)="dismissToast(t.id)">✕</button>
        <div class="mf-toast-bar"></div>
      </div>
    </div>

    <!-- ═══ CONFIRM MODAL ═══ -->
    <div class="mf-overlay" *ngIf="showConfirmModal">
      <div class="mf-modal">
        <div class="mf-modal-icon orange">?</div>
        <h3 class="mf-modal-title">Confirm Registration</h3>
        <p class="mf-modal-sub">Are you sure you want to submit this Manager Kaizen?</p>
        <div class="mf-modal-preview">
          <div class="mf-preview-row"><span class="mf-preview-lbl">Kaizen ID</span><span class="mf-preview-val">{{ kaizenNo }}</span></div>
          <div class="mf-preview-row"><span class="mf-preview-lbl">Theme</span><span class="mf-preview-val">{{ kaizenForm.value.theme }}</span></div>
        </div>
        <div class="mf-modal-btns">
          <button class="mf-mbtn-cancel" (click)="showConfirmModal = false">Review</button>
          <button class="mf-mbtn-ok" (click)="finalSubmit()">Submit Now</button>
        </div>
      </div>
    </div>

    <!-- ═══ SUCCESS MODAL ═══ -->
    <div class="mf-overlay" *ngIf="showSuccessModal">
      <div class="mf-modal success">
        <div class="mf-modal-icon green">✔</div>
        <h3 class="mf-modal-title">Success!</h3>
        <p class="mf-modal-sub">Manager Kaizen <strong>{{ lastSubmittedNo }}</strong> registered successfully.</p>
        <button class="mf-mbtn-ok" (click)="showSuccessModal = false">Great!</button>
      </div>
    </div>

    <!-- ═══ ROOT ═══ -->
    <div class="mf-root">

      <!-- PAGE HEADER -->
      <div class="mf-page-header">
        <div>
          <h1 class="mf-page-title">Manager Kaizen Entry</h1>
          <p class="mf-page-sub">3-step registration form</p>
        </div>
        <div class="mf-id-chip">
          <span class="mf-id-label">ID</span>
          <span class="mf-id-val">{{ kaizenNo }}</span>
          <span class="mf-id-date">{{ today | date:'dd MMM yyyy' }}</span>
        </div>
      </div>

      <!-- STEP INDICATOR -->
      <div class="mf-stepper">
        <div class="mf-step" *ngFor="let step of steps; let i = index"
             [class.active]="currentStep === i"
             [class.done]="currentStep > i">
          <div class="mf-step-icon">
            <svg *ngIf="currentStep <= i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
              <rect x="3" y="3" width="7" height="7" rx="1.5"/>
              <rect x="14" y="3" width="7" height="7" rx="1.5"/>
              <rect x="3" y="14" width="7" height="7" rx="1.5"/>
              <rect x="14" y="14" width="7" height="7" rx="1.5"/>
            </svg>
            <svg *ngIf="currentStep > i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
              <polyline points="20 6 9 17 4 12"/>
            </svg>
          </div>
          <span class="mf-step-label">{{ step }}</span>
          <div class="mf-step-line" *ngIf="i < steps.length - 1"></div>
        </div>
      </div>

      <!-- FORM CARD -->
      <form [formGroup]="kaizenForm" (ngSubmit)="onPreSubmit()">

        <!-- ══ STEP 1: Basic & Classification ══ -->
        <div class="mf-step-panel" *ngIf="currentStep === 0">

          <!-- 01 Basic Information -->
          <div class="mf-card">
            <div class="mf-card-header">
              <div class="mf-sec-badge">01</div>
              <div>
                <h2 class="mf-card-title">Basic Information</h2>
              </div>
              <span class="mf-card-hint">Employee &amp; plant details</span>
            </div>
            <div class="mf-divider"></div>
            <div class="mf-row-3">
              <div class="mf-field">
                <label>Employee ID <span class="mf-req">*</span></label>
                <input type="text" formControlName="emp_id" (keypress)="allowNumbersOnly($event)" placeholder="Numbers only">
                <div class="mf-err" *ngIf="kaizenForm.get('emp_id')?.touched && kaizenForm.get('emp_id')?.errors?.['required']">Required</div>
                <div class="mf-err" *ngIf="kaizenForm.get('emp_id')?.touched && kaizenForm.get('emp_id')?.errors?.['pattern']">Numbers only</div>
              </div>
              <div class="mf-field">
                <label>Manager Name <span class="mf-req">*</span></label>
                <input type="text" formControlName="emp_name" (keypress)="allowAlphabetsOnly($event)" placeholder="Full name">
                <div class="mf-err" *ngIf="kaizenForm.get('emp_name')?.touched && kaizenForm.get('emp_name')?.errors?.['required']">Required</div>
              </div>
              <div class="mf-field">
                <label>Plant (Unit) <span class="mf-req">*</span></label>
                <select formControlName="unit" (change)="onPlantChange()" class="mf-plant" placeholder="Select plant">
                  <option value="">Select Plant</option>
                  <option value="Unit 1">Unit 1</option>
                  <option value="Unit 2">Unit 2</option>
                  <option value="Unit 3">Unit 3</option>
                  <option value="Unit 4">Unit 4</option>
                  <option value="Unit 5">Unit 5</option>
                </select>
              </div>
            </div>
            <div class="mf-row-3" *ngIf="kaizenForm.get('unit')?.value">
              <div class="mf-field">
                <label>Department <span class="mf-req">*</span></label>
                <select formControlName="department" (change)="onDepartmentChange()">
                  <option value="">Select Department</option>
                  <option *ngFor="let d of departmentOptions" [value]="d">{{ d }}</option>
                </select>
              </div>
              <div class="mf-field" *ngIf="kaizenForm.get('department')?.value">
                <label>Section <span class="mf-req">*</span></label>
                <select formControlName="section">
                  <option value="">Select Section</option>
                  <option *ngFor="let s of sectionOptions" [value]="s">{{ s }}</option>
                </select>
              </div>
              <div class="mf-field">
                <label>Machine Name <span class="mf-req">*</span></label>
                <input type="text" formControlName="machine_no" placeholder="Machine / workstation">
              </div>
            </div>
          </div>

          <!-- 02 Classification -->
          <div class="mf-card">
            <div class="mf-card-header">
              <div class="mf-sec-badge">02</div>
              <div>
                <h2 class="mf-card-title">Classification</h2>
              </div>
              <span class="mf-card-hint">Type, group &amp; category</span>
            </div>
            <div class="mf-divider"></div>
            <div class="mf-row-3">
              <div class="mf-field">
                <label>Kaizen Type <span class="mf-req">*</span></label>
                <select formControlName="kaizen_type" class="mf-plant">
                  <option value="">Select kaizen_type</option>
                  <option value="Innovative">Innovative</option>
                  <option value="Restorative">Restorative</option>
                  <option value="Renovative">Renovative</option>
                  <option value="Breakthrough">Breakthrough</option>
                </select>
              </div>
              <div class="mf-field">
                <label>Group (PQCDSM) <span class="mf-req">*</span></label>
                <select formControlName="pqcdsm" class="mf-plant">
                  <option value="">Select Group</option>
                  <option value="P - Productivity">P - Productivity</option>
                  <option value="Q - Quality">Q - Quality</option>
                  <option value="C - Cost">C - Cost</option>
                  <option value="D - Delivery">D - Delivery</option>
                  <option value="S - Safety">S - Safety</option>
                  <option value="M - Morale">M - Morale</option>
                </select>
              </div>
              <div class="mf-field">
                <label>Activity Pillar <span class="mf-req">*</span></label>
                <select formControlName="pillar" class="mf-plant">
                  <option value="">Select pillar</option>
                  <option *ngFor="let p of pillars" [value]="p">{{ p }}</option>
                </select>
              </div>
            </div>
            <div class="mf-row-1">
              <div class="mf-field">
                <label>Kaizen Category <span class="mf-req">*</span></label>
                <select formControlName="kaizen_category" class="mf-plant">
                  <option value="">Select Category</option>
                  <option *ngFor="let cat of categories" [value]="cat.v">{{ cat.l }}</option>
                </select>
              </div>
            </div>
            <div class="mf-row-1">
              <div class="mf-field">
                <label>Kaizen Theme <span class="mf-req">*</span></label>
                <input type="text" formControlName="theme" (input)="checkDuplicateTheme()"
                       [class.mf-input-error]="isDuplicate" placeholder="Enter a unique theme title">
                <div class="mf-err" *ngIf="isDuplicate">⚠ This theme already exists. Use a unique title.</div>
              </div>
            </div>
          </div>

        </div>

        <!-- ══ STEP 2: Analysis & Solution ══ -->
        <div class="mf-step-panel" *ngIf="currentStep === 1">

          <!-- 03 5-Why -->
          <div class="mf-card">
            <div class="mf-card-header">
              <div class="mf-sec-badge">03</div>
              <div>
                <h2 class="mf-card-title">5-Why Analysis &amp; Root Cause</h2>
              </div>
              <span class="mf-card-hint">Identify the root cause</span>
            </div>
            <div class="mf-divider"></div>
            <div class="mf-row-2">
              <div class="mf-why-panel">
                <div class="mf-field mf-mb-sm"><label>Why 1 <span class="mf-req">*</span></label><input type="text" formControlName="why1" placeholder="Why did the problem occur?"></div>
                <div class="mf-field mf-mb-sm"><label>Why 2 <span class="mf-req">*</span></label><input type="text" formControlName="why2" placeholder="Why did Why 1 happen?"></div>
                <div class="mf-field mf-mb-sm"><label>Why 3 <span class="mf-req">*</span></label><input type="text" formControlName="why3" placeholder="Why did Why 2 happen?"></div>
                <div class="mf-field mf-mb-sm"><label>Why 4 <span class="mf-opt">Optional</span></label><input type="text" formControlName="why4" placeholder="Why did Why 3 happen?"></div>
                <div class="mf-field"><label>Why 5 <span class="mf-opt">Optional</span></label><input type="text" formControlName="why5" placeholder="Root cause confirmation"></div>
              </div>
              <div class="mf-field">
                <label>Root Cause Summary <span class="mf-req">*</span></label>
                <textarea formControlName="root_cause" rows="10" placeholder="Summarize the root cause..."></textarea>
              </div>
            </div>
          </div>

          <!-- 04 Problem & Solution -->
          <div class="mf-card">
            <div class="mf-card-header">
              <div class="mf-sec-badge">04</div>
              <div>
                <h2 class="mf-card-title">Problem &amp; Solution</h2>
              </div>
              <span class="mf-card-hint">Current state &amp; improvements</span>
            </div>
            <div class="mf-divider"></div>
            <div class="mf-row-2">
              <div class="mf-field"><label>Current Problem <span class="mf-req">*</span></label><textarea formControlName="problem_status" rows="4" placeholder="Describe the current problem..."></textarea></div>
              <div class="mf-field"><label>Improvement Idea <span class="mf-req">*</span></label><textarea formControlName="idea" rows="4" placeholder="Describe the improvement idea..."></textarea></div>
            </div>
            <div class="mf-row-1">
              <div class="mf-field"><label>Countermeasure (Action Taken) <span class="mf-req">*</span></label><textarea formControlName="countermeasure" rows="3" placeholder="Describe the countermeasure..."></textarea></div>
            </div>
            <div class="mf-row-3">
              <div class="mf-field"><label>Benchmark</label><input type="text" formControlName="benchmark"></div>
              <div class="mf-field"><label>Target</label><input type="text" formControlName="target"></div>
              <div class="mf-field"><label>Analysis Summary</label><textarea formControlName="analysis" rows="2"></textarea></div>
            </div>
          </div>

        </div>

        <!-- ══ STEP 3: Results & Deployment ══ -->
        <div class="mf-step-panel" *ngIf="currentStep === 2">

          <!-- 05 Timeline -->
          <div class="mf-card">
            <div class="mf-card-header">
              <div class="mf-sec-badge">05</div>
              <div>
                <h2 class="mf-card-title">Timeline &amp; Results</h2>
              </div>
              <span class="mf-card-hint">Dates &amp; final outcome</span>
            </div>
            <div class="mf-divider"></div>
            <div class="mf-row-3">
              <div class="mf-field"><label>Start Date <span class="mf-req">*</span></label><input type="date" formControlName="start_date"></div>
              <div class="mf-field"><label>End Date <span class="mf-req">*</span></label><input type="date" formControlName="end_date"></div>
              <div class="mf-field"><label>Final Result Value <span class="mf-req">*</span></label><input type="text" formControlName="final_result" placeholder="e.g. 12% reduction"></div>
            </div>
          </div>

          <!-- 06 Before/After -->
          <div class="mf-card">
            <div class="mf-card-header">
              <div class="mf-sec-badge">06</div>
              <div>
                <h2 class="mf-card-title">Before &amp; After Evidence</h2>
              </div>
              <span class="mf-card-hint">Photo &amp; description</span>
            </div>
            <div class="mf-divider"></div>
            <div class="mf-row-2">
              <div class="mf-ev-card mf-before">
                <div class="mf-ev-badge mf-before-badge">Before Improvement</div>
                <input type="file" (change)="onFileChange($event, 'before_img')" accept="image/*,application/pdf,video/mp4,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/plain">
                <p class="mf-hint">Any size — auto-compressed to under 500KB</p>
                <div class="mf-err" *ngIf="compressing['before_img']">⏳ Compressing...</div>
                <div class="mf-ok" *ngIf="compressInfo['before_img']">{{ compressInfo['before_img'] }}</div>
                <label>Before Description <span class="of-req">*</span></label>
                <textarea formControlName="before_desc" rows="4" placeholder="Describe the current problem..."></textarea>
              </div>
              <div class="mf-ev-card mf-after">
                <div class="mf-ev-badge mf-after-badge">After Improvement</div>
                <input type="file" (change)="onFileChange($event, 'after_img')" accept="image/*,application/pdf,video/mp4,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/plain">
                <p class="mf-hint">Any size — auto-compressed to under 500KB</p>
                <div class="mf-err" *ngIf="compressing['after_img']">⏳ Compressing...</div>
                <div class="mf-ok" *ngIf="compressInfo['after_img']">{{ compressInfo['after_img'] }}</div>
                <label>After Description <span class="of-req">*</span></label>
                <textarea formControlName="after_desc" rows="4" placeholder="Describe the improvement made..."></textarea>
              </div>
            </div>
          </div>

          <!-- 07 Horizontal Deployment -->
          <div class="mf-card">
            <div class="mf-card-header">
              <div class="mf-sec-badge">07</div>
              <div>
                <h2 class="mf-card-title">Horizontal Deployment</h2>
              </div>
              <button type="button" class="mf-add-btn" (click)="addRow()">+ Add Machine</button>
            </div>
            <div class="mf-divider"></div>
            <div class="mf-table-wrap">
              <table class="mf-table" formArrayName="deployments">
                <thead><tr><th>Sr.</th><th>Area / Machine</th><th>Responsible</th><th>Target Date</th><th>Status</th><th></th></tr></thead>
                <tbody>
                  <tr *ngFor="let row of deploymentRows.controls; let i=index" [formGroupName]="i">
                    <td class="mf-sr">{{ i+1 }}</td>
                    <td><input type="text" formControlName="area"></td>
                    <td><input type="text" formControlName="resp" (keypress)="allowAlphabetsOnly($event)"></td>
                    <td><input type="date" formControlName="target"></td>
                    <td><select formControlName="status"><option value="Pending">Pending</option><option value="Done">Done</option></select></td>
                    <td><button type="button" (click)="removeRow(i)" *ngIf="deploymentRows.length > 1" class="mf-del-btn">✕</button></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <!-- 08 Benefits & Team -->
          <div class="mf-card">
            <div class="mf-card-header">
              <div class="mf-sec-badge">08</div>
              <div>
                <h2 class="mf-card-title">Benefits &amp; Team</h2>
              </div>
              <span class="mf-card-hint">Gains &amp; contributors</span>
            </div>
            <div class="mf-divider"></div>
            <div class="mf-row-2">
              <div class="mf-field"><label>Benefits (PQCDSM) <span class="mf-req">*</span></label><textarea
  formControlName="benefits_pqcdsm"
  rows="5"
  (keydown)="handleBenefitsNumbering($event)"
  placeholder="1. Time saved">
</textarea></div>
              <div class="mf-field">
                <label>Team Members <span class="mf-req">*</span></label>
                <textarea formControlName="team_members" rows="5"
                          (keypress)="allowTeamInput($event)"
                          (keydown)="handleTeamNumbering($event)"
                          placeholder="1. Member Name"></textarea>
                <p class="mf-hint">Alphabets and spaces only</p>
              </div>
            </div>
          </div>

        </div>

        <!-- ══ BOTTOM NAV ══ -->
        <div class="mf-bottom-nav">
          <span class="mf-step-counter">Step {{ currentStep + 1 }} of {{ steps.length }}</span>
          <div class="mf-nav-btns">
            <button type="button" class="mf-btn-prev" *ngIf="currentStep > 0" (click)="prevStep()">
              ← Previous
            </button>
            <button type="button" class="mf-btn-next"
                    *ngIf="currentStep < steps.length - 1"
                    [disabled]="!isCurrentStepValid()"
                    [title]="!isCurrentStepValid() ? 'Fill all required fields to continue' : ''"
                    (click)="nextStep()">
              Next Step →
            </button>
            <button type="submit" class="mf-btn-next mf-btn-submit"
                    *ngIf="currentStep === steps.length - 1"
                    [disabled]="kaizenForm.invalid || isDuplicate || isAnyCompressing()">
              <span *ngIf="isAnyCompressing()">⏳ Compressing...</span>
              <span *ngIf="!isAnyCompressing()">Submit Kaizen →</span>
            </button>
          </div>
        </div>

      </form>
    </div>
  `,
  styles: [`
    /* ══════════════════════════════════
       TOASTER
    ══════════════════════════════════ */
    .mf-toast-container {
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 99999;
      display: flex;
      flex-direction: column;
      gap: 10px;
      pointer-events: none;
    }
    .mf-toast {
      pointer-events: all;
      display: flex;
      align-items: flex-start;
      gap: 12px;
      width: 340px;
      max-width: calc(100vw - 40px);
      background: #1e1e2e;
      border: 1px solid #2e2e45;
      border-radius: 16px;
      padding: 14px 16px 18px;
      box-shadow: 0 20px 60px rgba(0,0,0,.5), 0 4px 16px rgba(0,0,0,.3);
      cursor: pointer;
      position: relative;
      overflow: hidden;
      opacity: 0;
      transform: translateX(120%) scale(0.9);
      transition: opacity .35s cubic-bezier(.22,1,.36,1),
                  transform .35s cubic-bezier(.22,1,.36,1);
    }
    .mf-toast--visible {
      opacity: 1;
      transform: translateX(0) scale(1);
    }
    .mf-toast--success { border-left: 4px solid #22c55e; }
    .mf-toast--error   { border-left: 4px solid #ef4444; }
    .mf-toast--warning { border-left: 4px solid #f97316; }

    .mf-toast-icon {
      width: 36px; height: 36px; border-radius: 10px;
      display: flex; align-items: center; justify-content: center;
      flex-shrink: 0;
    }
    .mf-toast-icon svg { width: 18px; height: 18px; }
    .mf-toast--success .mf-toast-icon { background: rgba(34,197,94,.15); color: #22c55e; }
    .mf-toast--error   .mf-toast-icon { background: rgba(239,68,68,.15);  color: #ef4444; }
    .mf-toast--warning .mf-toast-icon { background: rgba(249,115,22,.15); color: #f97316; }

    .mf-toast-body { flex: 1; min-width: 0; }
    .mf-toast-title {
      font-size: 13px; font-weight: 700; color: #f1f5f9;
      letter-spacing: .01em; margin-bottom: 3px;
    }
    .mf-toast-msg {
      font-size: 12px; color: #94a3b8; line-height: 1.5;
      word-break: break-word;
    }
    .mf-toast-close {
      background: none; border: none; color: #475569;
      font-size: 12px; cursor: pointer; padding: 2px 4px;
      border-radius: 4px; flex-shrink: 0; line-height: 1;
      transition: color .15s;
      font-family: inherit;
    }
    .mf-toast-close:hover { color: #94a3b8; }

    /* Progress bar */
    .mf-toast-bar {
      position: absolute;
      bottom: 0; left: 0;
      height: 3px;
      border-radius: 0 0 0 16px;
      animation: mf-bar 4s linear forwards;
    }
    .mf-toast--success .mf-toast-bar { background: #22c55e; }
    .mf-toast--error   .mf-toast-bar { background: #ef4444; }
    .mf-toast--warning .mf-toast-bar { background: #f97316; }
    @keyframes mf-bar {
      from { width: 100%; }
      to   { width: 0%; }
    }

    /* ══════════════════════════════════
       MODAL
    ══════════════════════════════════ */
    .mf-overlay {
      position: fixed; inset: 0;
      background: rgba(0, 0, 0, 0.7); backdrop-filter: blur(10px);
      display: flex; align-items: center; justify-content: center;
      z-index: 9999;
    }
    .mf-modal {
      width: 360px; max-width: 92vw;
      background: #1e1e2e; border: 1px solid #2e2e42;
      border-radius: 20px; padding: 26px;
      box-shadow: 0 40px 90px rgba(0,0,0,.5);
      animation: mf-popup .28s ease;
    }
    .mf-modal.success { border-top: 4px solid #22c55e; }
    @keyframes mf-popup {
      from { opacity: 0; transform: translateY(16px) scale(.96); }
      to   { opacity: 1; transform: translateY(0) scale(1); }
    }
    .mf-modal-icon {
      width: 64px; height: 64px; border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      margin: 0 auto 18px; color: #fff;
      font-size: 26px; font-weight: 900;
    }
    .orange { background: linear-gradient(135deg,#f97316,#ea580c); }
    .green  { background: linear-gradient(135deg,#22c55e,#16a34a); }
    .mf-modal-title { text-align: center; font-size: 20px; font-weight: 800; color: #f1f5f9; margin-bottom: 8px; }
    .mf-modal-sub   { text-align: center; color: #94a3b8; font-size: 14px; margin-bottom: 22px; line-height: 1.6; }
    .mf-modal-preview {
      background: #252537; border: 1px solid #2e2e45;
      border-radius: 14px; padding: 16px; margin-bottom: 20px;
    }
    .mf-preview-row { display: flex; justify-content: space-between; padding: 6px 0; }
    .mf-preview-lbl { color: #64748b; font-weight: 600; font-size: 13px; }
    .mf-preview-val { color: #f1f5f9; font-weight: 800; font-size: 13px; }
    .mf-modal-btns  { display: flex; gap: 10px; }
    .mf-mbtn-cancel, .mf-mbtn-ok {
      flex: 1; height: 46px; border-radius: 12px;
      font-weight: 700; cursor: pointer; font-size: 14px;
      font-family: inherit; transition: all .2s;
    }
    .mf-mbtn-cancel { background: transparent; border: 1px solid #3e3e55; color: #94a3b8; }
    .mf-mbtn-cancel:hover { border-color: #ef4444; color: #ef4444; }
    .mf-mbtn-ok { border: none; background: linear-gradient(135deg,#6366f1,#4f46e5); color: #fff; }
    .mf-mbtn-ok:hover { background: linear-gradient(135deg,#818cf8,#6366f1); }

    /* ══════════════════════════════════
       ROOT
    ══════════════════════════════════ */
    .mf-root {
      font-family: 'DM Sans', 'Plus Jakarta Sans', sans-serif;
      background: #F1F5F9;
      min-height: 100vh;
      padding: 32px 28px 60px;
      color: #000000;
    }

    /* ══════════════════════════════════
       PAGE HEADER
    ══════════════════════════════════ */
    .mf-page-header {
      display: flex; align-items: flex-start;
      justify-content: space-between; margin-bottom: 28px;
    }
    .mf-page-title {
      font-size: 30px; font-weight: 800; color: #000000;
      letter-spacing: -.02em;
    }
    .mf-page-sub { margin-top: 4px; color: #000000; font-size: 14px; font-weight: 500; opacity: .6; }
    .mf-id-chip {
      background: rgba(252, 122, 47, 0.89); border: 1px solid #f38748;
      border-radius: 999px; padding: 10px 20px;
      display: flex; align-items: center; gap: 12px;
    }
    .mf-id-label {
      font-size: 10px; text-transform: uppercase;
      letter-spacing: .12em; font-weight: 800; color: #000000;
    }
    .mf-id-val   { font-size: 14px; font-weight: 800; color: #ffffff; }
    .mf-id-date  {
      font-size: 13px; font-weight: 600; color: #ffffff;
      border-left: 1px solid #2e2e45; padding-left: 12px;
    }

    /* ══════════════════════════════════
       STEPPER
    ══════════════════════════════════ */
    .mf-stepper {
      display: flex; align-items: center;
      gap: 0; margin-bottom: 28px;
    }
    .mf-step {
      display: flex; align-items: center; gap: 12px;
      flex: 1;
    }
    .mf-step-icon {
      width: 44px; height: 44px; border-radius: 12px; flex-shrink: 0;
      background: rgba(252, 122, 47, 0.89); border: 1px solid #f38748;
      display: flex; align-items: center; justify-content: center;
      color: #d5d8dd; transition: all .3s;
    }
    .mf-step-icon svg { width: 20px; height: 20px; }
    .mf-step.active .mf-step-icon {
      background: #6366f1; border-color: #6366f1;
      color: #fff; box-shadow: 0 8px 24px rgba(99,102,241,.35);
    }
    .mf-step.done .mf-step-icon {
      background: #22c55e; border-color: #22c55e; color: #e7e7e7;
    }
    .mf-step-label {
      font-size: 13px; font-weight: 600;
      color: #000000; transition: color .3s; white-space: nowrap;
    }
    .mf-step.active .mf-step-label { color: #818cf8; font-weight: 700; }
    .mf-step.done .mf-step-label  { color: #22c55e; }
    .mf-step-line {
      flex: 1; height: 1px;
      background: #2e2e45;
      margin: 0 12px;
    }

    /* ══════════════════════════════════
       CARD
    ══════════════════════════════════ */
    .mf-card {
      background: #f3ecea; border: 1px solid #ff3b0a;
      border-radius: 20px; padding: 24px;
      margin-bottom: 20px;
    }
    .mf-card-header {
      display: flex; align-items: center; gap: 14px;
    }
    .mf-sec-badge {
      width: 36px; height: 36px; border-radius: 10px; flex-shrink: 0;
      background: rgba(252, 122, 47, 0.89); border: 1px solid #f38748;
      display: flex; align-items: center; justify-content: center;
      font-size: 11px; font-weight: 800; color: #e6d7d7;
      letter-spacing: .04em;
    }
    .mf-card-title {
      font-size: 16px; font-weight: 700; color: #ff6003;
      letter-spacing: -.01em; margin: 0;
    }
    .mf-card-hint {
      margin-left: auto; font-size: 12px;
      color: #505b6b; font-weight: 500;
    }
    .mf-divider {
      height: 1px; background: #1a1a1b;
      margin: 18px 0;
    }
    .mf-plant { color: black; font-size: 12px; }

    /* ══════════════════════════════════
       GRID
    ══════════════════════════════════ */
    .mf-row-1, .mf-row-2, .mf-row-3 { margin-bottom: 18px; }
    .mf-row-1 { display: grid; grid-template-columns: 1fr; gap: 18px; }
    .mf-row-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; }
    .mf-row-3 { display: grid; grid-template-columns: repeat(3,1fr); gap: 18px; }

    /* ══════════════════════════════════
       FIELDS
    ══════════════════════════════════ */
    .mf-field { display: flex; flex-direction: column; gap: 8px; }
    .mf-field label {
      font-size: 12px; font-weight: 600; color: #000000;
      letter-spacing: .02em;
    }
    .mf-req  { color: #f87171; margin-left: 2px; }
    .mf-opt  { color: #475569; font-size: 10px; font-weight: 400; }
    .mf-err  { color: #f87171; font-size: 11px; font-weight: 600; }
    .mf-ok   { color: #22c55e; font-size: 11px; font-weight: 600; }
    .mf-hint { color: #475569; font-size: 11px; font-weight: 500; margin: 0; }
    .mf-mb-sm { margin-bottom: 14px; }

    input[type="text"], input[type="date"], select, textarea {
      width: 100%; border: 1.5px solid #cac6c4bd;
      background: #F1F5F9;
      border-radius: 10px; padding: 12px 14px;
      font-size: 14px; font-weight: 500; color: #000000;
      font-family: inherit; transition: border-color .18s, box-shadow .18s;
      resize: vertical; box-sizing: border-box;
    }
    input::placeholder, textarea::placeholder { color: #01020c; font-size: 13px; }
    select option { background: #F1F5F9; color: #010508; }
    input:focus, select:focus, textarea:focus {
      outline: none; border-color: #a3a3a8;
      box-shadow: 0 0 0 3px rgba(206, 100, 59, 0.15);
    }
    .mf-input-error { border-color: #ef4444 !important; }

    /* ══════════════════════════════════
       WHY PANEL
    ══════════════════════════════════ */
    .mf-why-panel {
      background: #F1F5F9; border: 1px solid #2a2a3e;
      border-radius: 14px; padding: 18px;
    }

    /* ══════════════════════════════════ 
       EVIDENCE CARDS
    ══════════════════════════════════ */
    .mf-ev-card {
      padding: 20px; border-radius: 14px;
      display: flex; flex-direction: column; gap: 10px;
    }
    .mf-ev-card label {
      display: block;
      font-size: 0.8rem;
      font-weight: 600;
      color: var(--text-secondary, #64748b);
      margin-top: 10px;
      margin-bottom: 4px;
    }
    .mf-before { background: #f3ecea; border: 1px solid #cac6c4bd; }
    .mf-after  { background: #f3ecea; border: 1px solid #cac6c4bd; }
    .mf-ev-badge {
      width: max-content; padding: 5px 14px; border-radius: 999px;
      font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .06em;
    }
    .mf-before-badge { background: #3f1515; color: #fca5a5; }
    .mf-after-badge  { background: #143f1e; color: #86efac; }

    /* ══════════════════════════════════
       TABLE
    ══════════════════════════════════ */
    .mf-table-wrap {
      overflow: auto; border-radius: 14px;
      border: 1px solid #cac6c4bd; background: #f3ecea;
    }
    .mf-table { width: 100%; border-collapse: collapse; }
    .mf-table th {
      background: #f3ecea; padding: 13px 14px;
      font-size: 11px; text-transform: uppercase; letter-spacing: .05em;
      color: #000000; font-weight: 700; border-bottom: 1px solid #cac6c4bd;
      text-align: left;
    }
    .mf-table td { padding: 10px 14px; border-bottom: 1px solid #1e1e2e; }
    .mf-table tr:last-child td { border-bottom: none; }
    .mf-table td input, .mf-table td select { padding: 9px 12px; border-radius: 8px; font-size: 13px; }
    .mf-sr { font-weight: 700; color: #475569; text-align: center; }
    .mf-del-btn {
      width: 30px; height: 30px; border: none; border-radius: 8px;
      background: #3f1515; color: #f87171; cursor: pointer; font-weight: 700;
      transition: background .18s;
    }
    .mf-del-btn:hover { background: #5c1f1f; }

    /* ══════════════════════════════════
       ADD BUTTON
    ══════════════════════════════════ */
    .mf-add-btn {
      height: 36px; padding: 0 16px; border: none; border-radius: 10px;
      background: rgba(252, 122, 47, 0.89); border: 1px solid #f38748;
      color: #ffffff; font-weight: 700; cursor: pointer;
      font-family: inherit; font-size: 13px; transition: all .18s;
    }
    .mf-add-btn:hover { background: rgba(99,102,241,.25); }

    /* ══════════════════════════════════
       BOTTOM NAV
    ══════════════════════════════════ */
    .mf-bottom-nav {
      display: flex; align-items: center;
      justify-content: space-between;
      background: rgba(252, 122, 47, 0.89); border: 1px solid #f38748;
      border-radius: 16px; padding: 16px 24px;
      margin-top: 8px;
    }
    .mf-step-counter {
      font-size: 13px; font-weight: 600; color: #171b20;
    }
    .mf-nav-btns { display: flex; gap: 10px; }
    .mf-btn-prev {
      height: 44px; padding: 0 24px; border: 1px solid #dfdfdf;
      border-radius: 12px; background: rgba(252, 122, 47, 0.89);
      color: #ffffff; font-size: 14px; font-weight: 600;
      cursor: pointer; font-family: inherit; transition: all .2s;
    }
    .mf-btn-prev:hover { transform: translateY(-1px); border-color: #dfdfdf; color: #ffffff; }
    .mf-btn-next {
      height: 44px; padding: 0 28px; border: 1px solid #dfdfdf;
      border-radius: 12px;
      background: rgba(252, 122, 47, 0.89);
      color: #ffffff; font-size: 14px; font-weight: 700;
      cursor: pointer; font-family: inherit; transition: all .22s;
      box-shadow: 0 8px 24px rgba(99,102,241,.3);
    }
    .mf-btn-next:hover { transform: translateY(-1px); box-shadow: 0 12px 28px rgba(255, 98, 7, 0.89); }
    .mf-btn-next:disabled {
      background: rgba(252, 122, 47, 0.89); color: #ffffff; cursor: not-allowed;
      box-shadow: none; transform: none;
    }

    /* ══════════════════════════════════
       RESPONSIVE
    ══════════════════════════════════ */
    @media (max-width: 900px) {
      .mf-row-2, .mf-row-3 { grid-template-columns: 1fr; }
      .mf-root { padding: 16px 14px 60px; }
      .mf-stepper { gap: 6px; }
      .mf-step-label { display: none; }
      .mf-step.active .mf-step-label { display: block; }
      .mf-page-title { font-size: 22px; }
      .mf-toast-container { top: 12px; right: 12px; }
      .mf-toast { width: 300px; }
    }
  `]
})
export class ManagerRegistrationComponent implements OnInit {

  public steps = ['Basic & Classification', 'Analysis & Solution', 'Results & Deployment'];
  public currentStep = 0;

  public kaizenNo        = '';
  public today           = new Date();
  public kaizenForm!: FormGroup;
  public showConfirmModal  = false;
  public showSuccessModal  = false;
  public lastSubmittedNo   = '';
  public isDuplicate       = false;

  public compressing:  { [key: string]: boolean } = { before_img: false, after_img: false };
  public compressInfo: { [key: string]: string  } = { before_img: '', after_img: '' };
  public fileErrors:   { [key: string]: boolean } = { before_img: false, after_img: false };
  private files:       { [key: string]: File | null } = { before_img: null, after_img: null };
  private allThemes:   string[] = [];

  public departmentOptions: string[] = [];
  public sectionOptions:    string[] = [];

  /* ── Toaster state ── */
  public toasts: Toast[] = [];
  private toastCounter = 0;

  private readonly plantDeptMap: { [plant: string]: string[] } = {
    'Unit 1': ['Production','Maintenance','Quality','Stores','HR & Admin'],
    'Unit 2': ['Production','Maintenance','Quality','Stores','HR & Admin'],
    'Unit 3': ['Production','Maintenance','Quality','Stores','HR & Admin'],
    'Unit 4': ['Production','Maintenance','Quality','Stores','HR & Admin'],
    'Unit 5': ['Production','Maintenance','Quality','Stores','HR & Admin'],
  };
  private readonly deptSectionMap: { [dept: string]: string[] } = {
    'Production':  ['Assembly','Welding','Machining','Painting','Packing'],
    'Maintenance': ['Electrical','Mechanical','Civil','Utilities'],
    'Quality':     ['Incoming','In-Process','Final Inspection','Lab'],
    'Stores':      ['Raw Material','Finished Goods','Spare Parts'],
    'HR & Admin':  ['Recruitment','Training','Payroll','Administration'],
  };

  public pillars = ['KK','JH','PM','QM','NEDM','NPDM','DM','E&T','SHE','LM'];
  public categories = [
    { v: 'C-1|Restorative (TPM)',              l: 'C-1: Restorative (Using TPM Methodology)' },
    { v: 'C-2|Renovative (TPM)',               l: 'C-2: Renovative (Using TPM Methodology)' },
    { v: 'C-3|Innovative (TPM)',               l: 'C-3: Innovative (Using TPM Methodology)' },
    { v: 'C-4|Breakthrough (TPM)',             l: 'C-4: Breakthrough (Using TPM Methodology)' },
    { v: 'C-5|Poka Yoke (TPM)',                l: 'C-5: Poka Yoke (Using TPM Methodology)' },
    { v: 'C-6|KARAKURI & YUTORI',              l: 'C-6: KARAKURI (No Energy Loss) & YUTORI' },
    { v: 'C-7|JH Shop Floor Visualization',    l: 'C-7: JH - Shop Floor Visualization' },
    { v: 'C-8|KK OEE Compliance',              l: 'C-8: KK OEE Compliance' },
    { v: 'C-9|KK Bottleneck Process Solution', l: 'C-9: KK Bottleneck Process Solution' },
    { v: 'C-10|JH Circle Board Updating',      l: 'C-10: JH - Circle Board updating' },
    { v: 'C-11|JH One Point Lessons',          l: 'C-11: JH - One Point Lessons' },
    { v: 'C-12|JH White Tag Abnormality',      l: 'C-12: JH: White tag abnormality' },
    { v: 'C-13|JH (HTA / SOC / Ease for CLITA)', l: 'C-13: JH (HTA / SOC / Ease for CLITA)' },
    { v: 'C-14|JH Step 4 M-M Combination',    l: 'C-14: JH step 4 Man-Machine combination' },
    { v: 'C-15|JH Step 5 M-M Combination',    l: 'C-15: JH step 5 Man-Machine combination' },
    { v: 'C-16|JH Step 1, 2, 3 Repeat',       l: 'C-16: JH: Repeat of JH Step 1, 2, 3' },
    { v: 'C-17|JH Minor Stoppage Monitoring',  l: 'C-17: JH: Minor Stoppage Monitoring' },
    { v: 'C-18|JH RED Tag Abnormality',        l: 'C-18: JH: RED tag abnormality' },
    { v: 'C-19|QM Assembly Pokamapping',       l: 'C-19: QM: Product Assembly Pokamapping' },
    { v: 'C-20|PM MP Sheets Generation',       l: 'C-20: PM: Generation of MP sheets' },
    { v: 'C-21|NEDM MP Sheets Implementation', l: 'C-21: NEDM: Implementation of MP sheets' },
    { v: 'C-22|NEDM Low Cost Automation',      l: 'C-22: NEDM: Low Cost Automation' },
    { v: 'C-23|OTPM MAKIGAMI',                 l: 'C-23: OTPM: MAKIGAMI' },
    { v: 'C-24|OTPM Red Tag Office',           l: 'C-24: OTPM: Red tag at Office area (5S)' },
    { v: 'C-25|SHE Near Miss/Unsafe Condition',l: 'C-25: SHE: Near miss & Unsafe condition' },
    { v: 'C-26|SHE Unsafe Act',                l: 'C-26: SHE: Unsafe act' },
    { v: 'C-27|SHE Ergonomic Hazard',          l: 'C-27: SHE: Ergonomic hazard' },
    { v: 'C-28|SHE CO2 Emission Reduction',    l: 'C-28: SHE: CO2 emission reduction' },
    { v: 'C-29|SHE Micro Level HIRA',          l: 'C-29: SHE: Micro level HIRA' },
    { v: 'C-30|5S Zone Space Saved',           l: 'C-30: 5S: Zone wise space saved' },
    { v: 'C-31|5S Best 1S-3S',                 l: 'C-31: 5S: Best 1S, 2S, 3S at Zones' },
    { v: 'C-32|All Members',                   l: 'C-32: Sure Appreciation' },
    { v: 'C-33|All Members',                   l: 'C-33: Won the Awards from CII (Platinium & Gold)' },
    { v: 'C-34|All Members',                   l: 'C-34: Won the Awards from CII (Jury Challenger)' },
  ];

  constructor(
    private router: Router,
    private http: HttpClient,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.generateKaizenNo();
    this.loadExistingThemes();
    this.kaizenForm = new FormGroup({
      emp_id:          new FormControl('', [Validators.required, Validators.pattern('^[0-9]+$')]),
      emp_name:        new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z ]+$')]),
      unit:            new FormControl('', Validators.required),
      department:      new FormControl('', Validators.required),
      section:         new FormControl('', Validators.required),
      machine_no:      new FormControl('', Validators.required),
      kaizen_type:     new FormControl('', Validators.required),
      pqcdsm:          new FormControl('', Validators.required),
      kaizen_category: new FormControl('', Validators.required),
      theme:           new FormControl('', Validators.required),
      problem_status:  new FormControl('', Validators.required),
      idea:            new FormControl('', Validators.required),
      countermeasure:  new FormControl('', Validators.required),
      pillar:          new FormControl('', Validators.required),
      why1:            new FormControl('', Validators.required),
      why2:            new FormControl('', Validators.required),
      why3:            new FormControl('', Validators.required),
      why4:            new FormControl(''),
      why5:            new FormControl(''),
      root_cause:      new FormControl('', Validators.required),
      analysis:        new FormControl(''),
      benchmark:       new FormControl(''),
      target:          new FormControl(''),
      start_date:      new FormControl('', Validators.required),
      end_date:        new FormControl('', Validators.required),
      final_result:    new FormControl('', Validators.required),
      before_desc:     new FormControl('', Validators.required),
      after_desc:      new FormControl('', Validators.required),
      benefits_pqcdsm: new FormControl('1.', Validators.required),
      team_members:    new FormControl('1. ', Validators.required),
      deployments:     new FormArray([this.createRow()])
    });
  }

  /* ══════════════════════════════════
     TOASTER METHODS
  ══════════════════════════════════ */
  showToast(type: 'success' | 'error' | 'warning', title: string, message: string) {
    const id = ++this.toastCounter;
    const toast: Toast = { id, type, title, message, visible: false };
    this.toasts.push(toast);
    this.cdr.detectChanges();

    // Trigger enter animation on next frame
    requestAnimationFrame(() => {
      toast.visible = true;
      this.cdr.detectChanges();
    });

    // Auto-dismiss after 4s
    setTimeout(() => this.dismissToast(id), 4000);
  }

  dismissToast(id: number) {
    const toast = this.toasts.find(t => t.id === id);
    if (!toast) return;
    toast.visible = false;
    this.cdr.detectChanges();
    // Remove from DOM after exit animation
    setTimeout(() => {
      this.toasts = this.toasts.filter(t => t.id !== id);
      this.cdr.detectChanges();
    }, 400);
  }

  /* ── Step field map for validation ── */
  private readonly stepRequiredFields: string[][] = [
    ['emp_id','emp_name','unit','department','section','machine_no','pqcdsm','kaizen_category','theme'],
    ['why1','why2','why3','root_cause','problem_status','idea','countermeasure'],
    ['start_date','end_date','final_result','before_desc','after_desc','benefits_pqcdsm','team_members'],
  ];

  isCurrentStepValid(): boolean {
    const fields = this.stepRequiredFields[this.currentStep] || [];
    const allValid = fields.every(f => {
      const ctrl = this.kaizenForm.get(f);
      return ctrl && ctrl.valid && (ctrl.value !== '' && ctrl.value !== null);
    });
    if (this.currentStep === 0 && this.isDuplicate) return false;
    return allValid;
  }

  /* ── Step navigation ── */
  nextStep() {
    if (!this.isCurrentStepValid()) {
      const fields = this.stepRequiredFields[this.currentStep] || [];
      fields.forEach(f => this.kaizenForm.get(f)?.markAsTouched());
      this.showToast('warning', 'Incomplete Fields', 'Please fill all required fields before proceeding.');
      return;
    }
    if (this.currentStep < this.steps.length - 1) this.currentStep++;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  prevStep() {
    if (this.currentStep > 0) this.currentStep--;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  /* ── Plant / Dept cascades ── */
  onPlantChange() {
    const plant = this.kaizenForm.get('unit')?.value;
    this.departmentOptions = plant ? (this.plantDeptMap[plant] || []) : [];
    this.sectionOptions = [];
    this.kaizenForm.patchValue({ department: '', section: '' });
  }
  onDepartmentChange() {
    const dept = this.kaizenForm.get('department')?.value;
    this.sectionOptions = dept ? (this.deptSectionMap[dept] || []) : [];
    this.kaizenForm.patchValue({ section: '' });
  }

  generateKaizenNo() {
    const currentYear = new Date().getFullYear();
    this.http.get<any>('http://localhost:8080/api/manager?action=count').subscribe(res => {
      const nextId = (res.count + 1).toString().padStart(3, '0');
      this.kaizenNo = `MG-${currentYear}-${nextId}`;
    });
  }

  loadExistingThemes() {
    this.http.get<any[]>('http://localhost:8080/api/kaizen/my-kaizens').subscribe({
      next: (res) => { this.allThemes = res.map(k => (k.theme || '').toLowerCase().trim()); },
      error: () => { this.allThemes = []; }
    });
  }

  /* ── Deployment table ── */
  createRow() {
    return new FormGroup({
      area:   new FormControl(''),
      resp:   new FormControl(''),
      target: new FormControl(''),
      status: new FormControl('Pending')
    });
  }
  get deploymentRows() { return this.kaizenForm.get('deployments') as FormArray; }
  addRow()              { this.deploymentRows.push(this.createRow()); }
  removeRow(i: number)  { this.deploymentRows.removeAt(i); }

  /* ── Input guards ── */
  allowNumbersOnly(e: KeyboardEvent): boolean   { return e.charCode >= 48 && e.charCode <= 57; }
  allowAlphabetsOnly(e: KeyboardEvent): boolean {
    const c = e.charCode;
    return (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c === 32;
  }
  allowTeamInput(e: KeyboardEvent): boolean {
    const c = e.charCode;
    return (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c === 32 || c === 46 || (c >= 48 && c <= 57);
  }

  checkDuplicateTheme() {
    const theme = this.kaizenForm.get('theme')?.value?.toLowerCase().trim();
    this.isDuplicate = theme && theme.length > 2 ? this.allThemes.includes(theme) : false;
  }

  /* ── File / image handling ── */
  onFileChange(event: any, field: string) {
    const file = event.target.files[0];
    if (!file) return;
    if (file.size <= 512000) {
      this.fileErrors[field] = false;
      this.compressInfo[field] = `✓ ${Math.round(file.size/1024)}KB — ready`;
      this.files[field] = file;
      this.cdr.detectChanges(); return;
    }
    this.compressing[field] = true; this.cdr.detectChanges();
    this.compressImage(file, 500).then(compressed => {
      this.compressing[field] = false; this.fileErrors[field] = false;
      this.files[field] = compressed;
      this.compressInfo[field] = `✓ Compressed: ${Math.round(file.size/1024)}KB → ${Math.round(compressed.size/1024)}KB`;
      this.cdr.detectChanges();
    }).catch(() => {
      this.compressing[field] = false;
      this.fileErrors[field] = true;
      this.showToast('error', 'Compression Failed', 'Image compress karne mein error aaya. Dobara try karein.');
      this.cdr.detectChanges();
    });
  }

  compressImage(file: File, maxSizeKB: number): Promise<File> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (e: any) => {
        const img = new Image(); img.src = e.target.result;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let w = img.width, h = img.height; const MAX = 1200;
          if (w > MAX || h > MAX) {
            if (w > h) { h = Math.round(h * MAX / w); w = MAX; }
            else        { w = Math.round(w * MAX / h); h = MAX; }
          }
          canvas.width = w; canvas.height = h;
          canvas.getContext('2d')!.drawImage(img, 0, 0, w, h);
          let quality = 0.9;
          const tryCompress = () => {
            const dataUrl = canvas.toDataURL('image/jpeg', quality);
            const sizeKB = Math.round(dataUrl.length * 3 / 4 / 1024);
            if (sizeKB <= maxSizeKB || quality <= 0.3) {
              const arr = dataUrl.split(','); const bstr = atob(arr[1]);
              let n = bstr.length; const u8 = new Uint8Array(n);
              while (n--) u8[n] = bstr.charCodeAt(n);
              resolve(new File([u8], file.name, { type: 'image/jpeg' }));
            } else { quality -= 0.1; tryCompress(); }
          };
          tryCompress();
        };
        img.onerror = () => reject();
      };
      reader.onerror = () => reject();
    });
  }

  isAnyCompressing(): boolean { return Object.values(this.compressing).some(v => v); }
  hasFileError():     boolean { return Object.values(this.fileErrors).some(v => v); }

  handleTeamNumbering(e: any) {
    if (e.key === 'Enter') {
      const val = e.target.value; const lines = val.split('\n');
      if (lines[lines.length - 1].trim().length > 3) {
        e.preventDefault();
        this.kaizenForm.patchValue({ team_members: val + '\n' + (lines.length + 1) + '. ' });
      }
    }
  }
  handleBenefitsNumbering(e: KeyboardEvent) {
    if (e.key === 'Enter') {
      const val = (e.target as HTMLTextAreaElement).value;
      const lines = val.split('\n');
      if (lines[lines.length - 1].trim().length > 3) {
        e.preventDefault();
        this.kaizenForm.patchValue({ benefits_pqcdsm: val + '\n' + (lines.length + 1) + '. ' });
      }
    }
  }

  onPreSubmit() {
    Object.keys(this.kaizenForm.controls).forEach(k => this.kaizenForm.get(k)?.markAsTouched());

    if (!this.files['before_img'] || !this.files['after_img']) {
      this.showToast('warning', 'Images Missing', 'Before aur After dono images upload karein.');
      return;
    }
    if (this.hasFileError()) {
      this.showToast('error', 'File Error', 'Kuch files mein error hai. Dobara upload karein.');
      return;
    }
    if (this.isDuplicate) {
      this.showToast('warning', 'Duplicate Theme', 'Yeh theme pehle se exist karti hai. Unique theme use karein.');
      return;
    }
    if (this.isAnyCompressing()) {
      this.showToast('warning', 'Please Wait', 'Files abhi compress ho rahi hain. Thoda wait karein.');
      return;
    }
    if (this.kaizenForm.invalid) {
      this.showToast('error', 'Form Incomplete', 'Saare required fields fill karein phir submit karein.');
      return;
    }

    this.showConfirmModal = true;
  }

  finalSubmit() {
    this.showConfirmModal = false;
    const formData = new FormData();
    Object.keys(this.kaizenForm.value).forEach(key => {
      if (key !== 'deployments') formData.append(key, this.kaizenForm.value[key]);
    });
    formData.append('deployments', JSON.stringify(this.kaizenForm.value.deployments));
    formData.append('kaizen_id', this.kaizenNo);
    formData.append('depo', this.kaizenForm.value.department);
    if (this.files['before_img']) formData.append('before_img', this.files['before_img']!);
    if (this.files['after_img'])  formData.append('after_img',  this.files['after_img']!);

    this.http.post('http://localhost:8080/api/manager/save', formData).subscribe({
      next: (res: any) => {
        if (res && res.status === 'success') {
          this.lastSubmittedNo = this.kaizenNo;
          this.showSuccessModal = true;
          this.showToast('success', 'Kaizen Registered!', `${this.kaizenNo} successfully submit ho gaya.`);
          this.currentStep = 0;
          this.kaizenForm.reset({ unit: '', department: '', section: '', kaizen_type: 'Innovative', pillar: 'KK', team_members: '1. ' });
          this.departmentOptions = []; this.sectionOptions = [];
          while (this.deploymentRows.length !== 0) this.deploymentRows.removeAt(0);
          this.addRow();
          this.files = { before_img: null, after_img: null };
          this.fileErrors = { before_img: false, after_img: false };
          this.compressing = { before_img: false, after_img: false };
          this.compressInfo = { before_img: '', after_img: '' };
          document.querySelectorAll<HTMLInputElement>('input[type="file"]').forEach(i => i.value = '');
          this.generateKaizenNo(); this.loadExistingThemes();
        } else {
          this.showToast('error', 'Backend Error', res?.message || 'Server se unknown error aaya.');
        }
      },
      error: () => this.showToast('error', 'Connection Failed', 'Backend se connect nahi ho paya. Server check karein.')
    });
  }

  logout() { sessionStorage.clear(); this.router.navigate(['/login']); }
}