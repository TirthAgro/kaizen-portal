import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingReviews } from './pending-reviews';

describe('PendingReviews', () => {
  let component: PendingReviews;
  let fixture: ComponentFixture<PendingReviews>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PendingReviews]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PendingReviews);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
