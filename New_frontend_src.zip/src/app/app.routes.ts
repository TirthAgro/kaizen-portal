/*import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { OperatorFormComponent } from '../operator/operator-form.component';
import { SupervisorFormComponent } from '../supervisor/supervisor-form.component';
import { PendingReviewsComponent } from './pending-reviews/pending-reviews';
import { ApprovedHistoryComponent } from './approved-history/approved-history';
//import { ManagerDashboardComponent } from './manager-login/manager-dashboard';
import { ManagerDashboardComponent } from './manager-login/manager_dashboard';
import { ManagerRegistrationComponent } from './manager-registration/manager-registration.component';
//import { ManagerMyListComponent } from './manager-login/manager-my-list';
//import { TeamTrackerComponent } from './manager-login/team-tracker';
import { HodDashboardComponent } from './hod-login/hod-dashboard.component';
// BEX Imports
import { BexLayoutComponent } from './BEX_login/bex-layout.component'; // Import the Layout!
import { BexDashboardComponent } from './BEX_login/bex_dashboard';
import { ManageUsersComponent } from './BEX_login/manage_users';
import { DownloadReportComponent } from './BEX_login/download_report';
import { GlobKaizenComponent } from './BEX_login/glob_kaizen';
import { ViewKaizenComponent } from '../view_Kaizen/view_kaizen';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'admin-login', component: AdminLoginComponent },
  { path: 'view-kaizen', component: ViewKaizenComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'pending-reviews', component: PendingReviewsComponent },
  { path: 'approved-history', component: ApprovedHistoryComponent },
  { path: 'operator-form', component: OperatorFormComponent },
  { path: 'supervisor-form', component: SupervisorFormComponent },
  { path: 'new-kaizen', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: '', redirectTo: 'manager-dashboard', pathMatch: 'full' },
  //{ path: 'manager-dashboard', component: ManagerDashboardComponent },
  { path: 'manager-dashboard', component: ManagerDashboardComponent },
  { path: 'admin-login', loadComponent: () => import('./admin-login/admin-login.component').then(m => m.AdminLoginComponent) },
  { path: 'manager-registration', component: ManagerRegistrationComponent },
  { path: 'hod-dashboard', component: HodDashboardComponent },
  { path: '',
    component: BexLayoutComponent, // This wraps all children below
    children: [
      { path: 'bex-dashboard', component: BexDashboardComponent },
      { path: 'manage-users', component: ManageUsersComponent },
      { path: 'report', component: DownloadReportComponent },
      { path: 'glob-kaizen', component: GlobKaizenComponent },
    ]
  },
    
  { path: '', redirectTo: '/admin-login', pathMatch: 'full' },
  //{ path: 'manager-my-list', component: ManagerMyListComponent },
  //{ path: 'team-tracker', component: TeamTrackerComponent },
  { path: '**', redirectTo: 'manager-dashboard' }
   // Wildcard to catch any errors and go home
];*/

















































import { Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';
import { RoleGuard } from './guards/role.guard';

// import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
// import { AdminLoginComponent } from './admin-login/admin-login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { OperatorFormComponent } from '../operator/operator-form.component';
import { SupervisorFormComponent } from '../supervisor/supervisor-form.component';
import { PendingReviewsComponent } from './pending-reviews/pending-reviews';
import { ApprovedHistoryComponent } from './approved-history/approved-history';
import { ManagerDashboardComponent } from './manager-login/manager_dashboard';
import { ManagerRegistrationComponent } from './manager-registration/manager-registration.component';
import { HodDashboardComponent } from './hod-login/hod-dashboard.component';
import { BexLayoutComponent } from './BEX_login/bex-layout.component';
import { BexDashboardComponent } from './BEX_login/bex_dashboard';
import { ManageUsersComponent } from './BEX_login/manage_users';
import { DownloadReportComponent } from './BEX_login/download_report';
import { GlobKaizenComponent } from './BEX_login/glob_kaizen';
import { ViewKaizenComponent } from '../view_Kaizen/view_kaizen';
import { SeniorLevelComponent } from './Senior_level/senior_level.component';

export const routes: Routes = [

  // Public routes — no login needed
  // { path: '', component: HomeComponent },
  { path: '', component: LoginComponent },
  // { path: 'admin-login', component: AdminLoginComponent },

  // Operator + Supervisor — both can access new-kaizen
  {
    path: 'new-kaizen',
    component: OperatorFormComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['OPERATOR', 'SUPERVISOR'] }
  },

  {
  path: 'operator-form',
  component: OperatorFormComponent,
  canActivate: [AuthGuard, RoleGuard],
  data: { roles: ['OPERATOR', 'SUPERVISOR'] }
},

  // Supervisor form (if separate page needed)
  {
    path: 'supervisor-form',
    component: SupervisorFormComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['SUPERVISOR'] }
  },
  {
    path: 'senior-level',
    component: SeniorLevelComponent,
  },

  // Dashboard — any logged in user
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [AuthGuard]
  },

  // View Kaizen — any logged in user
  {
    path: 'view-kaizen',
    component: ViewKaizenComponent,
    // canActivate: [AuthGuard]
  },

  // Pending reviews — any logged in user
  {
    path: 'pending-reviews',
    component: PendingReviewsComponent,
    canActivate: [AuthGuard]
  },

  // Approved history — any logged in user
  {
    path: 'approved-history',
    component: ApprovedHistoryComponent,
    canActivate: [AuthGuard]
  },

  // Manager routes
  {
    path: 'manager-dashboard',
    component: ManagerDashboardComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['MANAGER'] }
  },
  {
    path: 'manager-registration',
    component: ManagerRegistrationComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['MANAGER'] }
  },

  // HOD routes
  {
    path: 'hod-dashboard',
    component: HodDashboardComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['HOD'] }
  },

  // BEX routes
  {
    path: 'bex-dashboard',
    component: BexLayoutComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['BUSINESS_EXCELLENCE'] },
    children: [
      { path: '', component: BexDashboardComponent }
    ]
  },
  {
    path: 'manage-users',
    component: BexLayoutComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['BUSINESS_EXCELLENCE'] },
    children: [
      { path: '', component: ManageUsersComponent }
    ]
  },
  {
    path: 'report',
    component: BexLayoutComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['BUSINESS_EXCELLENCE'] },
    children: [
      { path: '', component: DownloadReportComponent }
    ]
  },
  {
    path: 'glob-kaizen',
    component: BexLayoutComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['BUSINESS_EXCELLENCE'] },
    children: [
      { path: '', component: GlobKaizenComponent }
    ]
  },

  // Catch all
  { path: '**', redirectTo: '' }
];