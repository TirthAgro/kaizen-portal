import { Component, OnInit, AfterViewInit, HostListener, ElementRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Chart, registerables } from 'chart.js';
Chart.register(...registerables);

interface UserData {
  plant_id: string;
  role:     string;
  user_id:  string;
  plant:    string;
  section:  string;
}

export interface HistoryRecord {
  id:           number;
  filled_by:    string;
  filled_for:   string;
  form_type:    string;
  submitted_on: string;
  status:       'Approved' | 'Rejected' | 'Pending';
  remark:       string;
}

export interface KaizenNotification {
  id:        number;
  title:     string;
  filled_by: string;
  time_ago:  string;
  manager:   string;
  status:    'Approved' | 'Rejected' | 'Pending';
}

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent implements OnInit, AfterViewInit {

  @ViewChild('pieCanvas')  pieCanvas!:  ElementRef<HTMLCanvasElement>;
  @ViewChild('barCanvas')  barCanvas!:  ElementRef<HTMLCanvasElement>;

  public user:        UserData | null = null;
  public userInitial: string          = '?';
  public profileOpen: boolean         = false;
  public activeTab:   string          = 'dashboard';

  private pieChart: Chart | null = null;
  private barChart: Chart | null = null;

  // ── Stats ──
  public stats = { pending: 22, approved: 186, target: 240, costSaving: '₹1.84Cr' };

  // ── Notifications ──
  public notifications: KaizenNotification[] = [
    { id:1, title:'Line 3 Cycle Time Reduction', filled_by:'EMP001', time_ago:'2 hrs ago',  manager:'Mgr. Verma', status:'Approved' },
    { id:2, title:'Fixture Layout Change',        filled_by:'EMP003', time_ago:'5 hrs ago',  manager:'Mgr. Shah',  status:'Rejected' },
    { id:3, title:'Coolant Reuse Process',        filled_by:'EMP007', time_ago:'1 day ago',  manager:'',           status:'Pending'  },
    { id:4, title:'Tool Change Standardisation',  filled_by:'EMP002', time_ago:'2 days ago', manager:'Mgr. Verma', status:'Approved' },
    { id:5, title:'Scrap Sorting Station',        filled_by:'EMP005', time_ago:'3 days ago', manager:'Mgr. Patel', status:'Rejected' },
  ];

  // ── Deployment ──
  public deploymentData = [
    { name:'Assembly — Plant 1',    pct:92, color:'#22c55e' },
    { name:'Paint Shop — Plant 2',  pct:88, color:'#38bdf8' },
    { name:'SCM — Corporate',       pct:81, color:'#f59e0b' },
    { name:'Quality — Plant 3',     pct:83, color:'#a855f7' },
    { name:'Stores — Plant 1',      pct:67, color:'#ff6b2b' },
    { name:'Maintenance — Plant 2', pct:54, color:'#ef4444' },
  ];

  // ── History ──
  public historyData: HistoryRecord[] = [
    { id:1, filled_by:'EMP001', filled_for:'EMP005', form_type:'Operator',   submitted_on:'2025-07-10 09:14', status:'Approved', remark:'Good improvement on line 3.' },
    { id:2, filled_by:'EMP002', filled_for:'EMP007', form_type:'Supervisor', submitted_on:'2025-07-11 11:30', status:'Pending',  remark:'' },
    { id:3, filled_by:'EMP003', filled_for:'EMP009', form_type:'Operator',   submitted_on:'2025-07-12 14:05', status:'Rejected', remark:'Incomplete data provided.' },
    { id:4, filled_by:'EMP001', filled_for:'EMP010', form_type:'Senior',     submitted_on:'2025-07-13 08:55', status:'Approved', remark:'Verified and closed.' },
    { id:5, filled_by:'EMP004', filled_for:'EMP002', form_type:'Supervisor', submitted_on:'2025-07-14 16:20', status:'Pending',  remark:'' },
    { id:6, filled_by:'EMP005', filled_for:'EMP003', form_type:'Operator',   submitted_on:'2025-07-15 10:10', status:'Approved', remark:'Excellent Kaizen submission.' },
  ];

  public filterStatus: string = 'All';
  public searchQuery:  string = '';

  get filteredHistory(): HistoryRecord[] {
    return this.historyData.filter(r => {
      const matchStatus = this.filterStatus === 'All' || r.status === this.filterStatus;
      const q = this.searchQuery.toLowerCase();
      const matchSearch = !q ||
        r.filled_by.toLowerCase().includes(q)  ||
        r.filled_for.toLowerCase().includes(q) ||
        r.form_type.toLowerCase().includes(q);
      return matchStatus && matchSearch;
    });
  }

  constructor(private router: Router) {}

  ngOnInit() {
    const raw = localStorage.getItem('user');
    if (raw) {
      this.user        = JSON.parse(raw) as UserData;
      this.userInitial = this.user.user_id?.charAt(0).toUpperCase() ?? '?';
    }
  }

  ngAfterViewInit() {
    if (this.activeTab === 'dashboard') {
      setTimeout(() => this.initCharts(), 100);
    }
  }

  initCharts() {
    this.destroyCharts();
    if (this.pieCanvas?.nativeElement) {
      this.pieChart = new Chart(this.pieCanvas.nativeElement, {
        type: 'doughnut',
        data: {
          labels: ['Approved', 'Pending', 'Rejected', 'Remaining'],
          datasets: [{
            data: [
              this.stats.approved,
              this.stats.pending,
              12,
              this.stats.target - this.stats.approved - this.stats.pending - 12
            ],
            backgroundColor: ['#22c55e', '#f59e0b', '#ef4444', '#1e293b'],
            borderWidth: 0,
            hoverOffset: 6
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          cutout: '62%',
          plugins: {
            legend: { display: false },
            tooltip: { callbacks: { label: (c) => ' ' + c.label + ': ' + c.raw } }
          }
        }
      });
    }

    if (this.barCanvas?.nativeElement) {
      this.barChart = new Chart(this.barCanvas.nativeElement, {
        type: 'bar',
        data: {
          labels: ['EMP001','EMP002','EMP003','EMP004','EMP005','EMP006'],
          datasets: [{
            label: 'Kaizens',
            data: [14, 11, 9, 8, 7, 6],
            backgroundColor: 'rgba(56,189,248,0.18)',
            borderColor: '#38bdf8',
            borderWidth: 1.5,
            borderRadius: 5,
            borderSkipped: false
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            x: { grid: { display: false }, ticks: { color: '#64748b', font: { size: 11 } } },
            y: { grid: { color: 'rgba(0,0,0,0.04)' }, ticks: { color: '#64748b', font: { size: 11 }, stepSize: 4 }, beginAtZero: true }
          }
        }
      });
    }
  }

  destroyCharts() {
    this.pieChart?.destroy(); this.pieChart = null;
    this.barChart?.destroy(); this.barChart = null;
  }

  setTab(tab: string) {
    this.activeTab   = tab;
    this.profileOpen = false;
    if (tab === 'dashboard') {
      setTimeout(() => this.initCharts(), 150);
    }
  }

  toggleProfile()      { this.profileOpen = !this.profileOpen; }
  closeProfile()       { this.profileOpen = false; }
  setFilter(s: string) { this.filterStatus = s; }
  onSearch(e: Event)   { this.searchQuery = (e.target as HTMLInputElement).value; }

  @HostListener('document:keydown.escape')
  onEscape() { this.profileOpen = false; }

  navigateTo(path: string) { this.profileOpen = false; this.router.navigate([path]); }

  onLogout() { localStorage.removeItem('user'); this.router.navigate(['/login']); }
}