// ════════════════════════════════════════════════════════════
//  manager-dashboard.component.ts
//  ✅ Enterprise Kaizen Platform UI — Full Redesign v2
//  ✅ Matches image: sidebar + hero KPIs + plan/actual + metrics + chart + dept table + deployment analytics
// ════════════════════════════════════════════════════════════

import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ManagerRegistrationComponent } from '../manager-registration/manager-registration.component';

interface Toast {
  id: number;
  message: string;
  type: 'success' | 'error' | 'warning' | 'info';
}

@Component({
  selector: 'app-manager-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, HttpClientModule, FormsModule, ManagerRegistrationComponent],
  encapsulation: ViewEncapsulation.None,
  template: `
    <div class="shell">

      <!-- ═══════════════ TOAST STACK ═══════════════ -->
      <div class="toast-stack">
        <div *ngFor="let t of toasts" class="toast"
          [class.toast--success]="t.type==='success'" [class.toast--error]="t.type==='error'"
          [class.toast--warning]="t.type==='warning'" [class.toast--info]="t.type==='info'">
          <div class="toast-icon">
            <svg *ngIf="t.type==='success'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>
            <svg *ngIf="t.type==='error'"   viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            <svg *ngIf="t.type==='warning'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
            <svg *ngIf="t.type==='info'"    viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
          </div>
          <span class="toast-msg">{{ t.message }}</span>
          <button class="toast-close" (click)="dismissToast(t.id)">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>
      </div>

      <!-- ═══════════════ CONFIRM DIALOG ═══════════════ -->
      <div class="modal-bg" *ngIf="confirmDialog.visible" (click)="confirmDialog.visible=false">
        <div class="confirm-box" (click)="$event.stopPropagation()">
          <div class="confirm-icon-wrap">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
              <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
          </div>
          <h3 class="confirm-title">{{ confirmDialog.title }}</h3>
          <p class="confirm-msg">{{ confirmDialog.message }}</p>
          <div class="confirm-btns">
            <button class="confirm-cancel" (click)="confirmDialog.visible=false">Cancel</button>
            <button class="confirm-ok" [class.confirm-ok--danger]="confirmDialog.danger" (click)="onConfirmOk()">{{ confirmDialog.okLabel }}</button>
          </div>
        </div>
      </div>

      <!-- ════════════════════ SIDEBAR ════════════════════ -->
      <aside class="sidebar" [class.sidebar--off]="sidebarClosed">
        <div class="sb-head">
          <div class="sb-logo-img"><img src="assets/shaktiman_logo.png" alt="logo"></div>
          <div>
            <span class="sb-brand-name">SHAKTI<span class="sb-brand-accent">पथ</span></span>
            <span class="sb-brand-sub">Every step towards Success</span>
          </div>
        </div>
        <div class="sb-sep"></div>

        <div class="sb-role-badge">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" width="13" height="13"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
          Manager Dashboard
        </div>

        <nav class="sb-nav">
          <button class="nav-btn" [class.nav-btn--active]="currentView==='insights'" (click)="currentView='insights'">
            <svg class="nav-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round">
              <rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/>
              <rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/>
            </svg>Executive Dashboard
          </button>

          <button class="nav-btn" [class.nav-btn--active]="currentView==='registration'" (click)="currentView='registration'">
            <svg class="nav-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round">
              <path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2"/>
              <rect x="9" y="3" width="6" height="4" rx="1"/>
            </svg>Kaizen Management
          </button>

          <button class="nav-btn" [class.nav-btn--active]="currentView==='approvals'" (click)="currentView='approvals'">
            <svg class="nav-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round">
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>
            </svg>Approval Workflow
            <span class="nav-badge" *ngIf="pendingApprovalCount > 0">{{ pendingApprovalCount }}</span>
          </button>

          <button class="nav-btn" (click)="null">
            <svg class="nav-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round">
              <line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>
            </svg>Horizontal Deployment
          </button>

          <button class="nav-btn" (click)="null">
            <svg class="nav-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round">
              <line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/>
            </svg>Vertical Implementation
          </button>

          <button class="nav-btn" [class.nav-btn--active]="currentView==='tracker'" (click)="currentView='tracker'">
            <svg class="nav-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round">
              <line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
            </svg>Cost Saving Analytics
          </button>

          <button class="nav-btn" (click)="null">
            <svg class="nav-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round">
              <path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2"/>
              <rect x="9" y="3" width="6" height="4" rx="1"/><path d="M9 12h6M9 16h4"/>
            </svg>Audit & Compliance
          </button>
        </nav>

        <div class="sb-sep" style="margin-top:auto"></div>
        <div class="sb-role-section">
          <div class="sb-role-header">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13" stroke-linecap="round">
              <rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>
            </svg>
            Role Access
          </div>
          <div class="sb-role-links">
            <span class="sb-role-link">· Department Analytics</span>
            <span class="sb-role-link">· Budget Saving</span>
            <span class="sb-role-link">· Cross Functional Review</span>
          </div>
        </div>

        <div class="sb-footer">
          <div class="sb-profile">
            <div class="sb-avatar">{{ (emp_id || 'M').charAt(0).toUpperCase() }}</div>
            <div class="sb-profile-info">
              <span class="sb-profile-name">{{ emp_id || 'Manager' }}</span>
              <span class="sb-profile-plant">{{emp_id}} · {{ plant }} · {{ section }}</span>
            </div>
          </div>
          <button class="sb-logout-btn" (click)="logout()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
              <polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>
            </svg>Sign Out
          </button>
        </div>
      </aside>

      <!-- ════════════════════ MAIN ════════════════════ -->
      <div class="main-wrap">

        <!-- TOPBAR -->
        <header class="topbar">
          <div class="topbar-left">
            <button class="topbar-toggle" (click)="toggleSidebar()">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                <line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/>
              </svg>
            </button>
            <div class="topbar-breadcrumb">
              <span class="tb-path">Shaktiman Kaizen Management</span>
              <span class="tb-title">Manager Dashboard</span>
            </div>
          </div>
          <div class="topbar-right">
            <button class="topbar-icon-btn" title="Notifications">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" width="16" height="16">
                <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>
              </svg>
            </button>
            <button class="sync-btn" (click)="fetchDbStats()">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
                <polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/>
                <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
              </svg>Sync Data
            </button>
          </div>
        </header>

        <main class="page-content">

          <!-- ══════════ INSIGHTS VIEW ══════════ -->
          <ng-container *ngIf="currentView === 'insights'">

            <!-- ── HERO HEADER ── -->
            <div class="hero-header">
              <div class="hero-deco hero-deco-1"></div>
              <div class="hero-deco hero-deco-2"></div>
              <div class="hero-inner">
                <div class="hero-left">
                  <div class="hero-badges">
                    <span class="hero-badge hero-badge--orange">ENTERPRISE PERFORMANCE</span>
                    <span class="hero-badge hero-badge--green">
                      <span class="live-dot"></span>System Live
                    </span>
                  </div>
                  <h2 class="hero-title">Welcome back!</h2>
                  <p class="hero-sub">You have <strong class="welcome-count">{{ pendingApprovalCount }}</strong>
                    submission{{ pendingApprovalCount !== 1 ? 's' : '' }} pending for your approval.</p>
                </div>
                <div class="hero-right">
                  <button class="hero-cta" (click)="currentView='approvals'">
                    Review Now
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
                      <line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>
                    </svg>
                  </button>
                </div>
              </div>

             
            </div>
             <!-- Hero KPI Strip -->
              <div class="hero-kpi-strip">
                <div class="hero-kpi-item">
                  <div class="hero-kpi-top">
                    <span class="hero-kpi-label">Pending</span>
                    <div class="hero-kpi-icon-sm">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" width="14" height="14"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                    </div>
                  </div>
                  <div class="hero-kpi-val">{{ pendingApprovalCount }}</div>
                </div>
                <div class="hero-kpi-div"></div>
                <div class="hero-kpi-item">
                  <div class="hero-kpi-top">
                    <span class="hero-kpi-label">Approved</span>
                    <div class="hero-kpi-icon-sm hero-kpi-icon-sm--green">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" width="14" height="14"><polyline points="20 6 9 17 4 12"/></svg>
                    </div>
                  </div>
                  <div class="hero-kpi-val">{{ approvedCount }}</div>
                </div>
                <div class="hero-kpi-div"></div>
                <div class="hero-kpi-item">
                  <div class="hero-kpi-top">
                    <span class="hero-kpi-label">Target</span>
                    <div class="hero-kpi-icon-sm hero-kpi-icon-sm--amber">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" width="14" height="14"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                    </div>
                  </div>
                  <div class="hero-kpi-val">{{ goalTarget }}</div>
                </div>
                <div class="hero-kpi-div"></div>
                <div class="hero-kpi-item">
                  <div class="hero-kpi-top">
                    <span class="hero-kpi-label">Cost Saving</span>
                    <div class="hero-kpi-icon-sm hero-kpi-icon-sm--violet">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" width="14" height="14"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                    </div>
                  </div>
                  <div class="hero-kpi-val">{{ costSaving }}</div>
                </div>
              </div>

            <!-- ── PLAN vs ACTUAL SECTION ── -->
            <div class="section-header">
              <div>
                <div class="section-title">Plan vs Actual Analytics</div>
                <div class="section-sub">Enterprise KPI performance tracking</div>
              </div>
              <button class="sync-btn-sm" (click)="fetchDbStats()">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
                  <polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/>
                  <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
                </svg>
              </button>
            </div>
            <div class="plan-grid">
              <div class="plan-card" *ngFor="let p of planMetrics">
                <div class="plan-label">{{ p.label }}</div>
                <div class="plan-row">
                  <div>
                    <div class="plan-sub">Plan</div>
                    <div class="plan-plan-val">{{ p.plan }}</div>
                  </div>
                  <div style="text-align:right">
                    <div class="plan-sub">Actual</div>
                    <div class="plan-actual-val" [style.color]="p.color">{{ p.actual }}</div>
                  </div>
                </div>
                <div class="plan-bar-track">
                  <div class="plan-bar-fill" [style.width.%]="p.pct" [style.background]="p.color"></div>
                </div>
                <div class="plan-ach-row">
                  <span class="plan-ach" [style.color]="p.color">Achievement</span>
                  <span class="plan-ach-pct" [style.color]="p.color">{{ p.pct }}%</span>
                </div>
              </div>
            </div>

            <!-- ── INNOVATION METRIC CARDS ── -->
            <div class="metric-grid">
              <div class="metric-card">
                <div class="metric-icon-box metric-icon--brand">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
                </div>
                <div class="metric-body">
                  <div class="metric-sub-lbl">Breakthrough Kaizen</div>
                  <div class="metric-big-val">{{ breakthroughCount }}</div>
                  <div class="metric-foot">Enterprise Analytics</div>
                </div>
              </div>
              <div class="metric-card">
                <div class="metric-icon-box metric-icon--blue">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                </div>
                <div class="metric-body">
                  <div class="metric-sub-lbl">Innovation Kaizen</div>
                  <div class="metric-big-val" style="color:#2563EB">{{ myTotalCount }}</div>
                  <div class="metric-foot">Enterprise Analytics</div>
                </div>
              </div>
              <div class="metric-card">
                <div class="metric-icon-box metric-icon--green">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                </div>
                <div class="metric-body">
                  <div class="metric-sub-lbl">Horizontal Deployment</div>
                  <div class="metric-big-val" style="color:#059669">{{ approvedCount }}</div>
                  <div class="metric-foot">Enterprise Analytics</div>
                </div>
              </div>
              <div class="metric-card">
                <div class="metric-icon-box metric-icon--violet">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></svg>
                </div>
                <div class="metric-body">
                  <div class="metric-sub-lbl">Vertical Implementation</div>
                  <div class="metric-big-val" style="color:#7C3AED">{{ pendingApprovalCount }}</div>
                  <div class="metric-foot">Enterprise Analytics</div>
                </div>
              </div>
            </div>

            <!-- ── BOTTOM ROW ── -->
            <div class="bottom-row">

              <!-- Bar Chart -->
              <div class="panel panel-chart">
                <div class="panel-head">
                  <div>
                    <div class="panel-title">Department Efficiency</div>
                    <div class="panel-sub">Monthly submission trend</div>
                  </div>
                  <div class="chart-controls">
                    <select class="div-select" [(ngModel)]="selectedDivision">
                      <option *ngFor="let d of divisions">{{ d }}</option>
                    </select>
                    <div class="chart-legend">
                      <span class="legend-dot"></span>
                      <span class="legend-txt">Submissions</span>
                    </div>
                  </div>
                </div>
                <div class="panel-body">
                  <div class="bar-chart">
                    <div class="bar-item" *ngFor="let item of chartData">
                      <div class="bar-track">
                        <div class="bar-fill" [style.height.%]="item.val" [class.bar-fill--hi]="item.val >= 80"></div>
                      </div>
                      <span class="bar-lbl">{{ item.month }}</span>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Department Performance Table -->
              <div class="panel panel-dept">
                <div class="panel-head">
                  <div>
                    <div class="panel-title">Department Performance</div>
                    <div class="panel-sub">Cross-functional department metrics</div>
                  </div>
                  <button class="export-btn">Export Report ↗</button>
                </div>
                <div class="table-wrap">
                  <table class="dept-tbl">
                    <thead>
                      <tr>
                        <th>Department</th><th>Plant</th><th>Kaizens</th>
                        <th>Cost Saving</th><th>Efficiency</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr *ngFor="let r of deptData">
                        <td class="dept-name">{{ r.dept }}</td>
                        <td class="dept-muted">{{ r.plant }}</td>
                        <td class="dept-num">{{ r.kaizens }}</td>
                        <td class="dept-cost">{{ r.cost }}</td>
                        <td>
                          <div class="eff-wrap">
                            <div class="eff-track">
                              <div class="eff-fill"
                                [style.width.%]="r.eff"
                                [class.eff-fill--hi]="r.eff >= 75"
                                [class.eff-fill--mid]="r.eff >= 50 && r.eff < 75"
                                [class.eff-fill--lo]="r.eff < 50">
                              </div>
                            </div>
                            <span class="eff-pct"
                              [class.eff-pct--hi]="r.eff >= 75"
                              [class.eff-pct--mid]="r.eff >= 50 && r.eff < 75"
                              [class.eff-pct--lo]="r.eff < 50">
                              {{ r.eff }}%
                            </span>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <!-- Deployment Analytics (Target Progress) -->
              <div class="panel panel-deploy">
                <div class="panel-head">
                  <div>
                    <div class="panel-title">Deployment Analytics</div>
                    <div class="panel-sub">Goal: {{ goalTarget }} Approved</div>
                  </div>
                  <button class="sync-btn-sm" (click)="fetchDbStats()">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
                      <polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/>
                      <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
                    </svg>
                  </button>
                </div>
                <div class="deploy-body">

                  <!-- Horizontal Deployment -->
                  <div class="deploy-item">
                    <div class="deploy-item-head">
                      <div class="deploy-item-info">
                        <div class="deploy-item-title">Horizontal Deployment</div>
                        <div class="deploy-item-sub">Implemented across departments</div>
                      </div>
                      <span class="deploy-pct" style="color: var(--brand)">{{ deployStats.horizontal }}%</span>
                    </div>
                    <div class="deploy-bar-track">
                      <div class="deploy-bar-fill deploy-bar--orange" [style.width.%]="deployStats.horizontal"></div>
                    </div>
                  </div>

                  <!-- Vertical Implementation -->
                  <div class="deploy-item">
                    <div class="deploy-item-head">
                      <div class="deploy-item-info">
                        <div class="deploy-item-title">Vertical Implementation</div>
                        <div class="deploy-item-sub">Rolled out at management levels</div>
                      </div>
                      <span class="deploy-pct" style="color: var(--brand)">{{ deployStats.vertical }}%</span>
                    </div>
                    <div class="deploy-bar-track">
                      <div class="deploy-bar-fill deploy-bar--orange" [style.width.%]="deployStats.vertical"></div>
                    </div>
                  </div>

                  <!-- Replication Success -->
                  <div class="deploy-item">
                    <div class="deploy-item-head">
                      <div class="deploy-item-info">
                        <div class="deploy-item-title">Replication Success</div>
                        <div class="deploy-item-sub">Successfully reused Kaizens</div>
                      </div>
                      <span class="deploy-pct" style="color: var(--brand)">{{ deployStats.replication }}%</span>
                    </div>
                    <div class="deploy-bar-track">
                      <div class="deploy-bar-fill deploy-bar--orange" [style.width.%]="deployStats.replication"></div>
                    </div>
                  </div>

                </div>
                <div class="target-footer">
                  <span class="target-footer-txt">{{ goalTarget - approvedCount }} more needed to hit goal</span>
                </div>
              </div>

            </div>
          </ng-container>

          <!-- ══════════ APPROVALS VIEW ══════════ -->
          <ng-container *ngIf="currentView === 'approvals'">
            <div class="page-top-row">
              <div class="breadcrumb">
                <span class="bc-root">Approvals</span><span class="bc-sep">/</span>
                <span class="bc-unit">{{ plantId }}</span><span class="bc-sep">/</span>
                <span class="bc-current">{{ section }} Section</span>
              </div>
              <button class="sync-btn" (click)="fetchPendingData()">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
                  <polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/>
                  <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
                </svg>Refresh
              </button>
            </div>
            <div class="panel">
              <div class="panel-head">
                <div>
                  <div class="panel-title">Approval Queue</div>
                  <div class="panel-sub">Submissions pending your review</div>
                </div>
                <span class="count-tag" *ngIf="pendingApprovalCount > 0">{{ pendingApprovalCount }} Pending</span>
              </div>
              <div class="table-wrap">
                <table class="data-tbl">
                  <thead>
                    <tr><th>Kaizen ID</th><th>Employee</th><th>Theme</th><th>Level</th><th>Action</th></tr>
                  </thead>
                  <tbody>
                    <tr *ngFor="let k of pendingKaizens">
                      <td><span class="id-tag">{{ k.kaizen_id }}</span></td>
                      <td><div class="emp-row"><div class="emp-av">{{ k.emp_name?.charAt(0) }}</div>{{ k.emp_name }}</div></td>
                      <td class="td-theme">{{ k.theme }}</td>
                      <td>
                        <span class="role-tag"
                          [class.role-tag--op]="k.role_type?.toLowerCase().startsWith('op')"
                          [class.role-tag--sup]="k.role_type?.toLowerCase().startsWith('su')"
                          [class.role-tag--man]="k.role_type?.toLowerCase().startsWith('ma')">
                          {{ k.role_type }}
                        </span>
                      </td>
                      <td><button class="btn-review" (click)="openReview(k)">Review →</button></td>
                    </tr>
                  </tbody>
                </table>
                <div class="tbl-empty" *ngIf="pendingKaizens.length === 0">
                  <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" opacity=".3">
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>
                  </svg>
                  <p>No pending approvals for {{ section }}.</p>
                </div>
              </div>
            </div>
          </ng-container>

          <!-- ══════════ TRACKER VIEW ══════════ -->
          <ng-container *ngIf="currentView === 'tracker'">
            <div class="page-top-row">
              <div class="breadcrumb">
                <span class="bc-root">History</span><span class="bc-sep">/</span>
                <span class="bc-unit">{{ plantId }}</span><span class="bc-sep">/</span>
                <span class="bc-current">{{ section }} Section</span>
              </div>
              <div class="search-wrap">
                <svg class="search-ico" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                  <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
                </svg>
                <input class="search-input" type="text" [(ngModel)]="searchTerm"
                  (input)="filterTrackerData()" placeholder="Search employee or theme…">
              </div>
            </div>
            <div class="panel">
              <div class="panel-head">
                <div>
                  <div class="panel-title">Team Tracker</div>
                  <div class="panel-sub">{{ filteredHistory.length }} record{{ filteredHistory.length !== 1 ? 's' : '' }} found</div>
                </div>
              </div>
              <div class="table-wrap">
                <table class="data-tbl">
                  <thead>
                    <tr><th>Kaizen ID</th><th>Level</th><th>Employee</th><th>Theme</th><th>Status</th><th>Remarks</th></tr>
                  </thead>
                  <tbody>
                    <tr *ngFor="let k of filteredHistory">
                      <td><span class="id-tag">{{ k.kaizen_id }}</span></td>
                      <td>
                        <span class="role-tag"
                          [class.role-tag--op]="k.role_type?.toLowerCase().startsWith('op')"
                          [class.role-tag--sup]="k.role_type?.toLowerCase().startsWith('su')"
                          [class.role-tag--man]="k.role_type?.toLowerCase().startsWith('ma')">
                          {{ k.role_type }}
                        </span>
                      </td>
                      <td><div class="emp-row"><div class="emp-av">{{ k.emp_name?.charAt(0) }}</div>{{ k.emp_name }}</div></td>
                      <td class="td-theme">{{ k.theme }}</td>
                      <td>
                        <span class="status-tag"
                          [class.st-approved]="k.status?.toLowerCase() === 'approved'"
                          [class.st-rejected]="k.status?.toLowerCase() === 'rejected'"
                          [class.st-pending]="k.status?.toLowerCase() === 'pending' || !k.status">
                          {{ k.status || 'Pending' }}
                        </span>
                      </td>
                      <td class="td-remark">{{ k.hod_remarks || '—' }}</td>
                    </tr>
                  </tbody>
                </table>
                <div class="tbl-empty" *ngIf="filteredHistory.length === 0">
                  <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" opacity=".3">
                    <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
                  </svg>
                  <p>No results found.</p>
                </div>
              </div>
            </div>
          </ng-container>

          <!-- ══════════ NEW KAIZEN VIEW ══════════ -->
          <ng-container *ngIf="currentView === 'registration'">
            <app-manager-form></app-manager-form>
          </ng-container>

        </main>
      </div>

      <!-- ════════════════════ REVIEW MODAL ════════════════════ -->
      <div class="modal-bg" *ngIf="selectedKaizen" (click)="selectedKaizen=null">
        <div class="modal-box" (click)="$event.stopPropagation()">
          <div class="modal-hdr">
            <div>
              <span class="modal-eyebrow">Kaizen Review</span>
              <h2 class="modal-id">{{ selectedKaizen.kaizen_id }}</h2>
            </div>
            <button class="modal-close-btn" (click)="selectedKaizen=null">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
              </svg>
            </button>
          </div>
          <div class="modal-body">
            <div class="meta-grid">
              <div class="meta-cell"><span class="meta-label">Employee</span><span class="meta-val">{{ selectedKaizen.emp_name }}</span></div>
              <div class="meta-cell"><span class="meta-label">Category</span><span class="meta-val">{{ selectedKaizen.kaizen_category || '—' }}</span></div>
              <div class="meta-cell meta-full"><span class="meta-label">Theme</span><span class="meta-val">{{ selectedKaizen.theme }}</span></div>
              <ng-container *ngIf="selectedKaizen.role_type === 'Supervisor'">
                <div class="meta-cell"><span class="meta-label">PQCDSM</span><span class="meta-val">{{ selectedKaizen.pqcdsm || '—' }}</span></div>
                <div class="meta-cell"><span class="meta-label">Problem Status</span><span class="meta-val">{{ selectedKaizen.problem_status || '—' }}</span></div>
                <div class="meta-cell meta-full"><span class="meta-label">Countermeasure</span><span class="meta-val meta-desc">{{ selectedKaizen.countermeasure || '—' }}</span></div>
              </ng-container>
            </div>
            <div class="img-compare">
              <div class="img-panel">
                <div class="img-lbl img-lbl-before">Before</div>
                <img *ngIf="safeImgSrc(selectedKaizen.before_img)" [src]="safeImgSrc(selectedKaizen.before_img)" class="img-el">
                <div *ngIf="!safeImgSrc(selectedKaizen.before_img)" class="img-empty">
                  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                  <span>No image available</span>
                </div>
              </div>
              <div class="img-panel">
                <div class="img-lbl img-lbl-after">After</div>
                <img *ngIf="safeImgSrc(selectedKaizen.after_img)" [src]="safeImgSrc(selectedKaizen.after_img)" class="img-el">
                <div *ngIf="!safeImgSrc(selectedKaizen.after_img)" class="img-empty">
                  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                  <span>No image available</span>
                </div>
              </div>
            </div>
            <div class="decision-area">
              <div class="decision-label-row"><label>Manager Remarks</label></div>
              <textarea [(ngModel)]="managerRemark" placeholder="Enter reason for approval or rejection…"></textarea>
              <div class="decision-btns">
                <button class="btn-reject" (click)="updateStatus('Rejected')" [disabled]="!managerRemark.trim()">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                  Reject
                </button>
                <button class="btn-approve" (click)="updateStatus('Approved')">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                  Approve Kaizen
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  `,
  styles: [`
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

    :host, .shell {
      --brand: #E85D04; --brand-dim: rgba(232,93,4,0.14);
      --navy: #0F172A; --navy2: #1E293B; --navy3: #162032;
      --sb-bg: #0F172A; --sb-hover: rgba(255,255,255,0.05);
      --sb-act: rgba(232,93,4,0.14); --sb-text: #94A3B8;
      --sb-hi: #F1F5F9; --sb-sep: rgba(255,255,255,0.07); --sb-w: 220px;
      --bg: #EEF2F7; --card: #FFFFFF; --muted: #F8FAFC;
      --t1: #0F172A; --t2: #475569; --t3: #94A3B8;
      --bdr: #E2E8F0; --bdr2: #CBD5E1;
      --blue: #2563EB; --blue-bg: #EFF6FF;
      --green: #059669; --green-bg: #ECFDF5;
      --violet: #7C3AED; --violet-bg: #F5F3FF;
      --amber: #B45309; --amber-bg: #FFFBEB;
      --red: #DC2626; --red-bg: #FEF2F2;
      --r-sm: 6px; --r-md: 10px; --r-lg: 14px; --r-xl: 18px;
      --font: 'Plus Jakarta Sans', sans-serif;
    }
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    .shell {
      display: flex; height: 100vh; width: 100vw;
      overflow: hidden; font-family: var(--font);
      background: var(--bg); color: var(--t1); font-size: 14px;
      position: relative;
    }

    /* ── TOASTS ── */
    .toast-stack { position: fixed; top: 20px; right: 20px; z-index: 9999; display: flex; flex-direction: column; gap: 10px; pointer-events: none; }
    .toast { display: flex; align-items: center; gap: 11px; padding: 13px 16px; border-radius: 12px; background: #fff; box-shadow: 0 8px 30px rgba(0,0,0,0.12); border-left: 4px solid transparent; min-width: 280px; max-width: 380px; pointer-events: all; animation: toastIn 0.28s cubic-bezier(0.34,1.56,0.64,1) forwards; }
    @keyframes toastIn { from { opacity:0; transform: translateX(60px) scale(0.95); } to { opacity:1; transform: translateX(0) scale(1); } }
    .toast--success { border-left-color: var(--green); } .toast--error { border-left-color: var(--red); } .toast--warning { border-left-color: var(--amber); } .toast--info { border-left-color: var(--blue); }
    .toast-icon { width: 32px; height: 32px; border-radius: 8px; display: grid; place-items: center; flex-shrink: 0; }
    .toast-icon svg { width: 16px; height: 16px; }
    .toast--success .toast-icon { background: var(--green-bg); color: var(--green); }
    .toast--error   .toast-icon { background: var(--red-bg);   color: var(--red);   }
    .toast--warning .toast-icon { background: var(--amber-bg); color: var(--amber); }
    .toast--info    .toast-icon { background: var(--blue-bg);  color: var(--blue);  }
    .toast-msg { flex: 1; font-size: 13.5px; font-weight: 500; color: var(--t1); line-height: 1.45; }
    .toast-close { width: 24px; height: 24px; border-radius: 6px; border: none; background: none; cursor: pointer; color: var(--t3); display: grid; place-items: center; }
    .toast-close svg { width: 13px; height: 13px; }
    .toast-close:hover { background: var(--muted); }

    /* ── CONFIRM DIALOG ── */
    .confirm-box { background: #fff; border-radius: 18px; padding: 32px 28px 26px; width: 100%; max-width: 380px; box-shadow: 0 24px 60px rgba(0,0,0,0.22); display: flex; flex-direction: column; align-items: center; gap: 10px; animation: toastIn 0.25s ease forwards; }
    .confirm-icon-wrap { width: 52px; height: 52px; border-radius: 50%; background: var(--amber-bg); display: grid; place-items: center; color: var(--amber); }
    .confirm-icon-wrap svg { width: 26px; height: 26px; }
    .confirm-title { font-size: 17px; font-weight: 800; color: var(--t1); text-align: center; }
    .confirm-msg   { font-size: 13.5px; color: var(--t2); text-align: center; line-height: 1.6; }
    .confirm-btns  { display: flex; gap: 10px; margin-top: 14px; width: 100%; }
    .confirm-cancel { flex: 1; padding: 11px; border-radius: var(--r-md); border: 1.5px solid var(--bdr); background: none; font-family: var(--font); font-size: 13.5px; font-weight: 600; color: var(--t2); cursor: pointer; }
    .confirm-ok { flex: 1; padding: 11px; border-radius: var(--r-md); border: none; background: var(--brand); font-family: var(--font); font-size: 13.5px; font-weight: 700; color: #fff; cursor: pointer; }
    .confirm-ok--danger { background: var(--red); }

    /* ── SIDEBAR ── */
    .sidebar { width: var(--sb-w); min-width: var(--sb-w); flex-shrink: 0; background: var(--sb-bg); display: flex; flex-direction: column; transition: width 0.3s ease, min-width 0.3s ease; overflow: hidden; position: relative; z-index: 10; }
    .sidebar--off { width: 0; min-width: 0; }
    .sb-head { display: flex; align-items: center; gap: 10px; padding: 18px 14px 14px; flex-shrink: 0; }
    .sb-logo-img { width: 40px; height: 40px; border-radius: 10px; background: #fff; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 12px rgba(0,0,0,0.15); flex-shrink: 0; }
    .sb-logo-img img { width: 28px; object-fit: contain; }
    .sb-brand-name { display: block; font-size: 14px; font-weight: 800; color: var(--sb-hi); white-space: nowrap; letter-spacing: 1px; }
    .sb-brand-accent { color: var(--brand); }
    .sb-brand-sub  { display: block; font-size: 9px; color: var(--sb-text); margin-top: 1px; white-space: nowrap; }
    .sb-sep { height: 1px; background: var(--sb-sep); margin: 0 14px; flex-shrink: 0; }
    .sb-role-badge { display: flex; align-items: center; gap: 6px; margin: 10px 14px 4px; background: rgba(232,93,4,0.12); color: #FB923C; font-size: 10.5px; font-weight: 700; padding: 5px 10px; border-radius: 6px; border-left: 2px solid var(--brand); }
    .sb-nav { flex: 1; padding: 6px 8px; display: flex; flex-direction: column; gap: 1px; overflow-y: auto; overflow-x: hidden; }
    .nav-btn { display: flex; align-items: center; gap: 8px; width: 100%; padding: 8px 10px; border: none; border-radius: var(--r-md); background: transparent; cursor: pointer; color: var(--sb-text); font-family: var(--font); font-size: 12.5px; font-weight: 500; text-align: left; white-space: nowrap; transition: background 0.15s, color 0.15s; }
    .nav-btn:hover { background: var(--sb-hover); color: var(--sb-hi); }
    .nav-btn--active { background: var(--sb-act); color: #FB923C; font-weight: 600; }
    .nav-ico { width: 15px; height: 15px; flex-shrink: 0; }
    .nav-badge { margin-left: auto; background: var(--brand); color: #fff; font-size: 9.5px; font-weight: 700; padding: 1px 6px; border-radius: 20px; }
    .sb-role-section { padding: 10px 14px 8px; flex-shrink: 0; }
    .sb-role-header { display: flex; align-items: center; gap: 6px; font-size: 9.5px; font-weight: 700; color: #475569; text-transform: uppercase; letter-spacing: 0.07em; margin-bottom: 6px; }
    .sb-role-links { display: flex; flex-direction: column; gap: 4px; }
    .sb-role-link { font-size: 11px; color: var(--sb-text); padding: 2px 6px; cursor: pointer; white-space: nowrap; }
    .sb-role-link:hover { color: var(--sb-hi); }
    .sb-footer { border-top: 1px solid var(--sb-sep); padding: 10px 12px 12px; flex-shrink: 0; display: flex; flex-direction: column; gap: 10px; }
    .sb-profile { display: flex; align-items: center; gap: 8px; }
    .sb-avatar { width: 30px; height: 30px; border-radius: 8px; background: rgba(232,93,4,0.2); color: #FB923C; display: grid; place-items: center; font-weight: 700; font-size: 12px; flex-shrink: 0; }
    .sb-profile-name  { display: block; font-size: 12px; font-weight: 600; color: var(--sb-hi); }
    .sb-profile-plant { display: block; font-size: 10px; color: var(--sb-text); white-space: nowrap; overflow: hidden; max-width: 120px; text-overflow: ellipsis; }
    .sb-logout-btn { display: flex; align-items: center; justify-content: center; gap: 8px; width: 100%; padding: 8px 12px; background: none; border: 1px solid rgba(239,68,68,0.3); border-radius: var(--r-md); cursor: pointer; color: #F87171; font-family: var(--font); font-size: 12px; font-weight: 600; transition: all 0.15s; }
    .sb-logout-btn svg { width: 13px; height: 13px; }
    .sb-logout-btn:hover { background: rgba(239,68,68,0.1); border-color: #EF4444; }

    /* ── TOPBAR ── */
    .main-wrap { flex: 1; min-width: 0; width: 0; display: flex; flex-direction: column; overflow: hidden; }
    .topbar { height: 54px; background: var(--card); border-bottom: 1px solid var(--bdr); display: flex; align-items: center; justify-content: space-between; padding: 0 20px; flex-shrink: 0; }
    .topbar-left { display: flex; align-items: center; gap: 14px; }
    .topbar-toggle { width: 32px; height: 32px; border-radius: var(--r-sm); border: 1px solid var(--bdr); background: none; display: grid; place-items: center; cursor: pointer; color: var(--t2); transition: all 0.15s; }
    .topbar-toggle svg { width: 16px; height: 16px; }
    .topbar-toggle:hover { border-color: var(--bdr2); color: var(--t1); }
    .topbar-breadcrumb { display: flex; flex-direction: column; }
    .tb-path  { font-size: 10px; color: var(--t3); font-weight: 500; }
    .tb-title { font-size: 13px; font-weight: 700; color: var(--t1); }
    .topbar-right { display: flex; align-items: center; gap: 8px; }
    .topbar-icon-btn { width: 32px; height: 32px; border-radius: var(--r-sm); border: 1px solid var(--bdr); background: none; display: grid; place-items: center; cursor: pointer; color: var(--t2); transition: all 0.15s; }
    .topbar-icon-btn:hover { border-color: var(--bdr2); color: var(--t1); }

    /* ── PAGE CONTENT ── */
    .page-content { flex: 1; overflow-y: hidden; padding: 16px 20px; display: flex; flex-direction: column; gap: 14px;}
    .page-content:has(app-manager-form) { padding: 0; }
    .page-top-row { display: flex; align-items: center; justify-content: space-between; }
    .breadcrumb { display: flex; align-items: center; gap: 6px; font-size: 13px; }
    .bc-root { color: var(--t3); font-weight: 500; } .bc-sep { color: var(--t3); } .bc-current { color: var(--t1); font-weight: 600; } .bc-unit { color: var(--brand); font-weight: 600; }
    .sync-btn { display: inline-flex; align-items: center; gap: 7px; padding: 7px 14px; background: var(--card); border: 1px solid var(--bdr); border-radius: var(--r-md); color: var(--t2); font-family: var(--font); font-size: 12px; font-weight: 600; cursor: pointer; transition: all 0.15s; }
    .sync-btn:hover { border-color: var(--brand); color: var(--brand); }
    .sync-btn-sm { width: 28px; height: 28px; border-radius: var(--r-sm); background: var(--muted); border: 1px solid var(--bdr); display: grid; place-items: center; cursor: pointer; color: var(--t3); transition: all 0.15s; }
    .sync-btn-sm:hover { border-color: var(--brand); color: var(--brand); }

    /* ── SECTION HEADER ── */
    .section-header { display: flex; align-items: center; justify-content: space-between; }
    .section-title { font-size: 14px; font-weight: 700; color: var(--t1); }
    .section-sub   { font-size: 12px; color: var(--t3); margin-top: 1px; }

    /* ═══════════════════════════════════════════
       HERO HEADER
    ═══════════════════════════════════════════ */
    .hero-header {
      background: linear-gradient(135deg, #0F172A 0%, #162032 55%, #1a2744 100%);
      border-radius: var(--r-xl);
      overflow: visible !important;
      
      display: flex;
      flex-direction: column;
    }
    .hero-deco { position: absolute; border-radius: 50%; pointer-events: none; }
    .hero-deco-1 { right: -40px; top: -40px; width: 200px; height: 200px; background: rgba(232,93,4,0.07); }
    .hero-deco-2 { right: 120px; bottom: -50px; width: 160px; height: 160px; background: rgba(99,102,241,0.05); }

    .hero-inner { position: relative; z-index: 1; padding: 20px 24px 14px; display: flex; align-items: center; justify-content: space-between; gap: 20px; flex-shrink: 0; }
    .hero-left { flex: 1; min-width: 0; }
    .hero-badges { display: flex; align-items: center; gap: 8px; margin-bottom: 10px; flex-wrap: wrap; }
    .hero-badge { font-size: 9.5px; font-weight: 700; padding: 3px 10px; border-radius: 20px; letter-spacing: 0.06em; text-transform: uppercase; }
    .hero-badge--orange { background: rgba(232,93,4,0.2); color: #FB923C; border: 1px solid rgba(232,93,4,0.3); }
    .hero-badge--green  { background: rgba(16,185,129,0.12); color: #10B981; border: 1px solid rgba(16,185,129,0.25); display: flex; align-items: center; gap: 5px; }
    .live-dot { width: 6px; height: 6px; border-radius: 50%; background: #10B981; flex-shrink: 0; animation: pulse 2s infinite; }
    @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
    .hero-title { font-size: 20px; font-weight: 800; color: #F1F5F9; letter-spacing: -0.4px; margin-bottom: 6px; }
    .hero-sub   { font-size: 11.5px; color: #c9d7eb; line-height: 1.6; max-width: 480px; }
    .hero-right { display: flex; align-items: center; flex-shrink: 0; }
    .hero-cta { display: inline-flex; align-items: center; gap: 8px; padding: 10px 22px; background: var(--brand); color: #fff; border: none; border-radius: 30px; font-family: var(--font); font-size: 13px; font-weight: 700; cursor: pointer; transition: all 0.15s; white-space: nowrap; }
    .hero-cta:hover { background: #c44d02; transform: translateY(-1px); }

    /* Hero KPI strip */
    .hero-kpi-strip {  
  

  margin-top: 10px;

  display: grid;
  grid-template-columns: repeat(4,1fr);

  border-top: 1px solid rgba(255,255,255,0.07);
  border-top-left-radius: var(--r-xl);
  border-top-right-radius: var(--r-xl);
  border-bottom-left-radius: var(--r-xl);
  border-bottom-right-radius: var(--r-xl);

  background: white;}
    .hero-kpi-item { padding: 16px 20px 18px; border-right: 1px solid rgba(0, 0, 0, 0.07); }
    .hero-kpi-item:last-child { border-right: none; }
    .hero-kpi-div { display: none; }
    .hero-kpi-top { display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px; }
    .hero-kpi-label { font-size: 10px; color: #64748B; font-weight: 600; text-transform: uppercase; letter-spacing: 0.06em; }
    .hero-kpi-icon-sm { width: 22px; height: 22px; border-radius: 6px; background: rgba(96,165,250,0.15); display: flex; align-items: center; justify-content: center; color: #60A5FA; flex-shrink: 0; }
    .hero-kpi-icon-sm--green  { background: rgba(52,211,153,0.15); color: #34D399; }
    .hero-kpi-icon-sm--amber  { background: rgba(245,158,11,0.15); color: #F59E0B; }
    .hero-kpi-icon-sm--violet { background: rgba(124,58,237,0.15); color: #A78BFA; }
    .hero-kpi-val { font-size: 28px; font-weight: 800; color: #474a50; line-height: 1.2; display: block; }

    /* ═══════════════════════════════════════════
       PLAN vs ACTUAL GRID
    ═══════════════════════════════════════════ */
    .plan-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; }
    .plan-card { background: var(--card); border-radius: var(--r-lg); padding: 14px 16px; border: 1px solid var(--bdr); }
    .plan-label { font-size: 10.5px; font-weight: 700; color: var(--t3); text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 8px; }
    .plan-row   { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 8px; }
    .plan-sub   { font-size: 9.5px; color: var(--t3); margin-bottom: 2px; }
    .plan-plan-val   { font-size: 13px; font-weight: 700; color: var(--t2); }
    .plan-actual-val { font-size: 14px; font-weight: 800; }
    .plan-bar-track  { height: 5px; background: #F1F5F9; border-radius: 4px; overflow: hidden; margin-bottom: 4px; }
    .plan-bar-fill   { height: 100%; border-radius: 4px; transition: width 1s ease; }
    .plan-ach-row { display: flex; justify-content: space-between; align-items: center; }
    .plan-ach { font-size: 9.5px; font-weight: 600; }
    .plan-ach-pct { font-size: 10.5px; font-weight: 800; }

    /* ═══════════════════════════════════════════
       INNOVATION METRIC CARDS
    ═══════════════════════════════════════════ */
    .metric-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; }
    .metric-card { background: var(--card); border-radius: var(--r-lg); padding: 14px 16px; border: 1px solid var(--bdr); display: flex; align-items: center; gap: 12px; transition: box-shadow 0.2s, transform 0.2s; }
    .metric-card:hover { box-shadow: 0 4px 20px rgba(0,0,0,0.07); transform: translateY(-1px); }
    .metric-icon-box { width: 44px; height: 44px; border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
    .metric-icon-box svg { width: 18px; height: 18px; }
    .metric-icon--brand  { background: rgba(232,93,4,0.12);  color: var(--brand); }
    .metric-icon--blue   { background: var(--blue-bg);       color: var(--blue);  }
    .metric-icon--green  { background: var(--green-bg);      color: var(--green); }
    .metric-icon--violet { background: var(--violet-bg);     color: var(--violet);}
    .metric-body { flex: 1; min-width: 0; }
    .metric-sub-lbl  { font-size: 10.5px; color: var(--t3); font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .metric-big-val  { font-size: 26px; font-weight: 800; color: var(--t1); line-height: 1.1; }
    .metric-foot     { font-size: 9.5px; color: var(--t3); margin-top: 1px; }

    /* ═══════════════════════════════════════════
       BOTTOM ROW
    ═══════════════════════════════════════════ */
    .bottom-row { display: grid; grid-template-columns: 280px 1fr 240px; gap: 10px;  }

    .panel { background: var(--card); border: 1px solid var(--bdr); border-radius: var(--r-xl); overflow: hidden; }
    .panel-head { display: flex; align-items: center; justify-content: space-between; padding: 13px 16px; border-bottom: 1px solid var(--bdr); }
    .panel-title { font-size: 13px; font-weight: 700; color: var(--t1); }
    .panel-sub   { font-size: 11px; color: var(--t3); margin-top: 1px; }
    .panel-body  { padding: 14px 16px; }

    /* Bar chart */
    .panel-chart { display: flex; flex-direction: column;height:350px;}
    .chart-controls { display: flex; align-items: center; gap: 8px; }
    .div-select { font-size: 10px; border: 1px solid var(--bdr); border-radius: 6px; padding: 4px 8px; color: var(--t2); background: var(--muted); outline: none; cursor: pointer; font-family: var(--font); max-width: 100px; }
    .div-select:focus { border-color: var(--brand); }
    .chart-legend { display: flex; align-items: center; gap: 4px; }
    .legend-dot { width: 7px; height: 7px; border-radius: 2px; background: var(--brand); }
    .legend-txt { font-size: 10px; color: var(--t3); }
    .bar-chart { display: flex; align-items: flex-end; gap: 6px; height: 110px; }
    .bar-item  { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 4px; height: 100%; }
    .bar-track { flex: 1; width: 100%; background: var(--muted); border-radius: 4px; overflow: hidden; display: flex; flex-direction: column; justify-content: flex-end; }
    .bar-fill  { background: rgba(232,93,4,0.3); border-radius: 4px; transition: height 0.8s ease; }
    .bar-fill--hi { background: var(--brand); }
    .bar-lbl   { font-size: 9.5px; color: var(--t3); font-weight: 600; }

    /* Department table */
    .panel-dept { display: flex; flex-direction: column;  margin-bottom:0;}
    .dept-tbl { width: 100%; border-collapse: collapse; }
    .dept-tbl th { padding: 8px 12px; text-align: left; font-size: 9.5px; font-weight: 700; color: var(--t3); text-transform: uppercase; letter-spacing: 0.06em; background: var(--muted); border-bottom: 1px solid var(--bdr); white-space: nowrap; }
    .dept-tbl td { padding: 9px 12px; border-bottom: 1px solid #F8FAFC; vertical-align: middle; }
    .dept-tbl tbody tr:last-child td { border-bottom: none; }
    .dept-tbl tbody tr:hover td { background: #FAFBFC; }
    .dept-name { font-size: 12px; font-weight: 600; color: var(--t1); }
    .dept-muted { font-size: 11.5px; color: var(--t3); }
    .dept-num  { font-size: 12.5px; font-weight: 700; color: var(--t1); }
    .dept-cost { font-size: 12px; font-weight: 700; color: var(--brand); }
    .eff-wrap  { display: flex; align-items: center; gap: 6px; }
    .eff-track { flex: 1; height: 4px; background: #F1F5F9; border-radius: 3px; overflow: hidden; min-width: 40px; }
    .eff-fill  { height: 100%; border-radius: 3px; }
    .eff-fill--hi  { background: var(--green); }
    .eff-fill--mid { background: var(--amber); }
    .eff-fill--lo  { background: var(--red); }
    .eff-pct { font-size: 10.5px; font-weight: 700; min-width: 30px; }
    .eff-pct--hi  { color: var(--green); } .eff-pct--mid { color: var(--amber); } .eff-pct--lo { color: var(--red); }
    .export-btn { font-size: 10.5px; color: var(--brand); font-weight: 600; border: none; background: rgba(232,93,4,0.08); cursor: pointer; padding: 4px 9px; border-radius: 6px; font-family: var(--font); white-space: nowrap; }

    /* ── DEPLOYMENT ANALYTICS PANEL ── */
    .panel-deploy { display: flex; flex-direction: column;margin-bottom:0;}
    .deploy-body { flex: 1; padding: 14px 16px; display: flex; flex-direction: column; gap: 14px; }
    .deploy-item { display: flex; flex-direction: column; gap: 6px; }
    .deploy-item-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 8px; }
    .deploy-item-info { flex: 1; }
    .deploy-item-title { font-size: 12px; font-weight: 600; color: var(--t1); }
    .deploy-item-sub   { font-size: 10px; color: var(--t3); margin-top: 1px; }
    .deploy-pct { font-size: 16px; font-weight: 800; flex-shrink: 0; line-height: 1; }
    .deploy-bar-track { height: 6px; background: #F1F5F9; border-radius: 4px; overflow: hidden; }
    .deploy-bar-fill  { height: 100%; border-radius: 4px; transition: width 1s ease; }
    .deploy-bar--orange { background: var(--brand); }

    /* Donut within deployment panel */
    .deploy-donut-section { border-top: 1px solid var(--bdr); padding-top: 12px;  }
    .deploy-donut-label { font-size: 11px; font-weight: 700; color: var(--t2); margin-bottom: 10px; }
    .donut-row { display: flex; align-items: center; gap: 12px; }
    .donut-container { width: 80px; height: 80px; position: relative; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
    .donut-svg { width: 100%; height: 100%; transform: rotate(-90deg); }
    .donut-bg    { fill: none; stroke: #F1F5F9; stroke-width: 4; }
    .donut-track { fill: none; stroke: var(--brand); stroke-width: 4; stroke-linecap: round; transition: stroke-dasharray 0.8s ease; }
    .donut-center { position: absolute; display: flex; flex-direction: column; align-items: center; }
    .donut-pct { font-size: 14px; font-weight: 800; color: var(--t1); line-height: 1; }
    .donut-lbl { font-size: 8.5px; color: var(--t3); margin-top: 1px; font-weight: 500; }
    .donut-stats { display: flex; flex-direction: column; gap: 8px; flex: 1; }
    .ds-item { display: flex; flex-direction: column; gap: 1px; }
    .ds-val { font-size: 18px; font-weight: 800; line-height: 1; }
    .ds-val--green { color: var(--green); }
    .ds-val--muted { color: var(--t3); }
    .ds-lbl { font-size: 10px; color: var(--t3); font-weight: 500; }
    .ds-div { width: 100%; height: 1px; background: var(--bdr); }
    .target-footer { padding: 10px 14px; border-top: 1px solid var(--bdr); background: #FFFBEB; text-align: center; }
    .target-footer-txt { font-size: 10px; color: #B45309; font-weight: 600; }

    /* ═══════════════════════════════════════════
       APPROVALS / TRACKER SHARED TABLE STYLES
    ═══════════════════════════════════════════ */
    .table-wrap { overflow-x: auto; }
    .data-tbl { width: 100%; border-collapse: collapse; }
    .data-tbl th { padding: 10px 18px; font-size: 10px; font-weight: 700; color: var(--t3); text-transform: uppercase; letter-spacing: .07em; background: var(--muted); border-bottom: 1px solid var(--bdr); text-align: left; white-space: nowrap; }
    .data-tbl td { padding: 12px 18px; font-size: 13px; color: var(--t1); border-bottom: 1px solid var(--bdr); vertical-align: middle; }
    .data-tbl tbody tr:last-child td { border-bottom: none; }
    .data-tbl tbody tr:hover td { background: #FAFBFC; }
    .id-tag  { font-size: 11px; font-weight: 700; font-family: monospace; background: var(--muted); border: 1px solid var(--bdr); padding: 3px 7px; border-radius: var(--r-sm); color: var(--t2); white-space: nowrap; }
    .emp-row { display: flex; align-items: center; gap: 8px; white-space: nowrap; }
    .emp-av  { width: 26px; height: 26px; border-radius: 50%; background: var(--violet-bg); color: var(--violet); display: grid; place-items: center; font-size: 10.5px; font-weight: 700; flex-shrink: 0; }
    .td-theme  { max-width: 180px; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; color: var(--t2); }
    .td-remark { max-width: 140px; color: var(--t2); font-size: 12px; }
    .role-tag { display: inline-block; font-size: 10px; font-weight: 700; padding: 2px 9px; border-radius: 20px; white-space: nowrap; text-transform: uppercase; letter-spacing: .04em; background: var(--muted); border: 1px solid var(--bdr); color: var(--t2); }
    .role-tag--op  { background: #ECFDF5; border-color: #A7F3D0; color: #065F46; }
    .role-tag--sup { background: var(--amber-bg); border-color: #FCD34D; color: #92400E; }
    .role-tag--man { background: var(--violet-bg); border-color: #C4B5FD; color: #4C1D95; }
    .status-tag { display: inline-block; font-size: 11px; font-weight: 600; padding: 3px 10px; border-radius: 20px; white-space: nowrap; }
    .st-approved { background: var(--green-bg); color: var(--green); }
    .st-rejected { background: var(--red-bg); color: var(--red); }
    .st-pending  { background: var(--amber-bg); color: var(--amber); }
    .count-tag { background: var(--amber-bg); color: var(--amber); font-size: 11px; font-weight: 700; padding: 4px 10px; border-radius: 20px; white-space: nowrap; }
    .btn-review { background: var(--t1); color: #fff; border: none; padding: 6px 12px; border-radius: var(--r-sm); font-family: var(--font); font-size: 12px; font-weight: 600; cursor: pointer; transition: background 0.15s; white-space: nowrap; }
    .btn-review:hover { background: var(--brand); }
    .tbl-empty { padding: 40px 24px; text-align: center; color: var(--t3); font-size: 13px; border-top: 1px solid var(--bdr); }
    .tbl-empty p { margin-top: 10px; }

    /* Search */
    .search-wrap  { position: relative; }
    .search-ico   { position: absolute; left: 10px; top: 50%; transform: translateY(-50%); color: var(--t3); }
    .search-input { padding: 7px 12px 7px 32px; border: 1px solid var(--bdr); border-radius: var(--r-md); font-family: var(--font); font-size: 12.5px; color: var(--t1); outline: none; background: var(--card); width: 210px; transition: border-color 0.15s; }
    .search-input:focus { border-color: var(--brand); }

    /* ═══════════════════════════════════════════
       REVIEW MODAL
    ═══════════════════════════════════════════ */
    .modal-bg { position: fixed; inset: 0; background: rgba(15,23,42,0.5); backdrop-filter: blur(5px); display: flex; align-items: center; justify-content: center; z-index: 200; padding: 20px; }
    .modal-box { background: var(--card); border-radius: var(--r-xl); width: 100%; max-width: 900px; box-shadow: 0 20px 60px rgba(0,0,0,0.2); display: flex; flex-direction: column; max-height: calc(100vh - 40px); overflow: hidden; }
    .modal-hdr { display: flex; align-items: flex-start; justify-content: space-between; padding: 20px 24px; border-bottom: 1px solid var(--bdr); gap: 16px; flex-shrink: 0; }
    .modal-eyebrow { display: block; font-size: 10px; font-weight: 700; color: var(--brand); text-transform: uppercase; letter-spacing: .07em; margin-bottom: 3px; }
    .modal-id { font-size: 18px; font-weight: 800; color: var(--t1); letter-spacing: -0.4px; }
    .modal-close-btn { width: 32px; height: 32px; border-radius: var(--r-sm); border: 1px solid var(--bdr); background: none; display: grid; place-items: center; cursor: pointer; color: var(--t3); flex-shrink: 0; }
    .modal-close-btn:hover { border-color: var(--bdr2); color: var(--t1); }
    .modal-body { overflow-y: auto; padding: 20px 24px; display: flex; flex-direction: column; gap: 18px; }
    .meta-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; background: var(--muted); border: 1px solid var(--bdr); border-radius: var(--r-lg); padding: 16px; }
    .meta-cell { display: flex; flex-direction: column; gap: 3px; }
    .meta-full  { grid-column: span 2; }
    .meta-label { font-size: 9.5px; font-weight: 700; color: var(--t3); text-transform: uppercase; letter-spacing: .06em; }
    .meta-val   { font-size: 13px; font-weight: 500; color: var(--t1); }
    .meta-desc  { font-size: 12.5px; font-weight: 400; color: var(--t2); line-height: 1.6; }
    .img-compare { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    .img-panel { border-radius: var(--r-lg); overflow: hidden; border: 1px solid var(--bdr); position: relative; background: #F8F9FB; display: flex; flex-direction: column; min-height: 180px; }
    .img-lbl { position: absolute; top: 8px; left: 8px; font-size: 10px; font-weight: 700; padding: 3px 9px; border-radius: var(--r-sm); letter-spacing: .05em; z-index: 2; }
    .img-lbl-before { background: var(--red-bg); color: var(--red); }
    .img-lbl-after  { background: var(--green-bg); color: var(--green); }
    .img-el { width: 100%; height: 220px; object-fit: contain; background: #000; }
    .img-empty { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 8px; color: var(--t3); font-size: 12px; min-height: 140px; }
    .decision-area { display: flex; flex-direction: column; gap: 9px; }
    .decision-label-row label { font-size: 12.5px; font-weight: 700; color: var(--t1); }
    textarea { width: 100%; height: 85px; border: 1px solid var(--bdr); border-radius: var(--r-md); padding: 11px 13px; font-family: var(--font); font-size: 13px; color: var(--t1); background: var(--muted); resize: none; outline: none; transition: border-color 0.15s; }
    textarea:focus { border-color: var(--brand); background: var(--card); }
    .decision-btns { display: flex; gap: 10px; margin-top: 4px; }
    .btn-reject, .btn-approve { display: inline-flex; align-items: center; gap: 7px; padding: 10px 18px; border-radius: var(--r-md); font-family: var(--font); font-size: 13px; font-weight: 700; cursor: pointer; transition: all 0.15s; }
    .btn-reject { background: var(--card); border: 1.5px solid var(--red); color: var(--red); }
    .btn-reject:hover:not(:disabled) { background: var(--red-bg); }
    .btn-reject:disabled { opacity: 0.35; cursor: not-allowed; }
    .btn-approve { flex: 1; background: var(--green); border: none; color: #fff; justify-content: center; }
    .btn-approve:hover { background: #047857; transform: translateY(-1px); }
  `]
})
export class ManagerDashboardComponent implements OnInit {
  public currentView: string = 'insights';
  public sidebarClosed: boolean = false;
  public plantId: string = '';
  public emp_id: string = '';
  public plant: string = '';
  public section: string = '';
  public myTotalCount: number = 0;
  public pendingApprovalCount: number = 0;
  public approvedCount: number = 0;
  public breakthroughCount: number = 0;
  public pendingKaizens: any[] = [];
  public history: any[] = [];
  public filteredHistory: any[] = [];
  public selectedKaizen: any = null;
  public managerRemark: string = '';
  public searchTerm: string = '';
  public selectedDivision: string = 'All Divisions';
  public goalTarget: number = 240;
  public costSaving: string = '₹1.84Cr';

  public deployStats = {
    horizontal: 74,
    vertical: 61,
    replication: 89
  };

  public divisions = ['All Divisions', 'Assembly', 'Paint Shop', 'SCM', 'Quality', 'Weld'];

  public chartData = [
    { month: 'Jan', val: 40 }, { month: 'Feb', val: 70 },
    { month: 'Mar', val: 50 }, { month: 'Apr', val: 90 },
    { month: 'May', val: 60 }, { month: 'Jun', val: 85 }
  ];

  public planMetrics = [
    { label: 'Kaizen Submission',      plan: '320',    actual: '243',      pct: 89, color: '#10B981' },
    { label: 'Cost Saving',            plan: '₹2.4Cr', actual: '₹1.84Cr', pct: 76, color: '#F59E0B' },
    { label: 'Horizontal Deployment',  plan: '140',    actual: '118',      pct: 84, color: '#E85D04' },
    { label: 'Vertical Impl.',         plan: '100',    actual: '86',       pct: 86, color: '#6366F1' },
  ];

  public deptData = [
    { dept: 'Assembly',   plant: 'Plant 1',   kaizens: 126, cost: '₹18.4L', eff: 52 },
    { dept: 'Paint Shop', plant: 'Plant 2',   kaizens: 84,  cost: '₹11.2L', eff: 83 },
    { dept: 'SCM',        plant: 'Corporate', kaizens: 56,  cost: '₹7.9L',  eff: 81 },
    { dept: 'Quality',    plant: 'Plant 3',   kaizens: 72,  cost: '₹9.3L',  eff: 85 },
    { dept: 'Weld',       plant: 'Plant 1',   kaizens: 48,  cost: '₹6.1L',  eff: 67 },
  ];

  public toasts: Toast[] = [];
  private toastCounter = 0;
  public confirmDialog = { visible: false, title: '', message: '', okLabel: 'Confirm', danger: false, callback: () => {} };

  constructor(
    private router: Router,
    private http: HttpClient,
    private cdr: ChangeDetectorRef,
    private route: ActivatedRoute
  ) {}

  showToast(message: string, type: Toast['type'] = 'info', duration = 4000) {
    const id = ++this.toastCounter;
    this.toasts.push({ id, message, type });
    this.cdr.detectChanges();
    setTimeout(() => this.dismissToast(id), duration);
  }
  dismissToast(id: number) { this.toasts = this.toasts.filter(t => t.id !== id); this.cdr.detectChanges(); }

  showConfirm(opts: { title: string; message: string; okLabel?: string; danger?: boolean; callback: () => void; }) {
    this.confirmDialog = { visible: true, title: opts.title, message: opts.message, okLabel: opts.okLabel ?? 'Confirm', danger: opts.danger ?? false, callback: opts.callback };
    this.cdr.detectChanges();
  }
  onConfirmOk() { this.confirmDialog.visible = false; this.confirmDialog.callback(); this.cdr.detectChanges(); }

  ngOnInit(): void {
    this.emp_id  = sessionStorage.getItem('emp_id')   || '';
    this.plant   = sessionStorage.getItem('plant')    || '';
    this.plantId = sessionStorage.getItem('plant_id') || '';
    this.section = sessionStorage.getItem('section')  || '';

    if (!this.plantId || !this.section) {
      this.showToast('Session expired. Please login again.', 'error', 6000);
      setTimeout(() => this.router.navigate(['/admin-login']), 1500);
      return;
    }
    this.route.queryParams.subscribe(params => { if (params['view']) this.currentView = params['view']; });
    this.refreshAllData();
  }

  refreshAllData() {
    this.fetchDbStats();
    this.fetchPendingData();
    this.fetchTrackerData();
  }

  fetchDbStats() {
    const url = `http://localhost:8080/api/manager?action=stats&unit=${encodeURIComponent(this.plant)}&section=${encodeURIComponent(this.section)}`;
    this.http.get<any>(url).subscribe({
      next: (res) => {
        if (!res) return;
        this.myTotalCount         = res.total        ?? 0;
        this.pendingApprovalCount = res.pending       ?? 0;
        this.approvedCount        = res.approved      ?? 0;
        this.breakthroughCount    = res.breakthrough  ?? 0;
        this.costSaving           = res.cost_saving   ?? '₹0';
        if (res.deploy_horizontal)  this.deployStats.horizontal  = res.deploy_horizontal;
        if (res.deploy_vertical)    this.deployStats.vertical    = res.deploy_vertical;
        if (res.deploy_replication) this.deployStats.replication = res.deploy_replication;
        this.cdr.detectChanges();
      },
      error: () => {}
    });
  }

  fetchPendingData() {
    const url = `http://localhost:8080/api/manager?action=pending&unit=${encodeURIComponent(this.plant)}&section=${encodeURIComponent(this.section)}`;
    this.http.get<any[]>(url).subscribe({
      next: (res) => { this.pendingKaizens = res ?? []; this.pendingApprovalCount = this.pendingKaizens.length; this.cdr.detectChanges(); },
      error: () => {}
    });
  }

  fetchTrackerData() {
    const url = `http://localhost:8080/api/manager?action=tracker&unit=${encodeURIComponent(this.plant)}&section=${encodeURIComponent(this.section)}`;
    this.http.get<any[]>(url).subscribe({
      next: (res) => { this.history = res ?? []; this.filteredHistory = res ?? []; this.cdr.detectChanges(); },
      error: () => {}
    });
  }

  openReview(kaizen: any) {
    this.selectedKaizen = kaizen;
    this.managerRemark = '';
    this.cdr.detectChanges();
    this.http.get<any>(`http://localhost:8080/api/kaizen/detail?id=${kaizen.id}&role=${kaizen.role_type}`).subscribe({
      next: (detail) => { this.selectedKaizen = { ...kaizen, ...detail }; this.cdr.detectChanges(); },
      error: () => {}
    });
  }

  updateStatus(status: string) {
    if (!this.selectedKaizen) return;
    if (status === 'Rejected' && !this.managerRemark.trim()) { this.showToast('Rejection requires a manager remark.', 'warning'); return; }
    const payload = { kaizen_id: this.selectedKaizen.kaizen_id, role_type: this.selectedKaizen.role_type, status, manager_remark: this.managerRemark };
    this.http.post('http://localhost:8080/api/manager/update-status', payload).subscribe({
      next: () => {
        this.pendingKaizens = this.pendingKaizens.filter(k => k.kaizen_id !== this.selectedKaizen.kaizen_id);
        this.selectedKaizen = null;
        this.refreshAllData();
        this.showToast(`Kaizen ${status === 'Approved' ? 'approved' : 'rejected'} successfully.`, status === 'Approved' ? 'success' : 'error');
      },
      error: () => this.showToast('Update failed. Please try again.', 'error')
    });
  }

  safeImgSrc(imgData: any): string | null {
    if (!imgData) return null;
    const str = String(imgData).trim();
    if (!str) return null;
    if (str.startsWith('http://') || str.startsWith('https://')) return str;
    if (str.startsWith('data:')) return str;
    if (/\.(jpg|jpeg|png|gif|webp)/i.test(str)) return 'http://localhost/kaizen-backend/uploads/' + str;
    if (str.length > 100) return 'data:image/jpeg;base64,' + str;
    return null;
  }

  filterTrackerData() {
    const term = this.searchTerm.toLowerCase();
    this.filteredHistory = this.history.filter(k =>
      k.emp_name?.toLowerCase().includes(term) ||
      k.theme?.toLowerCase().includes(term) ||
      k.kaizen_id?.toLowerCase().includes(term)
    );
  }

  getPercentage(): number {
    if (!this.approvedCount || !this.goalTarget) return 0;
    return Math.min(100, Math.round((this.approvedCount / this.goalTarget) * 100));
  }

  toggleSidebar() { this.sidebarClosed = !this.sidebarClosed; }

  logout() {
    this.showConfirm({
      title: 'Sign Out', message: 'Are you sure you want to sign out of the portal?',
      okLabel: 'Sign Out', danger: true,
      callback: () => { sessionStorage.clear(); this.router.navigate(['/login']); }
    });
  }
}