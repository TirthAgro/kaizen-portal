import { Component, OnInit, HostListener, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-toast',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="toast-wrapper" [class.show]="visible">
      <div class="toast-icon">⏱️</div>
      <div class="toast-body">
        <span class="toast-title">Session Expired</span>
        <span class="toast-msg">Please login again to continue.</span>
      </div>
      <div class="toast-progress"></div>
    </div>
  `,
  styles: [`
    .toast-wrapper {
      position: fixed;
      bottom: 30px;
      right: 30px;
      z-index: 9999;
      display: flex;
      align-items: center;
      gap: 12px;
      min-width: 300px;
      padding: 16px 20px;
      border-radius: 14px;
      background: #1e1e2e;
      box-shadow: 0 8px 32px rgba(0,0,0,0.4);
      border-left: 4px solid #f87171;
      transform: translateX(120%);
      opacity: 0;
      overflow: hidden;
      transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
    }
    .toast-wrapper.show {
      transform: translateX(0);
      opacity: 1;
    }
    .toast-icon { font-size: 24px; flex-shrink: 0; }
    .toast-body { display: flex; flex-direction: column; gap: 3px; }
    .toast-title {
      font-size: 13px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: #f87171;
    }
    .toast-msg { font-size: 13px; color: #94a3b8; }
    .toast-progress {
      position: absolute;
      bottom: 0; left: 0;
      height: 3px;
      width: 100%;
      background: #f87171;
      animation: shrink 3s linear forwards;
    }
    @keyframes shrink {
      from { width: 100%; }
      to   { width: 0%; }
    }
  `]
})
export class ToastComponent {
  visible = false;
}

// ─────────────────────────────────────────────

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterModule, RouterOutlet, ToastComponent],
  template: `
    <router-outlet></router-outlet>
    <app-toast #sessionToast></app-toast>
  `
})
export class AppComponent implements OnInit, OnDestroy {
  private timeout: any;
  private readonly TIMEOUT_MS = 30 * 60 * 1000;

  // ViewChild ke bina direct reference ke liye
  private toastEl: ToastComponent | null = null;

  constructor(private router: Router) {}

  ngOnInit() { this.resetTimer(); }

  ngOnDestroy() { clearTimeout(this.timeout); }

  @HostListener('document:mousemove')
  @HostListener('document:keypress')
  @HostListener('document:click')
  resetTimer() {
    clearTimeout(this.timeout);
    this.timeout = setTimeout(() => {
      sessionStorage.clear();
      localStorage.clear();
      this.showToast();
      setTimeout(() => this.router.navigate(['/login']), 3000);
    }, this.TIMEOUT_MS);
  }

  private showToast() {
    const toastEl = document.querySelector('app-toast .toast-wrapper');
    if (toastEl) {
      toastEl.classList.add('show');
      setTimeout(() => toastEl.classList.remove('show'), 3500);
    }
  }
}