import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';

import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx-js-style';

@Component({
  selector: 'app-download-report',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, HttpClientModule],
  encapsulation: ViewEncapsulation.None,
  template: `
<div class="rpt-page">

  <!-- ══════════════ PAGE HEADER ══════════════ -->
  <div class="rpt-header">
    <div class="rpt-header__left">
      <div class="rpt-header__icon">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
          <polyline points="14 2 14 8 20 8"/>
          <line x1="16" y1="13" x2="8" y2="13"/>
          <line x1="16" y1="17" x2="8" y2="17"/>
          <polyline points="10 9 9 9 8 9"/>
        </svg>
      </div>
      <div>
        <h1 class="rpt-header__title">Master Analytics & Reports</h1>
        <p class="rpt-header__sub">Filter, view and export Kaizen records across all units</p>
      </div>
    </div>

    <div class="rpt-header__right">
      <div class="rpt-count-card">
        <span class="rpt-count-card__label">Records Found</span>
        <span class="rpt-count-card__value">{{ filteredData.length }}</span>
      </div>
      <button class="rpt-export-btn rpt-export-btn--excel"
              (click)="exportExcel()" [disabled]="filteredData.length === 0">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
          <polyline points="7 10 12 15 17 10"/>
          <line x1="12" y1="15" x2="12" y2="3"/>
        </svg>
        Export Excel
      </button>
      <button class="rpt-export-btn rpt-export-btn--pdf"
              (click)="exportPDF()" [disabled]="filteredData.length === 0">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
          <polyline points="7 10 12 15 17 10"/>
          <line x1="12" y1="15" x2="12" y2="3"/>
        </svg>
        Export PDF
      </button>
    </div>
  </div>

  <!-- ══════════════ FILTER PANEL ══════════════ -->
  <div class="rpt-filter-panel">
    <div class="rpt-filter-panel__title-row">
      <div class="rpt-filter-panel__title-wrap">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
          <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>
        </svg>
        Filters
      </div>
      <button class="rpt-clear-btn" (click)="clearFilters()">Clear All</button>
    </div>

    <div class="rpt-filter-grid">
      <!-- Search -->
      <div class="rpt-fg rpt-fg--wide">
        <label class="rpt-fl">Global Search</label>
        <div class="rpt-search-wrap">
          <svg class="rpt-search-ico" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
          <input class="rpt-input" type="text" [(ngModel)]="filters.search"
                 (input)="fetchReportData()"
                 placeholder="Search Kaizen No, Theme, Section…">
        </div>
      </div>

      <!-- From Date -->
      <div class="rpt-fg">
        <label class="rpt-fl">From Date</label>
        <input class="rpt-input" type="date" [(ngModel)]="filters.fromDate"
               (change)="fetchReportData()">
      </div>

      <!-- To Date -->
      <div class="rpt-fg">
        <label class="rpt-fl">To Date</label>
        <input class="rpt-input" type="date" [(ngModel)]="filters.toDate"
               (change)="fetchReportData()">
      </div>

      <!-- Unit -->
      <div class="rpt-fg">
        <label class="rpt-fl">Unit</label>
        <select class="rpt-input" [(ngModel)]="filters.unit" (change)="fetchReportData()">
          <option value="">All Units</option>
          <option *ngFor="let u of units" [value]="u">{{ u }}</option>
        </select>
      </div>

      <!-- Role -->
      <div class="rpt-fg">
        <label class="rpt-fl">Role</label>
        <select class="rpt-input" [(ngModel)]="filters.role" (change)="fetchReportData()">
          <option value="">All Roles</option>
          <option value="Operator">Operator</option>
          <option value="Supervisor">Supervisor</option>
          <option value="Manager">Manager</option>
        </select>
      </div>

      <!-- Status -->
      <div class="rpt-fg">
        <label class="rpt-fl">Status</label>
        <select class="rpt-input" [(ngModel)]="filters.status" (change)="fetchReportData()">
          <option value="">All Status</option>
          <option value="Approved">Approved</option>
          <option value="Pending">Pending</option>
          <option value="Rejected">Rejected</option>
        </select>
      </div>
    </div>

    <!-- Active filter chips -->
    <div class="rpt-chips" *ngIf="hasActiveFilters()">
      <span class="rpt-chip" *ngIf="filters.unit">
        Unit: {{ filters.unit }}
        <button (click)="filters.unit=''; fetchReportData()">×</button>
      </span>
      <span class="rpt-chip" *ngIf="filters.role">
        Role: {{ filters.role }}
        <button (click)="filters.role=''; fetchReportData()">×</button>
      </span>
      <span class="rpt-chip" *ngIf="filters.status">
        Status: {{ filters.status }}
        <button (click)="filters.status=''; fetchReportData()">×</button>
      </span>
      <span class="rpt-chip" *ngIf="filters.fromDate">
        From: {{ filters.fromDate }}
        <button (click)="filters.fromDate=''; fetchReportData()">×</button>
      </span>
      <span class="rpt-chip" *ngIf="filters.toDate">
        To: {{ filters.toDate }}
        <button (click)="filters.toDate=''; fetchReportData()">×</button>
      </span>
    </div>
  </div>

  <!-- ══════════════ DATA TABLE ══════════════ -->
  <div class="rpt-table-panel">
    <div class="rpt-table-panel__head">
      <span class="rpt-table-panel__label">
        Showing <strong>{{ filteredData.length }}</strong> record{{ filteredData.length !== 1 ? 's' : '' }}
      </span>
      <span class="rpt-table-panel__hint">Click any row to view full details</span>
    </div>

    <div class="rpt-table-wrap">
      <table class="rpt-table">
        <thead>
          <tr>
            <th class="th-sno">#</th>
            <th>Kaizen ID</th>
            <th>Role</th>
            <th>Theme</th>
            <th>Unit</th>
            <th>Section</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let row of filteredData; let i = index"
              (click)="viewKaizen(row)" class="rpt-row">
            <td class="td-sno">{{ i + 1 }}</td>
            <td><span class="rpt-id-tag">{{ row.kaizen_id }}</span></td>
            <td>
              <span class="rpt-role-tag"
                [class.rpt-role-tag--op]="row.role === 'Operator'"
                [class.rpt-role-tag--sup]="row.role === 'Supervisor'"
                [class.rpt-role-tag--man]="row.role === 'Manager'">
                {{ row.role }}
              </span>
            </td>
            <td class="td-theme">{{ row.theme }}</td>
            <td class="td-muted">{{ row.unit }}</td>
            <td class="td-muted">{{ row.section || '—' }}</td>
            <td>
              <span class="rpt-status-tag"
                [class.rpt-status-tag--ap]="row.status === 'Approved'"
                [class.rpt-status-tag--rj]="row.status === 'Rejected'"
                [class.rpt-status-tag--pn]="row.status === 'Pending' || !row.status">
                {{ row.status || 'Pending' }}
              </span>
            </td>
          </tr>
        </tbody>
      </table>

      <!-- Empty state -->
      <div class="rpt-empty" *ngIf="filteredData.length === 0">
        <div class="rpt-empty__icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" opacity=".4">
            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
        </div>
        <p class="rpt-empty__title">No records found</p>
        <p class="rpt-empty__sub">Try adjusting your filters to see results</p>
      </div>
    </div>
  </div>

</div>
  `,
  styles: [`
   @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

/* ═══════════════════════════════════════
   ULTRA MODERN ANALYTICS REPORT UI
═══════════════════════════════════════ */

:host{
  --brand:#f97316;
  --brand-dark:#ea580c;
  --brand2:#8b5cf6;
  --brand3:#06b6d4;

  --card: #FFFFFF;
  --card2: #FDF8F2;

  --success:#10b981;
  --danger:#ef4444;
  --warning:#f59e0b;

  --text:#0f172a;
  --text2: #64748B;
  --muted:#94a3b8;

  --primary: #E8541A;
  --primary-2: #F97316;
  --primary-soft: rgba(232,84,26,.1);
 



  --glass:rgba(255,255,255,.78);
  --glass-strong:rgba(255,255,255,.92);

  --border:rgba(255,255,255,.65);

  --shadow:
    0 10px 40px rgba(15,23,42,.08),
    0 2px 12px rgba(15,23,42,.04);

  --radius:28px;

  --font:'Plus Jakarta Sans',sans-serif;
}

*{
  margin:0;
  padding:0;
  box-sizing:border-box;
}

html,
body{
  overflow-x:hidden;
}

/* ═════════ PAGE ═════════ */
.rpt-page{
  font-family:'Poppins';

  min-height:100vh;
  padding:30px;

  background:
    rgb(253, 244, 228);

  display:flex;
  flex-direction:column;
  gap:24px;

  color:var(--text);
}

/* ═════════ HEADER ═════════ */
.rpt-header{
 display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  margin-bottom: 22px;
  padding: 16px 22px;
  border-radius: 20px;
  background: #FFFFFF;
  border: 1px solid var(--border);
  box-shadow: 0 2px 12px rgba(28,25,23,.06);
}

.rpt-header__left{
  display:flex;
  align-items:center;
  gap:18px;
}

.rpt-header__icon{
  width: 52px;
  height: 52px;
  border-radius: 16px;
  background: linear-gradient(135deg, #E8541A, #F97316);
  display: flex;
  align-items: center;
  justify-content: center;
}

.rpt-header__title{
  font-size: 20px;
  font-weight: 800;
  letter-spacing: -.4px;
  color: #E8541A;
}

.rpt-header__sub{
  margin-top:6px;

  font-size:14px;
  font-weight:500;

  color: #64748B;;
}

/* RIGHT */
.rpt-header__right{
  display:flex;
  align-items:center;
  gap:14px;
  flex-wrap:wrap;
}

/* COUNT CARD */
.rpt-count-card{
  min-width:150px;

  padding:16px 20px;

  border-radius:22px;

  background:linear-gradient(135deg,#f97316,#fb923c);

  color:#fff;

  text-align:center;

  box-shadow:
    0 12px 28px rgba(249,115,22,.25);
}

.rpt-count-card__label{
  display:block;

  font-size:10px;
  font-weight:800;

  letter-spacing:2px;
  text-transform:uppercase;

  opacity:.8;
}

.rpt-count-card__value{
  display:block;

  margin-top:4px;

  font-size:32px;
  font-weight:800;
  line-height:1;
}

/* EXPORT BUTTONS */
.rpt-export-btn{
  border:none;
  outline:none;

  display:flex;
  align-items:center;
  justify-content:center;
  gap:8px;

  height:50px;
  padding:0 20px;

  border-radius:16px;

  font-family:'Poppins';
  font-size:13px;
  font-weight:700;

  cursor:pointer;
  transition:.25s ease;

  color:#fff;

  box-shadow:var(--shadow);
}

.rpt-export-btn:hover:not(:disabled){
  transform:translateY(-2px);
}

.rpt-export-btn:disabled{
  opacity:.45;
  cursor:not-allowed;
}

.rpt-export-btn--excel{
  background:linear-gradient(135deg,#16a34a,#22c55e);
}

.rpt-export-btn--pdf{
  background:linear-gradient(135deg,#dc2626,#ef4444);
}

/* ═════════ FILTER PANEL ═════════ */
.rpt-filter-panel{
  position:relative;

  padding:28px;

  border-radius:32px;

  background:rgba(255, 255, 255, 0.95);
  backdrop-filter:blur(18px);

  border:1px solid var(--border);

  box-shadow:var(--shadow);

  overflow:hidden;
}

.rpt-filter-panel::before{
  content:"";
  position:absolute;
  inset:0;

  background:
    linear-gradient(135deg,
      rgba(249,115,22,.04),
      rgba(139,92,246,.04));

  pointer-events:none;
}

.rpt-filter-panel__title-row{
  display:flex;
  align-items:center;
  justify-content:space-between;
  color: #E8541A;

  gap:14px;

  margin-bottom:24px;

  position:relative;
  z-index:2;
}

.rpt-filter-panel__title-wrap{
  display:flex;
  align-items:center;
  gap:10px;

  font-size:15px;
  font-weight:800;

  color:var(--text);
}

/* CLEAR BUTTON */
.rpt-clear-btn{
  border:none;
  outline:none;

  height:40px;
  padding:0 16px;

  border-radius:14px;

  background:rgba(239,68,68,.10);
  color:#dc2626;

  font-family:'Poppins';
  font-size:12px;
  font-weight:700;

  cursor:pointer;
  transition:.22s ease;
}

.rpt-clear-btn:hover{
  background:#ef4444;
  color:#fff;
}

/* ═════════ FILTER GRID ═════════ */
.rpt-filter-grid{
  position:relative;
  z-index:2;

  display:grid;

  grid-template-columns:
    minmax(280px,2fr)
    repeat(5,minmax(150px,1fr));

  gap:18px;
}

.rpt-fg{
  min-width:0;
}

.rpt-fg--wide{
  min-width:280px;
}

.rpt-fl{
  display:block;

  margin-bottom:10px;

  font-size:11px;
  font-weight:800;

  letter-spacing:1px;
  text-transform:uppercase;

  color: #1a1b1b;
}

/* INPUTS */
.rpt-input{
  width:100%;
  min-width:0;

  height:52px;

  border-radius:18px;
  border:1px solid #dbe3ee;

  background:rgba(255, 255, 255, 0.94);

  padding:0 16px;

  font-family:'Poppins';
  font-size:13px;
  font-weight:600;

  color: #000000;

  outline:none;

  transition:.22s ease;

  appearance:none;
}

.rpt-input::placeholder{
  color:#94a3b8;
  font-weight:600;
}

.rpt-input:hover{
  border-color:#cbd5e1;
}

.rpt-input:focus{
  border-color:rgba(249,115,22,.5);

  background:#fff;

  box-shadow:
    0 0 0 4px rgba(249,115,22,.10);
}

/* SEARCH */
.rpt-search-wrap{
  position:relative;
}

.rpt-search-ico{
  position:absolute;
  left:16px;
  top:50%;
  transform:translateY(-50%);

  color:#94a3b8;
  z-index:2;
}

.rpt-search-wrap .rpt-input{
  padding-left:44px;
}

/* SELECT */
select.rpt-input{
  padding-right:40px;
  cursor:pointer;

  background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='%2364748b' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E");

  background-repeat:no-repeat;
  background-position:right 14px center;
  color:grey;
}

/* DATE */
input[type="date"].rpt-input{
  padding-right:14px;
  color:grey;
}

/* CHIPS */
.rpt-chips{
  display:flex;
  flex-wrap:wrap;
  gap:10px;

  margin-top:24px;
  padding-top:20px;

  border-top:1px dashed rgba(148,163,184,.35);

  position:relative;
  z-index:2;
}

.rpt-chip{
  display:flex;
  align-items:center;
  gap:8px;

  padding:8px 14px;

  border-radius:999px;

  background:
    linear-gradient(135deg,
      rgba(249,115,22,.12),
      rgba(139,92,246,.08));

  border:1px solid rgba(249,115,22,.14);

  font-size:12px;
  font-weight:700;

  color:var(--brand);
}

.rpt-chip button{
  border:none;
  background:none;

  cursor:pointer;

  color:inherit;

  font-size:15px;
}

/* ═════════ TABLE PANEL ═════════ */
.rpt-table-panel{
  overflow:hidden;

  border-radius:32px;

  background:rgba(255, 255, 255, 0.93);
  backdrop-filter:blur(16px);

  border:1px solid var(--border);

  box-shadow:var(--shadow);
}

/* HEAD */
.rpt-table-panel__head{
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:12px;

  padding:20px 26px;

  border-bottom:1px solid rgba(226,232,240,.8);

  background:
    linear-gradient(135deg,
      rgba(249,115,22,.05),
      rgba(139,92,246,.03));
}

.rpt-table-panel__label{
  font-size:13px;
  font-weight:600;
  color: #E8541A;
}

.rpt-table-panel__label strong{
  color:var(--brand);
}

.rpt-table-panel__hint{
  font-size:12px;
  color:#64748b;
}

/* TABLE */
.rpt-table-wrap{
  overflow-x:auto;
}

.rpt-table{
  width:100%;
  min-width:1050px;

  border-collapse:collapse;
  table-layout:fixed;
}

/* ALIGNMENT FIX */
.rpt-table th,
.rpt-table td{
  text-align:left;
  vertical-align:middle;
}

/* HEADER */
.rpt-table thead th{
  padding:18px;

  font-size:11px;
  font-weight:800;

  letter-spacing:1px;
  text-transform:uppercase;

  color: #181818;

  background:#f8fafc;

  border-bottom:1px solid #e2e8f0;
}

/* BODY */
.rpt-table tbody td{
  padding:20px 18px;

  font-size:13px;
  font-weight:600;

  color:grey;

  border-bottom:1px solid #f1f5f9;
}

.rpt-row{
  transition:.22s ease;
  cursor:pointer;
}

.rpt-row:hover td{
  background:
    linear-gradient(135deg,
      rgba(249,115,22,.05),
      rgba(139,92,246,.03));
}

/* COLUMN FIX */
.th-sno,
.td-sno{
  width:70px;
  text-align:center !important;
}

.rpt-table th:nth-child(2),
.rpt-table td:nth-child(2){
  width:170px;
}

.rpt-table th:nth-child(3),
.rpt-table td:nth-child(3){
  width:170px;
}

.rpt-table th:nth-child(5),
.rpt-table td:nth-child(5){
  width:150px;
}

.rpt-table th:nth-child(6),
.rpt-table td:nth-child(6){
  width:150px;
}

.rpt-table th:nth-child(7),
.rpt-table td:nth-child(7){
  width:170px;
}

/* TEXT */
.td-theme{
  white-space:nowrap;
  overflow:hidden;
  text-overflow:ellipsis;

  font-weight:700;
}

.td-muted{
  color:var(--text2);
}

/* ID TAG */
.rpt-id-tag{
  display:inline-flex;
  align-items:center;

  padding:8px 14px;

  border-radius:12px;

  background:
    linear-gradient(135deg,
      rgba(249,115,22,.12),
      rgba(249,115,22,.05));

  border:1px solid rgba(249,115,22,.15);

  color:var(--brand-dark);

  font-family:monospace;
  font-size:12px;
  font-weight:800;
}

/* ROLE TAG */
.rpt-role-tag{
  display:inline-flex;
  align-items:center;
  justify-content:center;

  min-width:100px;

  padding:8px 14px;

  border-radius:999px;

  font-size:11px;
  font-weight:800;

  letter-spacing:.4px;
  text-transform:uppercase;
}

.rpt-role-tag--op{
  background:rgba(16,185,129,.12);
  color:#047857;
}

.rpt-role-tag--sup{
  background:rgba(245,158,11,.12);
  color:#b45309;
}

.rpt-role-tag--man{
  background:rgba(139,92,246,.12);
  color:#6d28d9;
}

/* STATUS */
.rpt-status-tag{
  display:inline-flex;
  align-items:center;
  justify-content:center;

  min-width:100px;

  padding:8px 14px;

  border-radius:999px;

  font-size:11px;
  font-weight:800;
}

.rpt-status-tag--ap{
  background:rgba(16,185,129,.12);
  color:#047857;
}

.rpt-status-tag--rj{
  background:rgba(239,68,68,.12);
  color:#dc2626;
}

.rpt-status-tag--pn{
  background:rgba(245,158,11,.12);
  color:#b45309;
}

/* EMPTY */
.rpt-empty{
  padding:90px 24px;
  text-align:center;
}

.rpt-empty__icon{
  width:80px;
  height:80px;

  margin:0 auto 18px;

  border-radius:24px;

  display:flex;
  align-items:center;
  justify-content:center;

  background:
    linear-gradient(135deg,
      rgba(249,115,22,.08),
      rgba(139,92,246,.08));

  color:#94a3b8;
}

.rpt-empty__title{
  font-size:18px;
  font-weight:800;
  color:var(--text);
}

.rpt-empty__sub{
  margin-top:5px;

  font-size:13px;
  color:#94a3b8;
}

/* SCROLLBAR */
.rpt-table-wrap::-webkit-scrollbar{
  height:8px;
}

.rpt-table-wrap::-webkit-scrollbar-thumb{
  background:rgba(148,163,184,.35);
  border-radius:999px;
}

/* ═════════ RESPONSIVE ═════════ */
@media(max-width:1250px){

  .rpt-filter-grid{
    grid-template-columns:repeat(2,1fr);
  }

  .rpt-fg--wide{
    grid-column:span 2;
  }

}

@media(max-width:768px){

  .rpt-page{
    padding:18px;
  }

  .rpt-header{
    padding:22px;
    flex-direction:column;
    align-items:flex-start;
  }

  .rpt-header__title{
    font-size:24px;
  }

  .rpt-header__right{
    width:100%;
  }

  .rpt-count-card{
    width:100%;
  }

  .rpt-export-btn{
    flex:1;
  }

  .rpt-filter-panel{
    padding:22px;
  }

  .rpt-filter-grid{
    grid-template-columns:1fr;
  }

  .rpt-fg--wide{
    grid-column:auto;
  }

  .rpt-table-panel__head{
    flex-direction:column;
    align-items:flex-start;
  }

}

@media(max-width:640px){

  .rpt-table{
    min-width:900px;
  }

}
  `]
})
export class DownloadReportComponent implements OnInit {
  api = 'http://localhost:8080/api/bex';
  units = ['Unit 1', 'Unit 2', 'Unit 3', 'Unit 4', 'Unit 5'];
  filteredData: any[] = [];

  filters = {
    search:    '',
    unit:      '',
    role:      '',
    status:    '',
    fromDate:  '',
    toDate:    ''
  };

  constructor(
    private http: HttpClient,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() { this.fetchReportData(); }

  fetchReportData() {
    const params = new URLSearchParams({
      action:  'master_list',
      unit:    this.filters.unit,
      role:    this.filters.role,
      status:  this.filters.status,
      search:  this.filters.search,
      from:    this.filters.fromDate,
      to:      this.filters.toDate
    });
    this.http.get<any[]>(`${this.api}?${params.toString()}`).subscribe({
      next: (res) => { this.filteredData = res ?? []; this.cdr.detectChanges(); },
      error: () => {}
    });
  }

  hasActiveFilters(): boolean {
    return !!(this.filters.unit || this.filters.role || this.filters.status
           || this.filters.fromDate || this.filters.toDate);
  }

  clearFilters() {
    this.filters = { search: '', unit: '', role: '', status: '', fromDate: '', toDate: '' };
    this.fetchReportData();
  }

  viewKaizen(row: any) {
    const role = (row.role || '').toLowerCase();
    const type = role === 'operator'   ? 'operator_kaizen'
               : role === 'supervisor' ? 'supervisor_kaizen'
               :                        'manager_kaizen';
    this.router.navigate(['/glob-kaizen'], { queryParams: { id: row.id, type } });
  }

  getStatusClass(status: string): string {
    if (status === 'Approved') return 'status-approved';
    if (status === 'Rejected') return 'status-rejected';
    return 'status-pending';
  }

  // ─────────────────────────────────────────────────────────────
  // EXCEL EXPORT
  // ─────────────────────────────────────────────────────────────
  exportExcel() {
    const wb = XLSX.utils.book_new();
    const ws: any = {};

    const titleStyle = {
      font: { bold: true, sz: 16, color: { rgb: '000000' } },
      alignment: { horizontal: 'center', vertical: 'center', wrapText: true }
    };
    const formatStyle = {
      font: { sz: 9 },
      alignment: { horizontal: 'left', vertical: 'center', wrapText: true }
    };
    const headerStyle = {
      font: { bold: true, sz: 9, color: { rgb: '000000' } },
      fill: { fgColor: { rgb: 'F2F2F2' } },
      alignment: { horizontal: 'center', vertical: 'center', wrapText: true },
      border: {
        top:    { style: 'thin', color: { rgb: '000000' } },
        bottom: { style: 'thin', color: { rgb: '000000' } },
        left:   { style: 'thin', color: { rgb: '000000' } },
        right:  { style: 'thin', color: { rgb: '000000' } }
      }
    };
    const dataStyle = {
      font: { sz: 9 },
      alignment: { horizontal: 'center', vertical: 'center', wrapText: true },
      border: {
        top:    { style: 'thin', color: { rgb: 'CCCCCC' } },
        bottom: { style: 'thin', color: { rgb: 'CCCCCC' } },
        left:   { style: 'thin', color: { rgb: 'CCCCCC' } },
        right:  { style: 'thin', color: { rgb: 'CCCCCC' } }
      }
    };
    const dataLeftStyle = {
      ...dataStyle,
      alignment: { horizontal: 'left', vertical: 'center', wrapText: true }
    };

    const C = (v: any, t: string, s: any) => ({ v, t, s });

    ws['!cols'] = [
      { wch: 5 }, { wch: 9 }, { wch: 12 }, { wch: 14 }, { wch: 32 },
      { wch: 20 }, { wch: 20 }, { wch: 12 }, { wch: 12 }, { wch: 28 },
      { wch: 26 }, { wch: 26 }, { wch: 30 }, { wch: 8 }, { wch: 18 },
      { wch: 28 }, { wch: 18 }
    ];
    ws['!rows'] = [{ hpt: 45 }, { hpt: 80 }];
    ws['!merges'] = [
      { s: { r: 0, c: 0  }, e: { r: 0, c: 1  } },
      { s: { r: 0, c: 2  }, e: { r: 0, c: 12 } },
      { s: { r: 0, c: 13 }, e: { r: 0, c: 16 } }
    ];

    ws['A1'] = C('SHAKTIMAN', 's', {
      font: { bold: true, sz: 10, color: { rgb: 'E85D04' } },
      alignment: { horizontal: 'center', vertical: 'center' }
    });
    ws['C1'] = C('KAIZEN Registration', 's', titleStyle);
    ws['N1'] = C('Format No. : TA/QMS/KR\nRevision : 00   04.04.2026', 's', formatStyle);

    const headers: [string, string][] = [
      ['A2','Sr\nNo'], ['B2','Month\n/\nYear'], ['C2','Business\nUnit'],
      ['D2','Deptt. /\nSection'], ['E2','KAIZEN THEME'],
      ['F2','Kaizen Type\nRestorative /\nRenovative /\nInnovative /\nBreakthrough /\nRoutine'],
      ['G2','Kaizen Category\nSee at Sheet NO. 2'], ['H2','Category\ncode\nSee at Sheet\nNO. 2'],
      ['I2','Group\nPQCDSME\n- 5S'],
      ['J2','Advantage description\nPQCDSME – 5S\n(Measurable Achievement)'],
      ['K2','KMI\n(Update relavant KMI\nExclusively for Best\nKaizens)'],
      ['L2','KPI\n(Update relavant KPI\nExclusively for\nBest Kaizens)'],
      ['M2','Kaizen\nPerformed\nby'], ['N2','Count'],
      ['O2','Certified by\nProcess\nOwner'],
      ['P2','CFT Verification\n(applicable in case\nof Critical change\nrelated to\nProcess / Product)'],
      ['Q2','Approved by\nHOD / BU\nHead']
    ];
    headers.forEach(([addr, val]) => { ws[addr] = C(val, 's', headerStyle); });

    const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    this.filteredData.forEach((row, i) => {
      const r = i + 3;
      const dateObj = new Date(row.created_at);
      const monthYear = isNaN(dateObj.getTime())
        ? '' : `${months[dateObj.getMonth()]} / ${dateObj.getFullYear()}`;
      const perf: string = row.performed_by || row.emp_name || '';

      const cols: [string, any, string][] = [
        [`A${r}`, i+1, 'n'], [`B${r}`, monthYear, 's'],
        [`C${r}`, row.unit || '', 's'], [`D${r}`, row.section || '', 's'],
        [`E${r}`, row.theme || '', 's'], [`F${r}`, row.kaizen_type || '', 's'],
        [`G${r}`, row.kaizen_category || '', 's'], [`H${r}`, row.category_code || '', 's'],
        [`I${r}`, row.pqcdsm || '', 's'], [`J${r}`, row.advantage_desc || '', 's'],
        [`K${r}`, row.kmi || '', 's'], [`L${r}`, row.kpi || '', 's'],
        [`M${r}`, perf, 's'], [`N${r}`, row.emp_count ?? 0, 'n'],
        [`O${r}`, row.certified_by || '', 's'], [`P${r}`, row.cft_verification || '', 's'],
        [`Q${r}`, row.approved_by || '', 's']
      ];
      cols.forEach(([addr, val, type]) => {
        const style = (addr.startsWith('E') || addr.startsWith('J') || addr.startsWith('M'))
          ? dataLeftStyle : dataStyle;
        ws[addr] = C(val, type, style);
      });
      if (!ws['!rows']) ws['!rows'] = [];
      ws['!rows'][r - 1] = { hpt: Math.max(25, perf.split('\n').length * 15) };
    });

    ws['!ref'] = `A1:Q${Math.max(this.filteredData.length + 2, 2)}`;
    XLSX.utils.book_append_sheet(wb, ws, 'Kaizen Registration');
    XLSX.writeFile(wb, `Kaizen_Registration_${Date.now()}.xlsx`);
  }

  // ─────────────────────────────────────────────────────────────
  // PDF EXPORT
  // ─────────────────────────────────────────────────────────────
  exportPDF() {
    const doc: any = new jsPDF('l', 'mm', 'a4');
    const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text('KAIZEN Registration', 148, 12, { align: 'center' });
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text('Format No. : TA/QMS/KR  |  Revision : 00   04.04.2026', 270, 10, { align: 'right' });

    const headers = [[
      'Sr\nNo','Month/\nYear','Unit','Section','KAIZEN THEME',
      'Kaizen\nType','Category','Cat.\nCode','Group\nPQCDSME',
      'Advantage\nDesc.','KMI','KPI','Performed\nby','Count',
      'Certified\nby','CFT\nVerify','Approved\nby'
    ]];

    const body = this.filteredData.map((row, i) => {
      const dateObj = new Date(row.created_at);
      const monthYear = isNaN(dateObj.getTime())
        ? '' : `${months[dateObj.getMonth()]}/${dateObj.getFullYear()}`;
      return [
        i+1, monthYear, row.unit||'', row.section||'',
        (row.theme||'').substring(0,35), row.kaizen_type||'',
        row.kaizen_category||'', row.category_code||'', row.pqcdsm||'',
        (row.advantage_desc||'').substring(0,20), row.kmi||'', row.kpi||'',
        row.performed_by || row.emp_name || '', row.emp_count??0,
        row.certified_by||'', row.cft_verification||'', row.approved_by||''
      ];
    });

    (doc as any).autoTable({
      head: headers, body,
      startY: 18, theme: 'grid',
      styles: { fontSize: 7, cellPadding: 2, valign: 'middle', halign: 'center' },
      headStyles: { fillColor: [242,242,242], textColor: [0,0,0], fontStyle: 'bold', fontSize: 7 },
      columnStyles: {
        0:{cellWidth:8}, 1:{cellWidth:13}, 2:{cellWidth:13}, 3:{cellWidth:13},
        4:{cellWidth:28,halign:'left'}, 5:{cellWidth:16}, 6:{cellWidth:16},
        7:{cellWidth:11}, 8:{cellWidth:13}, 9:{cellWidth:18,halign:'left'},
        10:{cellWidth:14}, 11:{cellWidth:14}, 12:{cellWidth:16,halign:'left'},
        13:{cellWidth:8}, 14:{cellWidth:14}, 15:{cellWidth:16}, 16:{cellWidth:14}
      }
    });

    doc.save(`Kaizen_Registration_${Date.now()}.pdf`);
  }
}