import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

// ── Toast model ──────────────────────────────────────────────
interface Toast {
  id: number;
  message: string;
  type: 'success' | 'error' | 'warning' | 'info';
}

@Component({
  selector: 'app-glob-kaizen',
  standalone: true,
  imports: [CommonModule, HttpClientModule, FormsModule],
  encapsulation: ViewEncapsulation.None,
  template: `
<div class="gk-page">

  <!-- ══════════════ TOAST STACK ══════════════ -->
  <div class="gk-toast-stack">
    <div
      *ngFor="let t of toasts"
      class="gk-toast"
      [class.gk-toast--success]="t.type === 'success'"
      [class.gk-toast--error]="t.type === 'error'"
      [class.gk-toast--warning]="t.type === 'warning'"
      [class.gk-toast--info]="t.type === 'info'"
    >
      <div class="gk-toast__icon">
        <svg *ngIf="t.type==='success'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>
        <svg *ngIf="t.type==='error'"   viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        <svg *ngIf="t.type==='warning'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
        <svg *ngIf="t.type==='info'"    viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
      </div>
      <span class="gk-toast__msg">{{ t.message }}</span>
      <button class="gk-toast__close" (click)="dismissToast(t.id)">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>
  </div>

  <!-- ══════════════ HEADER ══════════════ -->
  <div class="gk-header">
    <div class="gk-header__left">
      <div class="gk-header__icon">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round">
          <circle cx="12" cy="12" r="10"/>
          <line x1="2" y1="12" x2="22" y2="12"/>
          <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
        </svg>
      </div>
      <div>
        <h1 class="gk-header__title">Global Kaizen Repository</h1>
        <p class="gk-header__sub">Business Excellence Management Portal</p>
      </div>
    </div>
    <div class="gk-header__right">
      <div class="gk-count-card">
        <span class="gk-count-card__lbl">Total Records</span>
        <span class="gk-count-card__val">{{ filteredKaizens.length }}</span>
      </div>
      <button class="gk-refresh-btn" (click)="fetchAllKaizens()">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
          <polyline points="23 4 23 10 17 10"/>
          <polyline points="1 20 1 14 7 14"/>
          <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
        </svg>
        Refresh Data
      </button>
    </div>
  </div>

  <!-- ══════════════ FILTER PANEL ══════════════ -->
  <div class="gk-filter-panel">
    <div class="gk-filter-panel__top">
      <div class="gk-filter-panel__title">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
          <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>
        </svg>
        Filters
      </div>
      <button class="gk-clear-btn" (click)="clearAllFilters()">Clear All</button>
    </div>

    <div class="gk-filter-grid">
      <div class="gk-fg gk-fg--wide">
        <label class="gk-fl">Search Theme / ID</label>
        <div class="gk-search-wrap">
          <svg class="gk-search-ico" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
          <input class="gk-input" type="text" [(ngModel)]="filters.search"
                 (input)="applyFilters()" placeholder="Type to search…">
        </div>
      </div>

      <div class="gk-fg">
        <label class="gk-fl">Unit</label>
        <select class="gk-input" [(ngModel)]="filters.unit" (change)="applyFilters()">
          <option value="">All Units</option>
          <option value="Unit 1">Unit 1</option>
          <option value="Unit 2">Unit 2</option>
          <option value="Unit 3">Unit 3</option>
          <option value="Unit 4">Unit 4</option>
          <option value="Unit 5">Unit 5</option>
        </select>
      </div>

      <div class="gk-fg">
        <label class="gk-fl">Role</label>
        <select class="gk-input" [(ngModel)]="filters.role" (change)="applyFilters()">
          <option value="">All Roles</option>
          <option value="Operator">Operator</option>
          <option value="Supervisor">Supervisor</option>
          <option value="Manager">Manager</option>
        </select>
      </div>

      <div class="gk-fg">
        <label class="gk-fl">Status</label>
        <select class="gk-input" [(ngModel)]="filters.status" (change)="applyFilters()">
          <option value="">All Status</option>
          <option value="Pending">Pending</option>
          <option value="Approved">Approved</option>
          <option value="Rejected">Rejected</option>
        </select>
      </div>
    </div>

    <div class="gk-chips" *ngIf="filters.unit || filters.role || filters.status">
      <span class="gk-chip" *ngIf="filters.unit">
        Unit: {{ filters.unit }}
        <button (click)="filters.unit=''; applyFilters()">×</button>
      </span>
      <span class="gk-chip" *ngIf="filters.role">
        Role: {{ filters.role }}
        <button (click)="filters.role=''; applyFilters()">×</button>
      </span>
      <span class="gk-chip" *ngIf="filters.status">
        Status: {{ filters.status }}
        <button (click)="filters.status=''; applyFilters()">×</button>
      </span>
    </div>
  </div>

  <!-- ══════════════ LOADING ══════════════ -->
  <div class="gk-loading" *ngIf="isLoading">
    <div class="gk-spinner"></div>
    <p>Accessing Secure Records…</p>
  </div>

  <!-- ══════════════ TABLE ══════════════ -->
  <div class="gk-table-panel" *ngIf="!isLoading">
    <div class="gk-table-panel__head">
      <span class="gk-table-panel__lbl">
        Showing <strong>{{ filteredKaizens.length }}</strong>
        of <strong>{{ allKaizens.length }}</strong> records
      </span>
      <span class="gk-table-panel__hint">Click Review Audit to inspect a record</span>
    </div>

    <div class="gk-table-wrap">
      <table class="gk-table">
        <thead>
          <tr>
            <th class="th-sno">#</th>
            <th>Kaizen ID</th>
            <th>Role</th>
            <th>Plant Unit</th>
            <th>Department</th>
            <th>Kaizen Theme</th>
            <th>Status</th>
            <th class="th-action">Action</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let k of filteredKaizens; let i = index" class="gk-row">
            <td class="td-sno">{{ i + 1 }}</td>
            <td><span class="gk-id-tag">{{ k.kaizen_id }}</span></td>
            <td>
              <span class="gk-role-tag"
                [class.gk-role-tag--op]="k.role === 'Operator'"
                [class.gk-role-tag--sup]="k.role === 'Supervisor'"
                [class.gk-role-tag--man]="k.role === 'Manager'">
                {{ k.role }}
              </span>
            </td>
            <td class="td-muted">{{ k.unit }}</td>
            <td class="td-muted">{{ k.section }}</td>
            <td class="td-theme" [title]="k.theme">{{ k.theme }}</td>
            <td>
              <span class="gk-status-tag"
                [class.gk-status-tag--ap]="k.status === 'Approved'"
                [class.gk-status-tag--rj]="k.status === 'Rejected'"
                [class.gk-status-tag--pn]="k.status === 'Pending' || !k.status">
                {{ k.status || 'Pending' }}
              </span>
            </td>
            <td class="td-action">
              <button class="gk-audit-btn" (click)="openAudit(k)">
                Review Audit →
              </button>
            </td>
          </tr>
        </tbody>
      </table>

      <div class="gk-empty" *ngIf="filteredKaizens.length === 0">
        <div class="gk-empty__icon">
          <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" opacity=".4">
            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
        </div>
        <p class="gk-empty__title">No records match your criteria</p>
        <p class="gk-empty__sub">Try adjusting or clearing the filters above</p>
      </div>
    </div>
  </div>

</div>

<!-- ══════════════ AUDIT MODAL ══════════════ -->
<div class="gk-modal-bg" *ngIf="showModal" (click)="showModal = false">
  <div class="gk-modal" (click)="$event.stopPropagation()">

    <div class="gk-modal__hdr">
      <div>
        <span class="gk-modal__eyebrow">Kaizen Master Audit</span>
        <h2 class="gk-modal__id">{{ selectedKaizen?.kaizen_id }}</h2>
      </div>
      <button class="gk-modal__close" (click)="showModal = false">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
          <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
        </svg>
      </button>
    </div>

    <div class="gk-modal__body">

      <div class="gk-section-lbl">General Information</div>
      <div class="gk-info-grid">
        <div class="gk-info-cell">
          <span class="gk-info-label">Originator</span>
          <span class="gk-info-val">{{ selectedKaizen?.emp_name }} ({{ selectedKaizen?.emp_id }})</span>
        </div>
        <div class="gk-info-cell">
          <span class="gk-info-label">Plant / Unit</span>
          <span class="gk-info-val">{{ selectedKaizen?.unit }}</span>
        </div>
        <div class="gk-info-cell">
          <span class="gk-info-label">Department</span>
          <span class="gk-info-val">{{ selectedKaizen?.section }}</span>
        </div>
        <div class="gk-info-cell">
          <span class="gk-info-label">Machine No</span>
          <span class="gk-info-val">{{ selectedKaizen?.machine_no || 'N/A' }}</span>
        </div>
        <div class="gk-info-cell">
          <span class="gk-info-label">Kaizen Type</span>
          <span class="gk-info-val">{{ selectedKaizen?.kaizen_type || '—' }}</span>
        </div>
        <div class="gk-info-cell">
          <span class="gk-info-label">Category</span>
          <span class="gk-info-val">{{ selectedKaizen?.kaizen_category || '—' }}</span>
        </div>
        <div class="gk-info-cell">
          <span class="gk-info-label">PQCDSM</span>
          <span class="gk-info-val">{{ selectedKaizen?.pqcdsm || '—' }}</span>
        </div>
        <div class="gk-info-cell">
          <span class="gk-info-label">Submission Date</span>
          <span class="gk-info-val">{{ selectedKaizen?.created_at | date:'dd MMM yyyy, hh:mm a' }}</span>
        </div>
      </div>

      <div class="gk-section-lbl">Visual Evidence</div>
      <div class="gk-img-compare">
        <div class="gk-img-panel">
          <div class="gk-img-lbl gk-img-lbl--before">Before</div>
          <img *ngIf="safeImgSrc(selectedKaizen?.before_img)"
               [src]="safeImgSrc(selectedKaizen?.before_img)"
               class="gk-img-el" alt="Before">
          <div *ngIf="!safeImgSrc(selectedKaizen?.before_img)" class="gk-img-empty">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3">
              <rect x="3" y="3" width="18" height="18" rx="2"/>
              <circle cx="8.5" cy="8.5" r="1.5"/>
              <polyline points="21 15 16 10 5 21"/>
            </svg>
            <span>No image available</span>
          </div>
          <p class="gk-img-desc" *ngIf="selectedKaizen?.before_desc">{{ selectedKaizen.before_desc }}</p>
        </div>
        <div class="gk-img-panel">
          <div class="gk-img-lbl gk-img-lbl--after">After</div>
          <img *ngIf="safeImgSrc(selectedKaizen?.after_img)"
               [src]="safeImgSrc(selectedKaizen?.after_img)"
               class="gk-img-el" alt="After">
          <div *ngIf="!safeImgSrc(selectedKaizen?.after_img)" class="gk-img-empty">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3">
              <rect x="3" y="3" width="18" height="18" rx="2"/>
              <circle cx="8.5" cy="8.5" r="1.5"/>
              <polyline points="21 15 16 10 5 21"/>
            </svg>
            <span>No image available</span>
          </div>
          <p class="gk-img-desc" *ngIf="selectedKaizen?.after_desc">{{ selectedKaizen.after_desc }}</p>
        </div>
      </div>

      <div class="gk-section-lbl">Kaizen Details</div>
      <div class="gk-detail-grid">
        <div class="gk-detail-cell gk-detail-cell--full">
          <span class="gk-info-label">Improvement Theme</span>
          <p class="gk-detail-val">{{ selectedKaizen?.theme }}</p>
        </div>
        <div class="gk-detail-cell gk-detail-cell--full">
          <span class="gk-info-label">Problem Description / Idea</span>
          <p class="gk-detail-val">{{ selectedKaizen?.idea || 'Refer to attachments for visual details.' }}</p>
        </div>
        <div class="gk-detail-cell gk-detail-cell--full" *ngIf="selectedKaizen?.role === 'Manager'">
          <span class="gk-info-label">Managerial Impact & Benefits (PQCDSM)</span>
          <p class="gk-detail-val gk-detail-val--highlight">
            {{ selectedKaizen?.benefits_pqcdsm || 'Standard Managerial Improvement' }}
          </p>
        </div>
        <div class="gk-detail-cell gk-detail-cell--full" *ngIf="selectedKaizen?.role === 'Supervisor'">
          <span class="gk-info-label">Root Cause Analysis</span>
          <p class="gk-detail-val">{{ selectedKaizen?.root_cause || 'Process optimization focus.' }}</p>
        </div>
        <div class="gk-detail-cell gk-detail-cell--full">
          <span class="gk-info-label">Horizontal Deployment</span>
          <p class="gk-detail-val">{{ selectedKaizen?.horizantal_deployment || 'Not applicable' }}</p>
        </div>
      </div>

      <div class="gk-section-lbl">Business Excellence Verdict</div>
      <div class="gk-verdict">
        <label class="gk-verdict__lbl">Audit Remarks</label>
        <textarea class="gk-verdict__ta" [(ngModel)]="bexRemark"
          placeholder="Provide reason for approval or rejection…"></textarea>
        <div class="gk-verdict__btns">
          <button class="gk-btn-reject" (click)="updateStatus('Rejected')">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
            Reject Kaizen
          </button>
          <button class="gk-btn-approve" (click)="updateStatus('Approved')">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
              <polyline points="20 6 9 17 4 12"/>
            </svg>
            Authorize & Approve
          </button>
        </div>
      </div>

    </div>
  </div>
</div>
  `,
  styles: [`
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

/* ════════════════════════════════
   TOAST SYSTEM
════════════════════════════════ */
.gk-toast-stack {
  position: fixed;
  top: 20px;
  right: 20px;
  z-index: 9999;
  display: flex;
  flex-direction: column;
  gap: 10px;
  pointer-events: none;
}

.gk-toast {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px 16px;
  border-radius: 18px;
  background: #fff;
  box-shadow: 0 8px 32px rgba(0,0,0,0.13), 0 2px 8px rgba(0,0,0,0.06);
  border-left: 4px solid transparent;
  min-width: 290px;
  max-width: 390px;
  pointer-events: all;
  animation: gkToastIn 0.28s cubic-bezier(0.34,1.56,0.64,1) forwards;
}

@keyframes gkToastIn {
  from { opacity: 0; transform: translateX(60px) scale(0.95); }
  to   { opacity: 1; transform: translateX(0) scale(1); }
}

.gk-toast--success { border-left-color: #22C55E; }
.gk-toast--error   { border-left-color: #EF4444; }
.gk-toast--warning { border-left-color: #F59E0B; }
.gk-toast--info    { border-left-color: #3B82F6; }

.gk-toast__icon {
  width: 34px; height: 34px;
  border-radius: 10px;
  display: grid; place-items: center;
  flex-shrink: 0;
}
.gk-toast__icon svg { width: 17px; height: 17px; }

.gk-toast--success .gk-toast__icon { background: #DCFCE7; color: #16A34A; }
.gk-toast--error   .gk-toast__icon { background: #FEE2E2; color: #DC2626; }
.gk-toast--warning .gk-toast__icon { background: #FEF3C7; color: #D97706; }
.gk-toast--info    .gk-toast__icon { background: #DBEAFE; color: #2563EB; }

.gk-toast__msg {
  flex: 1;
  font-size: 13.5px;
  font-weight: 500;
  color: #1E293B;
  line-height: 1.45;
}

.gk-toast__close {
  width: 26px; height: 26px;
  border-radius: 8px;
  border: none;
  background: none;
  cursor: pointer;
  color: #94A3B8;
  display: grid; place-items: center;
  flex-shrink: 0;
  transition: background 0.15s, color 0.15s;
}
.gk-toast__close svg { width: 13px; height: 13px; }
.gk-toast__close:hover { background: #F1F5F9; color: #1E293B; }

/* ════════════════════════════════
   PREMIUM LIGHT MODERN UI
════════════════════════════════ */
:host{
  --primary:#FF6B35;
  --primary-2:#FF8C42;
  --primary-soft:rgba(255,107,53,.14);
  --success:#22C55E;
  --danger:#EF4444;
  --warning:#F59E0B;
  --purple:#8B5CF6;
  --cyan:#06B6D4;
  --card: #FFFFFF;
  --card2: #FDF8F2;
  --text:#1E293B;
  --text-light:#64748B;
  --text-fade:#94A3B8;
  --bg:#FFF7F2;
  --card:#FFFFFF;
  --card-soft:#FFFDFB;
  --border:#F1E5DD;
  --border-2:#E2E8F0;
  --shadow-sm:0 4px 14px rgba(15,23,42,.05);
  --shadow-md:0 10px 40px rgba(255,107,53,.10);
  --shadow-lg:0 25px 60px rgba(255,107,53,.16);
  --radius-sm:12px;
  --radius-md:18px;
  --radius-lg:24px;
  --radius-xl:30px;
  --font:'Plus Jakarta Sans',sans-serif;
}

.gk-page{
  min-height:100vh;
  background:
    rgb(253, 244, 228);
  padding:30px;
  display:flex;
  flex-direction:column;
  gap:24px;
  font-family:var(--font);
  color:var(--text);
}

.gk-header{ display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  margin-bottom: 22px;
  padding: 16px 22px;
  border-radius: 20px;
  background: #FFFFFF;
  border: 1px solid var(--border);
  box-shadow: 0 2px 12px rgba(28,25,23,.06);
 }

.gk-header__left{ display:flex; align-items:center; gap:18px; }

.gk-header__icon{
  width:62px; height:62px;
  border-radius:22px;
  background:linear-gradient(135deg,#f97316,#fb923c);
  color:white;
  display:grid; place-items:center;
  box-shadow:0 12px 30px rgba(255,107,53,.28), inset 0 1px 2px rgba(255,255,255,.3);
}

.gk-header__title{
  font-size: 20px;
  font-weight: 800;
  letter-spacing: -.4px;
  color:  #E8541A;
}

.gk-header__sub{
  color:#64748B;
  font-size:13px;
  font-weight:600;
  margin-top: 0;
} 
.gk-header__right{ display:flex; align-items:center; gap:14px; }

.gk-count-card{
  min-width:110px; height:40px;  padding:14px 22px; border-radius:22px;
  background:linear-gradient(135deg, #f97316, #fb923c);
  border:1px solid #FFE1D3; text-align:center; box-shadow:var(--shadow-sm);
}
.gk-count-card__lbl{ display:block; font-size:11px; font-weight:800; text-transform:uppercase; letter-spacing:.08em; color:#fffefd; }
.gk-count-card__val{ display:block; margin-top:-4px; font-size:30px; font-weight:800; color:#FFFFFF; }

.gk-refresh-btn{
  height:52px; padding:0 22px; border:none; border-radius:18px;
  background:linear-gradient(135deg,var(--primary),var(--primary-2));
  color:#ff8000;
  display:flex; align-items:center; gap:8px;
  font-family:var(--font); font-size:13px; font-weight:700;
  cursor:pointer; transition:.25s ease;
  box-shadow:0 12px 28px rgba(255,107,53,.22);
}
.gk-refresh-btn:hover{ transform:translateY(-2px) scale(1.01); }

.gk-filter-panel{
  background:rgba(255,255,255,.82); backdrop-filter:blur(18px);
  border:1px solid rgba(255,255,255,.8); border-radius:30px;
  padding:26px; box-shadow:0 10px 40px rgba(255,107,53,.10); overflow:hidden;
}

.gk-filter-panel__top{
  display:flex; justify-content:space-between; align-items:center;
  margin-bottom:16px; gap:16px; flex-wrap:wrap;
}

.gk-filter-panel__title{ display:flex; align-items:center; gap:10px; font-size:16px; font-weight:800; color:#EA580C; }

.gk-clear-btn{
  border:none; background:#FFF1EA; color:#EA580C;
  height:42px; padding:0 18px; border-radius:14px;
  font-size:12px; font-weight:700; cursor:pointer; transition:.25s ease;
}
.gk-clear-btn:hover{ background:#FFE4D5; transform:translateY(-1px); }

.gk-filter-grid{
  display:grid;
  grid-template-columns:minmax(260px,1.4fr) repeat(3,minmax(180px,1fr));
  gap:18px; width:100%;
}

.gk-fg{ width:100%; min-width:0; }
.gk-fg--wide{ width:100%; }

.gk-fl{ display:block; margin-bottom:10px; font-size:11px; font-weight:800; color:#64748B; text-transform:uppercase; letter-spacing:.08em; }

.gk-search-wrap{ position:relative; width:100%; }
.gk-search-ico{ position:absolute; left:16px; top:50%; transform:translateY(-50%); color:#FB923C; }
.gk-search-wrap .gk-input{ padding-left:46px; }

.gk-input{
  width:100% !important; min-width:0; height:56px;
  border:1.5px solid #F3DED2; background:#FFFDFC; border-radius:18px;
  padding:0 18px; font-family:var(--font); font-size:14px; font-weight:600;
  color:var(--text); outline:none; transition:.25s ease; box-sizing:border-box;
}
.gk-input::placeholder{ color:Grey; font-weight:500; }
.gk-input:focus{
  border-color:#FF8C42; background:#fff;
  box-shadow:0 0 0 5px rgba(255,140,66,.10), 0 8px 20px rgba(255,107,53,.08);
}

select.gk-input{
  appearance:none;
  background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='%23FB923C' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E");
  background-repeat:no-repeat; background-position:right 16px center;
  padding-right:42px; cursor:pointer;
  color:grey;
  font-size:14px; font-weight:600;
}

.gk-chips{ display:flex; flex-wrap:wrap; gap:10px; margin-top:22px; padding-top:18px; border-top:1px solid #F5E7DF; }
.gk-chip{
  display:flex; align-items:center; gap:8px; padding:9px 14px;
  border-radius:999px; background:linear-gradient(135deg,#FFF1EA,#FFE7DA);
  border:1px solid #FFD7C2; color:#EA580C; font-size:12px; font-weight:700;
}
.gk-chip button{
  width:20px; height:20px; border:none; border-radius:50%;
  background:rgba(255,255,255,.7); color:#EA580C; cursor:pointer;
  display:grid; place-items:center; font-size:12px; font-weight:800;
}

.gk-table-panel{
  background:rgba(255,255,255,.86); backdrop-filter:blur(14px);
  border-radius:30px; overflow:hidden; box-shadow:var(--shadow-lg);
}
.gk-table-panel__head{
  padding:22px 26px; display:flex; justify-content:space-between; align-items:center;
  flex-wrap:wrap; gap:12px; border-bottom:1px solid #F6E8DF; 
}
.gk-table-panel__lbl{ font-size:14px; color:#E8541A; }
.gk-table-panel__lbl strong{ color:var(--primary); }
.gk-table-panel__hint{ font-size:12px; color:#FB923C; font-weight:600; }

.gk-table{ width:100%; border-collapse:collapse; }
.gk-table th{
  background: #FFF8F3; padding:16px 18px; font-size:11px; font-weight:800;
  text-transform:uppercase; letter-spacing:.08em; color: #524747;
  border-bottom:1px solid #FBE4D6; text-align:left;
}
.gk-table td{ padding:18px; border-bottom:1px solid #F8EEE8; font-size:13.5px; }
.gk-row{ transition:.2s ease; }
.gk-row:hover{ background:linear-gradient(90deg,#FFF8F4,#FFFFFF); }
.td-theme{ font-weight:700; color:#334155; }
.td-muted { color: #64748B; }

.gk-id-tag{
  background:#FFF1EA; color:#EA580C; border:1px solid #FFD7C2;
  padding:6px 12px; border-radius:12px; font-size:12px; font-weight:800; font-family:monospace;
}

.gk-role-tag{
  display:inline-flex; align-items:center; padding:7px 12px;
  border-radius:999px; font-size:11px; font-weight:800; letter-spacing:.05em; text-transform:uppercase; color:gray;
}
.gk-status-tag{
  display:inline-flex; align-items:center; padding:7px 14px;
  border-radius:999px; font-size:11px; font-weight:800;
}
.gk-status-tag--ap{ background:#DCFCE7; color:#15803D; }
.gk-status-tag--rj{ background:#FEE2E2; color:#B91C1C; }
.gk-status-tag--pn{ background:#FEF3C7; color:#B45309; }

.gk-audit-btn{
  border:none;
  background:linear-gradient(135deg,#FF6B35,#FB923C);
  color:#fff; padding:11px 18px; border-radius:14px;
  font-family:var(--font); font-size:12px; font-weight:700;
  cursor:pointer; transition:.25s ease;
  box-shadow:0 10px 24px rgba(255,107,53,.18);
}
.gk-audit-btn:hover{ transform:translateY(-2px); }

.gk-empty{ padding:56px 24px; text-align:center; }
.gk-empty__icon{ display:flex; justify-content:center; margin-bottom:12px; }
.gk-empty__title{ font-size:15px; font-weight:700; color:#64748B; }
.gk-empty__sub{ font-size:13px; color:#94A3B8; margin-top:4px; }

.gk-loading{ display:flex; flex-direction:column; align-items:center; gap:14px; padding:60px; color:#94A3B8; font-size:14px; }
.gk-spinner{
  width:36px; height:36px; border-radius:50%;
  border:3px solid #FFE4D5; border-top-color:#FF6B35;
  animation:gkSpin 0.8s linear infinite;
}
@keyframes gkSpin{ to{ transform:rotate(360deg); } }

.gk-modal-bg{
  position:fixed; inset:0; background:rgba(255,153,102,.18);
  backdrop-filter:blur(10px); display:flex; align-items:center;
  justify-content:center; padding:30px; z-index:999;
}
.gk-modal{
  width:100%; max-width:980px; max-height:92vh; overflow:hidden;
  background:#fff; border-radius:32px;
  box-shadow:0 30px 80px rgba(255,107,53,.22);
  display:flex; flex-direction:column;
}
.gk-modal__hdr{
  padding:28px 30px; display:flex; justify-content:space-between;
  align-items:flex-start; border-bottom:1px solid #F5E7DF;
}
.gk-modal__eyebrow{ display:block; font-size:11px; font-weight:800; color:#FB923C; text-transform:uppercase; letter-spacing:.08em; }
.gk-modal__id{
  margin-top:6px; font-size:28px; font-weight:800;
  background:linear-gradient(90deg,#FF6B35,#F97316);
  -webkit-background-clip:text; -webkit-text-fill-color:transparent;
}
.gk-modal__close{
  width:44px; height:44px; border:none; border-radius:16px;
  background:#FFF3ED; color:#F97316; display:grid; place-items:center;
  cursor:pointer; transition:.2s ease;
}
.gk-modal__close:hover{ background:#FFE4D5; }
.gk-modal__body{ padding:28px; overflow-y:auto; display:flex; flex-direction:column; gap:22px; }

.gk-section-lbl{ font-size:11px; font-weight:800; color:#F97316; text-transform:uppercase; letter-spacing:.08em; }

.gk-info-grid{
  display:grid; grid-template-columns:repeat(2,1fr); gap:16px;
  background:#FFF9F5; border-radius:24px; padding:20px; border:1px solid #FBE4D6;
}
.gk-info-cell{ background:#fff; border-radius:18px; padding:16px; border:1px solid #F5E7DF; }
.gk-info-label{ display:block; font-size:10px; font-weight:800; color:#94A3B8; text-transform:uppercase; letter-spacing:.08em; margin-bottom:6px; }
.gk-info-val{ font-size:14px; font-weight:600; }

.gk-img-compare{ display:grid; grid-template-columns:1fr 1fr; gap:18px; }
.gk-img-panel{
  overflow:hidden; border-radius:24px; background:#fff;
  border:1px solid #F5E7DF; box-shadow:var(--shadow-sm); position:relative;
}
.gk-img-lbl{ position:absolute; top:14px; left:14px; z-index:2; padding:6px 12px; border-radius:999px; font-size:11px; font-weight:800; }
.gk-img-lbl--before{ background:#FEE2E2; color:#DC2626; }
.gk-img-lbl--after { background:#DCFCE7; color:#15803D; }
.gk-img-el{ width:100%; height:260px; object-fit:contain; background:#FFF8F3; }
.gk-img-empty{
  display:flex; flex-direction:column; align-items:center; justify-content:center;
  gap:10px; min-height:180px; color:#94A3B8; font-size:13px;
}
.gk-img-desc{ padding:16px; font-size:13px; color:#64748B; line-height:1.6; }

.gk-detail-grid{ display:flex; flex-direction:column; gap:14px; }
.gk-detail-val{
  background:#FFFDFC; border:1px solid #F5E7DF; border-radius:18px;
  padding:16px; margin-top:6px; line-height:1.7; color:#475569;
}
.gk-detail-val--highlight{ background:#FFF7ED; border-left:4px solid #F59E0B; }

.gk-verdict{
  background:#FFF9F5; border-radius:24px; padding:24px;
  border:1px solid #FBE4D6; display:flex; flex-direction:column; gap:16px;
}
.gk-verdict__lbl{ font-size:14px; font-weight:800; }
.gk-verdict__ta{
  width:100%; min-height:110px; border:1.5px solid #F5E7DF; background:#fff;
  border-radius:18px; padding:16px; font-family:var(--font); font-size:14px;
  resize:none; outline:none; transition:.2s ease;
}
.gk-verdict__ta:focus{ border-color:#FF8C42; box-shadow:0 0 0 5px rgba(255,140,66,.12); }
.gk-verdict__btns{ display:flex; gap:14px; }

.gk-btn-reject,.gk-btn-approve{
  flex:1; height:52px; border:none; border-radius:18px;
  display:flex; align-items:center; justify-content:center; gap:8px;
  font-family:var(--font); font-size:14px; font-weight:800;
  cursor:pointer; transition:.25s ease;
}
.gk-btn-reject{ background:#fff; color:#DC2626; border:1.5px solid #FECACA; }
.gk-btn-reject:hover{ background:#FEF2F2; }
.gk-btn-approve{
  background:linear-gradient(135deg,#22C55E,#16A34A);
  color:#fff; box-shadow:0 14px 30px rgba(34,197,94,.20);
}
.gk-btn-approve:hover{ transform:translateY(-2px); }

@media(max-width:1200px){ .gk-filter-grid{ grid-template-columns:1fr 1fr; } }
@media(max-width:768px){
  .gk-filter-panel{ padding:20px; }
  .gk-filter-grid{ grid-template-columns:1fr; }
  .gk-input{ height:52px; }
  .gk-clear-btn{ width:100%; }
}
  `]
})
export class GlobKaizenComponent implements OnInit {
  apiBase = 'http://localhost:8080/api/bex';
  isLoading = true;
  allKaizens: any[] = [];
  filteredKaizens: any[] = [];

  filters = { unit: '', role: '', status: '', search: '' };
  showModal = false;
  selectedKaizen: any = null;
  bexRemark = '';

  // ── Toast state ────────────────────────────────────────────
  public toasts: Toast[] = [];
  private toastCounter = 0;

  constructor(private http: HttpClient, private cdr: ChangeDetectorRef) {}

  ngOnInit() { this.fetchAllKaizens(); }

  // ─────────────────────────────────────────────────────────────
  //  Toast helpers
  // ─────────────────────────────────────────────────────────────
  showToast(message: string, type: Toast['type'] = 'info', duration = 4000) {
    const id = ++this.toastCounter;
    this.toasts.push({ id, message, type });
    this.cdr.detectChanges();
    setTimeout(() => this.dismissToast(id), duration);
  }

  dismissToast(id: number) {
    this.toasts = this.toasts.filter(t => t.id !== id);
    this.cdr.detectChanges();
  }

  // ─────────────────────────────────────────────────────────────
  //  Data methods
  // ─────────────────────────────────────────────────────────────
  fetchAllKaizens() {
    this.isLoading = true;
    this.http.get<any[]>(`${this.apiBase}?action=master_list`).subscribe({
      next: (res) => {
        this.allKaizens = Array.isArray(res) ? res : [];
        this.applyFilters();
        this.isLoading = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.isLoading = false;
        this.cdr.detectChanges();
      }
    });
  }

  applyFilters() {
    this.filteredKaizens = this.allKaizens.filter(k => {
      const matchUnit   = !this.filters.unit   || k.unit   === this.filters.unit;
      const matchRole   = !this.filters.role   || k.role   === this.filters.role;
      const matchStatus = !this.filters.status || k.status === this.filters.status;
      const matchSearch = !this.filters.search ||
        k.theme?.toLowerCase().includes(this.filters.search.toLowerCase()) ||
        k.kaizen_id?.toLowerCase().includes(this.filters.search.toLowerCase());
      return matchUnit && matchRole && matchStatus && matchSearch;
    });
  }

  clearAllFilters() {
    this.filters = { unit: '', role: '', status: '', search: '' };
    this.applyFilters();
  }

  safeImgSrc(imgData: any): string | null {
    if (!imgData) return null;
    const str = String(imgData).trim();
    if (!str) return null;
    if (str.startsWith('http://') || str.startsWith('https://')) return str;
    if (str.startsWith('data:')) return str;
    if (/\.(jpg|jpeg|png|gif|webp)/i.test(str)) {
      return 'http://localhost/kaizen-backend/uploads/' + str;
    }
    if (str.length > 100) return 'data:image/jpeg;base64,' + str;
    return null;
  }

  openAudit(kaizen: any) {
    this.selectedKaizen = kaizen;
    this.bexRemark = kaizen.admin_remark || '';
    this.showModal = true;
  }

  updateStatus(newStatus: string) {
    // ✅ REPLACED: alert('Please provide a remark for rejection.')
    if (!this.bexRemark && newStatus === 'Rejected') {
      this.showToast('A remark is required before rejecting a Kaizen.', 'warning');
      return;
    }

    const payload = {
      id:     this.selectedKaizen.id,
      role:   this.selectedKaizen.role,
      status: newStatus,
      remark: this.bexRemark
    };

    this.http.post(`${this.apiBase}/final-update`, payload).subscribe({
      next: (res: any) => {
        if (res.status === 'updated') {
          // ✅ REPLACED: alert(`Kaizen … has been ${newStatus} successfully.`)
          this.showToast(
            `Kaizen ${this.selectedKaizen.kaizen_id} ${newStatus === 'Approved' ? 'approved' : 'rejected'} successfully.`,
            newStatus === 'Approved' ? 'success' : 'error'
          );
          this.showModal = false;
          this.fetchAllKaizens();
        } else {
          // ✅ REPLACED: alert('Update failed: …')
          this.showToast('Update failed: ' + (res.message || 'Unknown error'), 'error');
        }
      },
      // ✅ REPLACED: alert('Server error during update.')
      error: () => this.showToast('Server error during update. Please try again.', 'error')
    });
  }
}