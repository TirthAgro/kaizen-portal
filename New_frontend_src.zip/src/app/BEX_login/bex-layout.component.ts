import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';

@Component({
  selector: 'app-bex-layout',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="bex-shell">

      <!-- ═══════ SIDEBAR ═══════ -->
      <aside class="bex-sidebar" [class.collapsed]="sidebarClosed">

        <div class="bex-brand">
          <div class="bex-brand-mark">
            <svg width="22" height="22" viewBox="0 0 20 20" fill="none">
              <rect x="2" y="2" width="7" height="7" rx="1.5" fill="#f97316"/>
              <rect x="11" y="2" width="7" height="7" rx="1.5" fill="#f97316" opacity="0.5"/>
              <rect x="2" y="11" width="7" height="7" rx="1.5" fill="#f97316" opacity="0.5"/>
              <rect x="11" y="11" width="7" height="7" rx="1.5" fill="#f97316" opacity="0.3"/>
            </svg>
          </div>
          <div class="bex-brand-text" *ngIf="!sidebarClosed">
            <span class="bex-brand-name">BEX</span>
            <span class="bex-brand-sub">PRECISION</span>
          </div>
        </div>

        <nav class="bex-nav">
          <div class="bex-nav-label" *ngIf="!sidebarClosed">NAVIGATION</div>

          <a routerLink="/bex-dashboard" routerLinkActive="active" class="bex-nav-item">
            <div class="bex-nav-icon">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                <rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/>
                <rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>
              </svg>
            </div>
            <span class="bex-nav-label-item" *ngIf="!sidebarClosed">Dashboard</span>
            <div class="bex-nav-active-bar"></div>
          </a>

          <a routerLink="/manage-users" routerLinkActive="active" class="bex-nav-item">
            <div class="bex-nav-icon">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                <circle cx="9" cy="7" r="4"/>
                <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
              </svg>
            </div>
            <span class="bex-nav-label-item" *ngIf="!sidebarClosed">User Control</span>
            <div class="bex-nav-active-bar"></div>
          </a>

          <a routerLink="/report" routerLinkActive="active" class="bex-nav-item">
            <div class="bex-nav-icon">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                <line x1="18" y1="20" x2="18" y2="10"/>
                <line x1="12" y1="20" x2="12" y2="4"/>
                <line x1="6" y1="20" x2="6" y2="14"/>
              </svg>
            </div>
            <span class="bex-nav-label-item" *ngIf="!sidebarClosed">Analytics</span>
            <div class="bex-nav-active-bar"></div>
          </a>

          <a routerLink="/glob-kaizen" routerLinkActive="active" class="bex-nav-item">
            <div class="bex-nav-icon">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                <circle cx="12" cy="12" r="10"/>
                <line x1="2" y1="12" x2="22" y2="12"/>
                <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
              </svg>
            </div>
            <span class="bex-nav-label-item" *ngIf="!sidebarClosed">Global Repo</span>
            <div class="bex-nav-active-bar"></div>
          </a>
        </nav>

        <!-- ═══ FOOTER ═══ -->
        <div class="bex-sidebar-footer">

          <!-- ✅ User Profile Card -->
          <div class="bex-user-card">
            <div class="bex-user-avatar">{{ userInitial }}</div>
            <div class="bex-user-info" *ngIf="!sidebarClosed">
              <span class="bex-user-name">{{ userName }}</span>
              <span class="bex-user-role">{{ userRole }}</span>
            </div>
          </div>

          <!-- Logout -->
          <button (click)="logout()" class="bex-logout-btn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
              <polyline points="16 17 21 12 16 7"/>
              <line x1="21" y1="12" x2="9" y2="12"/>
            </svg>
            <span *ngIf="!sidebarClosed">Exit Portal</span>
          </button>

        </div>
      </aside>

      <!-- ═══════ MAIN AREA ═══════ -->
      <div class="bex-main">
        <header class="bex-topbar">
          <div class="bex-topbar-left">
            <button class="bex-toggle-btn" (click)="toggleSidebar()">
              <span class="bex-hline"></span>
              <span class="bex-hline"></span>
              <span class="bex-hline"></span>
            </button>
            <div class="bex-topbar-title">
              SHAKTI<span class="bex-topbar-title-path">पथ</span> <p class="bex-topbar-thin">Every Step towards Success</p>
            </div>
          </div>
          <div class="bex-topbar-right">
            <div class="bex-logo-wrap">
              <img src="assets/images/test-logo.png" alt="Shaktiman" class="bex-logo-img">
            </div>
          </div>
        </header>

        <main class="bex-content">
          <router-outlet></router-outlet>
        </main>
      </div>
    </div>
  `,
  styles: [`
    :host {
      --orange: #f97316;
      --orange-dim: rgba(249,115,22,0.12);
      --orange-border: rgba(249,115,22,0.22);
      --bg-base: #0b0f19;
      --bg-card: rgba(255,255,255,0.03);
      --border: rgba(255,255,255,0.07);
      --text-primary: #f9fafb;
      --text-muted: #6b7280;
      --sb-width: 240px;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    :host { display: block; font-family: 'Poppins' ;}

    .bex-shell { display: flex; height: 100vh; width: 100vw; overflow: hidden; background: var(--bg-base); }

    /* Sidebar */
    .bex-sidebar {
      width: var(--sb-width); height: 100vh;
      background: rgba(255,255,255,0.02);
      border-right: 1px solid var(--border);
      display: flex; flex-direction: column; flex-shrink: 0;
      transition: width 0.35s cubic-bezier(0.4,0,0.2,1);
      overflow: hidden;
    }
    .bex-sidebar.collapsed { width: 68px; }

    .bex-brand { display: flex; align-items: center; gap: 12px; padding: 28px 18px 24px; border-bottom: 1px solid var(--border); }
    .bex-brand-mark { width: 40px; height: 40px; background: var(--orange-dim); border: 1px solid var(--orange-border); border-radius: 10px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
    .bex-brand-text { display: flex; flex-direction: column; overflow: hidden; white-space: nowrap; }
    .bex-brand-name { font-size: 16px; font-weight: 800; color: var(--text-primary); letter-spacing: 4px; }
    .bex-brand-sub  { font-size: 9px; font-weight: 600; color: var(--orange); letter-spacing: 3px; margin-top: 1px; }

    .bex-nav { flex: 1; padding: 20px 10px; display: flex; flex-direction: column; gap: 4px; }
    .bex-nav-label { font-size: 9px; font-weight: 600; letter-spacing: 1.5px; color: #374151; padding: 0 12px 12px; white-space: nowrap; }
    .bex-nav-item { display: flex; align-items: center; gap: 12px; padding: 11px 12px; border-radius: 10px; color: var(--text-muted); text-decoration: none; font-size: 13px; font-weight: 500; transition: all 0.2s; white-space: nowrap; overflow: hidden; }
    .bex-nav-item:hover { color: var(--text-primary); background: var(--bg-card); }
    .bex-nav-item.active { color: var(--text-primary); background: var(--orange-dim); border: 1px solid var(--orange-border); }
    .bex-nav-item.active .bex-nav-icon { color: var(--orange); }
    .bex-nav-active-bar { display: none; }
    .bex-nav-icon { display: flex; align-items: center; justify-content: center; flex-shrink: 0; width: 20px; }
    .bex-nav-label-item { overflow: hidden; }

    /* ── Footer ── */
    .bex-sidebar-footer {
      padding: 12px 10px 20px;
      border-top: 1px solid var(--border);
      display: flex; flex-direction: column; gap: 8px;
    }

    /* User card */
    .bex-user-card {
      display: flex; align-items: center; gap: 10px;
      padding: 10px 12px;
      background: rgba(249,115,22,0.06);
      border: 1px solid rgba(249,115,22,0.14);
      border-radius: 10px;
      overflow: hidden;
    }
    .bex-user-avatar {
      width: 34px; height: 34px;
      border-radius: 9px;
      background: rgba(249,115,22,0.18);
      border: 1px solid rgba(249,115,22,0.3);
      display: flex; align-items: center; justify-content: center;
      font-size: 14px; font-weight: 800;
      color: #f97316; flex-shrink: 0;
      text-transform: uppercase;
    }
    .bex-user-info {
      display: flex; flex-direction: column; gap: 2px;
      overflow: hidden; white-space: nowrap; min-width: 0;
    }
    .bex-user-name {
      font-size: 12px; font-weight: 700;
      color: var(--text-primary);
      overflow: hidden; text-overflow: ellipsis;
    }
    .bex-user-role {
      font-size: 10px; font-weight: 500;
      color: #f97316; opacity: 0.85;
      overflow: hidden; text-overflow: ellipsis;
    }

    /* Logout */
    .bex-logout-btn {
      display: flex; align-items: center; gap: 10px;
      width: 100%; padding: 10px 12px;
      background: transparent;
      border: 1px solid rgba(239,68,68,0.2);
      border-radius: 10px; color: #ef4444;
      font-family: 'Poppins';
      font-size: 12px; font-weight: 600;
      cursor: pointer; transition: all 0.2s;
      white-space: nowrap; overflow: hidden;
    }
    .bex-logout-btn:hover { background: rgba(239,68,68,0.08); border-color: rgba(239,68,68,0.4); }

    /* Main */
    .bex-main { flex: 1; display: flex; flex-direction: column; min-width: 0; overflow: hidden; }

    .bex-topbar { height: 68px; background: #f5f3f3; border-bottom: 1px solid #e5e7eb; display: flex; align-items: center; justify-content: space-between; padding: 0 28px; flex-shrink: 0; }
    .bex-topbar-left { display: flex; align-items: center; gap: 20px; }
    .bex-toggle-btn { width: 38px; height: 38px; color:rgb(0,0,0); border: 1px solid #e5e7eb; border-radius: 9px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 4px; cursor: pointer; transition: all 0.2s; padding: 0; }
    .bex-toggle-btn:hover { border-color: #f97316; background: rgba(249,115,22,0.08); }
    .bex-hline { display: block; width: 16px; height: 1.5px; background: #374151; border-radius: 99px; transition: all 0.3s; }
    .bex-toggle-btn:hover .bex-hline { background: var(--orange); }
    .bex-topbar-title { font-size: 15px; font-weight: 700; color: #111827; letter-spacing: 2px; }
    .bex-topbar-title-path{color: #f97316;}
    .bex-topbar-thin  { font-weight: 300; color: #6b7280; font-size: 10px; letter-spacing: 1.5px; }
    .bex-topbar-right { display: flex; align-items: center; }
    .bex-logo-img {  height: 26px; object-fit: contain;
    }

    .bex-content { flex: 1; overflow-y: auto; background: var(--bg-base); }
    .bex-content::-webkit-scrollbar { width: 4px; }
    .bex-content::-webkit-scrollbar-track { background: transparent; }
    .bex-content::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 99px; }
  `]
})
export class BexLayoutComponent implements OnInit {
  sidebarClosed = false;

  userName    = 'Admin';
  userRole    = 'Business Excellence';
  userInitial = 'A';

  constructor(private router: Router) {}

  ngOnInit() {
    // sessionStorage se user data read karo
    // apne login component mein jo key use ki ho woh match karo
    const name = sessionStorage.getItem('user_id')
              || sessionStorage.getItem('username')
              || sessionStorage.getItem('name')
              || 'Admin';

    const role = sessionStorage.getItem('role')
              || 'Business Excellence';

    this.userName    = name;
    this.userRole    = role;
    this.userInitial = name.charAt(0).toUpperCase();
  }

  toggleSidebar() { this.sidebarClosed = !this.sidebarClosed; }
  logout()        { this.router.navigate(['/login']); }
}