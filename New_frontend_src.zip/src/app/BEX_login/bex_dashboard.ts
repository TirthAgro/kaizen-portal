import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { RouterModule, Router } from '@angular/router';
import { ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'app-bex-dashboard',
  standalone: true,
  imports: [CommonModule, HttpClientModule, RouterModule],
  encapsulation: ViewEncapsulation.None,
  template: `
    <div class="bex-root">

      <!-- ═══════ TOP HEADER BAR ═══════ -->
      <div class="bex-header">
        <div class="bex-header-left">
          <div class="bex-logo-mark">
            <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
              <rect x="2" y="2" width="8" height="8" rx="2" fill="#fff" opacity="0.9"/>
              <rect x="12" y="2" width="8" height="8" rx="2" fill="#fff" opacity="0.5"/>
              <rect x="2" y="12" width="8" height="8" rx="2" fill="#fff" opacity="0.5"/>
              <rect x="12" y="12" width="8" height="8" rx="2" fill="#fff" opacity="0.3"/>
            </svg>
          </div>
          <div>
            <div class="bex-page-title">Performance Overview</div>
            <div class="bex-page-sub">Business Excellence Dashboard</div>
          </div>
        </div>
       
        <div class="bex-header-right">
          <div class="bex-total-badge">
            <span class="bex-total-label">GRAND TOTAL</span>
            <span class="bex-total-value">{{ grandTotal }}</span>
          </div>
        </div>
      </div>

      <!-- ═══════ HERO BANNER ═══════ -->
      <div class="bex-hero">
        <div class="bex-hero-left">
          <div class="bex-hero-title">Multi Level Enterprise Kaizen Platform</div>
          <div class="bex-hero-sub">Enterprise improvement platform with role-based access, plan vs actual analytics, breakthrough innovation tracking, cost saving, vertical implementation and horizontal deployment.</div>
        </div>
        <div class="bex-hero-stats">
          <div class="bex-hstat">
            <div class="bex-hstat-label">PENDING</div>
            <div class="bex-hstat-val">22</div>
          </div>
          <div class="bex-hstat">
            <div class="bex-hstat-label">APPROVED</div>
            <div class="bex-hstat-val">186</div>
          </div>
          <div class="bex-hstat">
            <div class="bex-hstat-label">TARGET</div>
            <div class="bex-hstat-val">240</div>
          </div>
          <div class="bex-hstat bex-hstat-accent">
            <div class="bex-hstat-label">COST SAVING</div>
            <div class="bex-hstat-val">₹1.84Cr</div>
          </div>
        </div>
      </div>

      <!-- ═══════ PLAN VS ACTUAL ═══════ -->
      <div class="bex-section-label">PLAN VS ACTUAL ANALYTICS</div>
      <div class="bex-pva-grid">
        <div class="bex-pva-card">
          <div class="bex-pva-name">Kaizen Submission</div>
          <div class="bex-pva-row"><span class="bex-pva-key">Plan</span><span class="bex-pva-plan">320</span></div>
          <div class="bex-pva-row"><span class="bex-pva-key">Actual</span><span class="bex-pva-actual">284</span></div>
          <div class="bex-pva-bar"><div class="bex-pva-bar-fill" style="width:89%"></div></div>
          <div class="bex-pva-ach">Achievement: <span class="bex-pva-ach-val">89%</span></div>
        </div>
        <div class="bex-pva-card">
          <div class="bex-pva-name">Cost Saving</div>
          <div class="bex-pva-row"><span class="bex-pva-key">Plan</span><span class="bex-pva-plan">₹2.4Cr</span></div>
          <div class="bex-pva-row"><span class="bex-pva-key">Actual</span><span class="bex-pva-actual">₹1.84Cr</span></div>
          <div class="bex-pva-bar"><div class="bex-pva-bar-fill" style="width:77%"></div></div>
          <div class="bex-pva-ach">Achievement: <span class="bex-pva-ach-val">77%</span></div>
        </div>
        <div class="bex-pva-card">
          <div class="bex-pva-name">Horizontal Deployment</div>
          <div class="bex-pva-row"><span class="bex-pva-key">Plan</span><span class="bex-pva-plan">140</span></div>
          <div class="bex-pva-row"><span class="bex-pva-key">Actual</span><span class="bex-pva-actual">118</span></div>
          <div class="bex-pva-bar"><div class="bex-pva-bar-fill" style="width:84%"></div></div>
          <div class="bex-pva-ach">Achievement: <span class="bex-pva-ach-val">84%</span></div>
        </div>
        <div class="bex-pva-card">
          <div class="bex-pva-name">Vertical Implementation</div>
          <div class="bex-pva-row"><span class="bex-pva-key">Plan</span><span class="bex-pva-plan">100</span></div>
          <div class="bex-pva-row"><span class="bex-pva-key">Actual</span><span class="bex-pva-actual">86</span></div>
          <div class="bex-pva-bar"><div class="bex-pva-bar-fill" style="width:86%"></div></div>
          <div class="bex-pva-ach">Achievement: <span class="bex-pva-ach-val">86%</span></div>
        </div>
      </div>

      <!-- ═══════ ENTERPRISE ANALYTICS ═══════ -->
      <div class="bex-section-label">ENTERPRISE ANALYTICS</div>
      <div class="bex-metric-grid">
        <div class="bex-metric-card">
          <div class="bex-metric-icon bex-icon-orange">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
              <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
          </div>
          <div>
            <div class="bex-metric-val">128</div>
            <div class="bex-metric-label">Breakthrough Kaizen</div>
            <div class="bex-metric-sub">Enterprise Analytics</div>
          </div>
        </div>
        <div class="bex-metric-card">
          <div class="bex-metric-icon bex-icon-cyan">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
            </svg>
          </div>
          <div>
            <div class="bex-metric-val">284</div>
            <div class="bex-metric-label">Innovation Kaizen</div>
            <div class="bex-metric-sub">Enterprise Analytics</div>
          </div>
        </div>
        <div class="bex-metric-card">
          <div class="bex-metric-icon bex-icon-green">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
              <polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/>
            </svg>
          </div>
          <div>
            <div class="bex-metric-val">118</div>
            <div class="bex-metric-label">Horizontal Deployment</div>
            <div class="bex-metric-sub">Enterprise Analytics</div>
          </div>
        </div>
        <div class="bex-metric-card">
          <div class="bex-metric-icon bex-icon-purple">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
              <line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>
            </svg>
          </div>
          <div>
            <div class="bex-metric-val">86</div>
            <div class="bex-metric-label">Vertical Implementation</div>
            <div class="bex-metric-sub">Enterprise Analytics</div>
          </div>
        </div>
      </div>

      <!-- ═══════ UNIT CARDS GRID ═══════ -->
      <div class="bex-section-label">UNIT PERFORMANCE — CLICK ANY UNIT FOR DETAILS</div>
      <div class="bex-units-grid">
        <div
          class="bex-unit-card"
          *ngFor="let unit of unitData; let i = index"
          [attr.data-rank]="getRank(i)"
          (click)="openUnitDetail(i)">

          <div class="bex-unit-header">
            <div class="bex-unit-badge">UNIT {{ (i + 1).toString().padStart(2, '0') }}</div>
            <div class="bex-unit-rank-dot" [class.top]="getTopUnit() === i + 1">
              <svg width="8" height="8" viewBox="0 0 8 8">
                <circle cx="4" cy="4" r="4" [attr.fill]="getTopUnit() === i + 1 ? '#f97316' : '#d1cdc7'"/>
              </svg>
            </div>
          </div>

          <div class="bex-unit-number">{{ unit }}</div>

          <div class="bex-unit-footer">
            <div class="bex-unit-label">Total Submissions</div>
            <div class="bex-unit-bar">
              <div class="bex-unit-bar-fill"
                [style.width.%]="grandTotal > 0 ? (unit / grandTotal * 100) : 0">
              </div>
            </div>
            <div class="bex-unit-pct">
              {{ grandTotal > 0 ? (unit / grandTotal * 100 | number:'1.0-1') : 0 }}%
            </div>
          </div>
          <div class="bex-unit-click-hint">↗ Click for section details</div>
        </div>
      </div>

      <!-- ═══════ SUMMARY STRIP ═══════ -->
      <div class="bex-section-label">SUMMARY</div>
      <div class="bex-summary-strip">
        <div class="bex-stat-item">
          <div class="bex-stat-icon">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
              <rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/>
              <rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>
            </svg>
          </div>
          <div class="bex-stat-body">
            <div class="bex-stat-label">Total Units</div>
            <div class="bex-stat-val">{{ unitData.length }}</div>
          </div>
        </div>
        <div class="bex-stat-item accent">
          <div class="bex-stat-icon">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
            </svg>
          </div>
          <div class="bex-stat-body">
            <div class="bex-stat-label">Top Performer</div>
            <div class="bex-stat-val">Unit {{ getTopUnit().toString().padStart(2, '0') }}</div>
          </div>
        </div>
        <div class="bex-stat-item">
          <div class="bex-stat-icon">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
              <line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>
            </svg>
          </div>
          <div class="bex-stat-body">
            <div class="bex-stat-label">Avg. Submissions</div>
            <div class="bex-stat-val">{{ getAverage() }}</div>
          </div>
        </div>
        <div class="bex-stat-item">
          <div class="bex-stat-icon">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
              <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
            </svg>
          </div>
          <div class="bex-stat-body">
            <div class="bex-stat-label">Total Kaizens</div>
            <div class="bex-stat-val">{{ grandTotal }}</div>
          </div>
        </div>
      </div>

      <!-- ═══════ BOTTOM ROW ═══════ -->
      <div class="bex-bottom-row">

        <!-- Dept Performance -->
        <div class="bex-bottom-card">
          <div class="bex-bottom-card-title">Department Performance</div>
          <div class="bex-bottom-card-sub">Cross-functional department metrics</div>
          <table class="bex-dept-table">
            <thead>
              <tr>
                <th>Department</th><th>Plant</th><th>Kaizens</th><th>Cost Saving</th><th>Efficiency</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let dept of deptData">
                <td>{{ dept.name }}</td>
                <td class="bex-muted">{{ dept.plant }}</td>
                <td>{{ dept.kaizens }}</td>
                <td class="bex-orange">{{ dept.saving }}</td>
                <td>
                  <span class="bex-eff-badge" [class.bex-eff-high]="dept.efficiency >= 90" [class.bex-eff-mid]="dept.efficiency < 90">
                    {{ dept.efficiency }}%
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- Dept Efficiency Chart -->
        <div class="bex-bottom-card">
          <div class="bex-bottom-card-title">Department Efficiency</div>
          <div class="bex-bottom-card-sub">Monthly submission trend</div>
          <div class="bex-bar-chart">
            <div class="bex-bar-col" *ngFor="let bar of monthBars">
              <div class="bex-bar-fill" [style.height.%]="bar.pct"></div>
              <div class="bex-bar-label">{{ bar.month }}</div>
            </div>
          </div>
        </div>

        <!-- Deployment Analytics -->
        <div class="bex-bottom-card">
          <div class="bex-bottom-card-title">Deployment Analytics</div>
          <div class="bex-deploy-list">
            <div class="bex-deploy-item" *ngFor="let d of deployData">
              <div class="bex-deploy-row">
                <span class="bex-deploy-name">{{ d.name }}</span>
                <span class="bex-deploy-pct" [style.color]="d.color">{{ d.pct }}%</span>
              </div>
              <div class="bex-deploy-hint">{{ d.hint }}</div>
              <div class="bex-deploy-bar">
                <div class="bex-deploy-bar-fill" [style.width.%]="d.pct" [style.background]="d.color"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- ═══════ UNIT DETAIL MODAL ═══════ -->
      <div class="bex-modal-overlay" *ngIf="selectedUnit !== null" (click)="closeDetail($event)">
        <div class="bex-modal" *ngIf="selectedUnit !== null">
          <div class="bex-modal-header">
            <div>
              <div class="bex-modal-title">Unit {{ (selectedUnit + 1).toString().padStart(2,'0') }} — Kaizen Details</div>
              <div class="bex-modal-sub">Section-wise breakdown of all kaizen submissions</div>
            </div>
            <button class="bex-modal-close" (click)="closeModal()">✕</button>
          </div>

          <div class="bex-modal-kpis">
            <div class="bex-modal-kpi">
              <div class="bex-modal-kpi-label">TOTAL</div>
              <div class="bex-modal-kpi-val" [style.color]="unitColors[selectedUnit]">{{ unitData[selectedUnit] }}</div>
            </div>
            <div class="bex-modal-kpi">
              <div class="bex-modal-kpi-label">TARGET</div>
              <div class="bex-modal-kpi-val">{{ unitSections[selectedUnit].target }}</div>
            </div>
            <div class="bex-modal-kpi">
              <div class="bex-modal-kpi-label">ACHIEVEMENT</div>
              <div class="bex-modal-kpi-val"
                [style.color]="getAchievement(selectedUnit) >= 80 ? '#16a34a' : '#d97706'">
                {{ getAchievement(selectedUnit) }}%
              </div>
            </div>
          </div>

          <div class="bex-modal-sec-title">SECTION-WISE KAIZEN BREAKDOWN</div>
          <div class="bex-modal-sections">
            <div class="bex-modal-sec-row" *ngFor="let sec of unitSections[selectedUnit].sections">
              <div class="bex-sec-dot" [style.background]="sec.color"></div>
              <div class="bex-sec-name">{{ sec.name }}</div>
              <div class="bex-sec-bar-wrap">
                <div class="bex-sec-bar-fill"
                  [style.width.%]="getSecBarWidth(selectedUnit, sec.count)"
                  [style.background]="sec.color">
                </div>
              </div>
              <div class="bex-sec-count">{{ sec.count }}</div>
              <div class="bex-sec-pct">{{ getSecPct(selectedUnit, sec.count) }}%</div>
            </div>
          </div>

          <div class="bex-modal-bottom">
            <div class="bex-modal-bstat">
              <div class="bex-modal-bstat-icon bex-icon-green-soft">✓</div>
              <div>
                <div class="bex-modal-bstat-label">Approved</div>
                <div class="bex-modal-bstat-val">{{ unitSections[selectedUnit].approved }}</div>
              </div>
            </div>
            <div class="bex-modal-bstat">
              <div class="bex-modal-bstat-icon bex-icon-orange-soft">⏳</div>
              <div>
                <div class="bex-modal-bstat-label">Pending</div>
                <div class="bex-modal-bstat-val">{{ unitSections[selectedUnit].pending }}</div>
              </div>
            </div>
            <div class="bex-modal-bstat">
              <div class="bex-modal-bstat-icon bex-icon-purple-soft">▦</div>
              <div>
                <div class="bex-modal-bstat-label">Sections</div>
                <div class="bex-modal-bstat-val">{{ unitSections[selectedUnit].sections.length }}</div>
              </div>
            </div>
            <div class="bex-modal-bstat">
              <div class="bex-modal-bstat-icon bex-icon-cyan-soft">₹</div>
              <div>
                <div class="bex-modal-bstat-label">Cost Saving</div>
                <div class="bex-modal-bstat-val">{{ unitSections[selectedUnit].saving }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  `,
  styles: [`

/* ════════════════════════════════
   ROOT
════════════════════════════════ */
.bex-root {
  --primary: #E8541A;
  --primary-2: #F97316;
  --primary-soft: rgba(232,84,26,.1);
  --bg: #FFFBF5;
  --card: #FFFFFF;
  --card2: #FDF8F2;
  --border: #EDE5D8;
  --border2: #E2D6C8;
  --text: #1C1917;
  --text-2: #57534E;
  --muted: #A8A29E;
  --green: #16A34A;
  --green-soft: rgba(22,163,74,.12);
  --purple: #7C3AED;
  --purple-soft: rgba(124,58,237,.12);
  --cyan: #0891B2;
  --cyan-soft: rgba(8,145,178,.12);
  --amber: #D97706;

  min-height: 100vh;
  padding: 28px 32px;
  background: var(--bg);
  color: var(--text);
  font-family: 'Segoe UI', system-ui, sans-serif;
}

/* ════════════════════════════════
   HEADER
════════════════════════════════ */
.bex-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  margin-bottom: 22px;
  padding: 16px 22px;
  border-radius: 20px;
  background: var(--card);
  border: 1px solid var(--border);
  box-shadow: 0 2px 12px rgba(28,25,23,.06);
}

.bex-header-left {
  display: flex;
  align-items: center;
  gap: 14px;
}

.bex-logo-mark {
  width: 52px;
  height: 52px;
  border-radius: 16px;
  background: linear-gradient(135deg, #E8541A, #F97316);
  display: flex;
  align-items: center;
  justify-content: center;
}

.bex-page-title {
  font-size: 20px;
  font-weight: 800;
  letter-spacing: -.4px;
  color: var(--primary);
}

.bex-page-sub {
  margin-top: 3px;
  font-size: 12px;
  font-weight: 600;
  color: var(--muted);
}

.bex-header-center {
  display: flex;
  align-items: center;
  gap: 8px;
}

.bex-badge {
  padding: 4px 12px;
  border-radius: 999px;
  font-size: 10px;
  font-weight: 800;
  letter-spacing: .08em;
}

.bex-badge-orange {
  background: rgba(232,84,26,.12);
  color: var(--primary);
}

.bex-badge-green {
  background: rgba(22,163,74,.12);
  color: var(--green);
}

.bex-header-right {
  display: flex;
  align-items: center;
}

.bex-total-badge {
  min-width: 130px;
  padding: 12px 16px;
  border-radius: 16px;
  background: linear-gradient(135deg, #E8541A, #F97316);
  border: 1px solid #FFD6C2;
  text-align: right;
}

.bex-total-label {
  display: block;
  font-size: 10px;
  font-weight: 800;
  letter-spacing: .12em;
  color: rgba(255,255,255,.8);
}

.bex-total-value {
  display: block;
  margin-top: 3px;
  font-size: 26px;
  font-weight: 900;
  color: #fff;
}

/* ════════════════════════════════
   HERO
════════════════════════════════ */
.bex-hero {
  display: flex;
  align-items: center;
  gap: 24px;
  margin-bottom: 22px;
  padding: 22px 26px;
  border-radius: 20px;
  background: var(--card);
  border: 1px solid var(--border);
  border-left: 4px solid var(--primary);
  box-shadow: 0 2px 12px rgba(28,25,23,.05);
}

.bex-hero-left {
  flex: 1;
}

.bex-hero-title {
  font-size: 18px;
  font-weight: 800;
  color: var(--text);
  margin-bottom: 6px;
  letter-spacing: -.3px;
}

.bex-hero-sub {
  font-size: 12px;
  color: var(--text-2);
  line-height: 1.6;
}

.bex-hero-stats {
  display: flex;
  gap: 10px;
  flex-shrink: 0;
}

.bex-hstat {
  background: var(--card2);
  border: 1px solid var(--border);
  border-radius: 14px;
  padding: 12px 16px;
  text-align: center;
  min-width: 80px;
}

.bex-hstat-label {
  font-size: 9px;
  color: var(--muted);
  font-weight: 700;
  letter-spacing: .07em;
  margin-bottom: 4px;
}

.bex-hstat-val {
  font-size: 20px;
  font-weight: 800;
  color: var(--text);
}

.bex-hstat-accent .bex-hstat-val {
  color: var(--primary);
}

/* ════════════════════════════════
   SECTION LABEL
════════════════════════════════ */
.bex-section-label {
  font-size: 11px;
  font-weight: 700;
  color: var(--muted);
  letter-spacing: .08em;
  margin: 0 0 10px 2px;
}

/* ════════════════════════════════
   PLAN VS ACTUAL
════════════════════════════════ */
.bex-pva-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 14px;
  margin-bottom: 22px;
}

.bex-pva-card {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 16px;
  padding: 16px 18px;
  box-shadow: 0 1px 6px rgba(28,25,23,.04);
}

.bex-pva-name {
  font-size: 11px;
  font-weight: 600;
  color: var(--text-2);
  margin-bottom: 10px;
}

.bex-pva-row {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  margin-bottom: 2px;
}

.bex-pva-key {
  font-size: 11px;
  color: var(--muted);
}

.bex-pva-plan {
  font-size: 18px;
  font-weight: 800;
  color: var(--text);
}

.bex-pva-actual {
  font-size: 18px;
  font-weight: 800;
  color: var(--primary);
}

.bex-pva-bar {
  height: 5px;
  border-radius: 999px;
  background: #F1EBE3;
  margin: 10px 0 6px;
  overflow: hidden;
}

.bex-pva-bar-fill {
  height: 100%;
  border-radius: 999px;
  background: linear-gradient(90deg, var(--primary), var(--primary-2));
  transition: width .6s ease;
}

.bex-pva-ach {
  font-size: 11px;
  color: var(--muted);
  font-weight: 600;
}

.bex-pva-ach-val {
  color: var(--primary);
  font-weight: 800;
}

/* ════════════════════════════════
   ENTERPRISE ANALYTICS
════════════════════════════════ */
.bex-metric-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 14px;
  margin-bottom: 22px;
}

.bex-metric-card {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 16px;
  padding: 16px 18px;
  display: flex;
  align-items: center;
  gap: 14px;
  box-shadow: 0 1px 6px rgba(28,25,23,.04);
  transition: .22s ease;
}

.bex-metric-card:hover {
  transform: translateY(-3px);
  box-shadow: 0 8px 24px rgba(232,84,26,.09);
}

.bex-metric-icon {
  width: 48px;
  height: 48px;
  border-radius: 14px;
  display: grid;
  place-items: center;
  flex-shrink: 0;
}

.bex-icon-orange { background: rgba(232,84,26,.1); color: var(--primary); }
.bex-icon-cyan   { background: rgba(8,145,178,.1); color: var(--cyan); }
.bex-icon-green  { background: rgba(22,163,74,.1); color: var(--green); }
.bex-icon-purple { background: rgba(124,58,237,.1); color: var(--purple); }

.bex-metric-val {
  font-size: 28px;
  font-weight: 900;
  color: var(--text);
  letter-spacing: -1px;
  line-height: 1;
}

.bex-metric-label {
  font-size: 12px;
  font-weight: 600;
  color: var(--text-2);
  margin-top: 3px;
}

.bex-metric-sub {
  font-size: 10px;
  color: var(--muted);
  margin-top: 2px;
}

/* ════════════════════════════════
   UNIT GRID
════════════════════════════════ */
.bex-units-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;
  margin-bottom: 22px;
}

.bex-unit-card {
  position: relative;
  overflow: hidden;
  padding: 20px;
  border-radius: 22px;
  background: var(--card);
  border: 1px solid var(--border);
  box-shadow: 0 2px 10px rgba(28,25,23,.05);
  transition: .28s ease;
  display: flex;
  flex-direction: column;
  gap: 14px;
  cursor: pointer;
}

.bex-unit-card::before {
  content: '';
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, rgba(232,84,26,.05), transparent 65%);
  opacity: 0;
  transition: .3s ease;
}

.bex-unit-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 16px 40px rgba(232,84,26,.12);
}

.bex-unit-card:hover::before { opacity: 1; }

.bex-unit-card:nth-child(1) { border-bottom: 6px solid #E8541A; }
.bex-unit-card:nth-child(2) { border-bottom: 6px solid #7C3AED; }
.bex-unit-card:nth-child(3) { border-bottom: 6px solid #0891B2; }
.bex-unit-card:nth-child(4) { border-bottom: 6px solid #16A34A; }
.bex-unit-card:nth-child(5) { border-bottom: 6px solid #D97706; }

.bex-unit-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.bex-unit-badge {
  padding: 5px 12px;
  border-radius: 999px;
  background: #FFF1EA;
  color: #C2440F;
  font-size: 10px;
  font-weight: 800;
  letter-spacing: .1em;
}

.bex-unit-rank-dot { width: 10px; height: 10px; border-radius: 50%; }

.bex-unit-number {
  font-size: 52px;
  font-weight: 900;
  letter-spacing: -2px;
  line-height: 1;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-size: 100%;
}

.bex-unit-card:nth-child(1) .bex-unit-number { background-image: linear-gradient(135deg,#E8541A,#F97316); }
.bex-unit-card:nth-child(2) .bex-unit-number { background-image: linear-gradient(135deg,#7C3AED,#8B5CF6); }
.bex-unit-card:nth-child(3) .bex-unit-number { background-image: linear-gradient(135deg,#0891B2,#06B6D4); }
.bex-unit-card:nth-child(4) .bex-unit-number { background-image: linear-gradient(135deg,#16A34A,#22C55E); }
.bex-unit-card:nth-child(5) .bex-unit-number { background-image: linear-gradient(135deg,#D97706,#F59E0B); }

.bex-unit-footer { display: flex; flex-direction: column; gap: 6px; }

.bex-unit-label { font-size: 11px; font-weight: 600; color: var(--muted); }

.bex-unit-bar {
  height: 6px;
  border-radius: 999px;
  overflow: hidden;
  background: #F1EBE3;
}

.bex-unit-bar-fill {
  height: 100%;
  border-radius: 999px;
  transition: width .6s ease;
}

.bex-unit-card:nth-child(1) .bex-unit-bar-fill { background: #E8541A; }
.bex-unit-card:nth-child(2) .bex-unit-bar-fill { background: #7C3AED; }
.bex-unit-card:nth-child(3) .bex-unit-bar-fill { background: #0891B2; }
.bex-unit-card:nth-child(4) .bex-unit-bar-fill { background: #16A34A; }
.bex-unit-card:nth-child(5) .bex-unit-bar-fill { background: #D97706; }

.bex-unit-pct { font-size: 11px; font-weight: 700; text-align: right; }
.bex-unit-card:nth-child(1) .bex-unit-pct { color: #E8541A; }
.bex-unit-card:nth-child(2) .bex-unit-pct { color: #7C3AED; }
.bex-unit-card:nth-child(3) .bex-unit-pct { color: #0891B2; }
.bex-unit-card:nth-child(4) .bex-unit-pct { color: #16A34A; }
.bex-unit-card:nth-child(5) .bex-unit-pct { color: #D97706; }

.bex-unit-click-hint { font-size: 10px; color: var(--muted); }

/* ════════════════════════════════
   SUMMARY STRIP
════════════════════════════════ */
.bex-summary-strip {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 14px;
  margin-bottom: 22px;
}

.bex-stat-item {
  background: var(--card);
  border-radius: 18px;
  padding: 18px;
  border: 1px solid var(--border);
  display: flex;
  align-items: center;
  gap: 14px;
  box-shadow: 0 1px 6px rgba(28,25,23,.04);
  transition: .22s ease;
}

.bex-stat-item:hover { transform: translateY(-3px); }

.bex-stat-icon {
  width: 48px;
  height: 48px;
  border-radius: 14px;
  display: grid;
  place-items: center;
  background: #FFF4EC;
  color: var(--primary);
  flex-shrink: 0;
}

.bex-stat-label { font-size: 11px; font-weight: 600; color: var(--muted); }

.bex-stat-val {
  margin-top: 3px;
  font-size: 22px;
  font-weight: 800;
  color: var(--text);
}

.bex-stat-divider { display: none; }

/* ════════════════════════════════
   BOTTOM ROW
════════════════════════════════ */
.bex-bottom-row {
  display: grid;
  grid-template-columns: 1.4fr 1fr 1fr;
  gap: 14px;
  margin-bottom: 22px;
}

.bex-bottom-card {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 18px;
  padding: 18px 20px;
  box-shadow: 0 1px 6px rgba(28,25,23,.04);
}

.bex-bottom-card-title {
  font-size: 13px;
  font-weight: 700;
  color: var(--text);
  margin-bottom: 3px;
}

.bex-bottom-card-sub {
  font-size: 10px;
  color: var(--muted);
  margin-bottom: 14px;
}

.bex-dept-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12px;
}

.bex-dept-table th {
  color: var(--muted);
  font-weight: 700;
  font-size: 10px;
  letter-spacing: .05em;
  text-align: left;
  padding: 4px 0;
  border-bottom: 1px solid var(--border);
}

.bex-dept-table td {
  padding: 7px 0;
  border-bottom: 1px solid var(--border);
  color: var(--text-2);
}

.bex-muted { color: var(--muted) !important; }
.bex-orange { color: var(--primary) !important; font-weight: 700; }

.bex-eff-badge {
  padding: 2px 8px;
  border-radius: 999px;
  font-size: 10px;
  font-weight: 700;
}

.bex-eff-high { background: rgba(22,163,74,.12); color: #16A34A; }
.bex-eff-mid  { background: rgba(232,84,26,.1); color: var(--primary); }

.bex-bar-chart {
  display: flex;
  align-items: flex-end;
  gap: 8px;
  height: 80px;
  margin-top: 4px;
}

.bex-bar-col {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  height: 100%;
  justify-content: flex-end;
}

.bex-bar-fill {
  width: 100%;
  background: linear-gradient(180deg, var(--primary), #F97316);
  border-radius: 4px 4px 0 0;
  min-height: 8px;
  opacity: .75;
  transition: opacity .2s;
}

.bex-bar-fill:hover { opacity: 1; }

.bex-bar-label { font-size: 9px; color: var(--muted); }

.bex-deploy-list { display: flex; flex-direction: column; gap: 14px; margin-top: 4px; }

.bex-deploy-item {}

.bex-deploy-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2px;
}

.bex-deploy-name { font-size: 12px; font-weight: 600; color: var(--text); }
.bex-deploy-pct  { font-size: 13px; font-weight: 800; }
.bex-deploy-hint { font-size: 10px; color: var(--muted); margin-bottom: 5px; }

.bex-deploy-bar {
  height: 6px;
  border-radius: 999px;
  background: #F1EBE3;
  overflow: hidden;
}

.bex-deploy-bar-fill {
  height: 100%;
  border-radius: 999px;
  transition: width .6s ease;
}

/* ════════════════════════════════
   MODAL
════════════════════════════════ */
.bex-modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(28,25,23,.45);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 200;
  padding: 20px;
}

.bex-modal {
  background: var(--card);
  border: 1px solid var(--border2);
  border-radius: 24px;
  width: 100%;
  max-width: 560px;
  max-height: 88vh;
  overflow-y: auto;
  padding: 26px;
  box-shadow: 0 24px 60px rgba(28,25,23,.18);
}

.bex-modal-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 20px;
}

.bex-modal-title { font-size: 17px; font-weight: 800; color: var(--text); }
.bex-modal-sub   { font-size: 11px; color: var(--muted); margin-top: 3px; }

.bex-modal-close {
  background: var(--card2);
  border: 1px solid var(--border);
  color: var(--muted);
  width: 32px;
  height: 32px;
  border-radius: 10px;
  cursor: pointer;
  font-size: 15px;
  display: grid;
  place-items: center;
  transition: .2s;
}

.bex-modal-close:hover { color: var(--text); border-color: var(--border2); }

.bex-modal-kpis {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
  margin-bottom: 20px;
}

.bex-modal-kpi {
  background: var(--card2);
  border: 1px solid var(--border);
  border-radius: 14px;
  padding: 12px 14px;
}

.bex-modal-kpi-label { font-size: 10px; color: var(--muted); font-weight: 700; letter-spacing: .07em; margin-bottom: 4px; }
.bex-modal-kpi-val   { font-size: 22px; font-weight: 800; color: var(--text); }

.bex-modal-sec-title {
  font-size: 10px;
  font-weight: 700;
  color: var(--muted);
  letter-spacing: .08em;
  margin-bottom: 10px;
}

.bex-modal-sections {}

.bex-modal-sec-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 9px 0;
  border-bottom: 1px solid var(--border);
}

.bex-modal-sec-row:last-child { border-bottom: none; }

.bex-sec-dot   { width: 9px; height: 9px; border-radius: 50%; flex-shrink: 0; }
.bex-sec-name  { flex: 1; font-size: 12px; font-weight: 600; color: var(--text-2); }
.bex-sec-bar-wrap { flex: 2; height: 5px; border-radius: 999px; background: #F1EBE3; overflow: hidden; }
.bex-sec-bar-fill { height: 100%; border-radius: 999px; transition: width .5s ease; }
.bex-sec-count { font-size: 12px; font-weight: 800; color: var(--text); min-width: 24px; text-align: right; }
.bex-sec-pct   { font-size: 10px; font-weight: 700; color: var(--muted); min-width: 32px; text-align: right; }

.bex-modal-bottom {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
  margin-top: 16px;
}

.bex-modal-bstat {
  background: var(--card2);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 10px 14px;
  display: flex;
  align-items: center;
  gap: 10px;
}

.bex-modal-bstat-icon {
  width: 32px;
  height: 32px;
  border-radius: 9px;
  display: grid;
  place-items: center;
  font-size: 14px;
  font-weight: 700;
  flex-shrink: 0;
}

.bex-icon-green-soft  { background: rgba(22,163,74,.12);  color: var(--green); }
.bex-icon-orange-soft { background: rgba(232,84,26,.1);   color: var(--primary); }
.bex-icon-purple-soft { background: rgba(124,58,237,.1);  color: var(--purple); }
.bex-icon-cyan-soft   { background: rgba(8,145,178,.1);   color: var(--cyan); }

.bex-modal-bstat-label { font-size: 10px; color: var(--muted); }
.bex-modal-bstat-val   { font-size: 15px; font-weight: 800; color: var(--text); }

/* ════════════════════════════════
   ANIMATIONS
════════════════════════════════ */
.bex-unit-card { animation: bexFade .5s ease both; }
.bex-unit-card:nth-child(1) { animation-delay: .05s; }
.bex-unit-card:nth-child(2) { animation-delay: .10s; }
.bex-unit-card:nth-child(3) { animation-delay: .15s; }
.bex-unit-card:nth-child(4) { animation-delay: .20s; }
.bex-unit-card:nth-child(5) { animation-delay: .25s; }

@keyframes bexFade {
  from { opacity: 0; transform: translateY(20px); }
  to   { opacity: 1; transform: translateY(0); }
}

/* ════════════════════════════════
   RESPONSIVE
════════════════════════════════ */
@media (max-width: 1100px) {
  .bex-bottom-row { grid-template-columns: 1fr 1fr; }
}

@media (max-width: 992px) {
  .bex-root { padding: 20px; }
  .bex-hero { flex-direction: column; align-items: flex-start; }
  .bex-hero-stats { flex-wrap: wrap; }
  .bex-header-center { display: none; }
}

@media (max-width: 768px) {
  .bex-root { padding: 14px; }
  .bex-header { flex-direction: column; align-items: flex-start; }
  .bex-header-right { width: 100%; justify-content: flex-end; }
  .bex-page-title { font-size: 17px; }
  .bex-unit-number { font-size: 40px; }
  .bex-admin-section { padding: 18px; }
  .bex-bottom-row { grid-template-columns: 1fr; }
  .bex-pva-grid { grid-template-columns: 1fr 1fr; }
  .bex-metric-grid { grid-template-columns: 1fr 1fr; }
}
  `]
})
export class BexDashboardComponent implements OnInit {

  api = 'http://localhost:8080/api/bex';

  unitData: number[] = [0, 0, 0, 0, 0];
  grandTotal = 0;
  selectedUnit: number | null = null;

  unitColors = ['#E8541A', '#7C3AED', '#0891B2', '#16A34A', '#D97706'];

  unitSections = [
    {
      target: 80, approved: 52, pending: 8, saving: '₹18.4L',
      sections: [
        { name: 'Assembly Line A', count: 24, color: '#E8541A' },
        { name: 'Quality Check',   count: 18, color: '#F97316' },
        { name: 'Packaging',       count: 14, color: '#FBBF24' },
        { name: 'Logistics',       count: 10, color: '#F87171' },
        { name: 'Maintenance',     count: 6,  color: '#FCA5A5' }
      ]
    },
    {
      target: 60, approved: 38, pending: 5, saving: '₹11.2L',
      sections: [
        { name: 'Paint Shop',      count: 20, color: '#7C3AED' },
        { name: 'Body Welding',    count: 16, color: '#8B5CF6' },
        { name: 'Engine Assembly', count: 12, color: '#A78BFA' },
        { name: 'Trim Line',       count: 5,  color: '#C4B5FD' },
        { name: 'Inspection',      count: 3,  color: '#DDD6FE' }
      ]
    },
    {
      target: 55, approved: 32, pending: 4, saving: '₹7.9L',
      sections: [
        { name: 'SCM Hub',     count: 18, color: '#0891B2' },
        { name: 'Warehouse A', count: 14, color: '#06B6D4' },
        { name: 'Procurement', count: 9,  color: '#22D3EE' },
        { name: 'Dispatch',    count: 5,  color: '#67E8F9' },
        { name: 'Returns',     count: 2,  color: '#A5F3FC' }
      ]
    },
    {
      target: 70, approved: 45, pending: 6, saving: '₹9.3L',
      sections: [
        { name: 'Quality Lab',    count: 22, color: '#16A34A' },
        { name: 'R&D',            count: 18, color: '#22C55E' },
        { name: 'Process Eng.',   count: 15, color: '#4ADE80' },
        { name: 'Testing',        count: 7,  color: '#86EFAC' },
        { name: 'Calibration',    count: 3,  color: '#BBF7D0' }
      ]
    },
    {
      target: 50, approved: 28, pending: 3, saving: '₹5.6L',
      sections: [
        { name: 'Innovation Hub', count: 16, color: '#D97706' },
        { name: 'Kaizen Circle',  count: 13, color: '#F59E0B' },
        { name: '5S Team',        count: 8,  color: '#FBBF24' },
        { name: 'Safety',         count: 4,  color: '#FCD34D' },
        { name: 'HR Initiatives', count: 2,  color: '#FDE68A' }
      ]
    }
  ];

  deptData = [
    { name: 'Assembly',  plant: 'Plant 1',   kaizens: 126, saving: '₹18.4L', efficiency: 92 },
    { name: 'Paint Shop',plant: 'Plant 2',   kaizens: 84,  saving: '₹11.2L', efficiency: 88 },
    { name: 'SCM',       plant: 'Corporate', kaizens: 56,  saving: '₹7.9L',  efficiency: 81 },
    { name: 'Quality',   plant: 'Plant 3',   kaizens: 72,  saving: '₹9.3L',  efficiency: 89 }
  ];

  monthBars = [
    { month: 'Jan', pct: 55 },
    { month: 'Feb', pct: 70 },
    { month: 'Mar', pct: 60 },
    { month: 'Apr', pct: 82 },
    { month: 'May', pct: 100 },
    { month: 'Jun', pct: 65 }
  ];

  deployData = [
    { name: 'Horizontal Deployment',  hint: 'Implemented across departments',    pct: 74, color: '#E8541A' },
    { name: 'Vertical Implementation',hint: 'Rolled out at management levels',   pct: 61, color: '#7C3AED' },
    { name: 'Replication Success',    hint: 'Successfully reused Kaizens',       pct: 89, color: '#16A34A' }
  ];

  constructor(
    private http: HttpClient,
    private router: Router,
    private cd: ChangeDetectorRef
  ) {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
  }

  ngOnInit(): void {
    this.loadDashboard();
  }

  getTopUnit(): number {
    const max = Math.max(...this.unitData);
    return this.unitData.indexOf(max) + 1;
  }

  getAverage(): number {
    if (this.unitData.length === 0) return 0;
    const total = this.unitData.reduce((a, b) => a + b, 0);
    return Math.round(total / this.unitData.length);
  }

  getRank(index: number): string {
    const sorted = [...this.unitData].sort((a, b) => b - a);
    const rank = sorted.indexOf(this.unitData[index]) + 1;
    return rank <= 1 ? 'top' : rank <= 3 ? 'mid' : 'low';
  }

  getAchievement(idx: number): number {
    return Math.round(this.unitData[idx] / this.unitSections[idx].target * 100);
  }

  getSecBarWidth(unitIdx: number, count: number): number {
    const max = Math.max(...this.unitSections[unitIdx].sections.map(s => s.count));
    return Math.round(count / max * 100);
  }

  getSecPct(unitIdx: number, count: number): number {
    return Math.round(count / this.unitData[unitIdx] * 100);
  }

  openUnitDetail(index: number): void {
    this.selectedUnit = index;
  }

  closeModal(): void {
    this.selectedUnit = null;
  }

  closeDetail(event: MouseEvent): void {
    if ((event.target as HTMLElement).classList.contains('bex-modal-overlay')) {
      this.selectedUnit = null;
    }
  }

  loadDashboard() {
    this.http.get<any[]>(`${this.api}?action=dashboard`)
      .subscribe({
        next: (res) => {
          this.unitData = res.map(r => Number(r.total));
          this.grandTotal = this.unitData.reduce((a, b) => a + b, 0);
          this.cd.detectChanges();
        },
        error: (err) => {}
      });
  }

  logout() {
    this.router.navigate(['/login']);
  }
}