import { Component, OnInit, ChangeDetectorRef, ViewChild, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';

// ══════════════════════════════════════════
// TOAST COMPONENT
// ══════════════════════════════════════════
@Component({
  selector: 'app-mu-toast',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="mu-toast-stack">
      <div *ngFor="let t of toasts" class="mu-toast" [ngClass]="t.type" [class.show]="t.show">
        <div class="mu-toast-icon">{{ icons[t.type] }}</div>
        <div class="mu-toast-body">
          <span class="mu-toast-title">{{ titles[t.type] }}</span>
          <span class="mu-toast-msg">{{ t.message }}</span>
        </div>
        <button class="mu-toast-close" (click)="remove(t)">✕</button>
        <div class="mu-toast-bar" [ngClass]="t.type"></div>
      </div>
    </div>
  `,
  styles: [`
    .mu-toast-stack {
      position: fixed; bottom: 28px; right: 28px; z-index: 99999;
      display: flex; flex-direction: column; gap: 12px; pointer-events: none;
    }
    .mu-toast {
      pointer-events: all;
      display: flex; align-items: center; gap: 13px;
      min-width: 310px; max-width: 400px;
      padding: 15px 18px; border-radius: 16px;
      background: #1e1e2e;
      box-shadow: 0 10px 36px rgba(0,0,0,.38);
      border-left: 4px solid transparent;
      transform: translateX(115%); opacity: 0;
      transition: transform 0.38s cubic-bezier(0.34,1.56,0.64,1), opacity 0.38s ease;
      overflow: hidden; position: relative;
    }
    .mu-toast.show { transform: translateX(0); opacity: 1; }
    .mu-toast.success { border-color: #4ade80; }
    .mu-toast.error   { border-color: #f87171; }
    .mu-toast.warning { border-color: #fbbf24; }
    .mu-toast.info    { border-color: #60a5fa; }
    .mu-toast-icon { font-size: 22px; flex-shrink: 0; }
    .mu-toast-body { display: flex; flex-direction: column; gap: 2px; flex: 1; }
    .mu-toast-title { font-size: 11px; font-weight: 800; letter-spacing: 0.7px; text-transform: uppercase; color: #e2e8f0; }
    .mu-toast-msg { font-size: 13px; color: #94a3b8; line-height: 1.4; }
    .mu-toast-close { background: none; border: none; color: #475569; cursor: pointer; font-size: 12px; padding: 2px 4px; flex-shrink: 0; transition: color .2s; }
    .mu-toast-close:hover { color: #e2e8f0; }
    .mu-toast-bar { position: absolute; bottom: 0; left: 0; height: 3px; width: 100%; animation: mu-shrink 3.5s linear forwards; }
    .mu-toast-bar.success { background: #4ade80; }
    .mu-toast-bar.error   { background: #f87171; }
    .mu-toast-bar.warning { background: #fbbf24; }
    .mu-toast-bar.info    { background: #60a5fa; }
    @keyframes mu-shrink { from { width: 100%; } to { width: 0%; } }
  `]
})
export class MuToastComponent {
  toasts: { id: number; message: string; type: string; show: boolean }[] = [];
  private counter = 0;
  icons:  Record<string, string> = { success: '✅', error: '🚫', warning: '⚠️', info: 'ℹ️' };
  titles: Record<string, string> = { success: 'Success', error: 'Error', warning: 'Warning', info: 'Info' };

  show(message: string, type: 'success' | 'error' | 'warning' | 'info' = 'info', duration = 3500) {
    const toast = { id: ++this.counter, message, type, show: false };
    this.toasts.push(toast);
    setTimeout(() => toast.show = true, 20);
    setTimeout(() => this.remove(toast), duration);
  }

  remove(toast: any) {
    toast.show = false;
    setTimeout(() => this.toasts = this.toasts.filter(t => t.id !== toast.id), 420);
  }
}

// ══════════════════════════════════════════
// CONFIRM DIALOG COMPONENT
// ══════════════════════════════════════════
@Component({
  selector: 'app-mu-confirm',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="mu-overlay" [class.show]="visible" (click)="onBg($event)">
      <div class="mu-box" [class.show]="visible">
        <div class="mu-box-icon">🗑️</div>
        <div class="mu-box-title">{{ title }}</div>
        <div class="mu-box-msg">{{ message }}</div>
        <div class="mu-box-actions">
          <button class="mu-box-cancel" (click)="respond(false)">Cancel</button>
          <button class="mu-box-ok"     (click)="respond(true)">Delete</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .mu-overlay {
      position: fixed; inset: 0; z-index: 99998;
      background: rgba(15,23,42,0.55); backdrop-filter: blur(5px);
      display: flex; align-items: center; justify-content: center;
      opacity: 0; pointer-events: none; transition: opacity .3s ease;
    }
    .mu-overlay.show { opacity: 1; pointer-events: all; }
    .mu-box {
      background: #ffffff; border-radius: 24px;
      padding: 36px 32px 28px; min-width: 320px; max-width: 400px;
      text-align: center; box-shadow: 0 24px 64px rgba(15,23,42,.22);
      transform: scale(0.88) translateY(20px);
      transition: transform 0.35s cubic-bezier(0.34,1.56,0.64,1);
    }
    .mu-box.show { transform: scale(1) translateY(0); }
    .mu-box-icon  { font-size: 44px; margin-bottom: 16px; }
    .mu-box-title { font-size: 18px; font-weight: 800; color: #0f172a; margin-bottom: 10px; }
    .mu-box-msg   { font-size: 14px; color: #64748b; line-height: 1.5; margin-bottom: 28px; }
    .mu-box-actions { display: flex; gap: 12px; }
    .mu-box-cancel { flex: 1; height: 46px; border-radius: 14px; border: 1px solid #e2e8f0; background: #fff; font-size: 13px; font-weight: 700; color: #64748b; cursor: pointer; transition: .2s ease; }
    .mu-box-cancel:hover { background: #f8fafc; border-color: #cbd5e1; }
    .mu-box-ok { flex: 1; height: 46px; border-radius: 14px; border: none; background: linear-gradient(135deg, #ef4444, #f87171); font-size: 13px; font-weight: 700; color: #fff; cursor: pointer; transition: .2s ease; box-shadow: 0 8px 20px rgba(239,68,68,.28); }
    .mu-box-ok:hover { transform: translateY(-2px); box-shadow: 0 12px 28px rgba(239,68,68,.36); }
  `]
})
export class MuConfirmComponent {
  visible = false;
  title   = 'Confirm Delete';
  message = 'Are you sure? This action cannot be undone.';
  private resolveFn: ((v: boolean) => void) | null = null;

  open(title: string, message: string): Promise<boolean> {
    this.title = title; this.message = message; this.visible = true;
    return new Promise(r => this.resolveFn = r);
  }

  respond(val: boolean) {
    this.visible = false;
    this.resolveFn?.(val);
    this.resolveFn = null;
  }

  onBg(e: MouseEvent) {
    if ((e.target as HTMLElement).classList.contains('mu-overlay')) this.respond(false);
  }
}

// ══════════════════════════════════════════
// MANAGE USERS COMPONENT
// ══════════════════════════════════════════
@Component({
  selector: 'app-manage-users',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, HttpClientModule, MuToastComponent, MuConfirmComponent],
  template: `
    <div class="mu-root">

      <!-- PAGE HEADER -->
      <div class="mu-page-header">
        <div class="mu-page-header-left">
          <div class="mu-page-icon">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
              <circle cx="9" cy="7" r="4"/>
              <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
              <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
            </svg>
          </div>
          <div>
            <div class="mu-page-title">{{ editMode ? 'Modify User' : 'User Management' }}</div>
            <div class="mu-page-sub">{{ editMode ? 'Edit existing identity' : 'Provision & manage identities' }}</div>
          </div>
        </div>
        <div class="mu-user-count">
          <span class="mu-count-label">TOTAL USERS</span>
          <span class="mu-count-val">{{ users.length }}</span>
        </div>
      </div>

      <div class="mu-layout">

        <!-- LEFT: FORM -->
        <div class="mu-form-panel">
          <div class="mu-panel-header">
            <div class="mu-panel-dot" [class.edit]="editMode"></div>
            <span>{{ editMode ? 'Edit Identity' : 'Enroll New User' }}</span>
          </div>

          <form (ngSubmit)="saveUser()" class="mu-form">
            <div class="mu-field">
              <label class="mu-label">User ID</label>
              <div class="mu-input-wrap">
                <svg class="mu-input-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>
                </svg>
                <input type="text" [(ngModel)]="form.user_id" name="user_id" required class="mu-input" placeholder="Enter user ID">
              </div>
            </div>

            <div class="mu-field">
              <label class="mu-label">Password <span class="mu-req">*</span></label>
              <div class="mu-input-wrap">
                <svg class="mu-input-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                </svg>
                <input [type]="showPwd ? 'text' : 'password'" [(ngModel)]="form.password" name="password" required
                       class="mu-input" placeholder="Min 6 letters, 1 number, 1 special"
                       (input)="validatePassword(form.password)">
                <button type="button" class="mu-pwd-toggle" (click)="showPwd = !showPwd">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                    <path *ngIf="!showPwd" d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                    <circle *ngIf="!showPwd" cx="12" cy="12" r="3"/>
                    <path *ngIf="showPwd" d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
                    <line *ngIf="showPwd" x1="1" y1="1" x2="23" y2="23"/>
                  </svg>
                </button>
              </div>
              <div class="mu-strength-bar" *ngIf="form.password">
                <div class="mu-strength-fill" [style.width.%]="getPwdStrength()" [style.background]="getPwdStrengthColor()"></div>
              </div>
              <div class="mu-pwd-rules" *ngIf="form.password">
                <div class="mu-rule" [class.pass]="(form.password.match(/[a-zA-Z]/g)||[]).length >= 6">
                  <span class="mu-rule-icon">{{ (form.password.match(/[a-zA-Z]/g)||[]).length >= 6 ? '✓' : '○' }}</span>
                  6 alphabets ({{ (form.password.match(/[a-zA-Z]/g)||[]).length }}/6)
                </div>
                <div class="mu-rule" [class.pass]="(form.password.match(/[0-9]/g)||[]).length >= 1">
                  <span class="mu-rule-icon">{{ (form.password.match(/[0-9]/g)||[]).length >= 1 ? '✓' : '○' }}</span>
                  1 number
                </div>
                <div class="mu-rule" [class.pass]="(form.password.match(/[^a-zA-Z0-9]/g)||[]).length >= 1">
                  <span class="mu-rule-icon">{{ (form.password.match(/[^a-zA-Z0-9]/g)||[]).length >= 1 ? '✓' : '○' }}</span>
                  1 special char
                </div>
              </div>
            </div>

            <div class="mu-field">
              <label class="mu-label">Role</label>
              <div class="mu-input-wrap">
                <svg class="mu-input-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                  <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                </svg>
                <select [(ngModel)]="form.role" name="role" required class="mu-input mu-select">
                  <option value="" disabled selected>Select Role</option>
                  <option value="Supervisor">Supervisor</option>
                  <option value="Manager">Manager</option>
                  <option value="HOD">HOD</option>
                  <option value="Business Excellence">Business Excellence</option>
                </select>
              </div>
            </div>

            <div class="mu-field">
              <label class="mu-label">Plant <span class="mu-optional">optional</span></label>
              <div class="mu-input-wrap">
                <svg class="mu-input-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                  <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>
                </svg>
                <select [(ngModel)]="form.plant_id" name="plant_id" class="mu-input mu-select">
                  <option value="" disabled selected>Select Plant</option>
                  <option *ngFor="let u of units" [value]="u">{{ u }}</option>
                </select>
              </div>
            </div>

            <div class="mu-field">
              <label class="mu-label">Section <span class="mu-optional">optional</span></label>
              <div class="mu-input-wrap">
                <svg class="mu-input-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                  <line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/>
                  <line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/>
                  <line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>
                </svg>
                <input type="text" [(ngModel)]="form.section" name="section" class="mu-input" placeholder="e.g. Production A">
              </div>
            </div>

            <div class="mu-field">
              <label class="mu-label">Email <span class="mu-optional">for password reset</span></label>
              <div class="mu-input-wrap">
                <svg class="mu-input-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                  <polyline points="22,6 12,13 2,6"/>
                </svg>
                <input type="email" [(ngModel)]="form.email" name="email" class="mu-input" placeholder="user@company.com">
              </div>
            </div>

            <div class="mu-form-actions">
              <button type="submit" class="mu-btn-primary">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path *ngIf="!editMode" d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/>
                  <polyline *ngIf="!editMode" points="17 21 17 13 7 13 7 21"/>
                  <polyline *ngIf="!editMode" points="7 3 7 8 15 8"/>
                  <path *ngIf="editMode" d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                  <path *ngIf="editMode" d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                </svg>
                {{ editMode ? 'Update User' : 'Save User' }}
              </button>
              <button type="button" class="mu-btn-cancel" *ngIf="editMode" (click)="resetForm()">Cancel</button>
            </div>
          </form>
        </div>

        <!-- RIGHT: TABLE -->
        <div class="mu-table-panel">
          <div class="mu-table-header">
            <div class="mu-panel-header">
              <div class="mu-panel-dot"></div>
              <span>Existing Identities</span>
            </div>
            <div class="mu-search-wrap">
              <svg class="mu-search-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
              </svg>
              <input type="text" [(ngModel)]="searchTerm" class="mu-search" placeholder="Search by ID, role or plant...">
              <button class="mu-search-clear" *ngIf="searchTerm" (click)="searchTerm=''">✕</button>
            </div>
          </div>
          <div class="mu-table-wrap">
            <table class="mu-table">
              <thead>
                <tr><th>User ID</th><th>Role</th><th>Plant</th><th>Section</th><th>Actions</th></tr>
              </thead>
              <tbody>
                <tr *ngFor="let user of filteredUsers()" class="mu-row">
                  <td>
                    <div class="mu-user-id">
                      <div class="mu-avatar">{{ user.user_id.charAt(0).toUpperCase() }}</div>
                      <span>{{ user.user_id }}</span>
                    </div>
                  </td>
                  <td>
                    <span class="mu-badge" [ngClass]="'role-' + user.role.toLowerCase().replace(' ', '-')">{{ user.role }}</span>
                  </td>
                  <td class="mu-cell-muted">{{ user.plant_id || '—' }}</td>
                  <td class="mu-cell-muted">{{ user.section || '—' }}</td>
                  <td>
                    <div class="mu-actions">
                      <button class="mu-act-btn edit" (click)="editUser(user)" title="Edit">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                          <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                          <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                        </svg>
                      </button>
                      <button class="mu-act-btn delete" (click)="deleteUser(user)" title="Delete">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                          <polyline points="3 6 5 6 21 6"/>
                          <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>
                          <path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/>
                        </svg>
                      </button>
                    </div>
                  </td>
                </tr>
                <tr *ngIf="filteredUsers().length === 0">
                  <td colspan="5" class="mu-empty">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" style="opacity:.3;margin-bottom:8px;">
                      <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
                    </svg>
                    <div>No users found for "{{ searchTerm }}"</div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

    <!-- TOAST & CONFIRM -->
    <app-mu-toast   #toast></app-mu-toast>
    <app-mu-confirm #confirmDlg></app-mu-confirm>
  `,
  styles: [`
    @import url('https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700;800&display=swap');
    :host { --orange:#f97316; --orange2:#fb923c; --dark:#0f172a; --text:#334155; --muted:#64748b; --line:#e2e8f0; --white:#ffffff; --card: #FFFFFF;  --border: #EDE5D8;
  --border2: #E2D6C8;    --primary: #E8541A;  --primary-2: #F97316;  --primary-soft: rgba(232,84,26,.1);}
    * { box-sizing:border-box; }
    .mu-root {  min-height:100vh; padding:32px; background: rgb(253, 244, 228); color:var(--dark); overflow:hidden; }
    .mu-page-header { display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  margin-bottom: 22px;
  padding: 16px 22px;
  border-radius: 20px;
  background: var(--card);
  border: 1px solid var(--border);
  box-shadow: 0 2px 12px rgba(28,25,23,.06);
} 
    .mu-page-header-left { display:flex; align-items:center; gap:18px; }
    .mu-page-icon { width:58px; height:58px; border-radius:18px; display:flex; align-items:center; justify-content:center; background:linear-gradient(135deg,var(--orange),var(--orange2)); color:#fff; box-shadow:0 10px 24px rgba(249,115,22,.28); }
    .mu-page-title {  font-size: 20px;  font-weight: 800;  letter-spacing: -.4px;  color: var(--primary); }
    .mu-page-sub { margin-top:5px; font-size:13px; color:var(--muted); }
    .mu-user-count { min-width:135px; padding:14px 20px; border-radius:20px; background:linear-gradient(135deg,var(--orange),var(--orange2)); display:flex; flex-direction:column; align-items:flex-end; color:#fff; box-shadow:0 10px 26px rgba(249,115,22,.3); }
    .mu-count-label { font-size:10px; font-weight:800; letter-spacing:1.3px; opacity:.85; }
    .mu-count-val { font-size:30px; font-weight:800; line-height:1; }
    .mu-layout { display:grid; grid-template-columns:360px 1fr; gap:26px; align-items:start; }
    .mu-form-panel, .mu-table-panel { background:rgba(255,255,255,.72); backdrop-filter:blur(18px); border:1px solid rgba(255,255,255,.85); border-radius:30px; overflow:hidden; box-shadow:0 12px 40px rgba(15,23,42,.06),inset 0 1px 0 rgba(255,255,255,.8); }
    .mu-panel-header { display:flex; align-items:center; gap:12px; padding:22px 24px; border-bottom:1px solid rgba(226,232,240,.9); font-size:14px; font-weight:700; color:var(--dark); }
    .mu-panel-dot { width:10px; height:10px; border-radius:50%; background:#64748b; }
    .mu-panel-dot.edit { background:var(--orange); box-shadow:0 0 10px rgba(249,115,22,.6); }
    .mu-form { padding:24px; display:flex; flex-direction:column; gap:18px; }
    .mu-field { display:flex; flex-direction:column; gap:8px; }
    .mu-label { display:flex; align-items:center; gap:4px; font-size:12px; font-weight:700; color:var(--text); }
    .mu-req { color:#ef4444; }
    .mu-optional { font-size:10px; font-weight:600; color:#94a3b8; }
    .mu-input-wrap { position:relative; width:100%; }
    .mu-input-icon { position:absolute; left:14px; top:50%; transform:translateY(-50%); color:#64748b; z-index:2; }
    .mu-input { width:100%; height:50px; border-radius:16px; border:1px solid var(--line); background:rgba(255,255,255,.92); padding:0 42px; font-size:13px; font-weight:600; color:var(--dark); outline:none; transition:.25s ease; appearance:none; }
    .mu-input::placeholder { color:#94a3b8; }
    .mu-input:hover { border-color:#cbd5e1; }
    .mu-input:focus { border-color:var(--orange); background:#fff; box-shadow:0 0 0 4px rgba(249,115,22,.12); }
    .mu-select { cursor:pointer; background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='%2364748b' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E"); background-repeat:no-repeat; background-position:right 16px center; padding-right:44px; }
    .mu-pwd-toggle { position:absolute; right:14px; top:50%; transform:translateY(-50%); border:none; background:none; color:#64748b; cursor:pointer; display:flex; align-items:center; justify-content:center; }
    .mu-pwd-toggle:hover { color:var(--orange); }
    .mu-strength-bar { width:100%; height:6px; border-radius:999px; overflow:hidden; background:#e2e8f0; }
    .mu-strength-fill { height:100%; border-radius:999px; transition:.35s ease; }
    .mu-pwd-rules { display:flex; flex-wrap:wrap; gap:10px; margin-top:4px; }
    .mu-rule { display:flex; align-items:center; gap:5px; font-size:11px; font-weight:600; color:#94a3b8; }
    .mu-rule.pass { color:#10b981; }
    .mu-form-actions { display:flex; gap:12px; margin-top:4px; }
    .mu-btn-primary { flex:1; height:50px; border:none; border-radius:16px; display:flex; align-items:center; justify-content:center; gap:8px; background:linear-gradient(135deg,var(--orange),var(--orange2)); color:#fff; font-size:13px; font-weight:700; cursor:pointer; transition:.25s ease; box-shadow:0 10px 24px rgba(249,115,22,.28); }
    .mu-btn-primary:hover { transform:translateY(-2px); box-shadow:0 16px 34px rgba(249,115,22,.35); }
    .mu-btn-cancel { height:50px; padding:0 20px; border-radius:16px; border:1px solid var(--line); background:#fff; font-size:13px; font-weight:700; color:#64748b; cursor:pointer; transition:.25s ease; }
    .mu-btn-cancel:hover { border-color:#ef4444; color:#ef4444; }
    .mu-table-header { display:flex; align-items:center; justify-content:space-between; gap:18px; }
    .mu-table-header .mu-panel-header { flex:1; }
    .mu-search-wrap { position:relative; width:290px; margin-right:22px; }
    .mu-search-icon { position:absolute; left:14px; top:50%; transform:translateY(-50%); color:#94a3b8; }
    .mu-search { width:100%; height:48px; border-radius:15px; border:1px solid var(--line); background:#fff; padding:0 40px; font-size:13px; font-weight:600; color:var(--dark); outline:none; transition:.25s ease; }
    .mu-search:focus { border-color:var(--orange); box-shadow:0 0 0 4px rgba(249,115,22,.12); }
    .mu-search-clear { position:absolute; right:12px; top:50%; transform:translateY(-50%); border:none; background:none; color:#94a3b8; cursor:pointer; }
    .mu-table-wrap { overflow-x:auto; padding:14px; }
    .mu-table { width:100%; min-width:850px; border-collapse:separate; border-spacing:0 12px; table-layout:fixed; }
    .mu-table th:nth-child(1),.mu-table td:nth-child(1){width:28%}
    .mu-table th:nth-child(2),.mu-table td:nth-child(2){width:26%}
    .mu-table th:nth-child(3),.mu-table td:nth-child(3){width:16%}
    .mu-table th:nth-child(4),.mu-table td:nth-child(4){width:18%}
    .mu-table th:nth-child(5),.mu-table td:nth-child(5){width:12%;text-align:center}
    .mu-table th { padding:0 18px 10px; text-align:left; font-size:11px; font-weight:800; letter-spacing:1px; text-transform:uppercase; color:#64748b; }
    .mu-row { transition:.25s ease; }
    .mu-row td { background:#fff; padding:18px; font-size:13px; font-weight:600; color:var(--dark); vertical-align:middle; box-shadow:0 4px 16px rgba(15,23,42,.04); }
    .mu-row td:first-child { border-radius:18px 0 0 18px; }
    .mu-row td:last-child  { border-radius:0 18px 18px 0; }
    .mu-row:hover td { background:#fffaf7; transform:translateY(-2px); box-shadow:0 10px 24px rgba(15,23,42,.08); }
    .mu-user-id { display:flex; align-items:center; gap:14px; }
    .mu-avatar { width:40px; height:40px; border-radius:14px; display:flex; align-items:center; justify-content:center; background:linear-gradient(135deg,var(--orange),var(--orange2)); color:#fff; font-size:14px; font-weight:800; flex-shrink:0; box-shadow:0 8px 18px rgba(249,115,22,.25); }
    .mu-cell-muted { color:#64748b !important; }
    .mu-badge { display:inline-flex; align-items:center; justify-content:center; padding:7px 13px; border-radius:999px; font-size:10px; font-weight:800; letter-spacing:.4px; white-space:nowrap; }
    .role-supervisor          { background:rgba(59,130,246,.12); color:#2563eb; }
    .role-manager             { background:rgba(16,185,129,.12);  color:#059669; }
    .role-hod                 { background:rgba(168,85,247,.12);  color:#7c3aed; }
    .role-business-excellence { background:rgba(249,115,22,.12);  color:#ea580c; }
    .mu-actions { display:flex; justify-content:center; gap:8px; }
    .mu-act-btn { width:36px; height:36px; border:none; border-radius:12px; display:flex; align-items:center; justify-content:center; cursor:pointer; transition:.25s ease; }
    .mu-act-btn.edit   { background:rgba(59,130,246,.12); color:#2563eb; }
    .mu-act-btn.edit:hover   { background:#2563eb; color:#fff; transform:translateY(-2px); }
    .mu-act-btn.delete { background:rgba(239,68,68,.12); color:#ef4444; }
    .mu-act-btn.delete:hover { background:#ef4444; color:#fff; transform:translateY(-2px); }
    .mu-empty { padding:70px 20px !important; text-align:center; color:#94a3b8 !important; }
    .mu-form-panel  { animation:muFade .45s ease; }
    .mu-table-panel { animation:muFade .55s ease; }
    @keyframes muFade { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
    @media(max-width:1100px){.mu-layout{grid-template-columns:1fr}.mu-form-panel{width:100%}}
    @media(max-width:768px){.mu-root{padding:18px}.mu-page-header{flex-direction:column;align-items:flex-start}.mu-table-header{flex-direction:column;align-items:stretch;padding-bottom:18px}.mu-search-wrap{width:calc(100% - 24px);margin:0 auto}.mu-table{min-width:850px}}
  `]
})
export class ManageUsersComponent implements OnInit, AfterViewInit {
  api = 'http://localhost:8080/api/bex';
  editMode = false;
  searchTerm: string = '';
  showPwd: boolean = false;
  units = ['Unit 1', 'Unit 2', 'Unit 3', 'Unit 4', 'Unit 5'];
  users: any[] = [];
  form: any = { user_id: '', password: '', role: '', plant_id: '', section: '', old_user_id: '', email: '' };
  passwordErrors: string[] = [];
  passwordValid: boolean = false;

  @ViewChild('toast')      toast!: MuToastComponent;
  @ViewChild('confirmDlg') confirmDlg!: MuConfirmComponent;

  constructor(private router: Router, private http: HttpClient, private cdr: ChangeDetectorRef) {}

  ngOnInit() { this.loadUsers(); }
  ngAfterViewInit() {}

  filteredUsers() {
    if (!this.searchTerm) return this.users;
    const term = this.searchTerm.toLowerCase();
    return this.users.filter(u =>
      u.user_id.toLowerCase().includes(term) ||
      u.role.toLowerCase().includes(term) ||
      (u.plant_id && u.plant_id.toLowerCase().includes(term)) ||
      (u.section  && u.section.toLowerCase().includes(term))
    );
  }

  loadUsers() {
    this.http.get<any[]>(`${this.api}?action=get_users&t=${Date.now()}`).subscribe(res => {
      this.users = [...res];
      this.cdr.detectChanges();
    });
  }

  saveUser() {
    if (!this.form.role) {
      this.toast.show('Please select a role before saving.', 'warning');
      return;
    }
    this.validatePassword(this.form.password);
    if (!this.passwordValid) {
      this.toast.show('Password issue: ' + this.passwordErrors.join(' | '), 'error');
      return;
    }
    this.http.post(`${this.api}/save-user`, this.form).subscribe(() => {
      this.toast.show(this.editMode ? 'User updated successfully!' : 'User enrolled successfully!', 'success');
      this.resetForm();
      this.loadUsers();
    });
  }

  editUser(user: any) {
    this.editMode = true;
    this.form = { ...user, old_user_id: user.user_id };
    window.scrollTo(0, 0);
  }

  async deleteUser(user: any) {
    const ok = await this.confirmDlg.open(
      'Delete User',
      `Are you sure you want to delete "${user.user_id}"? This action cannot be undone.`
    );
    if (ok) {
      this.http.post(`${this.api}/delete-user`, { user_id: user.user_id }).subscribe(() => {
        this.toast.show(`User "${user.user_id}" deleted.`, 'error');
        this.loadUsers();
      });
    }
  }

  validatePassword(pwd: string) {
    const errors: string[] = [];
    const letters = (pwd.match(/[a-zA-Z]/g) || []).length;
    const numbers = (pwd.match(/[0-9]/g)    || []).length;
    const special = (pwd.match(/[^a-zA-Z0-9]/g) || []).length;
    if (letters < 6) errors.push(`Min 6 alphabets (${letters}/6)`);
    if (numbers < 1) errors.push('At least 1 number required');
    if (special < 1) errors.push('At least 1 special character required');
    this.passwordErrors = errors;
    this.passwordValid  = errors.length === 0;
  }

  getPwdStrength(): number {
    const pwd = this.form.password || '';
    let s = 0;
    if ((pwd.match(/[a-zA-Z]/g)     || []).length >= 6) s += 34;
    if ((pwd.match(/[0-9]/g)        || []).length >= 1) s += 33;
    if ((pwd.match(/[^a-zA-Z0-9]/g) || []).length >= 1) s += 33;
    return s;
  }

  getPwdStrengthColor(): string {
    const s = this.getPwdStrength();
    if (s <= 33) return '#ef4444';
    if (s <= 66) return '#f59e0b';
    return '#10b981';
  }

  getPwdStrengthLabel(): string {
    const s = this.getPwdStrength();
    if (s <= 33) return 'Weak';
    if (s <= 66) return 'Medium';
    return 'Strong ✓';
  }

  resetForm() {
    this.editMode = false;
    this.showPwd  = false;
    this.form = { user_id: '', password: '', role: '', plant_id: '', section: '', old_user_id: '', email: '' };
    this.searchTerm    = '';
    this.passwordErrors = [];
    this.passwordValid  = false;
    this.cdr.detectChanges();
  }
}