import { Component, OnInit, ChangeDetectorRef, NgZone } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

/* ── Toast model ───────────────────────────────────────────── */
interface Toast {
  id: number;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message: string;
  visible: boolean;
}

@Component({
  selector: 'app-hod-dashboard',
  standalone: true,
  imports: [CommonModule, HttpClientModule],
  template: `
    <div class="shell">

      <!-- ══════════════════════ TOAST STACK ══════════════════════ -->
      <div class="toast-stack">
        <div
          *ngFor="let t of toasts"
          class="toast toast--{{ t.type }}"
          [class.toast--visible]="t.visible"
          (click)="dismissToast(t.id)">

          <!-- Icon -->
          <div class="toast__icon">
            <!-- success -->
            <svg *ngIf="t.type === 'success'" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
              <polyline points="20 6 9 17 4 12"/>
            </svg>
            <!-- error -->
            <svg *ngIf="t.type === 'error'" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
            <!-- warning -->
            <svg *ngIf="t.type === 'warning'" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
            <!-- info -->
            <svg *ngIf="t.type === 'info'" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>
            </svg>
          </div>

          <!-- Text -->
          <div class="toast__body">
            <span class="toast__title">{{ t.title }}</span>
            <span class="toast__msg">{{ t.message }}</span>
          </div>

          <!-- Close -->
          <button class="toast__close" (click)="dismissToast(t.id); $event.stopPropagation()">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>

          <!-- Progress bar -->
          <div class="toast__progress toast__progress--{{ t.type }}"></div>
        </div>
      </div>

      <!-- ══════════════════════ SIDEBAR ══════════════════════ -->
      <aside class="sidebar" [class.sidebar--collapsed]="isSidebarClosed">

        <!-- Brand -->
        <div class="sb-brand">
          <div class="sb-logo">
            <span class="sb-logo__img"><img src="assets/shaktiman_logo.png" alt="logo"></span>
          </div>
          <div class="sb-brand__text">
            <span class="sb-brand__name">Shaktiman</span>
            <span class="sb-brand__role">HOD Portal</span>
          </div>
        </div>

        <div class="sb-divider"></div>

        <!-- Navigation -->
        <nav class="sb-nav">
          <p class="sb-nav__group-label">Overview</p>

          <button class="sb-nav__item" [class.sb-nav__item--active]="currentView === 'dashboard'"
            (click)="currentView = 'dashboard'">
            <span class="sb-nav__icon">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/>
                <rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>
              </svg>
            </span>
            <span class="sb-nav__label">Intelligence</span>
          </button>

          <button class="sb-nav__item" [class.sb-nav__item--active]="currentView === 'pending'"
            (click)="currentView = 'pending'">
            <span class="sb-nav__icon">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                <polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/>
                <line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/>
              </svg>
            </span>
            <span class="sb-nav__label">Decisions</span>
            <span class="sb-nav__badge" *ngIf="counts.pending > 0">{{ counts.pending }}</span>
          </button>

          <p class="sb-nav__group-label" style="margin-top: 24px;">Archives</p>

          <button class="sb-nav__item" [class.sb-nav__item--active]="currentView === 'history'"
            (click)="currentView = 'history'">
            <span class="sb-nav__icon">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="12 8 12 12 14 14"/><path d="M3.05 11a9 9 0 1 1 .5 4m-.5 5v-5h5"/>
              </svg>
            </span>
            <span class="sb-nav__label">History</span>
          </button>

        </nav>

        <!-- Profile -->
        <div class="sb-profile">
          <div class="sb-profile__avatar">H</div>
          <div class="sb-profile__info">
            <span class="sb-profile__name">Head of Dept.</span>
            <span class="sb-profile__plant">{{emp_id}} · {{ plant }}</span>
          </div>
          <button class="sb-profile__logout" (click)="logout()" title="Sign out">Sign out
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
              <polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>
            </svg>
          </button>
        </div>
      </aside>

      <!-- ══════════════════════ MAIN ══════════════════════ -->
      <div class="main">

        <!-- Top Bar -->
        <header class="topbar">
          <div class="topbar__left">
            <button class="topbar__toggle" (click)="isSidebarClosed = !isSidebarClosed">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                <line x1="3" y1="6" x2="21" y2="6"/>
                <line x1="3" y1="12" x2="21" y2="12"/>
                <line x1="3" y1="18" x2="21" y2="18"/>
              </svg>
            </button>
            <div class="topbar__page-title">
              <span class="topbar__eyebrow">SHAKTI<span class="topbar__eyebrow_path">पथ</span></span>
              <h1 class="topbar__heading">Every Step towards Success</h1>
            </div>
          </div>
          <div class="topbar__right">
            <div class="topbar__status">
              <span class="topbar__status-dot"></span>
              <span>System Live</span>
            </div>
            <div class="topbar__logo">
              <img src="assets/shaktiman_logo.png" alt="Shaktiman" height="28">
            </div>
          </div>
        </header>

        <!-- Content -->
        <main class="content">

          <!-- ── DASHBOARD VIEW ── -->
          <div *ngIf="currentView === 'dashboard'">

            <!-- KPI Row -->
            <div class="kpi-grid">
              <div class="kpi-card">
                <div class="kpi-card__header">
                  <span class="kpi-card__label">Operator Ideas</span>
                  <span class="kpi-card__icon kpi-card__icon--blue">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
                  </span>
                </div>
                <div class="kpi-card__value kpi-card__value--blue">{{ counts.op }}</div>
                <div class="kpi-card__meta">Total Registered</div>
                <div class="kpi-card__bar kpi-card__bar--blue"></div>
              </div>

              <div class="kpi-card">
                <div class="kpi-card__header">
                  <span class="kpi-card__label">Supervisor Input</span>
                  <span class="kpi-card__icon kpi-card__icon--emerald">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                  </span>
                </div>
                <div class="kpi-card__value kpi-card__value--emerald">{{ counts.sup }}</div>
                <div class="kpi-card__meta">Active Verification</div>
                <div class="kpi-card__bar kpi-card__bar--emerald"></div>
              </div>

              <div class="kpi-card">
                <div class="kpi-card__header">
                  <span class="kpi-card__label">Manager Kaizens</span>
                  <span class="kpi-card__icon kpi-card__icon--violet">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
                  </span>
                </div>
                <div class="kpi-card__value kpi-card__value--violet">{{ counts.man }}</div>
                <div class="kpi-card__meta">Implementation Phase</div>
                <div class="kpi-card__bar kpi-card__bar--violet"></div>
              </div>

              <div class="kpi-card kpi-card--urgent">
                <div class="kpi-card__header">
                  <span class="kpi-card__label">Awaiting Signature</span>
                  <span class="kpi-card__icon kpi-card__icon--amber">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                  </span>
                </div>
                <div class="kpi-card__value kpi-card__value--amber">{{ counts.pending }}</div>
                <div class="kpi-card__meta">Critical Priority</div>
                <div class="kpi-card__bar kpi-card__bar--amber"></div>
              </div>
            </div>

            <!-- Impact Distribution -->
            <div class="panel">
              <div class="panel__header">
                <div>
                  <h2 class="panel__title">Kaizen Impact Distribution</h2>
                  <p class="panel__subtitle">PQCDSM Category Breakdown — {{ plantId }}</p>
                </div>
              </div>
              <div class="panel__body">
                <div class="impact-track" *ngIf="impactTotal > 0; else noImpact">
                  <div class="impact-seg impact-seg--p" [style.flex]="getW('Productivity')">
                    <span *ngIf="getW('Productivity') > 6">P</span>
                  </div>
                  <div class="impact-seg impact-seg--q" [style.flex]="getW('Quality')">
                    <span *ngIf="getW('Quality') > 6">Q</span>
                  </div>
                  <div class="impact-seg impact-seg--c" [style.flex]="getW('Cost')">
                    <span *ngIf="getW('Cost') > 6">C</span>
                  </div>
                  <div class="impact-seg impact-seg--d" [style.flex]="getW('Delivery')">
                    <span *ngIf="getW('Delivery') > 6">D</span>
                  </div>
                  <div class="impact-seg impact-seg--s" [style.flex]="getW('Safety')">
                    <span *ngIf="getW('Safety') > 6">S</span>
                  </div>
                  <div class="impact-seg impact-seg--m" [style.flex]="getW('Morale')">
                    <span *ngIf="getW('Morale') > 6">M</span>
                  </div>
                </div>
                <ng-template #noImpact>
                  <div class="empty-state">No impact data available for {{ plantId }}</div>
                </ng-template>

                <div class="impact-legend">
                  <div class="legend-item" *ngFor="let item of impactData | keyvalue">
                    <span class="legend-dot legend-dot--{{ $any(item.key).toLowerCase().charAt(0) }}"></span>
                    <span class="legend-label">{{ item.key }}</span>
                    <span class="legend-val">{{ item.value }}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- ── PENDING VIEW ── -->
          <div *ngIf="currentView === 'pending'">
            <div class="panel">
              <div class="panel__header">
                <div>
                  <h2 class="panel__title">Priority Approval Queue</h2>
                  <p class="panel__subtitle">Awaiting HOD action — {{ counts.pending }} item(s) pending</p>
                </div>
                <span class="badge badge--amber" *ngIf="counts.pending > 0">{{ counts.pending }} Pending</span>
              </div>
              <div class="table-wrap">
                <table class="data-table">
                  <thead>
                    <tr>
                      <th>Kaizen ID</th>
                      <th>Employee</th>
                      <th>Source</th>
                      <th>Theme</th>
                      <th>Submitted</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr *ngFor="let k of getPendingList()">
                      <td><span class="id-chip">{{ k.kaizen_id }}</span></td>
                      <td>
                        <div class="emp-cell">
                          <div class="emp-avatar">{{ k.emp_name?.charAt(0) }}</div>
                          <span>{{ k.emp_name }}</span>
                        </div>
                      </td>
                      <td><span class="role-pill">{{ k.role_type }}</span></td>
                      <td class="theme-cell">{{ k.theme }}</td>
                      <td class="date-cell">{{ (k.submitted_at || k.created_at) | date:'dd MMM yyyy' }}</td>
                      <td>
                        <button class="btn-primary btn-sm" (click)="openKaizen(k)">
                          Review
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                        </button>
                      </td>
                    </tr>
                  </tbody>
                </table>
                <div class="empty-state table-empty" *ngIf="getPendingList().length === 0">
                  <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" opacity="0.3"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                  <p>All caught up — no pending approvals</p>
                </div>
              </div>
            </div>
          </div>

          <!-- ── HISTORY VIEW ── -->
          <div *ngIf="currentView === 'history'">
            <div class="panel">
              <div class="panel__header">
                <div>
                  <h2 class="panel__title">Global Approval History</h2>
                  <p class="panel__subtitle">Audit & modify all decisions — {{ kaizens.length }} total records</p>
                </div>
              </div>
              <div class="table-wrap">
                <table class="data-table">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Initiator</th>
                      <th>Source</th>
                      <th>Theme</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr *ngFor="let k of kaizens">
                      <td><span class="id-chip">{{ k.kaizen_id }}</span></td>
                      <td>
                        <div class="emp-cell">
                          <div class="emp-avatar">{{ k.emp_name?.charAt(0) }}</div>
                          <span>{{ k.emp_name }}</span>
                        </div>
                      </td>
                      <td><span class="role-pill">{{ k.role_type }}</span></td>
                      <td class="theme-cell">{{ k.theme }}</td>
                      <td>
                        <span class="status-badge"
                          [ngClass]="'status-badge--' + ((k.hod_status && k.hod_status !== 'Pending' ? k.hod_status : k.status) || 'pending').toLowerCase()">
                          {{ k.hod_status && k.hod_status !== 'Pending' ? k.hod_status : (k.status || 'Pending') }}
                        </span>
                      </td>
                      <td>
                        <button class="btn-ghost btn-sm" (click)="openKaizen(k)">Modify</button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <!-- ── MASTER VIEW ── -->
          <div *ngIf="currentView === 'master'">
            <div class="panel">
              <div class="panel__header">
                <div>
                  <h2 class="panel__title">Plant Master Configuration</h2>
                  <p class="panel__subtitle">System-level settings management</p>
                </div>
              </div>
              <div class="panel__body access-denied">
                <div class="access-icon">
                  <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                    <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                  </svg>
                </div>
                <h3>Access Restricted</h3>
                <p>Master Data Management is restricted to Admin-level accounts.<br>Contact your system administrator to request access.</p>
              </div>
            </div>
          </div>

        </main>
      </div>

      <!-- ══════════════════════ MODAL ══════════════════════ -->
      <div class="modal-backdrop" *ngIf="selectedKaizen" (click)="selectedKaizen = null">
        <div class="modal" (click)="$event.stopPropagation()">

          <div class="modal__header">
            <div class="modal__header-info">
              <span class="modal__eyebrow">Authorization Review</span>
              <h2 class="modal__title">{{ selectedKaizen.kaizen_id }}</h2>
            </div>
            <button class="modal__close" (click)="selectedKaizen = null">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
          </div>

          <div class="modal__body">

            <!-- Meta info -->
            <div class="meta-grid">
              <div class="meta-item">
                <span class="meta-item__label">Initiator</span>
                <span class="meta-item__val">{{ selectedKaizen.emp_name }}</span>
              </div>
              <div class="meta-item">
                <span class="meta-item__label">Source Level</span>
                <span class="meta-item__val"><span class="role-pill">{{ selectedKaizen.role_type }}</span></span>
              </div>
              <div class="meta-item">
                <span class="meta-item__label">Section</span>
                <span class="meta-item__val">{{ selectedKaizen.section || '—' }}</span>
              </div>
              <div class="meta-item">
                <span class="meta-item__label">Category</span>
                <span class="meta-item__val">{{ selectedKaizen.kaizen_category || '—' }}</span>
              </div>
              <div class="meta-item meta-item--full">
                <span class="meta-item__label">Kaizen Details</span>
                <span class="meta-item__val meta-item__val--desc">{{ selectedKaizen.before_desc || selectedKaizen.theme }}</span>
              </div>
            </div>

            <!-- Image Comparison -->
            <div class="img-compare">
              <div class="img-box">
                <div class="img-box__label img-box__label--before">Before</div>
                <img *ngIf="safeImgSrc(selectedKaizen.before_img)"
                     [src]="safeImgSrc(selectedKaizen.before_img)"
                     class="img-box__img">
                <div *ngIf="!safeImgSrc(selectedKaizen.before_img)" class="img-box__empty">
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                  <span>No image available</span>
                </div>
              </div>
              <div class="img-box">
                <div class="img-box__label img-box__label--after">After</div>
                <img *ngIf="safeImgSrc(selectedKaizen.after_img)"
                     [src]="safeImgSrc(selectedKaizen.after_img)"
                     class="img-box__img">
                <div *ngIf="!safeImgSrc(selectedKaizen.after_img)" class="img-box__empty">
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                  <span>No image available</span>
                </div>
              </div>
            </div>

            <!-- Decision -->
            <div class="decision-section">
              <label class="decision-section__label">
                Executive Remarks
                <span class="decision-section__current" *ngIf="selectedKaizen.hod_remarks">
                  Current: {{ selectedKaizen.hod_remarks }}
                </span>
              </label>
              <textarea #remarks class="decision-section__textarea"
                [value]="selectedKaizen.hod_remarks || ''"
                placeholder="Provide clear reasoning for your decision..."></textarea>

              <div class="decision-section__actions">
                <button class="btn-reject" (click)="process(selectedKaizen, 'Rejected', remarks.value)">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                  Reject Kaizen
                </button>
                <button class="btn-approve" (click)="process(selectedKaizen, 'Approved', remarks.value)">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
                  Approve Kaizen
                </button>
              </div>
            </div>

          </div>
        </div>
      </div>

    </div>
  `,
  styles: [`
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=Syne:wght@600;700;800&display=swap');

    /* ── DESIGN TOKENS ─────────────────────────────── */
    :host {
      --brand:       #E85D04;
      --brand-lt:    #FFF3EC;
      --brand-dim:   rgba(232, 93, 4, 0.12);

      --sb-bg:       #111827;
      --sb-border:   rgba(255,255,255,0.06);
      --sb-text:     #9CA3AF;
      --sb-text-act: #F9FAFB;
      --sb-width:    256px;

      --bg-page:     #FDF4E4;
      --bg-card:     #FFFFFF;
      --bg-muted:    #F9FAFB;

      --text-primary:   #111827;
      --text-secondary: #6B7280;
      --text-tertiary:  #9CA3AF;

      --border:         #E5E7EB;
      --border-strong:  #D1D5DB;

      --blue:    #2563EB; --blue-lt:    #EFF6FF;
      --emerald: #059669; --emerald-lt: #ECFDF5;
      --violet:  #7C3AED; --violet-lt:  #F5F3FF;
      --amber:   #D97706; --amber-lt:   #FFFBEB;
      --red:     #DC2626; --red-lt:     #FEF2F2;

      --shadow-sm:  0 1px 3px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04);
      --shadow-md:  0 4px 16px rgba(0,0,0,0.08), 0 2px 6px rgba(0,0,0,0.04);
      --shadow-lg:  0 12px 40px rgba(0,0,0,0.14), 0 4px 16px rgba(0,0,0,0.06);

      --radius-sm:  6px;
      --radius-md:  10px;
      --radius-lg:  14px;
      --radius-xl:  20px;

      --font-body:  'DM Sans', sans-serif;
      --font-head:  'Syne', sans-serif;
    }

    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    /* ── SHELL ─────────────────────────────────────── */
    .shell {
      position: fixed;
      inset: 0;
      overflow: hidden;
      font-family: var(--font-body);
      background: var(--bg-page);
      color: var(--text-primary);
    }

    .shell:has(.sidebar--collapsed) .main {
      left: 0;
    }

    /* ══════════════════════════════════════════════════
       TOAST SYSTEM
    ══════════════════════════════════════════════════ */
    .toast-stack {
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 9999;
      display: flex;
      flex-direction: column;
      gap: 10px;
      pointer-events: none;
    }

    .toast {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      background: #fff;
      border-radius: 12px;
      padding: 14px 16px 18px;
      min-width: 320px;
      max-width: 400px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.12), 0 2px 8px rgba(0,0,0,0.06);
      border: 1px solid var(--border);
      position: relative;
      overflow: hidden;
      pointer-events: all;
      cursor: pointer;

      /* enter: slide in from right */
      opacity: 0;
      transform: translateX(110%);
      transition: opacity 0.35s cubic-bezier(0.2,1,0.3,1),
                  transform 0.35s cubic-bezier(0.2,1,0.3,1);
    }

    .toast--visible {
      opacity: 1;
      transform: translateX(0);
    }

    /* Left accent stripe via border-left */
    .toast--success { border-left: 4px solid var(--emerald); }
    .toast--error   { border-left: 4px solid var(--red); }
    .toast--warning { border-left: 4px solid var(--amber); }
    .toast--info    { border-left: 4px solid var(--blue); }

    /* Icon circle */
    .toast__icon {
      width: 34px;
      height: 34px;
      border-radius: 50%;
      display: grid;
      place-items: center;
      flex-shrink: 0;
    }
    .toast--success .toast__icon { background: var(--emerald-lt); color: var(--emerald); }
    .toast--error   .toast__icon { background: var(--red-lt);     color: var(--red); }
    .toast--warning .toast__icon { background: var(--amber-lt);   color: var(--amber); }
    .toast--info    .toast__icon { background: var(--blue-lt);    color: var(--blue); }

    /* Body */
    .toast__body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 2px;
      min-width: 0;
    }
    .toast__title {
      font-size: 13.5px;
      font-weight: 700;
      color: var(--text-primary);
      line-height: 1.2;
    }
    .toast__msg {
      font-size: 12.5px;
      color: var(--text-secondary);
      line-height: 1.4;
    }

    /* Close button */
    .toast__close {
      background: none;
      border: none;
      cursor: pointer;
      color: var(--text-tertiary);
      padding: 2px;
      border-radius: 4px;
      display: grid;
      place-items: center;
      flex-shrink: 0;
      transition: color 0.15s;
    }
    .toast__close:hover { color: var(--text-primary); }

    /* Progress bar — shrinks to 0 in 4 s */
    .toast__progress {
      position: absolute;
      bottom: 0;
      left: 0;
      height: 3px;
      width: 100%;
      border-radius: 0 0 12px 12px;
      animation: toast-progress 4s linear forwards;
    }
    .toast__progress--success { background: var(--emerald); }
    .toast__progress--error   { background: var(--red); }
    .toast__progress--warning { background: var(--amber); }
    .toast__progress--info    { background: var(--blue); }

    @keyframes toast-progress {
      from { width: 100%; }
      to   { width: 0%; }
    }

    /* ── SIDEBAR ───────────────────────────────────── */
    .sidebar {
      position: absolute;
      top: 0; left: 0; bottom: 0;
      width: var(--sb-width);
      background: var(--sb-bg);
      display: flex; flex-direction: column;
      transition: width 0.3s ease, opacity 0.3s ease;
      overflow: hidden;
      border-right: 1px solid var(--sb-border);
      z-index: 10;
    }
    .sidebar--collapsed { width: 0; opacity: 0; }

    .sb-brand {
      display: flex; align-items: center; gap: 12px;
      padding: 28px 20px 24px;
    }
    .sb-logo {
    width:60px;
  height:60px;
  border-radius:20px;

  background:#fff;

  display:flex;
  align-items:center;
  justify-content:center;

  box-shadow:
    0 10px 24px rgba(0,0,0,.08);
    }
    .sb-logo__img img {
      width:48px; object-fit:cover;
    }
    .sb-brand__text { display: flex; flex-direction: column; line-height: 1; min-width: 0; }
    .sb-brand__name {
      font-family: var(--font-head); font-size: 15px;
      font-weight: 700; color: var(--sb-text-act);
      white-space: nowrap;
    }
    .sb-brand__role {
      font-size: 11px; color: var(--sb-text);
      margin-top: 3px; white-space: nowrap;
    }

    .sb-divider { height: 1px; background: var(--sb-border); margin: 0 20px; }

    .sb-nav { flex: 1; padding: 20px 12px; overflow-y: auto; }
    .sb-nav::-webkit-scrollbar { width: 4px; }
    .sb-nav::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 4px; }

    .sb-nav__group-label {
      font-size: 10px; font-weight: 600; letter-spacing: 0.08em;
      color: #4B5563; text-transform: uppercase;
      padding: 0 10px; margin-bottom: 6px;
    }

    .sb-nav__item {
      display: flex; align-items: center; gap: 10px;
      width: 100%; padding: 10px 12px; margin-bottom: 2px;
      border: none; border-radius: var(--radius-md);
      background: transparent; cursor: pointer;
      color: var(--sb-text); font-family: var(--font-body);
      font-size: 13.5px; font-weight: 500;
      transition: background 0.15s, color 0.15s;
      text-align: left; white-space: nowrap;
    }
    .sb-nav__item:hover { background: rgba(255,255,255,0.05); color: var(--sb-text-act); }
    .sb-nav__item--active {
      background: rgba(232, 93, 4, 0.15);
      color: #FB923C;
    }
    .sb-nav__icon { flex-shrink: 0; display: flex; }
    .sb-nav__label { flex: 1; }
    .sb-nav__badge {
      background: var(--brand); color: #fff;
      font-size: 11px; font-weight: 700;
      padding: 2px 7px; border-radius: 20px;
    }

    .sb-profile {
      display: flex; align-items: center; gap: 10px;
      padding: 16px 16px; border-top: 1px solid var(--sb-border);
    }
    .sb-profile__avatar {
      width: 34px; height: 34px; border-radius: 8px;
      background: rgba(232, 93, 4, 0.2); color: #FB923C;
      display: grid; place-items: center;
      font-weight: 700; font-size: 14px; flex-shrink: 0;
    }
    .sb-profile__info { flex: 1; min-width: 0; }
    .sb-profile__name {
      display: block; font-size: 13px; font-weight: 600;
      color: var(--sb-text-act); white-space: nowrap; overflow: hidden;
      text-overflow: ellipsis;
    }
    .sb-profile__plant {
      display: block; font-size: 11px; color: var(--sb-text);
      white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    }
    .sb-profile__logout {
      background: none; border: none; cursor: pointer;
      color: #4B5563; padding: 6px; border-radius: 6px;
      display: grid; place-items: center; transition: color 0.15s, background 0.15s;
      flex-shrink: 0;
    }
    .sb-profile__logout:hover { color: #EF4444; background: rgba(239,68,68,0.1); }

    /* ── MAIN ──────────────────────────────────────── */
    .main {
      position: absolute;
      top: 0; right: 0; bottom: 0;
      left: var(--sb-width);
      display: flex; flex-direction: column;
      overflow: hidden;
      transition: left 0.3s ease;
    }

    /* ── TOPBAR ────────────────────────────────────── */
    .topbar {
      height: 68px; background: var(--bg-card);
      border-bottom: 1px solid var(--border);
      display: flex; align-items: center;
      justify-content: space-between;
      padding: 0 28px; flex-shrink: 0;
    }
    .topbar__left { display: flex; align-items: center; gap: 20px; }
    .topbar__toggle {
      background: linear-gradient(135deg, #f97316, #fb923c); border: 1px solid var(--border);
      width: 36px; height: 36px; border-radius: var(--radius-sm);
      display: grid; place-items: center; cursor: pointer;
      color: black; transition: border-color 0.15s, color 0.15s;
    }
    .topbar__toggle:hover { border-color: var(--border-strong); color: var(--text-primary); }
    .topbar__eyebrow {
      font-size: 17px; font-weight: 700; color: var(--text-primary);
      letter-spacing: 0.03em; display: block;
    }
    .topbar__eyebrow_path{
    color:rgb(245, 135, 46)
    }
    .topbar__heading {
      font-family: var(--font-head); font-size: 11px;
      font-weight: 500; color:  var(--text-tertiary); line-height: 1;
    }
    .topbar__right { display: flex; align-items: center; gap: 16px; }
    .topbar__status {
      display: flex; align-items: center; gap: 6px;
      font-size: 12px; font-weight: 500; color: var(--text-secondary);
    }
    .topbar__status-dot {
      width: 7px; height: 7px; border-radius: 50%;
      background: var(--emerald);
      box-shadow: 0 0 0 2px rgba(5,150,105,0.2);
      animation: pulse-dot 2s infinite;
    }
    @keyframes pulse-dot {
      0%,100% { box-shadow: 0 0 0 2px rgba(5,150,105,0.2); }
      50%      { box-shadow: 0 0 0 5px rgba(5,150,105,0.0); }
    }
    .topbar__logo img { height: 28px; }

    /* ── CONTENT ───────────────────────────────────── */
    .content {
      flex: 1; overflow-y: auto;
      padding: 20px 32px;
      display: flex; flex-direction: column; gap: 24px;
    }

    /* ── KPI CARDS ─────────────────────────────────── */
    .kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(210px,1fr)); gap: 16px; }

    .kpi-card {
      background: var(--bg-card); border: 1px solid var(--border);
      border-radius: var(--radius-lg); padding: 20px;
      position: relative; overflow: hidden;
      transition: box-shadow 0.2s, transform 0.2s;
    }
    .kpi-card:hover { box-shadow: var(--shadow-md); transform: translateY(-2px); }
    .kpi-card--urgent { border-color: rgba(217,119,6,0.3); }

    .kpi-card__header {
      display: flex; align-items: center;
      justify-content: space-between; margin-bottom: 16px;
    }
    .kpi-card__label {
      font-size: 12px; font-weight: 600; color: var(--text-secondary);
      text-transform: uppercase; letter-spacing: 0.05em;
    }
    .kpi-card__icon {
      width: 30px; height: 30px; border-radius: var(--radius-sm);
      display: grid; place-items: center;
    }
    .kpi-card__icon--blue   { background: var(--blue-lt);    color: var(--blue); }
    .kpi-card__icon--emerald{ background: var(--emerald-lt); color: var(--emerald); }
    .kpi-card__icon--violet { background: var(--violet-lt);  color: var(--violet); }
    .kpi-card__icon--amber  { background: var(--amber-lt);   color: var(--amber); }

    .kpi-card__value {
      font-family: var(--font-body);
      font-size: 34px;
      font-weight: 700;
      line-height: 1;
      margin-bottom: 6px;
    }
    .kpi-card__value--blue   { color: var(--blue); }
    .kpi-card__value--emerald{ color: var(--emerald); }
    .kpi-card__value--violet { color: var(--violet); }
    .kpi-card__value--amber  { color: var(--amber); }

    .kpi-card__meta { font-size: 12px; color: var(--text-tertiary); }

    .kpi-card__bar {
      position: absolute; bottom: 0; left: 0; right: 0; height: 3px;
    }
    .kpi-card__bar--blue   { background: var(--blue); }
    .kpi-card__bar--emerald{ background: var(--emerald); }
    .kpi-card__bar--violet { background: var(--violet); }
    .kpi-card__bar--amber  { background: var(--amber); }

    /* ── PANEL ─────────────────────────────────────── */
    .panel {
      background: var(--bg-card); border: 1px solid var(--border);
      border-radius: var(--radius-xl); overflow: hidden;
    }
    .panel__header {
      display: flex; align-items: center; justify-content: space-between;
      padding: 20px 24px; border-bottom: 1px solid var(--border);
    }
    .panel__title {
      font-family: var(--font-head); font-size: 16px;
      font-weight: 700; color: var(--text-primary);
    }
    .panel__subtitle {
      font-size: 13px; color: var(--text-tertiary); margin-top: 3px;
    }
    .panel__body { padding: 24px; }

    /* ── IMPACT BAR ────────────────────────────────── */
    .impact-track {
      display: flex; height: 44px; border-radius: var(--radius-md);
      overflow: hidden; gap: 2px; background: var(--bg-muted);
      padding: 2px;
    }
    .impact-seg {
      display: flex; align-items: center; justify-content: center;
      font-size: 11px; font-weight: 800; color: rgba(255,255,255,0.9);
      border-radius: 6px; transition: flex 0.8s cubic-bezier(0.2,1,0.3,1);
      min-width: 0;
    }
    .impact-seg--p { background: var(--blue); }
    .impact-seg--q { background: var(--emerald); }
    .impact-seg--c { background: var(--amber); }
    .impact-seg--d { background: var(--violet); }
    .impact-seg--s { background: var(--red); }
    .impact-seg--m { background: #8B5CF6; }

    .impact-legend {
      display: flex; flex-wrap: wrap; gap: 20px;
      margin-top: 20px; padding-top: 20px;
      border-top: 1px solid var(--border);
    }
    .legend-item { display: flex; align-items: center; gap: 7px; }
    .legend-dot {
      width: 10px; height: 10px; border-radius: 3px; flex-shrink: 0;
    }
    .legend-dot--p { background: var(--blue); }
    .legend-dot--q { background: var(--emerald); }
    .legend-dot--c { background: var(--amber); }
    .legend-dot--d { background: var(--violet); }
    .legend-dot--s { background: var(--red); }
    .legend-dot--m { background: #8B5CF6; }
    .legend-label { font-size: 13px; color: var(--text-secondary); font-weight: 500; }
    .legend-val   { font-size: 13px; color: var(--text-primary);   font-weight: 700; }

    /* ── TABLE ─────────────────────────────────────── */
    .table-wrap { overflow-x: auto; }
    .data-table { width: 100%; border-collapse: collapse; }
    .data-table th {
      padding: 12px 20px; font-size: 11px; font-weight: 600;
      color: var(--text-tertiary); text-transform: uppercase;
      letter-spacing: 0.06em; text-align: left;
      background: var(--bg-muted); border-bottom: 1px solid var(--border);
      white-space: nowrap;
    }
    .data-table td {
      padding: 14px 20px; font-size: 13.5px; color: var(--text-primary);
      border-bottom: 1px solid var(--border);
      vertical-align: middle;
    }
    .data-table tbody tr:last-child td { border-bottom: none; }
    .data-table tbody tr:hover td { background: var(--bg-muted); }

    .id-chip {
      font-size: 12px; font-weight: 700; font-family: 'DM Mono', monospace;
      background: var(--bg-muted); border: 1px solid var(--border);
      padding: 3px 8px; border-radius: var(--radius-sm);
      color: var(--text-secondary); white-space: nowrap;
    }
    .emp-cell { display: flex; align-items: center; gap: 9px; }
    .emp-avatar {
      width: 28px; height: 28px; border-radius: 50%;
      background: #EDE9FE; color: #7C3AED;
      display: grid; place-items: center;
      font-size: 11px; font-weight: 700; flex-shrink: 0;
    }
    .role-pill {
      background: var(--bg-muted); border: 1px solid var(--border);
      font-size: 11px; font-weight: 600; padding: 3px 9px;
      border-radius: 20px; color: var(--text-secondary);
      text-transform: uppercase; letter-spacing: 0.04em;
    }
    .theme-cell {
      max-width: 220px; white-space: nowrap;
      overflow: hidden; text-overflow: ellipsis;
      color: var(--text-secondary);
    }
    .date-cell { color: var(--text-secondary); white-space: nowrap; }

    /* ── STATUS BADGE ──────────────────────────────── */
    .status-badge {
      display: inline-flex; align-items: center; gap: 5px;
      font-size: 11.5px; font-weight: 600;
      padding: 4px 10px; border-radius: 20px;
      text-transform: capitalize; white-space: nowrap;
    }
    .status-badge--approved { background: var(--emerald-lt); color: var(--emerald); }
    .status-badge--rejected { background: var(--red-lt);     color: var(--red); }
    .status-badge--pending  { background: var(--amber-lt);   color: var(--amber); }

    /* ── BADGE ─────────────────────────────────────── */
    .badge--amber {
      background: var(--amber-lt); color: var(--amber);
      font-size: 12px; font-weight: 700;
      padding: 5px 12px; border-radius: 20px;
    }

    /* ── BUTTONS ───────────────────────────────────── */
    .btn-primary {
      display: inline-flex; align-items: center; gap: 6px;
      background: var(--text-primary); color: #fff;
      border: none; border-radius: var(--radius-sm);
      font-family: var(--font-body); font-weight: 600;
      cursor: pointer; transition: background 0.15s, transform 0.15s;
    }
    .btn-primary:hover { background: var(--brand); }
    .btn-ghost {
      display: inline-flex; align-items: center; gap: 6px;
      background: none; color: var(--text-secondary);
      border: 1px solid var(--border); border-radius: var(--radius-sm);
      font-family: var(--font-body); font-weight: 600;
      cursor: pointer; transition: all 0.15s;
    }
    .btn-ghost:hover { border-color: var(--border-strong); color: var(--text-primary); }
    .btn-sm { padding: 7px 14px; font-size: 12.5px; }

    /* ── EMPTY STATE ───────────────────────────────── */
    .empty-state {
      padding: 48px 24px; text-align: center;
      color: var(--text-tertiary); font-size: 14px;
    }
    .table-empty { border-top: 1px solid var(--border); }
    .table-empty p { margin-top: 12px; }

    /* ── ACCESS DENIED ─────────────────────────────── */
    .access-denied {
      text-align: center; padding: 64px 24px;
    }
    .access-icon {
      width: 72px; height: 72px; border-radius: 50%;
      background: var(--bg-muted); border: 1px solid var(--border);
      display: grid; place-items: center; margin: 0 auto 20px;
      color: var(--text-tertiary);
    }
    .access-denied h3 {
      font-family: var(--font-head); font-size: 18px;
      font-weight: 700; color: var(--text-primary); margin-bottom: 10px;
    }
    .access-denied p { font-size: 14px; color: var(--text-secondary); line-height: 1.6; }

    /* ── MODAL ─────────────────────────────────────── */
    .modal-backdrop {
      position: fixed; inset: 0;
      background: rgba(17,24,39,0.55);
      backdrop-filter: blur(6px);
      display: flex; align-items: center; justify-content: center;
      z-index: 1000; padding: 24px;
    }
    .modal {
      background: var(--bg-card); border-radius: var(--radius-xl);
      width: 100%; max-width: 920px;
      box-shadow: var(--shadow-lg);
      display: flex; flex-direction: column;
      max-height: calc(100vh - 48px); overflow: hidden;
    }
    .modal__header {
      display: flex; align-items: flex-start;
      justify-content: space-between; gap: 16px;
      padding: 24px 28px; border-bottom: 1px solid var(--border);
      flex-shrink: 0;
    }
    .modal__eyebrow {
      font-size: 11px; font-weight: 600; color: var(--brand);
      letter-spacing: 0.06em; text-transform: uppercase; display: block;
      margin-bottom: 4px;
    }
    .modal__title {
      font-family: var(--font-head); font-size: 20px;
      font-weight: 800; color: var(--text-primary);
    }
    .modal__close {
      background: none; border: 1px solid var(--border);
      width: 36px; height: 36px; border-radius: var(--radius-sm);
      display: grid; place-items: center; cursor: pointer;
      color: var(--text-secondary); flex-shrink: 0;
      transition: all 0.15s;
    }
    .modal__close:hover { border-color: var(--border-strong); color: var(--text-primary); }

    .modal__body { overflow-y: auto; padding: 28px; display: flex; flex-direction: column; gap: 24px; }

    /* ── META GRID ─────────────────────────────────── */
    .meta-grid {
      display: grid; grid-template-columns: 1fr 1fr;
      gap: 12px; background: var(--bg-muted);
      border: 1px solid var(--border);
      border-radius: var(--radius-lg); padding: 20px;
    }
    .meta-item { display: flex; flex-direction: column; gap: 4px; }
    .meta-item--full { grid-column: span 2; }
    .meta-item__label {
      font-size: 11px; font-weight: 600; color: var(--text-tertiary);
      text-transform: uppercase; letter-spacing: 0.05em;
    }
    .meta-item__val { font-size: 14px; font-weight: 500; color: var(--text-primary); }
    .meta-item__val--desc {
      font-size: 13.5px; font-weight: 400; color: var(--text-secondary);
      line-height: 1.6;
    }

    /* ── IMAGE COMPARE ─────────────────────────────── */
    .img-compare { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    .img-box {
      border-radius: var(--radius-lg); overflow: hidden;
      border: 1px solid var(--border);
      position: relative; background: #F1F2F6;
      min-height: 240px; display: flex; flex-direction: column;
    }
    .img-box__label {
      position: absolute; top: 12px; left: 12px;
      font-size: 11px; font-weight: 700;
      padding: 4px 10px; border-radius: var(--radius-sm);
      letter-spacing: 0.05em; z-index: 1;
    }
    .img-box__label--before { background: var(--red-lt);     color: var(--red); }
    .img-box__label--after  { background: var(--emerald-lt); color: var(--emerald); }
    .img-box__img { width: 100%; height: 260px; object-fit: contain; background: #000; }
    .img-box__empty {
      flex: 1; display: flex; flex-direction: column;
      align-items: center; justify-content: center; gap: 10px;
      color: var(--text-tertiary); font-size: 13px; min-height: 200px;
    }

    /* ── DECISION SECTION ──────────────────────────── */
    .decision-section__label {
      display: flex; align-items: baseline; justify-content: space-between;
      font-size: 13px; font-weight: 600; color: var(--text-primary);
      margin-bottom: 10px;
    }
    .decision-section__current {
      font-size: 12px; font-weight: 400; color: var(--text-tertiary);
      font-style: italic;
    }
    .decision-section__textarea {
      width: 100%; height: 100px;
      border: 1px solid var(--border); border-radius: var(--radius-md);
      padding: 14px 16px; font-family: var(--font-body); font-size: 14px;
      color: var(--text-primary); background: var(--bg-muted);
      resize: none; outline: none; transition: border-color 0.15s;
    }
    .decision-section__textarea:focus {
      border-color: var(--brand); background: var(--bg-card);
    }
    .decision-section__actions {
      display: flex; gap: 12px; margin-top: 16px;
    }

    .btn-reject, .btn-approve {
      display: inline-flex; align-items: center; gap: 8px;
      padding: 12px 24px; border-radius: var(--radius-md);
      font-family: var(--font-body); font-size: 14px; font-weight: 700;
      cursor: pointer; transition: all 0.15s;
    }
    .btn-reject {
      background: var(--bg-card); border: 1.5px solid var(--red);
      color: var(--red);
    }
    .btn-reject:hover { background: var(--red-lt); }
    .btn-approve {
      flex: 1; background: var(--emerald); border: none; color: #fff;
      justify-content: center;
    }
    .btn-approve:hover { background: #047857; transform: translateY(-1px); }
  `]
})
export class HodDashboardComponent implements OnInit {
  public plantId: string = '';
  public plant: string = '';
  public emp_id: string = '';
  public currentView: string = 'dashboard';
  public isSidebarClosed: boolean = false;
  public kaizens: any[] = [];
  public selectedKaizen: any = null;
  public counts = { op: 0, sup: 0, man: 0, pending: 0 };
  public impactData: any = { Productivity: 0, Quality: 0, Cost: 0, Delivery: 0, Safety: 0, Morale: 0 };
  public impactTotal: number = 0;
  private isLoading: boolean = false;

  /* ── Toast state ───────────────────────────────── */
  public toasts: Toast[] = [];
  private toastCounter = 0;

  constructor(
    private http: HttpClient,
    private cdr: ChangeDetectorRef,
    private router: Router,
    private ngZone: NgZone
  ) {}

  ngOnInit() {
    this.emp_id  = sessionStorage.getItem('emp_id') || '';
    this.plant   = sessionStorage.getItem('plant')  || '';
    this.plantId = sessionStorage.getItem('plant')  || 'Unit 1';
    this.loadData();
  }

  /* ── Toast helpers ─────────────────────────────── */
  showToast(
    type: Toast['type'],
    title: string,
    message: string,
    duration = 4000
  ): void {
    const id = ++this.toastCounter;
    const toast: Toast = { id, type, title, message, visible: false };
    this.toasts.push(toast);
    this.cdr.detectChanges();

    // Trigger slide-in on next tick
    setTimeout(() => {
      toast.visible = true;
      this.cdr.detectChanges();
    }, 20);

    // Auto-dismiss
    setTimeout(() => this.dismissToast(id), duration);
  }

  dismissToast(id: number): void {
    const t = this.toasts.find(x => x.id === id);
    if (!t) return;
    t.visible = false;
    this.cdr.detectChanges();
    // Remove from array after slide-out animation
    setTimeout(() => {
      this.toasts = this.toasts.filter(x => x.id !== id);
      this.cdr.detectChanges();
    }, 400);
  }

  /* ── Rest of logic ─────────────────────────────── */
  getPageTitle(): string {
    const map: any = {
      dashboard: 'Intelligence Dashboard',
      pending:   'Decision Queue',
      history:   'Approval History',
      master:    'Master Configuration'
    };
    return map[this.currentView] || 'Dashboard';
  }

  openKaizen(k: any) {
    this.selectedKaizen = { ...k };
    this.cdr.detectChanges();

    const role = k.role_type || 'Manager';
    this.http.get<any>(
      `http://localhost:8080/api/kaizen/detail?id=${k.id}&role=${role}`
    ).subscribe({
      next: (detail) => {
        this.selectedKaizen = { ...k, ...detail };
        this.cdr.detectChanges();
      },
      error: () => {}
    });
  }

  loadData() {
    if (this.isLoading) return;
    this.isLoading = true;

    const url = `http://localhost:8080/api/kaizen?plant_id=${encodeURIComponent(this.plantId)}`;
    this.http.get(url).subscribe({
      next: (res: any) => {
        if (!res) { this.isLoading = false; return; }
        this.kaizens = res.list || [];
        this.counts  = res.counts
          ? { ...res.counts }
          : { op: 0, sup: 0, man: 0, pending: 0 };
        if (res.impact) {
          this.impactData  = { ...res.impact };
          this.impactTotal = Object.values(res.impact)
            .reduce((a: any, b: any) => Number(a) + Number(b), 0) as number;
        } else {
          this.impactTotal = 0;
        }
        this.isLoading = false;
        this.cdr.markForCheck();
        this.cdr.detectChanges();
      },
      error: () => { this.isLoading = false; }
    });
  }

  getPendingList() {
    return this.kaizens.filter(k => !k.hod_status || k.hod_status === 'Pending');
  }

  safeImgSrc(imgData: any): string | null {
    if (!imgData) return null;
    const str = String(imgData).trim();
    if (!str) return null;
    if (str.startsWith('http://') || str.startsWith('https://')) return str;
    if (str.startsWith('data:')) return str;
    if (/\.(jpg|jpeg|png|gif|webp)/.test(str)) {
      return 'http://localhost/kaizen-backend/uploads/' + str;
    }
    if (str.length > 100) return 'data:image/jpeg;base64,' + str;
    return null;
  }

  getW(key: string): number {
    if (this.impactTotal === 0 || !this.impactData[key]) return 0;
    return (Number(this.impactData[key]) / this.impactTotal) * 100;
  }

  process(k: any, status: string, remark: string) {
    if (!remark.trim()) {
      this.showToast(
        'warning',
        'Remarks Required',
        'Please provide feedback before modifying this decision.'
      );
      return;
    }

    this.http.post('http://localhost:8080/api/kaizen/update', {
      id:          k.id,
      action:      status,
      hod_remarks: remark,
      role_type:   k.role_type
    }).subscribe({
      next: (res: any) => {
        if (res?.error) {
          this.showToast('error', 'Update Failed', res.error);
        } else {
          const label = status === 'Approved' ? 'Approved' : 'Rejected';
          this.showToast(
            status === 'Approved' ? 'success' : 'error',
            `Kaizen ${label}`,
            `${k.kaizen_id} has been successfully ${label.toLowerCase()}.`
          );
          this.selectedKaizen = null;
          this.loadData();
        }
      },
      error: () =>
        this.showToast('error', 'Network Error', 'Action failed. Please try again.')
    });
  }

  logout() {
    sessionStorage.clear();
    this.router.navigate(['/login']);
  }
}