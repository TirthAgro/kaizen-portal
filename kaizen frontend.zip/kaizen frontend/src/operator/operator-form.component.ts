import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-operator-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule],
  encapsulation: ViewEncapsulation.None,
  template: `
    <div class="shaktiman-ribbon"></div>

    <div class="custom-overlay" *ngIf="showConfirmModal">
      <div class="modern-modal">
        <div class="modal-icon">?</div>
        <h3>Confirm Registration</h3>
        <p>Are you sure you want to submit this Kaizen to the portal?</p>
        <div class="modal-preview-box">
          <strong>Kaizen ID:</strong> {{ kaizenNo }}<br>
          <strong>Theme:</strong> {{ kaizenForm.value.theme }}
        </div>
        <div class="modal-actions">
          <button class="btn-cancel" (click)="showConfirmModal = false">Review</button>
          <button class="btn-confirm" (click)="finalSubmit()">Submit Now</button>
        </div>
      </div>
    </div>

    <div class="custom-overlay" *ngIf="showSuccessModal">
      <div class="modern-modal success-style">
        <div class="modal-icon check">✔</div>
        <h3>Success!</h3>
        <p>Kaizen <strong>{{ lastSubmittedNo }}</strong> has been registered.</p>
        <button class="btn-confirm" (click)="showSuccessModal = false">Great!</button>
      </div>
    </div>

    <div class="container-main">
      <div class="form-card">
        <header class="form-header">
          <div class="header-left">
            <span class="brand-label">SHAKTIMAN KAIZEN PORTAL</span>
            <h2>Operator Level Entry</h2>
          </div>
          <div class="header-right header-flex">
            <div class="meta-group">
              <div class="meta-box dark" [class.error-bg]="kaizenNo === 'KZN-Error'">
                Kaizen ID: {{ kaizenNo }}
                <button *ngIf="kaizenNo === 'KZN-Error'" (click)="fetchNextId()" class="retry-btn">Retry</button>
              </div>
              <div class="meta-box light">Reg Date: {{ today | date:'dd-MMM-yyyy hh:mm A' }}</div>
            </div>
            <button type="button" class="logout-pill" (click)="logout()">
              <span class="power-icon">⏻</span> Logout
            </button>
          </div>
        </header>

        <form [formGroup]="kaizenForm" (ngSubmit)="onPreSubmit()" class="form-content">

          <!-- ROW 1: Emp ID, Emp Name, Plant — always visible -->
          <div class="row-grid">
            <div class="field">
              <label>Employee ID <span class="req">*</span></label>
              <input type="text" formControlName="emp_id"
                     (keypress)="allowNumbersOnly($event)"
                     placeholder="Numbers only">
              <div class="err-msg" *ngIf="kaizenForm.get('emp_id')?.touched && kaizenForm.get('emp_id')?.errors?.['required']">Employee ID is required</div>
              <div class="err-msg" *ngIf="kaizenForm.get('emp_id')?.touched && kaizenForm.get('emp_id')?.errors?.['pattern']">Numbers only allowed</div>
            </div>
            <div class="field">
              <label>Employee Name <span class="req">*</span></label>
              <input type="text" formControlName="emp_name"
                     (keypress)="allowAlphabetsOnly($event)"
                     placeholder="Alphabets only">
              <div class="err-msg" *ngIf="kaizenForm.get('emp_name')?.touched && kaizenForm.get('emp_name')?.errors?.['required']">Employee Name is required</div>
              <div class="err-msg" *ngIf="kaizenForm.get('emp_name')?.touched && kaizenForm.get('emp_name')?.errors?.['pattern']">Alphabets only allowed</div>
            </div>
            <div class="field">
              <label>Plant (Unit) <span class="req">*</span></label>
              <select formControlName="unit" (change)="onUnitChange()">
                <option value="">Select Unit</option>
                <option *ngFor="let i of [1,2,3,4,5]" [value]="'Unit '+i">Unit {{i}}</option>
              </select>
              <div class="err-msg" *ngIf="kaizenForm.get('unit')?.touched && kaizenForm.get('unit')?.errors?.['required']">Unit is required</div>
            </div>
          </div>

          <!-- ROW 2: Department — visible ONLY after Plant is selected -->
          <div class="row-grid-dep" *ngIf="kaizenForm.get('unit')?.value">
            <div class="field">
              <label>Department <span class="req">*</span></label>
              <select formControlName="department" (change)="onDepartmentChange()">
                <option value="">Select Department</option>
                <option *ngFor="let dept of currentDepartments" [value]="dept">{{ dept }}</option>
              </select>
              <div class="err-msg" *ngIf="kaizenForm.get('department')?.touched && kaizenForm.get('department')?.errors?.['required']">Department is required</div>
            </div>
          </div>

          <!-- ROW 3: Zone + Section — visible ONLY after Department is selected -->
          <div class="row-grid" *ngIf="kaizenForm.get('department')?.value">
            <div class="field">
              <label>Zone / Circle <span class="req">*</span></label>
              <input type="text" formControlName="zone" placeholder="e.g. Zone A">
              <div class="err-msg" *ngIf="kaizenForm.get('zone')?.touched && kaizenForm.get('zone')?.errors?.['required']">Zone is required</div>
            </div>
            <div class="field">
              <label>Section <span class="req">*</span></label>
              <select formControlName="section" (change)="onSectionChange()">
                <option value="">Select Section</option>
                <option value="Welding">Welding</option>
                <option value="Cutting">Cutting</option>
                <option value="Assembly">Assembly</option>
                <option value="Machine Shop">Machine Shop</option>
                <option value="Other">Other (Type manually...)</option>
              </select>
              <div class="err-msg" *ngIf="kaizenForm.get('section')?.touched && kaizenForm.get('section')?.errors?.['required']">Section is required</div>
            </div>
            <!-- Other Section — visible ONLY after "Other" is selected -->
            <div class="field" *ngIf="kaizenForm.get('section')?.value === 'Other'">
              <label>Specify Section <span class="req">*</span></label>
              <input type="text" formControlName="other_section" placeholder="Enter Section Name">
            </div>
          </div>

          <!-- Kaizen Theme -->
          <div class="full-row field">
            <label>Kaizen Theme <span class="req">*</span></label>
            <input type="text" formControlName="theme"
                   (input)="checkDuplicateTheme()"
                   [class.error-border]="isDuplicate"
                   placeholder="Brief title of improvement">
            <div class="err-msg" *ngIf="isDuplicate">⚠ This Kaizen Theme already exists. Please use a unique title.</div>
            <div class="err-msg" *ngIf="kaizenForm.get('theme')?.touched && kaizenForm.get('theme')?.errors?.['required'] && !isDuplicate">Theme is required</div>
          </div>

          <!-- PQCDSM + Category -->
          <div class="row-grid-cat">
            <div class="field">
              <label>Group (PQCDSM) <span class="req">*</span></label>
              <select formControlName="pqcdsm">
                <option value="">Select Group</option>
                <option value="P - Productivity">P - Productivity</option>
                <option value="Q - Quality">Q - Quality</option>
                <option value="C - Cost">C - Cost</option>
                <option value="D - Delivery">D - Delivery</option>
                <option value="S - Safety">S - Safety</option>
                <option value="M - Morale">M - Morale</option>
              </select>
              <div class="err-msg" *ngIf="kaizenForm.get('pqcdsm')?.touched && kaizenForm.get('pqcdsm')?.errors?.['required']">PQCDSM is required</div>
            </div>
            <div class="field">
              <label>Kaizen Category <span class="req">*</span></label>
              <select formControlName="kaizen_category">
                <option value="">Select Category</option>
                <option *ngFor="let cat of categories" [value]="cat.v">{{cat.l}}</option>
              </select>
              <div class="err-msg" *ngIf="kaizenForm.get('kaizen_category')?.touched && kaizenForm.get('kaizen_category')?.errors?.['required']">Category is required</div>
            </div>
          </div>

          <!-- Dates -->
          <div class="row-grid-2">
            <div class="field">
              <label>Start Date <span class="req">*</span></label>
              <input type="date" formControlName="start_date">
              <div class="err-msg" *ngIf="kaizenForm.get('start_date')?.touched && kaizenForm.get('start_date')?.errors?.['required']">Start Date is required</div>
            </div>
            <div class="field">
              <label>End Date <span class="req">*</span></label>
              <input type="date" formControlName="end_date">
              <div class="err-msg" *ngIf="kaizenForm.get('end_date')?.touched && kaizenForm.get('end_date')?.errors?.['required']">End Date is required</div>
            </div>
          </div>

          <hr class="divider">

          <!-- Before / After Evidence -->
          <div class="row-grid-2">
            <div class="evidence-panel red-style">
              <label class="evidence-title">Before Status (Problem) <span class="req">*</span></label>
              <input type="file" (change)="onFileChange($event, 'before_img')" accept="image/*">
              <p class="file-hint">Any size — auto-compressed to under 500KB</p>
              <div class="err-msg" *ngIf="compressing['before_img']">⏳ Compressing image...</div>
              <div class="compress-info" *ngIf="compressInfo['before_img']">{{compressInfo['before_img']}}</div>
              <textarea formControlName="before_desc" rows="3" placeholder="Describe current problem..."></textarea>
              <div class="err-msg" *ngIf="kaizenForm.get('before_desc')?.touched && kaizenForm.get('before_desc')?.errors?.['required']">Before description is required</div>
            </div>
            <div class="evidence-panel green-style">
              <label class="evidence-title">After Status (Solution) <span class="req">*</span></label>
              <input type="file" (change)="onFileChange($event, 'after_img')" accept="image/*">
              <p class="file-hint">Any size — auto-compressed to under 500KB</p>
              <div class="err-msg" *ngIf="compressing['after_img']">⏳ Compressing image...</div>
              <div class="compress-info" *ngIf="compressInfo['after_img']">{{compressInfo['after_img']}}</div>
              <textarea formControlName="after_desc" rows="3" placeholder="Describe improvement made..."></textarea>
              <div class="err-msg" *ngIf="kaizenForm.get('after_desc')?.touched && kaizenForm.get('after_desc')?.errors?.['required']">After description is required</div>
            </div>
          </div>

          <!-- Benefits + Team -->
          <div class="row-grid-2">
            <div class="field">
              <label>Kaizen Benefits <span class="req">*</span></label>
              <textarea formControlName="benefits" rows="4" placeholder="e.g. Time saved, Cost reduction..."></textarea>
              <div class="err-msg" *ngIf="kaizenForm.get('benefits')?.touched && kaizenForm.get('benefits')?.errors?.['required']">Benefits is required</div>
            </div>
            <div class="field">
              <label>Team Members <span class="req">*</span></label>
              <textarea formControlName="team" rows="4"
                        (keypress)="allowTeamInput($event)"
                        (keydown)="handleTeamNumbering($event)"
                        placeholder="1. Member Name"></textarea>
              <p class="file-hint">Alphabets and spaces only</p>
              <div class="err-msg" *ngIf="kaizenForm.get('team')?.touched && kaizenForm.get('team')?.errors?.['required']">Team members is required</div>
            </div>
          </div>

          <button type="submit" class="btn-submit"
            [disabled]="isDuplicate || kaizenForm.invalid || hasFileError() || isAnyCompressing() || kaizenNo === 'KZN-Error'">
            {{ kaizenNo === 'KZN-Error' ? 'SYSTEM OFFLINE' : isAnyCompressing() ? 'COMPRESSING...' : (isDuplicate ? 'DUPLICATE THEME' : '✔ SUBMIT OPERATOR KAIZEN') }}
          </button>

        </form>
      </div>
    </div>
  `,
  styles: [`
    :root { --sorange: #ff7f27; --sdark: #000000; }
    body { background: #f0f2f5 !important; margin: 0; font-family: 'Inter', 'Segoe UI', sans-serif; }
    .shaktiman-ribbon { height: 18px; background: #ff7f27; position: fixed; top: 0; width: 100%; z-index: 1000; }
    .container-main { padding: 50px 20px; max-width: 1000px; margin: 0 auto; }
    .form-card { background: #fff; border-radius: 20px; box-shadow: 0 15px 40px rgba(0,0,0,0.12); overflow: hidden; }
    .form-header { background: #000; color: #fff; padding: 25px 35px; border-bottom: 5px solid #ff7f27; display: flex; justify-content: space-between; align-items: center; }
    .header-flex { display: flex; align-items: center; gap: 20px; }
    .meta-group { display: flex; flex-direction: column; align-items: flex-end; }
    .brand-label { color: #ff7f27; font-weight: 900; letter-spacing: 1.5px; font-size: 11px; }
    .meta-box { padding: 6px 15px; border-radius: 6px; font-weight: bold; font-size: 13px; margin-bottom: 5px; text-align: right; display: flex; align-items: center; gap: 10px; }
    .meta-box.dark { background: #222; color: #fff; }
    .meta-box.light { background: #f8f9fa; color: #007bff; border: 1px solid #ddd; }
    .error-bg { border: 2px solid #ef4444 !important; color: #ef4444 !important; }
    .retry-btn { background: #ef4444; color: white; border: none; padding: 2px 8px; border-radius: 4px; font-size: 10px; cursor: pointer; }
    .logout-pill { background: #ff7f27; color: #000; border: none; padding: 10px 18px; border-radius: 50px; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 8px; transition: 0.3s; font-size: 14px; }
    .logout-pill:hover { background: #fff; transform: scale(1.05); }
    .custom-overlay { position: fixed; top:0; left:0; width:100%; height:100%; background: rgba(0,0,0,0.6); z-index: 3000; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(8px); }
    .modern-modal { background: #fff; width: 420px; padding: 35px; border-radius: 25px; text-align: center; box-shadow: 0 25px 50px rgba(0,0,0,0.2); animation: popScale 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
    .modal-icon { width: 70px; height: 70px; background: #ff7f27; color: #fff; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 15px; font-size: 32px; }
    .modal-icon.check { background: #28a745; }
    .modal-preview-box { background: #f8f9fa; padding: 15px; border-radius: 12px; margin: 20px 0; font-size: 14px; text-align: left; border-left: 4px solid #ff7f27; }
    .modal-actions { display: flex; gap: 12px; }
    .btn-cancel { flex:1; padding: 12px; border: 1px solid #ddd; border-radius: 10px; background: #fff; cursor: pointer; }
    .btn-confirm { flex:1; padding: 12px; border: none; border-radius: 10px; background: #000; color: #fff; font-weight: bold; cursor: pointer; }
    .form-content { padding: 35px; }
    .row-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; margin-bottom: 20px; }
    .row-grid-dep { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; margin-bottom: 20px; }
    .row-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
    .row-grid-cat { display: grid; grid-template-columns: 1fr 2fr; gap: 20px; margin-bottom: 20px; }
    .full-row { margin-bottom: 20px; }
    .field { display: flex; flex-direction: column; gap: 6px; }
    .field label { font-weight: 700; color: #334155; font-size: 13px; }
    .req { color: #ef4444; font-size: 14px; font-weight: 900; margin-left: 2px; }
    input, select, textarea { padding: 12px; border: 2px solid #e2e8f0; border-radius: 10px; font-size: 14px; background: #fdfdfd; width: 100%; box-sizing: border-box; }
    input:focus, select:focus, textarea:focus { border-color: #ff7f27; outline: none; background: #fff; }
    .error-border { border-color: #ef4444 !important; }
    .err-msg { color: #ef4444; font-size: 11px; font-weight: bold; margin-top: 4px; }
    .compress-info { color: #10b981; font-size: 11px; font-weight: 600; margin-top: 4px; }
    .file-hint { font-size: 11px; color: #64748b; margin-top: 4px; font-weight: 600; }
    .divider { margin: 20px 0; border: 0; border-top: 2px dashed #eee; }
    .evidence-panel { padding: 18px; border-radius: 12px; background: #f8fafc; border: 2px dashed #cbd5e1; display: flex; flex-direction: column; gap: 8px; }
    .evidence-panel.red-style { border-left: 6px solid #ef4444; }
    .evidence-panel.green-style { border-left: 6px solid #22c55e; }
    .evidence-title { font-weight: 700; color: #334155; font-size: 13px; }
    .btn-submit { width: 100%; padding: 18px; background: #000; color: #fff; border: none; border-radius: 12px; font-size: 16px; font-weight: 800; cursor: pointer; transition: 0.2s; margin-top: 10px; }
    .btn-submit:hover:not(:disabled) { background: #ff7f27; transform: translateY(-2px); }
    .btn-submit:disabled { background: #cbd5e1; cursor: not-allowed; }
    @keyframes popScale { from { transform: scale(0.8); opacity: 0; } to { transform: scale(1); opacity: 1; } }
  `]
})
export class OperatorFormComponent implements OnInit {

  public kaizenNo: string = 'Fetching...';
  public today: Date = new Date();
  public kaizenForm!: FormGroup;
  public isSubmitting: boolean = false;
  public isDuplicate: boolean = false;
  public showConfirmModal: boolean = false;
  public showSuccessModal: boolean = false;
  public lastSubmittedNo: string = '';
  public fileErrors:   { [key: string]: boolean } = { before_img: false, after_img: false };
  public compressing:  { [key: string]: boolean } = { before_img: false, after_img: false };
  public compressInfo: { [key: string]: string  } = { before_img: '', after_img: '' };
  private selectedFiles: { [key: string]: File | null } = { before_img: null, after_img: null };
  private allThemes: string[] = [];

  public plantDepartments: { [unit: string]: string[] } = {
    'Unit 1': ['HTFE', 'FE', 'G & T'],
    'Unit 2': ['FTS'],
    'Unit 3': ['PD','SPED'],
    'Unit 4': ['SPARE PARTS','LOGISTICS'],
    'Unit 5': ['HTFE', 'FE', 'G & T'],
  };

  public currentDepartments: string[] = [];

  constructor(private router: Router, private http: HttpClient, private cdr: ChangeDetectorRef) {}

  public categories = [
    { v: 'C-1|Restorative (TPM)',              l: 'C-1: Restorative (Using TPM Methodology)' },
    { v: 'C-2|Renovative (TPM)',               l: 'C-2: Renovative (Using TPM Methodology)' },
    { v: 'C-3|Innovative (TPM)',               l: 'C-3: Innovative (Using TPM Methodology)' },
    { v: 'C-4|Breakthrough (TPM)',             l: 'C-4: Breakthrough (Using TPM Methodology)' },
    { v: 'C-5|Poka Yoke (TPM)',                l: 'C-5: Poka Yoke (Using TPM Methodology)' },
    { v: 'C-6|KARAKURI & YUTORI',              l: 'C-6: KARAKURI (No Energy Loss) & YUTORI' },
    { v: 'C-7|JH Shop Floor Visualization',    l: 'C-7: JH - Shop Floor Visualization' },
    { v: 'C-8|KK OEE Compliance',              l: 'C-8: KK OEE Compliance (Top 5 Machines across BU)' },
    { v: 'C-9|KK Bottleneck Process Solution', l: 'C-9: KK Bottleneck Process Identified & Solution' },
    { v: 'C-10|JH Circle Board Updating',      l: 'C-10: JH - Circle Board updating, Key indicators Monitoring' },
    { v: 'C-11|JH One Point Lessons',          l: 'C-11: JH - One Point Lessons for the month' },
    { v: 'C-12|JH White Tag Abnormality',      l: 'C-12: JH: Max no. of white tag abnormality Identified & Rectified' },
    { v: 'C-13|JH (HTA / SOC / Ease for CLITA)', l: 'C-13: JH (HTA / SOC / Ease for CLITA)' },
    { v: 'C-14|JH Step 4 M-M Combination',    l: 'C-14: JH step 4 Man-Machine combination' },
    { v: 'C-15|JH Step 5 M-M Combination',    l: 'C-15: JH step 5 Man-Machine combination' },
    { v: 'C-16|JH Step 1, 2, 3 Repeat',       l: 'C-16: JH: Repeat of JH Step 1, 2, 3' },
    { v: 'C-17|JH Minor Stoppage Monitoring',  l: 'C-17: JH: Minor Stoppage Monitoring and DO Kaizen' },
    { v: 'C-18|JH RED Tag Abnormality',        l: 'C-18: JH: Max no. of RED tag abnormality type Identified by TPM Circle' },
    { v: 'C-19|QM Assembly Pokamapping',       l: 'C-19: QM: Product Assembly Pokamapping & closure of issues' },
    { v: 'C-20|PM MP Sheets Generation',       l: 'C-20: PM: Generation of MP sheets' },
    { v: 'C-21|NEDM MP Sheets Implementation', l: 'C-21: NEDM: Successful Implementation of MP sheets' },
    { v: 'C-22|NEDM Low Cost Automation',      l: 'C-22: NEDM: Low Cost Automation' },
    { v: 'C-23|OTPM MAKIGAMI',                 l: 'C-23: OTPM: MAKIGAMI' },
    { v: 'C-24|OTPM Red Tag Office',           l: 'C-24: OTPM: Red tag at Office area (5S)' },
    { v: 'C-25|SHE Near Miss/Unsafe Condition',l: 'C-25: SHE: identified Near miss situation & Unsafe condition' },
    { v: 'C-26|SHE Unsafe Act',                l: 'C-26: SHE: Unsafe act' },
    { v: 'C-27|SHE Ergonomic Hazard',          l: 'C-27: SHE: Ergonomic hazard Condition' },
    { v: 'C-28|SHE CO2 Emission Reduction',    l: 'C-28: SHE: CO2 emission reduction by using Renewable Energy' },
    { v: 'C-29|SHE Micro Level HIRA',          l: 'C-29: SHE: Micro level HIRA for listed all Processes / Activities' },
    { v: 'C-30|5S Zone Space Saved',           l: 'C-30: 5S: Zone wise space saved THROUGH 5s' },
    { v: 'C-31|5S Best 1S-3S',                 l: 'C-31: 5S: Best 1S, 2S, 3S, at Zones' },
    { v: 'C-32|All Members',                   l: 'C-32: Sure Appreciation' },
    { v: 'C-33|All Members',                   l: 'C-33: Won the Awards from CII (Platinium & Gold)' },
    { v: 'C-34|All Members',                   l: 'C-34: Won the Awards from CII (Jury Challenger, Champion of Champians, Jury Champion)' },
  ];

  ngOnInit() {
    this.fetchNextId();
    this.loadExistingThemes();
    this.initForm();
  }

  initForm() {
    this.currentDepartments = [];
    this.kaizenForm = new FormGroup({
      emp_id:          new FormControl('', [Validators.required, Validators.pattern('^[0-9]+$')]),
      emp_name:        new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z ]+$')]),
      unit:            new FormControl('', Validators.required),
      department:      new FormControl('', Validators.required),
      zone:            new FormControl('', Validators.required),
      section:         new FormControl('', Validators.required),
      other_section:   new FormControl(''),
      theme:           new FormControl('', Validators.required),
      pqcdsm:          new FormControl('', Validators.required),
      kaizen_category: new FormControl('', Validators.required),
      start_date:      new FormControl('', Validators.required),
      end_date:        new FormControl('', Validators.required),
      before_desc:     new FormControl('', Validators.required),
      after_desc:      new FormControl('', Validators.required),
      benefits:        new FormControl('', Validators.required),
      team:            new FormControl('1. ', Validators.required)
    });
  }

  // Plant selected → show Department row, reset downstream
  onUnitChange() {
    const selectedUnit = this.kaizenForm.get('unit')?.value;
    this.currentDepartments = this.plantDepartments[selectedUnit] || [];
    this.kaizenForm.patchValue({ department: '', zone: '', section: '', other_section: '' });
  }

  // Department selected → show Zone+Section row, reset downstream
  onDepartmentChange() {
    this.kaizenForm.patchValue({ zone: '', section: '', other_section: '' });
  }

  // Section changed → clear other_section if not "Other"
  onSectionChange() {
    if (this.kaizenForm.get('section')?.value !== 'Other') {
      this.kaizenForm.patchValue({ other_section: '' });
    }
  }

  loadExistingThemes() {
    this.http.get<any[]>('http://localhost:8080/api/kaizen/my-kaizens').subscribe({
      next: (res) => {
        this.allThemes = res
          .map(k => (k.theme || '').toLowerCase().trim())
          .filter(t => t.length > 0);
      },
      error: () => { this.allThemes = []; }
    });
  }

  fetchNextId() {
    this.kaizenNo = 'Fetching...';
    this.http.get('http://localhost:8080/api/operator', { responseType: 'text' }).subscribe({
      next: (val) => {
        const count = val ? parseInt(val) : 0;
        const currentYear = new Date().getFullYear();
        this.kaizenNo = `OP-${currentYear}-${(count + 1).toString().padStart(3, '0')}`;
        this.cdr.detectChanges();
      },
      error: () => { this.kaizenNo = 'KZN-Error'; this.cdr.detectChanges(); }
    });
  }

  allowNumbersOnly(event: KeyboardEvent): boolean {
    return event.charCode >= 48 && event.charCode <= 57;
  }

  allowAlphabetsOnly(event: KeyboardEvent): boolean {
    const c = event.charCode;
    return (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c === 32;
  }

  allowTeamInput(event: KeyboardEvent): boolean {
    const c = event.charCode;
    return (c >= 65 && c <= 90) || (c >= 97 && c <= 122) ||
           c === 32 || c === 46 || (c >= 48 && c <= 57);
  }

  onFileChange(event: any, type: 'before_img' | 'after_img') {
    const file = event.target.files[0];
    if (!file) return;

    if (file.size <= 512000) {
      this.fileErrors[type]    = false;
      this.compressInfo[type]  = `✓ ${Math.round(file.size / 1024)}KB — ready`;
      this.selectedFiles[type] = file;
      this.cdr.detectChanges();
      return;
    }

    this.compressing[type]  = true;
    this.compressInfo[type] = '';
    this.cdr.detectChanges();

    this.compressImage(file, 500).then(compressed => {
      this.compressing[type]   = false;
      this.fileErrors[type]    = false;
      this.selectedFiles[type] = compressed;
      this.compressInfo[type]  =
        `✓ Compressed: ${Math.round(file.size / 1024)}KB → ${Math.round(compressed.size / 1024)}KB`;
      this.cdr.detectChanges();
    }).catch(() => {
      this.compressing[type]  = false;
      this.fileErrors[type]   = true;
      this.cdr.detectChanges();
      event.target.value = '';
    });
  }

  hasFileError(): boolean {
    return this.fileErrors['before_img'] || this.fileErrors['after_img'];
  }

  isAnyCompressing(): boolean {
    return Object.values(this.compressing).some(v => v);
  }

  compressImage(file: File, maxSizeKB: number): Promise<File> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (e: any) => {
        const img = new Image();
        img.src = e.target.result;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width  = img.width;
          let height = img.height;
          const MAX_DIMENSION = 1200;
          if (width > MAX_DIMENSION || height > MAX_DIMENSION) {
            if (width > height) {
              height = Math.round((height * MAX_DIMENSION) / width);
              width  = MAX_DIMENSION;
            } else {
              width  = Math.round((width * MAX_DIMENSION) / height);
              height = MAX_DIMENSION;
            }
          }
          canvas.width  = width;
          canvas.height = height;
          canvas.getContext('2d')!.drawImage(img, 0, 0, width, height);
          let quality = 0.9;
          const tryCompress = () => {
            const dataUrl = canvas.toDataURL('image/jpeg', quality);
            const sizeKB  = Math.round((dataUrl.length * 3) / 4 / 1024);
            if (sizeKB <= maxSizeKB || quality <= 0.3) {
              const arr   = dataUrl.split(',');
              const mime  = arr[0].match(/:(.*?);/)![1];
              const bstr  = atob(arr[1]);
              let n       = bstr.length;
              const u8arr = new Uint8Array(n);
              while (n--) u8arr[n] = bstr.charCodeAt(n);
              resolve(new File([u8arr], file.name, { type: mime }));
            } else {
              quality -= 0.1;
              tryCompress();
            }
          };
          tryCompress();
        };
        img.onerror = () => reject(new Error('Image load failed'));
      };
      reader.onerror = () => reject(new Error('File read failed'));
    });
  }

  checkDuplicateTheme() {
    const theme = this.kaizenForm.get('theme')?.value?.toLowerCase().trim();
    this.isDuplicate = theme && theme.length > 2 ? this.allThemes.includes(theme) : false;
  }

  handleTeamNumbering(e: KeyboardEvent) {
    if (e.key === 'Enter') {
      const val   = (e.target as HTMLTextAreaElement).value;
      const lines = val.split('\n');
      if (lines[lines.length - 1].trim().length > 3) {
        e.preventDefault();
        this.kaizenForm.patchValue({ team: val + '\n' + (lines.length + 1) + '. ' });
      }
    }
  }

  onPreSubmit() {
    Object.keys(this.kaizenForm.controls).forEach(key => {
      this.kaizenForm.get(key)?.markAsTouched();
    });
    if (this.kaizenForm.valid && !this.isDuplicate && !this.hasFileError() &&
        !this.isAnyCompressing() && this.kaizenNo !== 'KZN-Error') {
      this.showConfirmModal = true;
    }
  }

  finalSubmit() {
    this.isSubmitting = true;
    this.showConfirmModal = false;

    const formData = new FormData();
    Object.keys(this.kaizenForm.value).forEach(key => {
      formData.append(key, this.kaizenForm.value[key] ?? '');
    });

    formData.append('kaizen_id',    this.kaizenNo);
    formData.append('submitted_at', new Date().toISOString());
    formData.append('level',        'Operator');

    if (this.selectedFiles['before_img'])
      formData.append('before_img_file', this.selectedFiles['before_img']!);
    if (this.selectedFiles['after_img'])
      formData.append('after_img_file', this.selectedFiles['after_img']!);

    this.http.post('http://localhost:8080/api/operator/save', formData).subscribe({
      next: (res: any) => {
        if (res && res.status === 'success') {
          this.lastSubmittedNo = this.kaizenNo;
          this.showSuccessModal = true;
          this.isSubmitting    = false;
          this.initForm();
          this.selectedFiles = { before_img: null, after_img: null };
          this.fileErrors    = { before_img: false, after_img: false };
          this.compressing   = { before_img: false, after_img: false };
          this.compressInfo  = { before_img: '', after_img: '' };
          document.querySelectorAll<HTMLInputElement>('input[type="file"]')
            .forEach(i => i.value = '');
          this.fetchNextId();
          this.loadExistingThemes();
          this.cdr.detectChanges();
        } else {
          alert('Backend Error: ' + (res?.message || 'Unknown Error'));
          this.isSubmitting = false;
        }
      },
      error: (err) => {
        alert(err.status === 500 ? 'Database Error.' : 'Submission Failed. Check Spring Boot.');
        this.isSubmitting = false;
      }
    });
  }

  logout() {
    if (confirm('Are you sure you want to logout?')) {
      sessionStorage.clear();
      this.router.navigate(['/login']);
    }
  }
}