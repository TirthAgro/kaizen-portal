import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import jsPDF from 'jspdf';

@Component({
  selector: 'app-view-kaizen',
  standalone: true,
  imports: [CommonModule, HttpClientModule, FormsModule],
  template: `
<div class="vk-shell">
  <div class="vk-topbar">
    <div class="vk-topbar-left">
      <img src="assets/shaktiman_logo.png" class="vk-logo">
      <div>
        <div class="vk-brand">SHAKTIMAN KAIZEN PORTAL</div>
        <div class="vk-sub">Innovation Gallery</div>
      </div>
    </div>
    <div class="vk-topbar-right">
      <div class="vk-stat-chip"><span class="chip-label">Total</span><span class="chip-val">{{totalKaizens}}</span></div>
      <div class="vk-stat-chip approved"><span class="chip-label">Approved</span><span class="chip-val">{{approvedCount}}</span></div>
      <div class="vk-stat-chip pending"><span class="chip-label">Pending</span><span class="chip-val">{{pendingCount}}</span></div>
      <div class="vk-stat-chip rejected"><span class="chip-label">Rejected</span><span class="chip-val">{{rejectedCount}}</span></div>
    </div>
  </div>
  <div class="vk-content">
    <div class="vk-toolbar">
      <div class="vk-search-box">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
        <input type="text" [(ngModel)]="searchTerm" (input)="filterKaizens()" placeholder="Search by ID, Employee, Theme, Unit, Section...">
      </div>
      <div class="vk-filter-group">
        <select [(ngModel)]="statusFilter" (change)="filterKaizens()">
          <option value="">All Status</option>
          <option value="Pending">Pending</option>
          <option value="Approved">Approved</option>
          <option value="Rejected">Rejected</option>
        </select>
        <select [(ngModel)]="sourceFilter" (change)="filterKaizens()">
          <option value="">All Levels</option>
          <option value="operator">Operator</option>
          <option value="supervisor">Supervisor</option>
          <option value="manager">Manager</option>
        </select>
      </div>
    </div>
    <div class="vk-loading" *ngIf="isLoading"><div class="vk-spinner"></div><span>Loading Kaizen Records...</span></div>
    <div class="vk-table-card" *ngIf="!isLoading">
      <table class="vk-table">
        <thead><tr>
          <th>Kaizen ID</th><th>Employee</th><th>Level</th><th>Theme</th>
          <th>Unit / Section</th><th>Date</th><th>Status</th><th>Action</th>
        </tr></thead>
        <tbody>
          <tr *ngFor="let k of pagedKaizens" (click)="openFullDetails(k)">
            <td><strong class="vk-id">{{k.kaizen_id}}</strong></td>
            <td>
              <div class="vk-emp">
                <div class="vk-avatar">{{(k.emp_name || k.emp_id || '?').charAt(0).toUpperCase()}}</div>
                <div><div class="vk-emp-name">{{k.emp_name || k.emp_id}}</div><div class="vk-emp-id">{{k.emp_id}}</div></div>
              </div>
            </td>
            <td><span class="vk-level-badge" [ngClass]="k.source">{{k.source | titlecase}}</span></td>
            <td class="vk-theme">{{k.theme}}</td>
            <td><div class="vk-unit">{{k.unit}}</div><div class="vk-section">{{k.section}}</div></td>
            <td class="vk-date">{{k.created_at | date:'dd MMM yyyy'}}</td>
            <td>
              <span class="vk-status-pill" [ngClass]="k.status?.toLowerCase()">
                <span class="vk-dot"></span>{{k.status || 'Pending'}}
              </span>
            </td>
            <td class="vk-action-cell">
              <button class="vk-view-btn" (click)="openFullDetails(k); $event.stopPropagation()">View</button>
              <button class="vk-download-btn" (click)="downloadKaizenPdf(k); $event.stopPropagation()">&#8595; PDF</button>
            </td>
          </tr>
          <tr *ngIf="pagedKaizens.length === 0"><td colspan="8" class="vk-empty">No records found</td></tr>
        </tbody>
      </table>
      <div class="vk-pagination">
        <span class="vk-page-info">Showing {{(currentPage-1)*itemsPerPage + 1}} &ndash; {{Math.min(currentPage*itemsPerPage, filteredKaizens.length)}} of {{filteredKaizens.length}} records</span>
        <div class="vk-page-btns">
          <button (click)="prevPage()" [disabled]="currentPage===1">&#8592; Prev</button>
          <span class="vk-page-num">{{currentPage}} / {{totalPages}}</span>
          <button (click)="nextPage()" [disabled]="currentPage===totalPages">Next &#8594;</button>
        </div>
      </div>
    </div>
  </div>
  <div class="vk-overlay" *ngIf="selectedKaizen" (click)="selectedKaizen=null">
    <div class="vk-modal" (click)="$event.stopPropagation()">
      <div class="vk-modal-header">
        <div class="vk-modal-title">
          <span class="vk-modal-id">{{selectedKaizen.kaizen_id}}</span>
          <span class="vk-level-badge" [ngClass]="selectedKaizen.source">{{selectedKaizen.source | titlecase}}</span>
        </div>
        <div style="display:flex;gap:10px;align-items:center;">
          <button class="vk-download-btn modal-dl" (click)="downloadKaizenPdf(selectedKaizen)">&#8595; Download PDF</button>
          <button class="vk-close-btn" (click)="selectedKaizen=null">&#x2715;</button>
        </div>
      </div>
      <div class="vk-modal-body">
        <div class="vk-info-grid">
          <div class="vk-info-item"><label>Employee</label><span>{{selectedKaizen.emp_name || selectedKaizen.emp_id}}</span></div>
          <div class="vk-info-item"><label>Unit / Section</label><span>{{selectedKaizen.unit}} / {{selectedKaizen.section}}</span></div>
          <div class="vk-info-item"><label>Category</label><span>{{selectedKaizen.kaizen_category || 'N/A'}}</span></div>
          <div class="vk-info-item"><label>Status</label>
            <span class="vk-status-pill" [ngClass]="selectedKaizen.status?.toLowerCase()">
              <span class="vk-dot"></span>{{selectedKaizen.status || 'Pending'}}
            </span>
          </div>
          <div class="vk-info-item full"><label>Theme</label><span class="vk-theme-big">{{selectedKaizen.theme}}</span></div>
        </div>
        <div class="vk-comparison">
          <div class="vk-comp-box">
            <div class="vk-comp-label before">BEFORE</div>
            <div class="vk-img-frame" (click)="previewImage(selectedKaizen.before_img)">
              <img *ngIf="selectedKaizen.before_img" [src]="selectedKaizen.before_img" onerror="this.style.display='none'">
              <div class="vk-no-img" *ngIf="!selectedKaizen.before_img">No Image</div>
            </div>
          </div>
          <div class="vk-comp-box">
            <div class="vk-comp-label after">AFTER</div>
            <div class="vk-img-frame" (click)="previewImage(selectedKaizen.after_img)">
              <img *ngIf="selectedKaizen.after_img" [src]="selectedKaizen.after_img" onerror="this.style.display='none'">
              <div class="vk-no-img" *ngIf="!selectedKaizen.after_img">No Image</div>
            </div>
          </div>
        </div>
        <div class="vk-remarks" *ngIf="selectedKaizen.hod_remarks">
          <label>Management Remarks</label><p>{{selectedKaizen.hod_remarks}}</p>
        </div>
      </div>
    </div>
  </div>
  <div class="vk-img-preview" *ngIf="previewImg" (click)="previewImg=''">
    <img [src]="previewImg"><div class="vk-preview-hint">Click anywhere to close</div>
  </div>
</div>
  `,
  styles: [`
    * { box-sizing: border-box; margin: 0; padding: 0; }
    .vk-shell { min-height: 100vh; background: #f8fafc; font-family: 'Inter', 'Segoe UI', sans-serif; }
    .vk-topbar { background: linear-gradient(90deg, #FF8C00, #FF4500); padding: 0 40px; height: 72px; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 4px 20px rgba(0,0,0,0.15); }
    .vk-topbar-left { display: flex; align-items: center; gap: 14px; }
    .vk-logo { height: 42px; background: white; border-radius: 50%; padding: 4px; box-shadow: 0 2px 8px rgba(0,0,0,0.2); }
    .vk-brand { font-size: 1rem; font-weight: 800; color: white; letter-spacing: 1px; }
    .vk-sub { font-size: 0.7rem; color: rgba(255,255,255,0.8); }
    .vk-topbar-right { display: flex; gap: 12px; }
    .vk-stat-chip { background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.3); border-radius: 10px; padding: 6px 14px; text-align: center; min-width: 70px; }
    .vk-stat-chip.approved { background: rgba(16,185,129,0.25); border-color: #10b981; }
    .vk-stat-chip.pending { background: rgba(245,158,11,0.25); border-color: #f59e0b; }
    .vk-stat-chip.rejected { background: rgba(239,68,68,0.25); border-color: #ef4444; }
    .chip-label { display: block; font-size: 0.6rem; color: rgba(255,255,255,0.8); text-transform: uppercase; }
    .chip-val { display: block; font-size: 1.2rem; font-weight: 800; color: white; }
    .vk-content { padding: 30px 40px; }
    .vk-toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; gap: 16px; flex-wrap: wrap; }
    .vk-search-box { display: flex; align-items: center; gap: 10px; background: white; border: 1px solid #e2e8f0; border-radius: 10px; padding: 10px 16px; flex: 1; max-width: 400px; box-shadow: 0 2px 8px rgba(0,0,0,0.04); }
    .vk-search-box input { border: none; outline: none; font-size: 0.9rem; color: #334155; width: 100%; background: transparent; }
    .vk-filter-group { display: flex; gap: 10px; }
    .vk-filter-group select { padding: 10px 14px; border: 1px solid #e2e8f0; border-radius: 10px; font-size: 0.85rem; color: #475569; background: white; cursor: pointer; outline: none; box-shadow: 0 2px 8px rgba(0,0,0,0.04); }
    .vk-loading { display: flex; align-items: center; justify-content: center; gap: 12px; padding: 60px; color: #64748b; }
    .vk-spinner { width: 24px; height: 24px; border: 3px solid #e2e8f0; border-top-color: #FF8C00; border-radius: 50%; animation: spin 0.8s linear infinite; }
    @keyframes spin { to { transform: rotate(360deg); } }
    .vk-table-card { background: white; border-radius: 16px; box-shadow: 0 4px 20px rgba(0,0,0,0.06); overflow: hidden; border: 1px solid #f1f5f9; }
    .vk-table { width: 100%; border-collapse: collapse; }
    .vk-table th { background: #f8fafc; padding: 14px 18px; font-size: 0.72rem; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 700; text-align: left; border-bottom: 2px solid #f1f5f9; }
    .vk-table td { padding: 14px 18px; font-size: 0.875rem; color: #334155; border-bottom: 1px solid #f8fafc; vertical-align: middle; }
    .vk-table tr:hover td { background: #fafbfc; cursor: pointer; }
    .vk-id { color: #FF8C00; font-weight: 700; font-size: 0.85rem; }
    .vk-theme { max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-weight: 500; }
    .vk-unit { font-size: 0.85rem; font-weight: 600; color: #1e293b; }
    .vk-section { font-size: 0.75rem; color: #94a3b8; }
    .vk-date { font-size: 0.8rem; color: #64748b; white-space: nowrap; }
    .vk-empty { text-align: center; padding: 60px; color: #94a3b8; font-style: italic; }
    .vk-emp { display: flex; align-items: center; gap: 10px; }
    .vk-avatar { width: 34px; height: 34px; border-radius: 8px; background: linear-gradient(135deg, #FF8C00, #FF4500); color: white; font-weight: 800; font-size: 0.85rem; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
    .vk-emp-name { font-size: 0.85rem; font-weight: 600; color: #1e293b; }
    .vk-emp-id { font-size: 0.72rem; color: #94a3b8; }
    .vk-level-badge { display: inline-block; padding: 3px 10px; border-radius: 6px; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; }
    .vk-level-badge.operator { background: #dcfce7; color: #166534; }
    .vk-level-badge.supervisor { background: #fef3c7; color: #92400e; }
    .vk-level-badge.manager { background: #ede9fe; color: #5b21b6; }
    .vk-status-pill { display: inline-flex; align-items: center; gap: 6px; padding: 4px 10px; border-radius: 20px; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; }
    .vk-status-pill.approved { background: #dcfce7; color: #166534; }
    .vk-status-pill.pending { background: #fef9c3; color: #854d0e; }
    .vk-status-pill.rejected { background: #fee2e2; color: #991b1b; }
    .vk-dot { width: 6px; height: 6px; border-radius: 50%; background: currentColor; flex-shrink: 0; }
    .vk-action-cell { display: flex; gap: 6px; align-items: center; flex-wrap: nowrap; }
    .vk-view-btn { background: #1e293b; color: white; border: none; padding: 7px 16px; border-radius: 8px; font-size: 0.78rem; font-weight: 600; cursor: pointer; transition: 0.2s; white-space: nowrap; }
    .vk-view-btn:hover { background: #FF8C00; transform: scale(1.05); }
    .vk-download-btn { background: #0ea5e9; color: white; border: none; padding: 7px 14px; border-radius: 8px; font-size: 0.78rem; font-weight: 600; cursor: pointer; transition: 0.2s; white-space: nowrap; }
    .vk-download-btn:hover { background: #0284c7; transform: scale(1.05); }
    .vk-download-btn.modal-dl { padding: 8px 18px; font-size: 0.82rem; }
    .vk-pagination { display: flex; justify-content: space-between; align-items: center; padding: 16px 20px; border-top: 1px solid #f1f5f9; }
    .vk-page-info { font-size: 0.8rem; color: #64748b; }
    .vk-page-btns { display: flex; align-items: center; gap: 10px; }
    .vk-page-num { font-size: 0.85rem; font-weight: 600; color: #334155; }
    .vk-page-btns button { padding: 7px 14px; border: 1px solid #e2e8f0; border-radius: 8px; background: white; color: #475569; font-size: 0.8rem; font-weight: 600; cursor: pointer; transition: 0.2s; }
    .vk-page-btns button:hover:not(:disabled) { background: #FF8C00; color: white; border-color: #FF8C00; }
    .vk-page-btns button:disabled { opacity: 0.4; cursor: not-allowed; }
    .vk-overlay { position: fixed; inset: 0; background: rgba(15,23,42,0.7); backdrop-filter: blur(6px); display: flex; align-items: center; justify-content: center; z-index: 2000; padding: 20px; }
    .vk-modal { background: white; width: 100%; max-width: 900px; border-radius: 20px; overflow: hidden; box-shadow: 0 25px 60px rgba(0,0,0,0.4); max-height: 90vh; display: flex; flex-direction: column; }
    .vk-modal-header { padding: 20px 28px; background: #f8fafc; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; }
    .vk-modal-title { display: flex; align-items: center; gap: 12px; }
    .vk-modal-id { font-size: 1.1rem; font-weight: 800; color: #FF8C00; }
    .vk-close-btn { background: none; border: none; font-size: 1.4rem; color: #94a3b8; cursor: pointer; line-height: 1; width: 32px; height: 32px; border-radius: 8px; display: flex; align-items: center; justify-content: center; }
    .vk-close-btn:hover { background: #fee2e2; color: #ef4444; }
    .vk-modal-body { padding: 28px; overflow-y: auto; }
    .vk-info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 24px; background: #f8fafc; padding: 20px; border-radius: 12px; border: 1px solid #e2e8f0; }
    .vk-info-item { display: flex; flex-direction: column; gap: 4px; }
    .vk-info-item.full { grid-column: span 2; }
    .vk-info-item label { font-size: 0.7rem; color: #94a3b8; font-weight: 700; text-transform: uppercase; }
    .vk-info-item span { font-size: 0.9rem; color: #1e293b; font-weight: 500; }
    .vk-theme-big { font-size: 1rem; font-weight: 700; color: #0f172a; }
    .vk-comparison { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
    .vk-comp-box { border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
    .vk-comp-label { padding: 8px 16px; font-size: 0.72rem; font-weight: 800; letter-spacing: 1px; color: white; }
    .vk-comp-label.before { background: #ef4444; }
    .vk-comp-label.after { background: #10b981; }
    .vk-img-frame { height: 260px; background: #f1f5f9; display: flex; align-items: center; justify-content: center; cursor: pointer; overflow: hidden; }
    .vk-img-frame img { width: 100%; height: 100%; object-fit: cover; transition: 0.3s; }
    .vk-img-frame:hover img { transform: scale(1.03); }
    .vk-no-img { color: #94a3b8; font-size: 0.85rem; }
    .vk-remarks { background: #fffbeb; border: 1px solid #fde68a; border-radius: 10px; padding: 16px; }
    .vk-remarks label { font-size: 0.72rem; font-weight: 700; color: #92400e; text-transform: uppercase; display: block; margin-bottom: 6px; }
    .vk-remarks p { color: #1e293b; font-size: 0.9rem; line-height: 1.6; }
    .vk-img-preview { position: fixed; inset: 0; background: rgba(0,0,0,0.92); display: flex; flex-direction: column; align-items: center; justify-content: center; z-index: 3000; cursor: pointer; }
    .vk-img-preview img { max-width: 90vw; max-height: 85vh; border-radius: 8px; }
    .vk-preview-hint { color: rgba(255,255,255,0.5); font-size: 0.8rem; margin-top: 12px; }
  `]
})
export class ViewKaizenComponent implements OnInit {
  allKaizens: any[] = [];
  filteredKaizens: any[] = [];
  pagedKaizens: any[] = [];
  totalKaizens = 0;
  approvedCount = 0;
  pendingCount = 0;
  rejectedCount = 0;
  selectedKaizen: any = null;
  searchTerm = '';
  statusFilter = '';
  sourceFilter = '';
  previewImg = '';
  isLoading = true;
  currentPage = 1;
  itemsPerPage = 10;
  totalPages = 1;
  Math = Math;

  constructor(private http: HttpClient, private cdr: ChangeDetectorRef) {}

  ngOnInit() { this.loadMyKaizens(); }

  loadMyKaizens() {
    this.isLoading = true;
    const empId = sessionStorage.getItem('emp_id') || '';
    const role  = sessionStorage.getItem('role')   || 'Manager';
    this.http.get<any[]>(
      `http://localhost:8080/api/kaizen/my-kaizens?emp_id=${empId}&role=${role}`
    ).subscribe({
      next: (res) => {
        this.allKaizens      = Array.isArray(res) ? res : [];
        this.filteredKaizens = [...this.allKaizens];
        this.currentPage     = 1;
        this.calculateAnalytics();
        this.updatePagination();
        this.isLoading = false;
        this.cdr.detectChanges();
      },
      error: () => { this.isLoading = false; this.cdr.detectChanges(); }
    });
  }

  filterKaizens() {
    const term = this.searchTerm.toLowerCase().trim();
    this.filteredKaizens = this.allKaizens.filter(k => {
      const matchSearch = !term ||
        (k.kaizen_id      || '').toLowerCase().includes(term) ||
        (k.emp_name       || '').toLowerCase().includes(term) ||
        (k.emp_id         || '').toLowerCase().includes(term) ||
        (k.source         || '').toLowerCase().includes(term) ||
        (k.theme          || '').toLowerCase().includes(term) ||
        (k.unit           || '').toLowerCase().includes(term) ||
        (k.section        || '').toLowerCase().includes(term) ||
        (k.status         || '').toLowerCase().includes(term);
      const matchStatus = !this.statusFilter || k.status  === this.statusFilter;
      const matchSource = !this.sourceFilter || k.source  === this.sourceFilter;
      return matchSearch && matchStatus && matchSource;
    });
    this.currentPage = 1;
    this.updatePagination();
  }

  updatePagination() {
    this.totalPages = Math.max(1, Math.ceil(this.filteredKaizens.length / this.itemsPerPage));
    const start     = (this.currentPage - 1) * this.itemsPerPage;
    this.pagedKaizens = this.filteredKaizens.slice(start, start + this.itemsPerPage);
  }

  calculateAnalytics() {
    this.totalKaizens  = this.allKaizens.length;
    this.approvedCount = this.allKaizens.filter(k => k.status?.toLowerCase() === 'approved').length;
    this.pendingCount  = this.allKaizens.filter(k => k.status?.toLowerCase() === 'pending').length;
    this.rejectedCount = this.allKaizens.filter(k => k.status?.toLowerCase() === 'rejected').length;
  }

  nextPage()  { if (this.currentPage < this.totalPages) { this.currentPage++; this.updatePagination(); } }
  prevPage()  { if (this.currentPage > 1)               { this.currentPage--; this.updatePagination(); } }
  openFullDetails(k: any) { this.selectedKaizen = k; }
  previewImage(img: string) { if (img) this.previewImg = img; }

  downloadKaizenPdf(k: any) {
    const source = (k.source || '').toLowerCase();
    if (source === 'operator') this.downloadOperatorPdf(k);
    else                       this.downloadSupervisorManagerPdf(k);
  }

  private loadImg(url: string): Promise<string | null> {
    return new Promise(resolve => {
      if (!url) { resolve(null); return; }
      const img    = new Image();
      img.crossOrigin = 'anonymous';
      img.onload  = () => {
        const c = document.createElement('canvas');
        c.width  = img.naturalWidth;
        c.height = img.naturalHeight;
        c.getContext('2d')!.drawImage(img, 0, 0);
        resolve(c.toDataURL('image/jpeg', 0.85));
      };
      img.onerror = () => resolve(null);
      img.src = url;
    });
  }

  private fmtDate(val: unknown): string {
    if (!val) return '';
    try {
      const d = new Date(String(val));
      if (isNaN(d.getTime())) return String(val);
      return `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${d.getFullYear()}`;
    } catch { return String(val); }
  }

  // ── TEMPLATE 1: Kaizen Idea Sheet — Operator Level ────────────────────────
  private async downloadOperatorPdf(k: any) {
    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

    const setTC = (r: number, g: number, b: number) => doc.setTextColor(r, g, b);
    const setFC = (r: number, g: number, b: number) => doc.setFillColor(r, g, b);
    const setDC = (r: number, g: number, b: number) => doc.setDrawColor(r, g, b);

    const ML = 10, MT = 8, CW = 190, HALF = CW / 2;

    const fsr = (x: number, y: number, w: number, h: number,
                 fr: number, fg: number, fb: number) => {
      setFC(fr, fg, fb); setDC(0, 0, 0);
      doc.setLineWidth(0.4);
      doc.rect(x, y, w, h, 'FD');
    };

    const sr = (x: number, y: number, w: number, h: number) => {
      setFC(255, 255, 255); setDC(0, 0, 0);
      doc.setLineWidth(0.4);
      doc.rect(x, y, w, h, 'FD');
    };

    const txt = (
      s: string, x: number, y: number, size: number, style: string,
      tr: number, tg: number, tb: number,
      align: 'left' | 'center' | 'right' = 'left', maxW?: number
    ) => {
      doc.setFontSize(size);
      doc.setFont('helvetica', style);
      setTC(tr, tg, tb);
      const opts: { align: 'left'|'center'|'right'; maxWidth?: number } = { align };
      if (maxW !== undefined) opts.maxWidth = maxW;
      doc.text(String(s ?? ''), x, y, opts);
    };

    const [beforeData, afterData, logoData] = await Promise.all([
      this.loadImg(k.before_img),
      this.loadImg(k.after_img),
      this.loadImg('assets/shaktiman_logo.png')
    ]);

    let y = MT;

    // ROW 1: Company header
    const hdrH = 14;
    fsr(ML, y, CW, hdrH, 208, 228, 240);
    txt('TIRTH AGRO TECHNOLOGY PVT LTD', ML + CW / 2, y + 6,  12, 'bold',   0, 0, 0, 'center');
    txt('(SHAKTIMAN)',                   ML + CW / 2, y + 11,  9, 'normal', 0, 0, 0, 'center');
    if (logoData) {
      const lh = 12, lw = 20;
      doc.addImage(logoData, 'JPEG', ML + CW - lw - 2, y + 1, lw, lh);
    }
    y += hdrH;

    // ROW 2: Sheet title
    sr(ML, y, CW, 8);
    txt('Kaizen Idea Sheet-Opertor Level', ML + CW / 2, y + 5.5, 10, 'bold', 0, 0, 0, 'center');
    y += 8;

    // ROW 3: Doc code
    sr(ML,        y, HALF, 6);
    txt('Document Code : TA/QMS/KIS-OL', ML + 2,        y + 4, 7, 'normal', 0, 0, 0);
    sr(ML + HALF, y, HALF, 6);
    txt('Rev. 00/01.06.2018',             ML + HALF + 2, y + 4, 7, 'normal', 0, 0, 0);
    y += 6;

    // ROW 4: Theme
    sr(ML, y, CW, 8);
    txt('Theme :-', ML + 2,  y + 5, 7, 'bold',   0, 0, 0);
    txt(k.theme || '', ML + 22, y + 5, 7, 'normal', 0, 0, 0, 'left', CW - 26);
    y += 8;

    // ROW 5: Department  ← uses k.depo (now returned by backend)
    sr(ML, y, CW, 8);
    txt('Department :-', ML + 2,  y + 5, 7, 'bold',   0, 0, 0);
    txt(k.depo || k.unit || '', ML + 30, y + 5, 7, 'normal', 0, 0, 0, 'left', CW - 34);
    y += 8;

    // ROW 6: Section | Machine No
    sr(ML,        y, HALF, 8);
    txt('Section :-',    ML + 2,        y + 5, 7, 'bold',   0, 0, 0);
    txt(k.section || '', ML + 22,       y + 5, 7, 'normal', 0, 0, 0, 'left', HALF - 26);
    sr(ML + HALF, y, HALF, 8);
    txt('Machine No. :-',    ML + HALF + 2,  y + 5, 7, 'bold',   0, 0, 0);
    txt(k.machine_no || '',  ML + HALF + 30, y + 5, 7, 'normal', 0, 0, 0, 'left', HALF - 34);
    y += 8;

    // ROW 7: Kaizen Sr No
    sr(ML, y, CW, 8);
    txt('Kaizen Sr No :-', ML + 2,  y + 5, 7, 'bold',   0, 0, 0);
    txt(k.kaizen_id || '', ML + 32, y + 5, 7, 'normal', 0, 0, 0);
    y += 8;

    // ROW 8: Start Date | End Date  ← FIXED: k.start_date / k.end_date
    sr(ML,        y, HALF, 8);
    txt('Kaizen Start Date :-', ML + 2,  y + 5, 7, 'bold',   0, 0, 0);
    txt(this.fmtDate(k.start_date || k.created_at), ML + 40, y + 5, 7, 'normal', 0, 0, 0);
    sr(ML + HALF, y, HALF, 8);
    txt('Kaizen End Date :-', ML + HALF + 2,  y + 5, 7, 'bold',   0, 0, 0);
    txt(this.fmtDate(k.end_date),             ML + HALF + 37, y + 5, 7, 'normal', 0, 0, 0);
    y += 8;

    // ROW 9a: Before/After headers
    sr(ML,        y, HALF, 7);
    txt('Before: (Illustration with sketch & Date)', ML + HALF / 2,         y + 4.5, 7, 'bold', 0, 0, 0, 'center');
    sr(ML + HALF, y, HALF, 7);
    txt('After: (Illustration with sketch & Date)',  ML + HALF + HALF / 2,  y + 4.5, 7, 'bold', 0, 0, 0, 'center');
    y += 7;

    // ROW 9b: Images
    const imgH = 60;
    sr(ML,        y, HALF, imgH);
    sr(ML + HALF, y, HALF, imgH);
    if (beforeData) {
      doc.addImage(beforeData, 'JPEG', ML + 1,        y + 1, HALF - 2, imgH - 2);
    } else {
      txt('No Image Available', ML + HALF / 2,        y + imgH / 2, 7, 'italic', 160, 160, 160, 'center');
    }
    if (afterData) {
      doc.addImage(afterData,  'JPEG', ML + HALF + 1, y + 1, HALF - 2, imgH - 2);
    } else {
      txt('No Image Available', ML + HALF + HALF / 2, y + imgH / 2, 7, 'italic', 160, 160, 160, 'center');
    }
    y += imgH;

    // ROW 9c: Date placeholders
    sr(ML,        y, HALF, 8);
    txt('Date :-', ML + 2,        y + 5, 7, 'bold', 0, 0, 0);
    sr(ML + HALF, y, HALF, 8);
    txt('Date :-', ML + HALF + 2, y + 5, 7, 'bold', 0, 0, 0);
    y += 8;

    // ROW 10: Before/After Condition
    sr(ML,        y, HALF, 20);
    txt('Before Condition :-', ML + 2,        y + 5, 7, 'bold', 0, 0, 0);
    doc.setFontSize(7); doc.setFont('helvetica', 'normal'); setTC(0, 0, 0);
    doc.text(doc.splitTextToSize(k.before_desc || '', HALF - 4), ML + 2,        y + 10, { maxWidth: HALF - 4 });
    sr(ML + HALF, y, HALF, 20);
    txt('After Condition :-',  ML + HALF + 2, y + 5, 7, 'bold', 0, 0, 0);
    doc.setFontSize(7); doc.setFont('helvetica', 'normal'); setTC(0, 0, 0);
    doc.text(doc.splitTextToSize(k.after_desc  || '', HALF - 4), ML + HALF + 2, y + 10, { maxWidth: HALF - 4 });
    y += 20;

    // ROW 11: Team Members | Reviewed By
    const TW = CW * 0.55, RW = CW - TW;
    sr(ML, y, TW, 22);
    txt('Team Members :-', ML + 2, y + 5, 7, 'bold', 0, 0, 0);
    // ← FIXED: use k.team_members (now returned by backend); fallback to emp_name
    const teamVal = k.team_members || k.team || k.emp_name || '';
    doc.setFontSize(7); doc.setFont('helvetica', 'normal'); setTC(0, 0, 0);
    doc.text(doc.splitTextToSize(teamVal, TW - 4), ML + 2, y + 10, { maxWidth: TW - 4 });

    sr(ML + TW, y, RW, 22);
    txt('Kaizen Reviewed by: (KK Team)', ML + TW + 2, y + 5,  7,   'bold',   0, 0, 0);
    txt('Sign : _______________________', ML + TW + 2, y + 11, 7,   'normal', 0, 0, 0);
    txt('Date : _______________________', ML + TW + 2, y + 17, 7,   'normal', 0, 0, 0);
    y += 22;

    // Outer border
    setDC(0, 0, 0); doc.setLineWidth(0.8);
    doc.rect(ML, MT, CW, y - MT, 'S');

    doc.save(`Kaizen_${k.kaizen_id || 'download'}_Operator.pdf`);
  }

  // ── TEMPLATE 2: Kaizen Idea Sheet — Senior Level ──────────────────────────
  private async downloadSupervisorManagerPdf(k: any) {
    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

    const setTC = (r: number, g: number, b: number) => doc.setTextColor(r, g, b);
    const setFC = (r: number, g: number, b: number) => doc.setFillColor(r, g, b);
    const setDC = (r: number, g: number, b: number) => doc.setDrawColor(r, g, b);

    const ML = 8, MT = 6, CW = 194, HALF = CW / 2;

    const fsr = (x: number, y: number, w: number, h: number,
                 fr: number, fg: number, fb: number) => {
      setFC(fr, fg, fb); setDC(0, 0, 0);
      doc.setLineWidth(0.35);
      doc.rect(x, y, w, h, 'FD');
    };

    const sr = (x: number, y: number, w: number, h: number) => {
      setFC(255, 255, 255); setDC(0, 0, 0);
      doc.setLineWidth(0.35);
      doc.rect(x, y, w, h, 'FD');
    };

    const txt = (
      s: string, x: number, y: number, size: number, style: string,
      tr: number, tg: number, tb: number,
      align: 'left' | 'center' | 'right' = 'left', maxW?: number
    ) => {
      doc.setFontSize(size); doc.setFont('helvetica', style); setTC(tr, tg, tb);
      const opts: { align: 'left'|'center'|'right'; maxWidth?: number } = { align };
      if (maxW !== undefined) opts.maxWidth = maxW;
      doc.text(String(s ?? ''), x, y, opts);
    };

    const source     = (k.source || '').toLowerCase();
    const levelLabel = source === 'supervisor' ? 'Supervisor' : 'Manager';

    const [beforeData, afterData, logoData] = await Promise.all([
      this.loadImg(k.before_img),
      this.loadImg(k.after_img),
      this.loadImg('assets/shaktiman_logo.png')
    ]);

    let y = MT;

    // ROW 1: Company header
    fsr(ML, y, CW, 14, 208, 228, 240);
    txt('TIRTH AGRO TECHNOLOGY PVT LTD', ML + CW / 2, y + 6,  12, 'bold',   0, 0, 0, 'center');
    txt('(SHAKTIMAN)',                   ML + CW / 2, y + 11,  9, 'normal', 0, 0, 0, 'center');
    if (logoData) {
      const lh = 12, lw = 20;
      doc.addImage(logoData, 'JPEG', ML + CW - lw - 2, y + 1, lw, lh);
    }
    y += 14;

    // ROW 2: Sheet title
    sr(ML, y, CW, 8);
    txt('Kaizen Idea Sheet-Senior Level', ML + CW / 2, y + 5.5, 10, 'bold', 0, 0, 0, 'center');
    y += 8;

    // ROW 3: Doc code
    sr(ML,        y, HALF, 6);
    txt('Document Code : TA/QMS/KIS-SL', ML + 2,        y + 4, 7, 'normal', 0, 0, 0);
    sr(ML + HALF, y, HALF, 6);
    txt('Rev. 00/01.06.2018',             ML + HALF + 2, y + 4, 7, 'normal', 0, 0, 0);
    y += 6;

    // ROW 4: Activity header
    const actLabW = 28;
    const actCols = ['KK', 'JH', 'QM', 'PM', 'SHE', 'OTPM', 'DM', 'ET', '5S'];
    const actCW   = (CW - actLabW) / actCols.length;
    sr(ML, y, actLabW, 6);
    txt('Activity', ML + actLabW / 2, y + 4, 7, 'bold', 0, 0, 0, 'center');
    actCols.forEach((col, i) => {
      const cx = ML + actLabW + i * actCW;
      sr(cx, y, actCW, 6);
      txt(col, cx + actCW / 2, y + 4, 7, 'bold', 0, 0, 0, 'center');
    });
    y += 6;

    // ROW 5: Loss No./Step
    sr(ML, y, actLabW, 6);
    txt('Loss No./ Step', ML + actLabW / 2, y + 4, 6.5, 'bold', 0, 0, 0, 'center');
    actCols.forEach((_, i) => { sr(ML + actLabW + i * actCW, y, actCW, 6); });
    y += 6;

    // ROW 6: Result Area — highlight matched PQCDSM cells green  ← FIXED
    const raVals  = ['P', 'Q', 'C', 'D', 'S', 'M', '', '', ''];
    const pqcdsm  = (k.pqcdsm || '').toUpperCase();
    sr(ML, y, actLabW, 6);
    txt('Result Area', ML + actLabW / 2, y + 4, 6.5, 'bold', 0, 0, 0, 'center');
    raVals.forEach((val, i) => {
      const cx      = ML + actLabW + i * actCW;
      const matched = val !== '' && pqcdsm.includes(val);
      if (matched) {
        fsr(cx, y, actCW, 6, 144, 238, 144);  // light green fill
      } else {
        sr(cx, y, actCW, 6);
      }
      if (val) txt(val, cx + actCW / 2, y + 4, 7, 'bold', 0, 0, 0, 'center');
    });
    y += 6;

    // ROW 7: Plant | Machine | Kaizen Sr No
    const C3 = CW / 3;
    sr(ML,          y, C3, 8);
    txt('Plant :',          ML + 2,           y + 5, 7, 'bold',   0, 0, 0);
    txt(k.unit || '',       ML + 17,          y + 5, 7, 'normal', 0, 0, 0, 'left', C3 - 20);
    sr(ML + C3,     y, C3, 8);
    txt('Machine :',        ML + C3 + 2,      y + 5, 7, 'bold',   0, 0, 0);
    txt(k.machine_no || '', ML + C3 + 20,     y + 5, 7, 'normal', 0, 0, 0, 'left', C3 - 23);
    sr(ML + C3 * 2, y, C3, 8);
    txt('Kaizen Sr. No. :', ML + C3 * 2 + 2,  y + 5, 7, 'bold',   0, 0, 0);
    txt(k.kaizen_id || '',  ML + C3 * 2 + 30, y + 5, 7, 'normal', 0, 0, 0, 'left', C3 - 33);
    y += 8;

    // ROW 8: Kaizen Theme
    const lblW = CW * 0.30, valW = CW - lblW;
    sr(ML,        y, lblW, 8);
    txt('Kaizen theme :', ML + 2,        y + 5, 7, 'bold',   0, 0, 0);
    sr(ML + lblW, y, valW, 8);
    txt(k.theme || '',   ML + lblW + 2,  y + 5, 7, 'normal', 0, 0, 0, 'left', valW - 4);
    y += 8;

    // THREE-COLUMN BODY
    const LCW = Math.round(CW * 0.28);
    const MCW = Math.round(CW * 0.40);
    const RCW = CW - LCW - MCW;
    const LCX = ML;
    const MCX = ML + LCW;
    const RCX = ML + LCW + MCW;

    let lY = y, mY = y, rY = y;

    // ── LEFT COLUMN ──────────────────────────────────────────────────────────

    sr(LCX, lY, LCW, 6);
    txt('Problem/present status : Description', LCX + 2, lY + 4, 6.5, 'bold', 0, 0, 0, 'left', LCW - 4);
    lY += 6;

    sr(LCX, lY, LCW, 20);
    doc.setFontSize(7); doc.setFont('helvetica', 'normal'); setTC(0, 0, 0);
    // ← FIXED: k.analysis (now returned by backend)
    doc.text(doc.splitTextToSize(k.analysis || '', LCW - 4), LCX + 2, lY + 4, { maxWidth: LCW - 4 });
    lY += 20;

    sr(LCX, lY, LCW, 6);
    txt('Present status sketch/photo', LCX + LCW / 2, lY + 4, 6.5, 'bold', 0, 0, 0, 'center');
    lY += 6;

    sr(LCX, lY, LCW, 25);
    lY += 25;

    sr(LCX, lY, LCW, 6);
    txt('Why - why analysis : / Problem Phenomenon :', LCX + 2, lY + 4, 6.5, 'bold', 0, 0, 0, 'left', LCW - 4);
    lY += 6;

    // ← FIXED: k.why1 … k.why4 (now returned by backend)
    const whys: [string, string][] = [
      ['Why 1 :', String(k.why1 || '')],
      ['Why 2 :', String(k.why2 || '')],
      ['Why 3 :', String(k.why3 || '')],
      ['Why 4 :', String(k.why4 || '')]
    ];
    whys.forEach(([label, val]) => {
      sr(LCX, lY, LCW, 7);
      txt(label, LCX + 2,  lY + 4.5, 7, 'bold',   0, 0, 0);
      txt(val,   LCX + 16, lY + 4.5, 7, 'normal', 0, 0, 0, 'left', LCW - 20);
      lY += 7;
    });

    sr(LCX, lY, LCW, 10);
    txt('Root Cause :', LCX + 2, lY + 4, 7, 'bold', 0, 0, 0);
    doc.setFontSize(7); doc.setFont('helvetica', 'normal'); setTC(0, 0, 0);
    // ← FIXED: k.root_cause (now returned by backend)
    doc.text(doc.splitTextToSize(k.root_cause || '', LCW - 4), LCX + 2, lY + 8, { maxWidth: LCW - 4 });
    lY += 10;

    // ── MIDDLE COLUMN ────────────────────────────────────────────────────────

    sr(MCX, mY, MCW, 6);
    txt('Countermeasure(Engineering solution):', MCX + 2, mY + 4, 6.5, 'bold', 0, 0, 0, 'left', MCW - 4);
    mY += 6;

    sr(MCX, mY, MCW, 18);
    doc.setFontSize(7); doc.setFont('helvetica', 'normal'); setTC(0, 0, 0);
    // ← FIXED: k.countermeasure (now returned by backend)
    doc.text(doc.splitTextToSize(k.countermeasure || '', MCW - 4), MCX + 2, mY + 4, { maxWidth: MCW - 4 });
    mY += 18;

    const MH = MCW / 2;
    sr(MCX,      mY, MH, 6);
    txt('Before :', MCX + MH / 2,         mY + 4, 7, 'bold', 0, 0, 0, 'center');
    sr(MCX + MH, mY, MH, 6);
    txt('After :',  MCX + MH + MH / 2,    mY + 4, 7, 'bold', 0, 0, 0, 'center');
    mY += 6;

    const imgRowH2 = 42;
    sr(MCX,      mY, MH, imgRowH2);
    sr(MCX + MH, mY, MH, imgRowH2);
    if (beforeData) {
      doc.addImage(beforeData, 'JPEG', MCX + 1,      mY + 1, MH - 2, imgRowH2 - 2);
    } else {
      txt('No Image Available', MCX + MH / 2,        mY + imgRowH2 / 2, 6.5, 'italic', 160, 160, 160, 'center');
    }
    if (afterData) {
      doc.addImage(afterData,  'JPEG', MCX + MH + 1, mY + 1, MH - 2, imgRowH2 - 2);
    } else {
      txt('No Image Available', MCX + MH + MH / 2,   mY + imgRowH2 / 2, 6.5, 'italic', 160, 160, 160, 'center');
    }
    mY += imgRowH2;

    sr(MCX,      mY, MH, 12);
    txt('Brief Description :', MCX + 2,      mY + 4, 6.5, 'bold', 0, 0, 0);
    doc.setFontSize(6.5); doc.setFont('helvetica', 'normal'); setTC(0, 0, 0);
    doc.text(doc.splitTextToSize(k.before_desc || '', MH - 4), MCX + 2,      mY + 8, { maxWidth: MH - 4 });
    sr(MCX + MH, mY, MH, 12);
    txt('Brief Description :', MCX + MH + 2, mY + 4, 6.5, 'bold', 0, 0, 0);
    doc.setFontSize(6.5); doc.setFont('helvetica', 'normal'); setTC(0, 0, 0);
    doc.text(doc.splitTextToSize(k.after_desc  || '', MH - 4), MCX + MH + 2, mY + 8, { maxWidth: MH - 4 });
    mY += 12;

    sr(MCX, mY, MCW, 6);
    txt('Results :', MCX + 2, mY + 4, 7, 'bold', 0, 0, 0);
    mY += 6;

    sr(MCX, mY, MCW, 14);
    doc.setFontSize(7); doc.setFont('helvetica', 'normal'); setTC(0, 0, 0);
    // ← FIXED: k.benefits_pqcdsm (now returned by backend)
    doc.text(doc.splitTextToSize(k.benefits_pqcdsm || '', MCW - 4), MCX + 2, mY + 4, { maxWidth: MCW - 4 });
    mY += 14;

    sr(MCX, mY, MCW, 6);
    txt('Illustration with line chart/ graph :', MCX + 2, mY + 4, 6.5, 'bold', 0, 0, 0);
    mY += 6;

    sr(MCX, mY, MCW, 18);
    mY += 18;

    sr(MCX, mY, MCW, 7);
    txt('Note: Use separate sheet for better understanding, if needed', MCX + 2, mY + 4.5, 6.5, 'italic', 80, 80, 80);
    mY += 7;

    // ── RIGHT COLUMN ─────────────────────────────────────────────────────────
    const RLW = RCW * 0.45;
    const RVW = RCW - RLW;

    // ← FIXED: k.start_date / k.end_date (correct field names)
    const rLvRows: [string, string][] = [
      ['Bench mark',    k.benchmark  || ''],
      ['Target',        k.target     || ''],
      ['Kaizen start',  this.fmtDate(k.start_date || k.created_at)],
      ['Kaizen Finish', this.fmtDate(k.end_date)]
    ];
    rLvRows.forEach(([label, val]) => {
      sr(RCX,        rY, RLW, 7);
      txt(label, RCX + 2,        rY + 4.5, 7, 'bold',   0, 0, 0, 'left', RLW - 4);
      sr(RCX + RLW,  rY, RVW, 7);
      txt(val,   RCX + RLW + 2,  rY + 4.5, 7, 'normal', 0, 0, 0, 'left', RVW - 4);
      rY += 7;
    });

    sr(RCX, rY, RCW, 6);
    txt('Team members :', RCX + 2, rY + 4, 7, 'bold', 0, 0, 0);
    rY += 6;

    sr(RCX, rY, RCW, 22);
    // ← FIXED: k.team_members (now returned by backend)
    const tmVal = k.team_members || k.team || k.emp_name || '';
    doc.setFontSize(7); doc.setFont('helvetica', 'normal'); setTC(0, 0, 0);
    doc.text(doc.splitTextToSize(tmVal, RCW - 4), RCX + 2, rY + 4, { maxWidth: RCW - 4 });
    rY += 22;

    sr(RCX, rY, RCW, 6);
    txt('Benefits: (P,Q,C,D,S,M)', RCX + 2, rY + 4, 7, 'bold', 0, 0, 0);
    rY += 6;

    sr(RCX, rY, RCW, 12);
    doc.setFontSize(7); doc.setFont('helvetica', 'normal'); setTC(0, 0, 0);
    doc.text(doc.splitTextToSize(k.benefits_pqcdsm || '', RCW - 4), RCX + 2, rY + 4, { maxWidth: RCW - 4 });
    rY += 12;

    sr(RCX, rY, RCW, 6);
    txt('Scope & plan for Horizontal Deployment', RCX + 2, rY + 4, 6.5, 'bold', 0, 0, 0, 'left', RCW - 4);
    rY += 6;

    const hdCols: [string, number][] = [
      ['Sr.no.', 0.10], ['M/c.', 0.18], ['Target date', 0.22], ['Responsibility', 0.28], ['Status', 0.22]
    ];
    let hx = RCX;
    hdCols.forEach(([label, ratio]) => {
      const cw = RCW * ratio;
      fsr(hx, rY, cw, 5, 230, 230, 230);
      txt(label, hx + cw / 2, rY + 3.5, 6, 'bold', 0, 0, 0, 'center');
      hx += cw;
    });
    rY += 5;

    for (let ri = 0; ri < 5; ri++) {
      hx = RCX;
      hdCols.forEach(([, ratio]) => {
        const cw = RCW * ratio;
        sr(hx, rY, cw, 5);
        hx += cw;
      });
      rY += 5;
    }

    sr(RCX, rY, RCW, 10);
    txt('Reviewed By :',                     RCX + 2, rY + 4,   7,   'bold',   0, 0, 0);
    txt('Sign : __________ Date : __________', RCX + 2, rY + 8.5, 6.5, 'normal', 0, 0, 0);
    rY += 10;

    // Sync columns
    const endY = Math.max(lY, mY, rY);
    if (lY < endY) { sr(LCX, lY, LCW, endY - lY); }
    if (mY < endY) { sr(MCX, mY, MCW, endY - mY); }
    if (rY < endY) { sr(RCX, rY, RCW, endY - rY); }

    // Outer border
    setDC(0, 0, 0); doc.setLineWidth(0.8);
    doc.rect(ML, MT, CW, endY - MT, 'S');

    doc.save(`Kaizen_${k.kaizen_id || 'download'}_${levelLabel}.pdf`);
  }
}