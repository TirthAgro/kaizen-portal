import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-supervisor-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule],
  encapsulation: ViewEncapsulation.None,
  template: `
    <div class="shaktiman-ribbon"></div>

    <!-- Confirm Modal -->
    <div class="custom-overlay" *ngIf="showConfirmModal">
      <div class="modern-modal">
        <div class="modal-icon">?</div>
        <h3>Confirm Registration</h3>
        <p>Are you sure you want to submit this Supervisor Kaizen to the portal?</p>
        <div class="modal-preview-box">
          <strong>Kaizen ID:</strong> {{ kaizenNo }}<br>
          <strong>Theme:</strong> {{ kaizenForm.value.theme }}
        </div>
        <div class="modal-actions">
          <button class="btn-cancel" (click)="showConfirmModal = false">Review</button>
          <button class="btn-confirm" (click)="finalSubmit()" [disabled]="isSubmitting">
            {{ isSubmitting ? 'Processing...' : 'Submit Now' }}
          </button>
        </div>
      </div>
    </div>

    <!-- Success Modal -->
    <div class="custom-overlay" *ngIf="showSuccessModal">
      <div class="modern-modal success-style">
        <div class="modal-icon check">✔</div>
        <h3>Success!</h3>
        <p>Kaizen <strong>{{ lastSubmittedNo }}</strong> has been registered.</p>
        <button class="btn-confirm" (click)="showSuccessModal = false">Great!</button>
      </div>
    </div>

    <div class="container-main">
      <div class="form-card">

        <header class="form-header">
          <div class="header-left">
            <span class="brand-label">SHAKTIMAN KAIZEN PORTAL</span>
            <h2>Supervisor Level Entry</h2>
          </div>
          <div class="header-right header-flex">
            <div class="meta-group">
              <div class="meta-box dark" [class.error-bg]="kaizenNo === 'SUP-Error'">
                Kaizen ID: {{ kaizenNo }}
                <button *ngIf="kaizenNo === 'SUP-Error'" (click)="fetchNextId()" class="retry-btn">Retry</button>
              </div>
              <div class="meta-box light">Reg Date: {{ today | date:'dd-MMM-yyyy hh:mm A' }}</div>
            </div>
            <button type="button" class="logout-pill" (click)="logout()">
              <span class="power-icon">⏻</span> Logout
            </button>
          </div>
        </header>

        <form [formGroup]="kaizenForm" (ngSubmit)="onPreSubmit()" class="form-content">

          <!-- Row 1: Emp ID, Emp Name, Unit — always visible -->
          <div class="row-grid">
            <div class="field">
              <label>Employee ID <span class="req">*</span></label>
              <input type="text" formControlName="emp_id"
                     (keypress)="allowNumbersOnly($event)"
                     placeholder="Numbers only">
              <div class="err-msg" *ngIf="kaizenForm.get('emp_id')?.touched && kaizenForm.get('emp_id')?.errors?.['required']">Employee ID is required</div>
              <div class="err-msg" *ngIf="kaizenForm.get('emp_id')?.touched && kaizenForm.get('emp_id')?.errors?.['pattern']">Numbers only allowed</div>
            </div>
            <div class="field">
              <label>Employee Name <span class="req">*</span></label>
              <input type="text" formControlName="emp_name"
                     (keypress)="allowAlphabetsOnly($event)"
                     placeholder="Alphabets only">
              <div class="err-msg" *ngIf="kaizenForm.get('emp_name')?.touched && kaizenForm.get('emp_name')?.errors?.['required']">Employee Name is required</div>
              <div class="err-msg" *ngIf="kaizenForm.get('emp_name')?.touched && kaizenForm.get('emp_name')?.errors?.['pattern']">Alphabets only allowed</div>
            </div>
            <div class="field">
              <label>Plant (Unit) <span class="req">*</span></label>
              <select formControlName="unit" (change)="onUnitChange()">
                <option value="">Select Unit</option>
                <option *ngFor="let i of [1,2,3,4,5]" [value]="'Unit '+i">Unit {{i}}</option>
              </select>
              <div class="err-msg" *ngIf="kaizenForm.get('unit')?.touched && kaizenForm.get('unit')?.errors?.['required']">Unit is required</div>
            </div>
          </div>

          <!-- Row 2: Department + Section + Machine No
               Department visible ONLY after Unit selected
               Section visible ONLY after Department selected -->
          <div class="row-grid">

            <!-- Department — visible after Plant selected -->
            <div class="field" *ngIf="kaizenForm.get('unit')?.value">
              <label>Department <span class="req">*</span></label>
              <select formControlName="department" (change)="onDepartmentChange()">
                <option value="">Select Department</option>
                <option *ngFor="let d of availableDepartments" [value]="d">{{d}}</option>
              </select>
              <div class="err-msg" *ngIf="kaizenForm.get('department')?.touched && kaizenForm.get('department')?.errors?.['required']">Department is required</div>
            </div>

            <!-- Section — visible after Department selected -->
            <div class="field" *ngIf="kaizenForm.get('department')?.value">
              <label>Section <span class="req">*</span></label>
              <select formControlName="section">
                <option value="">Select Section</option>
                <option *ngFor="let s of availableSections" [value]="s">{{s}}</option>
              </select>
              <div class="err-msg" *ngIf="kaizenForm.get('section')?.touched && kaizenForm.get('section')?.errors?.['required']">Section is required</div>
            </div>

            <!-- Machine No — always visible -->
            <div class="field">
              <label>Machine Name/No. <span class="req">*</span></label>
              <input type="text" formControlName="machine_no">
              <div class="err-msg" *ngIf="kaizenForm.get('machine_no')?.touched && kaizenForm.get('machine_no')?.errors?.['required']">Machine No. is required</div>
            </div>

          </div>

          <!-- Row 3: Kaizen Type -->
          <div class="row-grid-2" style="margin-bottom:20px;">
            <div class="field">
              <label>Type of Kaizen <span class="req">*</span></label>
              <select formControlName="kaizen_type">
                <option value="Innovative">Innovative</option>
                <option value="Restorative">Restorative</option>
                <option value="Renovative">Renovative</option>
                <option value="Breakthrough">Breakthrough</option>
              </select>
            </div>
          </div>

          <!-- PQCDSM + Category -->
          <div class="row-grid-cat">
            <div class="field">
              <label>Group (PQCDSM) <span class="req">*</span></label>
              <select formControlName="pqcdsm">
                <option value="">Select Group</option>
                <option value="P - Productivity">P - Productivity</option>
                <option value="Q - Quality">Q - Quality</option>
                <option value="C - Cost">C - Cost</option>
                <option value="D - Delivery">D - Delivery</option>
                <option value="S - Safety">S - Safety</option>
                <option value="M - Morale">M - Morale</option>
              </select>
              <div class="err-msg" *ngIf="kaizenForm.get('pqcdsm')?.touched && kaizenForm.get('pqcdsm')?.errors?.['required']">PQCDSM is required</div>
            </div>
            <div class="field">
              <label>Kaizen Category <span class="req">*</span></label>
              <select formControlName="kaizen_category">
                <option value="">Select Category</option>
                <option *ngFor="let cat of categories" [value]="cat.v">{{cat.l}}</option>
              </select>
              <div class="err-msg" *ngIf="kaizenForm.get('kaizen_category')?.touched && kaizenForm.get('kaizen_category')?.errors?.['required']">Category is required</div>
            </div>
          </div>

          <!-- Theme -->
          <div class="full-row field">
            <label>Kaizen Theme <span class="req">*</span></label>
            <input type="text" formControlName="theme"
                   (input)="checkDuplicateTheme()"
                   [class.error-border]="isDuplicate"
                   placeholder="Brief title of improvement">
            <div class="err-msg" *ngIf="isDuplicate">⚠ This Kaizen Theme already exists. Please use a unique title.</div>
            <div class="err-msg" *ngIf="kaizenForm.get('theme')?.touched && kaizenForm.get('theme')?.errors?.['required'] && !isDuplicate">Theme is required</div>
          </div>

          <hr class="divider">

          <!-- Problem + Idea -->
          <div class="row-grid-2">
            <div class="field">
              <label>Problem / Current Status <span class="req">*</span></label>
              <textarea formControlName="problem_status" rows="3"></textarea>
              <div class="err-msg" *ngIf="kaizenForm.get('problem_status')?.touched && kaizenForm.get('problem_status')?.errors?.['required']">Problem status is required</div>
              <input type="file" (change)="onFileChange($event, 'problem_img')" class="mt-2" accept="image/*">
              <p class="file-hint">Any size — auto-compressed to under 500KB</p>
              <div class="err-msg" *ngIf="compressing['problem_img']">⏳ Compressing image...</div>
              <div class="compress-info" *ngIf="compressInfo['problem_img']">{{compressInfo['problem_img']}}</div>
            </div>
            <div class="field">
              <label>Idea / Concept <span class="req">*</span></label>
              <textarea formControlName="idea" rows="5"></textarea>
              <div class="err-msg" *ngIf="kaizenForm.get('idea')?.touched && kaizenForm.get('idea')?.errors?.['required']">Idea is required</div>
            </div>
          </div>

          <!-- Countermeasure -->
          <div class="full-row field">
            <label>Countermeasure (Engineering Solution) <span class="req">*</span></label>
            <textarea formControlName="countermeasure" rows="2"></textarea>
            <div class="err-msg" *ngIf="kaizenForm.get('countermeasure')?.touched && kaizenForm.get('countermeasure')?.errors?.['required']">Countermeasure is required</div>
          </div>

          <!-- 5-WHY -->
          <div class="why-panel">
            <label class="evidence-title">5-WHY ANALYSIS</label>
            <div class="why-grid">
              <div class="field">
                <label>Why 1 <span class="req">*</span></label>
                <input type="text" formControlName="why1" placeholder="Why did the problem occur?">
                <div class="err-msg" *ngIf="kaizenForm.get('why1')?.touched && kaizenForm.get('why1')?.errors?.['required']">Why 1 is required</div>
              </div>
              <div class="field">
                <label>Why 2 <span class="req">*</span></label>
                <input type="text" formControlName="why2" placeholder="Why did Why 1 happen?">
                <div class="err-msg" *ngIf="kaizenForm.get('why2')?.touched && kaizenForm.get('why2')?.errors?.['required']">Why 2 is required</div>
              </div>
              <div class="field">
                <label>Why 3 <span class="req">*</span></label>
                <input type="text" formControlName="why3" placeholder="Why did Why 2 happen?">
                <div class="err-msg" *ngIf="kaizenForm.get('why3')?.touched && kaizenForm.get('why3')?.errors?.['required']">Why 3 is required</div>
              </div>
              <div class="field">
                <label>Why 4 <span style="color:#94a3b8;font-size:11px;">(Optional)</span></label>
                <input type="text" formControlName="why4" placeholder="Why did Why 3 happen?">
              </div>
              <div class="field">
                <label>Why 5 <span style="color:#94a3b8;font-size:11px;">(Optional)</span></label>
                <input type="text" formControlName="why5" placeholder="Root cause confirmation">
              </div>
            </div>
          </div>

          <!-- Root Cause, Final Result, Analysis -->
          <div class="row-grid">
            <div class="field">
              <label>Root Cause <span class="req">*</span></label>
              <textarea formControlName="root_cause" rows="4"></textarea>
              <div class="err-msg" *ngIf="kaizenForm.get('root_cause')?.touched && kaizenForm.get('root_cause')?.errors?.['required']">Root cause is required</div>
            </div>
            <div class="field">
              <label>Final Result <span class="req">*</span></label>
              <textarea formControlName="final_result" rows="2"></textarea>
              <div class="err-msg" *ngIf="kaizenForm.get('final_result')?.touched && kaizenForm.get('final_result')?.errors?.['required']">Final result is required</div>
              <input type="file" (change)="onFileChange($event, 'result_img')" class="mt-2" accept="image/*">
              <p class="file-hint">Any size — auto-compressed to under 500KB</p>
              <div class="err-msg" *ngIf="compressing['result_img']">⏳ Compressing image...</div>
              <div class="compress-info" *ngIf="compressInfo['result_img']">{{compressInfo['result_img']}}</div>
            </div>
            <div class="field">
              <label>Analysis <span class="req">*</span></label>
              <textarea formControlName="analysis" rows="4"></textarea>
              <div class="err-msg" *ngIf="kaizenForm.get('analysis')?.touched && kaizenForm.get('analysis')?.errors?.['required']">Analysis is required</div>
            </div>
          </div>

          <!-- Dates -->
          <div class="row-grid-2">
            <div class="field">
              <label>Start Date <span class="req">*</span></label>
              <input type="date" formControlName="start_date">
              <div class="err-msg" *ngIf="kaizenForm.get('start_date')?.touched && kaizenForm.get('start_date')?.errors?.['required']">Start Date is required</div>
            </div>
            <div class="field">
              <label>End Date <span class="req">*</span></label>
              <input type="date" formControlName="end_date">
              <div class="err-msg" *ngIf="kaizenForm.get('end_date')?.touched && kaizenForm.get('end_date')?.errors?.['required']">End Date is required</div>
            </div>
          </div>

          <!-- Before / After Evidence -->
          <div class="row-grid-2">
            <div class="evidence-panel red-style">
              <label class="evidence-title">Before Status (Image) <span class="req">*</span></label>
              <input type="file" (change)="onFileChange($event, 'before_img')" accept="image/*">
              <p class="file-hint">Any size — auto-compressed to under 500KB</p>
              <div class="err-msg" *ngIf="compressing['before_img']">⏳ Compressing image...</div>
              <div class="compress-info" *ngIf="compressInfo['before_img']">{{compressInfo['before_img']}}</div>
              <textarea formControlName="before_desc" rows="3" class="mt-2" placeholder="Describe before..."></textarea>
              <div class="err-msg" *ngIf="kaizenForm.get('before_desc')?.touched && kaizenForm.get('before_desc')?.errors?.['required']">Before description is required</div>
            </div>
            <div class="evidence-panel green-style">
              <label class="evidence-title">After Status (Image) <span class="req">*</span></label>
              <input type="file" (change)="onFileChange($event, 'after_img')" accept="image/*">
              <p class="file-hint">Any size — auto-compressed to under 500KB</p>
              <div class="err-msg" *ngIf="compressing['after_img']">⏳ Compressing image...</div>
              <div class="compress-info" *ngIf="compressInfo['after_img']">{{compressInfo['after_img']}}</div>
              <textarea formControlName="after_desc" rows="3" class="mt-2" placeholder="Describe after..."></textarea>
              <div class="err-msg" *ngIf="kaizenForm.get('after_desc')?.touched && kaizenForm.get('after_desc')?.errors?.['required']">After description is required</div>
            </div>
          </div>

          <!-- Horizontal Deployment Table -->
          <div class="deployment-container mt-4">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:5px;">
              <label class="evidence-title">Horizontal Deployment Table</label>
              <button type="button" class="logout-pill" style="height:30px; font-size:11px;" (click)="addRow()">+ Add Row</button>
            </div>
            <table class="supervisor-lined-table">
              <thead>
                <tr>
                  <th>Sr.</th>
                  <th>M/C No</th>
                  <th>Responsibility</th>
                  <th>Target Date</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody formArrayName="horizontal_deployment">
                <tr *ngFor="let row of deploymentRows.controls; let i=index" [formGroupName]="i">
                  <td class="text-center">{{i+1}}</td>
                  <td><input type="text" formControlName="m_no"></td>
                  <td><input type="text" formControlName="resp" (keypress)="allowAlphabetsOnly($event)"></td>
                  <td><input type="date" formControlName="target"></td>
                  <td>
                    <select formControlName="status">
                      <option value="Pending">Pending</option>
                      <option value="In Progress">In Progress</option>
                      <option value="Done">Done</option>
                    </select>
                  </td>
                  <td class="text-center">
                    <button type="button" (click)="removeRow(i)"
                            style="color:red;border:none;background:none;cursor:pointer;font-weight:bold;">✖</button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <!-- Benefits + Team -->
          <div class="row-grid-2 mt-4">
            <div class="field">
              <label>Benefits (PQCDSM) <span class="req">*</span></label>
              <textarea formControlName="benefits" rows="3"></textarea>
              <div class="err-msg" *ngIf="kaizenForm.get('benefits')?.touched && kaizenForm.get('benefits')?.errors?.['required']">Benefits is required</div>
            </div>
            <div class="field">
              <label>Team Members <span class="req">*</span></label>
              <textarea formControlName="team" rows="3"
                        (keypress)="allowTeamInput($event)"
                        (keydown)="handleTeamNumbering($event)"
                        placeholder="1. Member Name"></textarea>
              <p class="file-hint">Alphabets and spaces only</p>
              <div class="err-msg" *ngIf="kaizenForm.get('team')?.touched && kaizenForm.get('team')?.errors?.['required']">Team members is required</div>
            </div>
          </div>

          <!-- Buttons -->
          <div style="display:flex; gap:10px; margin-top:20px;">
            <button type="button" class="btn-submit"
                    style="background:#6c757d; flex:0.3;"
                    (click)="clearForm()"
                    [disabled]="isSubmitting">CLEAR</button>
            <button type="submit" class="btn-submit"
                    [disabled]="isDuplicate || kaizenForm.invalid || isAnyCompressing() || isSubmitting || kaizenNo === 'SUP-Error'">
              {{ isSubmitting ? 'SUBMITTING...' :
                 isAnyCompressing() ? 'COMPRESSING...' :
                 kaizenNo === 'SUP-Error' ? 'SYSTEM OFFLINE' :
                 isDuplicate ? 'DUPLICATE THEME' :
                 '✔ SUBMIT SUPERVISOR KAIZEN' }}
            </button>
          </div>

        </form>
      </div>
    </div>
  `,
  styles: [`
    :root { --sorange: #ff7f27; --sdark: #000000; }
    body { background: #f0f2f5 !important; margin: 0; font-family: 'Inter', sans-serif; }
    .shaktiman-ribbon { height: 18px; background: #ff7f27; position: fixed; top: 0; width: 100%; z-index: 1000; }
    .container-main { padding: 50px 20px; max-width: 1000px; margin: 0 auto; }
    .form-card { background: #fff; border-radius: 20px; box-shadow: 0 15px 40px rgba(0,0,0,0.12); overflow: hidden; }
    .form-header { background: #000; color: #fff; padding: 25px 35px; border-bottom: 5px solid #ff7f27; display: flex; justify-content: space-between; align-items: center; }
    .header-flex { display: flex; align-items: center; gap: 20px; }
    .meta-group { display: flex; flex-direction: column; align-items: flex-end; }
    .meta-box { padding: 6px 15px; border-radius: 6px; font-weight: bold; font-size: 13px; margin-bottom: 5px; display: flex; align-items: center; gap: 8px; }
    .meta-box.dark { background: #222; color: #fff; }
    .meta-box.light { background: #f8f9fa; color: #007bff; border: 1px solid #ddd; }
    .error-bg { border: 2px solid #ef4444 !important; color: #ef4444 !important; }
    .retry-btn { background: #ef4444; color: white; border: none; padding: 2px 8px; border-radius: 4px; font-size: 10px; cursor: pointer; }
    .brand-label { color: #ff7f27; font-weight: 900; font-size: 11px; }
    .logout-pill { background: #ff7f27; color: #000; border: none; padding: 10px 18px; border-radius: 50px; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 8px; }
    .form-content { padding: 35px; }
    .row-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; margin-bottom: 20px; }
    .row-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
    .row-grid-cat { display: grid; grid-template-columns: 1fr 2fr; gap: 20px; margin-bottom: 20px; }
    .full-row { margin-bottom: 20px; }
    .field { display: flex; flex-direction: column; gap: 6px; }
    .field label { font-weight: 700; color: #334155; font-size: 13px; }
    .req { color: #ef4444; font-size: 14px; font-weight: 900; margin-left: 2px; }
    input, select, textarea { padding: 12px; border: 2px solid #e2e8f0; border-radius: 10px; font-size: 14px; width: 100%; box-sizing: border-box; }
    input:focus, select:focus, textarea:focus { border-color: #ff7f27; outline: none; background: #fff; }
    .err-msg { color: #ef4444; font-size: 11px; font-weight: bold; margin-top: 4px; }
    .compress-info { color: #10b981; font-size: 11px; font-weight: 600; margin-top: 4px; }
    .file-hint { font-size: 10px; color: #64748b; margin: 2px 0; }
    .divider { margin: 20px 0; border: 0; border-top: 2px dashed #eee; }
    .error-border { border-color: #ef4444 !important; }
    .btn-submit { width: 100%; padding: 18px; background: #000; color: #fff; border: none; border-radius: 12px; font-size: 16px; font-weight: 800; cursor: pointer; }
    .btn-submit:disabled { background: #cbd5e1; cursor: not-allowed; }
    .evidence-panel { padding: 18px; border-radius: 12px; background: #f8fafc; border: 2px dashed #cbd5e1; display: flex; flex-direction: column; gap: 6px; }
    .red-style { border-left: 6px solid #ef4444; }
    .green-style { border-left: 6px solid #22c55e; }
    .evidence-title { font-weight: 700; color: #334155; font-size: 13px; }
    .deployment-container { border: 1px solid #e2e8f0; border-radius: 12px; padding: 15px; background: #f8fafc; }
    .supervisor-lined-table { width: 100%; border-collapse: collapse; margin-top: 10px; border: 1px solid #e2e8f0; }
    .supervisor-lined-table th { background: #f1f5f9; padding: 10px; font-size: 12px; text-align: left; }
    .supervisor-lined-table td { padding: 5px; border-bottom: 1px solid #e2e8f0; }
    .supervisor-lined-table input, .supervisor-lined-table select { padding: 6px 8px; font-size: 12px; border-radius: 6px; }
    .text-center { text-align: center; }
    .mt-2 { margin-top: 8px; }
    .mt-4 { margin-top: 20px; }
    .why-panel { background: #f0f0ff; border: 2px solid #e2e8f0; border-left: 6px solid #6366f1; border-radius: 12px; padding: 18px; margin-bottom: 20px; }
    .why-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-top: 12px; }
    .custom-overlay { position: fixed; top:0; left:0; width:100%; height:100%; background: rgba(0,0,0,0.6); z-index: 3000; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(8px); }
    .modern-modal { background: #fff; width: 420px; padding: 35px; border-radius: 25px; text-align: center; animation: popScale 0.3s ease; }
    .modal-icon { width: 60px; height: 60px; background: #ff7f27; color: #fff; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 15px; font-size: 24px; }
    .modal-icon.check { background: #22c55e; }
    .modal-preview-box { background: #f8f9fa; padding: 15px; border-radius: 12px; margin: 20px 0; font-size: 14px; text-align: left; border-left: 4px solid #ff7f27; }
    .modal-actions { display: flex; gap: 10px; }
    .btn-cancel { flex:1; padding: 12px; border: 1px solid #ddd; border-radius: 8px; background: #fff; cursor: pointer; }
    .btn-confirm { flex:1; padding: 12px; border: none; border-radius: 8px; background: #000; color: #fff; font-weight: bold; cursor: pointer; }
    .btn-confirm:disabled { background: #94a3b8; cursor: not-allowed; }
    @keyframes popScale { from { transform: scale(0.9); opacity: 0; } to { transform: scale(1); opacity: 1; } }
  `]
})
export class SupervisorFormComponent implements OnInit {

  public isSubmitting     = false;
  public kaizenNo         = 'Fetching...';
  public lastSubmittedNo  = '';
  public today            = new Date();
  public kaizenForm!: FormGroup;
  public isDuplicate      = false;
  public showConfirmModal = false;
  public showSuccessModal = false;

  public availableDepartments: string[] = [];
  public availableSections: string[]    = [];

  public compressing: { [key: string]: boolean } = {
    before_img: false, after_img: false, problem_img: false, result_img: false
  };
  public compressInfo: { [key: string]: string } = {
    before_img: '', after_img: '', problem_img: '', result_img: ''
  };
  public fileErrors: { [key: string]: boolean } = {
    before_img: false, after_img: false, problem_img: false, result_img: false
  };

  private selectedFiles: { [key: string]: File | null } = {
    before_img: null, after_img: null, problem_img: null, result_img: null
  };
  private allThemes: string[] = [];

  private plantDepartments: { [unit: string]: string[] } = {
    'Unit 1': ['Production', 'Quality', 'Maintenance', 'Stores'],
    'Unit 2': ['Production', 'Quality', 'Maintenance', 'Stores'],
    'Unit 3': ['Production', 'Quality', 'Maintenance', 'Stores'],
    'Unit 4': ['Production', 'Quality', 'Maintenance', 'Stores'],
    'Unit 5': ['Production', 'Quality', 'Maintenance', 'Stores'],
  };

  private departmentSections: { [dept: string]: string[] } = {
    'Production':  ['Welding', 'Assembly', 'Paint Shop', 'Machine Shop'],
    'Quality':     ['Incoming', 'In-Process', 'Final Inspection', 'Quality'],
    'Maintenance': ['Mechanical', 'Electrical', 'Civil', 'Maintenance'],
    'Stores':      ['Raw Material', 'Finished Goods', 'Dispatch', 'Stores'],
  };

  public categories = [
    { v: 'C-1|Restorative (TPM)',              l: 'C-1: Restorative (Using TPM Methodology)' },
    { v: 'C-2|Renovative (TPM)',               l: 'C-2: Renovative (Using TPM Methodology)' },
    { v: 'C-3|Innovative (TPM)',               l: 'C-3: Innovative (Using TPM Methodology)' },
    { v: 'C-4|Breakthrough (TPM)',             l: 'C-4: Breakthrough (Using TPM Methodology)' },
    { v: 'C-5|Poka Yoke (TPM)',                l: 'C-5: Poka Yoke (Using TPM Methodology)' },
    { v: 'C-6|KARAKURI & YUTORI',              l: 'C-6: KARAKURI (No Energy Loss) & YUTORI' },
    { v: 'C-7|JH Shop Floor Visualization',    l: 'C-7: JH - Shop Floor Visualization' },
    { v: 'C-8|KK OEE Compliance',              l: 'C-8: KK OEE Compliance (Top 5 Machines across BU)' },
    { v: 'C-9|KK Bottleneck Process Solution', l: 'C-9: KK Bottleneck Process Identified & Solution' },
    { v: 'C-10|JH Circle Board Updating',      l: 'C-10: JH - Circle Board updating, Key indicators Monitoring' },
    { v: 'C-11|JH One Point Lessons',          l: 'C-11: JH - One Point Lessons for the month' },
    { v: 'C-12|JH White Tag Abnormality',      l: 'C-12: JH: Max no. of white tag abnormality Identified & Rectified' },
    { v: 'C-13|JH (HTA / SOC / Ease for CLITA)', l: 'C-13: JH (HTA / SOC / Ease for CLITA)' },
    { v: 'C-14|JH Step 4 M-M Combination',    l: 'C-14: JH step 4 Man-Machine combination' },
    { v: 'C-15|JH Step 5 M-M Combination',    l: 'C-15: JH step 5 Man-Machine combination' },
    { v: 'C-16|JH Step 1, 2, 3 Repeat',       l: 'C-16: JH: Repeat of JH Step 1, 2, 3' },
    { v: 'C-17|JH Minor Stoppage Monitoring',  l: 'C-17: JH: Minor Stoppage Monitoring and DO Kaizen' },
    { v: 'C-18|JH RED Tag Abnormality',        l: 'C-18: JH: Max no. of RED tag abnormality type Identified by TPM Circle' },
    { v: 'C-19|QM Assembly Pokamapping',       l: 'C-19: QM: Product Assembly Pokamapping & closure of issues' },
    { v: 'C-20|PM MP Sheets Generation',       l: 'C-20: PM: Generation of MP sheets' },
    { v: 'C-21|NEDM MP Sheets Implementation', l: 'C-21: NEDM: Successful Implementation of MP sheets' },
    { v: 'C-22|NEDM Low Cost Automation',      l: 'C-22: NEDM: Low Cost Automation' },
    { v: 'C-23|OTPM MAKIGAMI',                 l: 'C-23: OTPM: MAKIGAMI' },
    { v: 'C-24|OTPM Red Tag Office',           l: 'C-24: OTPM: Red tag at Office area (5S)' },
    { v: 'C-25|SHE Near Miss/Unsafe Condition',l: 'C-25: SHE: identified Near miss situation & Unsafe condition' },
    { v: 'C-26|SHE Unsafe Act',                l: 'C-26: SHE: Unsafe act' },
    { v: 'C-27|SHE Ergonomic Hazard',          l: 'C-27: SHE: Ergonomic hazard Condition' },
    { v: 'C-28|SHE CO2 Emission Reduction',    l: 'C-28: SHE: CO2 emission reduction by using Renewable Energy' },
    { v: 'C-29|SHE Micro Level HIRA',          l: 'C-29: SHE: Micro level HIRA for listed all Processes / Activities' },
    { v: 'C-30|5S Zone Space Saved',           l: 'C-30: 5S: Zone wise space saved THROUGH 5s' },
    { v: 'C-31|5S Best 1S-3S',                 l: 'C-31: 5S: Best 1S, 2S, 3S, at Zones' },
    { v: 'C-32|All Members',                   l: 'C-32: Sure Appreciation' },
    { v: 'C-33|All Members',                   l: 'C-33: Won the Awards from CII (Platinium & Gold)' },
    { v: 'C-34|All Members',                   l: 'C-34: Won the Awards from CII (Jury Challenger, Champion of Champians, Jury Champion)' },
  ];

  constructor(
    private router: Router,
    private http: HttpClient,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.initForm();
    this.fetchNextId();
    this.loadExistingThemes();
  }

  initForm() {
    this.availableDepartments = [];
    this.availableSections    = [];
    this.kaizenForm = new FormGroup({
      emp_id:          new FormControl('', [Validators.required, Validators.pattern('^[0-9]+$')]),
      emp_name:        new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z ]+$')]),
      unit:            new FormControl('', Validators.required),
      department:      new FormControl('', Validators.required),
      section:         new FormControl('', Validators.required),
      machine_no:      new FormControl('', Validators.required),
      kaizen_type:     new FormControl('Innovative', Validators.required),
      pqcdsm:          new FormControl('', Validators.required),
      kaizen_category: new FormControl('', Validators.required),
      theme:           new FormControl('', Validators.required),
      problem_status:  new FormControl('', Validators.required),
      idea:            new FormControl('', Validators.required),
      countermeasure:  new FormControl('', Validators.required),
      why1:            new FormControl('', Validators.required),
      why2:            new FormControl('', Validators.required),
      why3:            new FormControl('', Validators.required),
      why4:            new FormControl(''),
      why5:            new FormControl(''),
      root_cause:      new FormControl('', Validators.required),
      final_result:    new FormControl('', Validators.required),
      analysis:        new FormControl('', Validators.required),
      start_date:      new FormControl('', Validators.required),
      end_date:        new FormControl('', Validators.required),
      before_desc:     new FormControl('', Validators.required),
      after_desc:      new FormControl('', Validators.required),
      benefits:        new FormControl('', Validators.required),
      team:            new FormControl('1. ', Validators.required),
      horizontal_deployment: new FormArray([this.createRow()])
    });
  }

  createRow() {
    return new FormGroup({
      m_no:   new FormControl(''),
      resp:   new FormControl(''),
      target: new FormControl(''),
      status: new FormControl('Pending')
    });
  }

  get deploymentRows() {
    return this.kaizenForm.get('horizontal_deployment') as FormArray;
  }

  addRow()    { this.deploymentRows.push(this.createRow()); }
  removeRow(i: number) {
    if (this.deploymentRows.length > 1) this.deploymentRows.removeAt(i);
  }

  // Unit selected → show Department, reset downstream
  onUnitChange() {
    const unit = this.kaizenForm.get('unit')?.value;
    this.availableDepartments = this.plantDepartments[unit] || [];
    this.availableSections    = [];
    this.kaizenForm.patchValue({ department: '', section: '' });
  }

  // Department selected → show Section, reset downstream
  onDepartmentChange() {
    const dept = this.kaizenForm.get('department')?.value;
    this.availableSections = this.departmentSections[dept] || [];
    this.kaizenForm.patchValue({ section: '' });
  }

  loadExistingThemes() {
    this.http.get<any[]>('http://localhost:8080/api/kaizen/my-kaizens').subscribe({
      next: (res) => {
        this.allThemes = res
          .map(k => (k.theme || '').toLowerCase().trim())
          .filter(t => t.length > 0);
      },
      error: () => { this.allThemes = []; }
    });
  }

  fetchNextId() {
    this.kaizenNo = 'Fetching...';
    this.http.get('http://localhost:8080/api/supervisor', { responseType: 'text' }).subscribe({
      next: (val) => {
        const count = val ? parseInt(val, 10) : 0;
        this.kaizenNo = `SUP-${new Date().getFullYear()}-${(count + 1).toString().padStart(3, '0')}`;
        this.cdr.detectChanges();
      },
      error: () => { this.kaizenNo = 'SUP-Error'; this.cdr.detectChanges(); }
    });
  }

  allowNumbersOnly(event: KeyboardEvent): boolean {
    return event.charCode >= 48 && event.charCode <= 57;
  }

  allowAlphabetsOnly(event: KeyboardEvent): boolean {
    const c = event.charCode;
    return (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c === 32;
  }

  allowTeamInput(event: KeyboardEvent): boolean {
    const c = event.charCode;
    return (c >= 65 && c <= 90) || (c >= 97 && c <= 122) ||
           c === 32 || c === 46 || (c >= 48 && c <= 57);
  }

  onFileChange(event: any, field: string) {
    const file = event.target.files[0];
    if (!file) return;

    if (file.size <= 512000) {
      this.fileErrors[field]    = false;
      this.compressInfo[field]  = `✓ ${Math.round(file.size / 1024)}KB — ready`;
      this.selectedFiles[field] = file;
      this.cdr.detectChanges();
      return;
    }

    this.compressing[field]  = true;
    this.compressInfo[field] = '';
    this.cdr.detectChanges();

    this.compressImage(file, 500).then(compressed => {
      this.compressing[field]   = false;
      this.fileErrors[field]    = false;
      this.selectedFiles[field] = compressed;
      this.compressInfo[field]  =
        `✓ Compressed: ${Math.round(file.size / 1024)}KB → ${Math.round(compressed.size / 1024)}KB`;
      this.cdr.detectChanges();
    }).catch(() => {
      this.compressing[field] = false;
      this.fileErrors[field]  = true;
      this.cdr.detectChanges();
      event.target.value = '';
    });
  }

  compressImage(file: File, maxSizeKB: number): Promise<File> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (e: any) => {
        const img = new Image();
        img.src = e.target.result;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let w = img.width, h = img.height;
          const MAX = 1200;
          if (w > MAX || h > MAX) {
            if (w > h) { h = Math.round(h * MAX / w); w = MAX; }
            else        { w = Math.round(w * MAX / h); h = MAX; }
          }
          canvas.width = w; canvas.height = h;
          canvas.getContext('2d')!.drawImage(img, 0, 0, w, h);
          let quality = 0.9;
          const tryCompress = () => {
            const dataUrl = canvas.toDataURL('image/jpeg', quality);
            const sizeKB  = Math.round(dataUrl.length * 3 / 4 / 1024);
            if (sizeKB <= maxSizeKB || quality <= 0.3) {
              const arr  = dataUrl.split(',');
              const bstr = atob(arr[1]);
              let n = bstr.length;
              const u8 = new Uint8Array(n);
              while (n--) u8[n] = bstr.charCodeAt(n);
              resolve(new File([u8], file.name, { type: 'image/jpeg' }));
            } else {
              quality -= 0.1;
              tryCompress();
            }
          };
          tryCompress();
        };
        img.onerror = () => reject();
      };
      reader.onerror = () => reject();
    });
  }

  isAnyCompressing(): boolean {
    return Object.values(this.compressing).some(v => v);
  }

  hasFileError(): boolean {
    return Object.values(this.fileErrors).some(v => v);
  }

  checkDuplicateTheme() {
    const theme = this.kaizenForm.get('theme')?.value?.toLowerCase().trim();
    this.isDuplicate = theme && theme.length > 2 ? this.allThemes.includes(theme) : false;
  }

  handleTeamNumbering(e: KeyboardEvent) {
    if (e.key === 'Enter') {
      const val   = (e.target as HTMLTextAreaElement).value;
      const lines = val.split('\n');
      if (lines[lines.length - 1].trim().length > 3) {
        e.preventDefault();
        this.kaizenForm.patchValue({ team: val + '\n' + (lines.length + 1) + '. ' });
      }
    }
  }

  clearForm() {
    if (confirm('Clear all entries?')) {
      this.initForm();
      this.resetFileInputs();
      this.cdr.detectChanges();
    }
  }

  resetFileInputs() {
    this.selectedFiles = { before_img: null, after_img: null, problem_img: null, result_img: null };
    this.fileErrors    = { before_img: false, after_img: false, problem_img: false, result_img: false };
    this.compressing   = { before_img: false, after_img: false, problem_img: false, result_img: false };
    this.compressInfo  = { before_img: '', after_img: '', problem_img: '', result_img: '' };
    document.querySelectorAll<HTMLInputElement>('input[type="file"]').forEach(i => i.value = '');
  }

  onPreSubmit() {
    if (this.isSubmitting) return;
    Object.keys(this.kaizenForm.controls).forEach(k => this.kaizenForm.get(k)?.markAsTouched());
    if (this.kaizenForm.valid && !this.isDuplicate &&
        !this.hasFileError() && !this.isAnyCompressing() &&
        this.kaizenNo !== 'SUP-Error') {
      this.showConfirmModal = true;
    } else {
      alert('Please fill all required fields and ensure images are ready.');
    }
  }

  finalSubmit() {
    if (this.isSubmitting) return;
    this.isSubmitting = true;
    this.showConfirmModal = false;
    this.cdr.detectChanges();

    const formData = new FormData();
    const vals = this.kaizenForm.value;

    Object.keys(vals).forEach(key => {
      if (key !== 'horizontal_deployment') formData.append(key, vals[key]);
    });

    formData.append('kaizen_id',       this.kaizenNo);
    formData.append('submitted_at',    new Date().toISOString());
    formData.append('level',           'Supervisor');
    formData.append('deployment_data', JSON.stringify(
      vals.horizontal_deployment.filter((r: any) => r.m_no?.trim())
    ));

    if (this.selectedFiles['before_img'])  formData.append('before_img_file',  this.selectedFiles['before_img']!);
    if (this.selectedFiles['after_img'])   formData.append('after_img_file',   this.selectedFiles['after_img']!);
    if (this.selectedFiles['problem_img']) formData.append('problem_img_file', this.selectedFiles['problem_img']!);
    if (this.selectedFiles['result_img'])  formData.append('result_img_file',  this.selectedFiles['result_img']!);

    this.http.post('http://localhost:8080/api/supervisor/save', formData, { responseType: 'text' }).subscribe({
      next: () => {
        this.lastSubmittedNo  = this.kaizenNo;
        this.showSuccessModal = true;
        this.isSubmitting     = false;
        this.initForm();
        this.resetFileInputs();
        this.fetchNextId();
        this.loadExistingThemes();
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.isSubmitting = false;
        this.cdr.detectChanges();
        alert('Submission Error: ' + err.message);
      }
    });
  }

  logout() {
    if (confirm('Are you sure you want to logout?')) {
      sessionStorage.clear();
      this.router.navigate(['/login']);
    }
  }
}