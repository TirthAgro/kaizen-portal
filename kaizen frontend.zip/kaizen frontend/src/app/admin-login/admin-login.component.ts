import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-admin-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {
  selectedRole: string = ''; 
  adminId = '';
  adminPassword = '';
  liveTime = '';
  isLoading = false;

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit() {
    this.updateTime();
    setInterval(() => this.updateTime(), 1000);
  }

  selectRole(role: string) {
    this.selectedRole = role;
  }

  updateTime() {
    this.liveTime = new Date().toLocaleTimeString('en-IN', {
      timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', second: '2-digit'
    });
  }

  onAdminLogin(event: Event) {
    event.preventDefault();
    this.isLoading = true;

    const loginData = { 
      role: this.selectedRole, 
      admin_id: this.adminId, 
      password: this.adminPassword 
    };

    this.http.post('http://localhost:8080/api/auth/admin-login', loginData)
    .subscribe({
      next: (response: any) => {
        if (response.status === 'success') {
          // --- SESSION STORAGE UPDATES ---
          sessionStorage.setItem('role', this.selectedRole);
          sessionStorage.setItem('emp_id', response.user.admin_id);
          sessionStorage.setItem('plant_id', response.user.plant_id);
          sessionStorage.setItem('section', response.user.section);

          localStorage.setItem('admin_user', JSON.stringify(response.user));
          
          // --- DYNAMIC REDIRECTION LOGIC ---
          if (this.selectedRole === 'Business Excellence') {
    this.router.navigate(['/bex-dashboard']);
}
else if (this.selectedRole === 'HOD') {
    this.router.navigate(['/hod-dashboard']);
}
else if (this.selectedRole === 'Manager') {
    this.router.navigate(['/manager-dashboard']);
}
else {
    this.router.navigate(['/admin-dashboard']);
}
        } else {
          alert(response.message);
          this.isLoading = false;
        }
      },
      error: (err) => {
        
        this.isLoading = false;
        alert("Server Connection Error. Please check XAMPP.");
      }
    });
  }
}