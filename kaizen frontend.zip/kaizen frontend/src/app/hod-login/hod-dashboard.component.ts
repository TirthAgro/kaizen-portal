import { Component, OnInit, ChangeDetectorRef, NgZone } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-hod-dashboard',
  standalone: true,
  imports: [CommonModule, HttpClientModule],
  template: `
    <div class="app-container">
      <aside class="sidebar-pillar" [class.is-collapsed]="isSidebarClosed">
        <div class="gloss-shine"></div>
        
        <div class="sidebar-header">
           <div class="brand-shell">
             <div class="royal-logo">
               <span class="gold-accent">S</span>
             </div>
             <span class="brand-name">HOD</span>
             <span class="brand-sub">EXECUTIVE COUNCIL</span>
           </div>
        </div>

        <nav class="navigation-hub">
          <div class="nav-label">COMMAND CENTER</div>
          <a (click)="currentView = 'dashboard'" [class.active]="currentView === 'dashboard'" class="nav-item">
            <div class="nav-glow"></div>
            <i class="nav-icon">📊</i>
            <span class="nav-label-text">INTELLIGENCE</span>
          </a>
          <a (click)="currentView = 'pending'" [class.active]="currentView === 'pending'" class="nav-item">
            <div class="nav-glow"></div>
            <i class="nav-icon">⚖️</i>
            <span class="nav-label-text">DECISIONS</span>
            <span class="alert-badge" *ngIf="counts.pending > 0">{{counts.pending}}</span>
          </a>
          
          <div class="nav-label">PLANT ARCHIVES</div>
          <a (click)="currentView = 'history'" [class.active]="currentView === 'history'" class="nav-item">
            <div class="nav-glow"></div>
            <i class="nav-icon">📜</i>
            <span class="nav-label-text">HISTORY</span>
          </a>
          <a (click)="currentView = 'master'" [class.active]="currentView === 'master'" class="nav-item">
            <div class="nav-glow"></div>
            <i class="nav-icon">🔍</i>
            <span class="nav-label-text">MASTER DATA</span>
          </a>
        </nav>

        <div class="sidebar-footer">
           <div class="profile-preview">
              <div class="avatar">H</div>
              <div class="details">
                <span class="name">Head of Dept.</span>
                <span class="unit">{{ plantId }}</span>
              </div>
           </div>
           <button (click)="logout()" class="logout-trigger">EXIT PORTAL</button>
        </div>
      </aside>

      <div class="main-viewport">
        <header class="premium-topbar">
          <div class="bar-left">
            <button class="menu-toggle" (click)="isSidebarClosed = !isSidebarClosed">
              <div class="hamburger-box">
                <span class="line"></span>
                <span class="line"></span>
                <span class="line"></span>
              </div>
            </button>
            <h1 class="portal-heading">SHAKTIMAN <span class="thin">KAIZEN PORTAL</span></h1>
          </div>

          <div class="bar-right">
             <div class="status-chip">SYSTEM LIVE</div>
             <div class="logo-badge">
               <img src="assets/shaktiman_logo.png" alt="Shaktiman">
             </div>
          </div>
        </header>

        <main class="content-arena">
          <div class="view-portal" *ngIf="currentView === 'dashboard'">
            <div class="welcome-banner">
               <h2>Good Day, Administrator</h2>
               <p>Real-time Kaizen Intelligence for <strong>{{ plantId }}</strong></p>
            </div>

            <div class="insight-grid">
              <div class="insight-card-white border-blue">
                <span class="lab">Operator Ideas</span>
                <span class="val color-blue">{{counts.op}}</span>
                <div class="mini-trend">Total Registered</div>
              </div>
              <div class="insight-card-white border-emerald">
                <span class="lab">Supervisor Input</span>
                <span class="val color-emerald">{{counts.sup}}</span>
                <div class="mini-trend">Active Verification</div>
              </div>
              <div class="insight-card-white border-royal">
                <span class="lab">Manager Kaizens</span>
                <span class="val color-royal">{{counts.man}}</span>
                <div class="mini-trend">Implementation Phase</div>
              </div>
              <div class="insight-card-white border-gold pulse-border">
                <span class="lab">Awaiting Signature</span>
                <span class="val color-gold">{{counts.pending}}</span>
                <div class="mini-trend">Critical Priority</div>
              </div>
            </div>

            <div class="analytics-row">
                <div class="white-box">
                  <h3>Kaizen Impact Distribution (PQCDSM)</h3>
                  <div class="impact-bar-track" *ngIf="impactTotal > 0; else noData">
                      <div class="impact-segment p-bg" [style.width.%]="getW('Productivity')">P</div>
                      <div class="impact-segment q-bg" [style.width.%]="getW('Quality')">Q</div>
                      <div class="impact-segment c-bg" [style.width.%]="getW('Cost')">C</div>
                      <div class="impact-segment d-bg" [style.width.%]="getW('Delivery')">D</div>
                      <div class="impact-segment s-bg" [style.width.%]="getW('Safety')">S</div>
                      <div class="impact-segment m-bg" [style.width.%]="getW('Morale')">M</div>
                  </div>
                  <ng-template #noData>
                    <div class="empty-msg">No impact data available for {{ plantId }}</div>
                  </ng-template>

                  <div class="impact-legend">
                    <span *ngFor="let item of impactData | keyvalue" class="legend-item">
                      <i [class]="$any(item.key).toLowerCase().charAt(0) + '-bg'"></i>
                      {{ item.key }}: {{ item.value }}
                    </span>
                  </div>
                </div>
            </div>
          </div>

          <div class="view-portal" *ngIf="currentView === 'pending'">
            <div class="white-table-card">
              <div class="card-head">
                <h3>Priority Approval Queue (Awaiting HOD Action)</h3>
              </div>
              <div class="table-container">
                <table class="clean-table">
                  <thead>
                    <tr><th>Kaizen ID</th><th>Emp Name</th><th>Source</th><th>Theme</th><th>Date</th><th>Action</th></tr>
                  </thead>
                  <tbody>
                    <tr *ngFor="let k of getPendingList()">
                      <td><strong>{{ k.kaizen_id }}</strong></td>
                      <td>{{ k.emp_name }}</td>
                      <td><span class="section-pill">{{ k.role_type }}</span></td>
                      <td>{{ k.theme }}</td>
                      <td>{{ (k.submitted_at || k.created_at) | date:'dd MMM yyyy' }}</td>
                      <td><button class="btn-review" (click)="openKaizen(k)">Review Case</button></td>
                    </tr>
                  </tbody>
                </table>
                <div class="empty-notif" *ngIf="getPendingList().length === 0">No pending approvals found.</div>
              </div>
            </div>
          </div>

          <div class="view-portal" *ngIf="currentView === 'history'">
            <div class="white-table-card">
              <div class="card-head"><h3>Global Approval History (Audit & Modify All)</h3></div>
              <div class="table-container">
                <table class="clean-table">
                  <thead>
                    <tr><th>ID</th><th>Source</th><th>Initiator</th><th>Theme</th><th>Current Status</th><th>Action</th></tr>
                  </thead>
                  <tbody>
                    <tr *ngFor="let k of kaizens">
                      <td><strong>{{ k.kaizen_id }}</strong></td>
                      <td><span class="section-pill">{{ k.role_type }}</span></td>
                      <td>{{ k.emp_name }}</td>
                      <td>{{ k.theme }}</td>
                      <td>
                          <span class="status-indicator" 
                            [ngClass]="(k.hod_status && k.hod_status !== 'Pending' ? k.hod_status : k.status)?.toLowerCase() || 'pending'">
                            {{ k.hod_status && k.hod_status !== 'Pending' ? k.hod_status : (k.status || 'Pending') }}
                          </span>
                      </td>
                      <td>
                        <button class="btn-review secondary" (click)="openKaizen(k)">
                          Modify Decision
                        </button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <div class="view-portal" *ngIf="currentView === 'master'">
            <div class="white-table-card">
              <div class="card-head"><h3>Plant Master Configuration</h3></div>
              <div class="empty-notif-big">
                <span class="icon">⚙️</span>
                <p>Master Data Management is restricted to Admin levels.</p>
              </div>
            </div>
          </div>
        </main>
      </div>

      <div class="overlay-blur" *ngIf="selectedKaizen">
        <div class="decision-modal-white">
          <div class="modal-top">
            <h3>Authorization Override: {{selectedKaizen.kaizen_id}}</h3>
            <button class="x-close" (click)="selectedKaizen = null">×</button>
          </div>
          <div class="modal-content-area">
            <div class="manager-details-grid">
                <div><strong>Initiator:</strong> {{selectedKaizen.emp_name}}</div>
                <div><strong>Source Level:</strong> {{selectedKaizen.role_type}}</div>
                <div><strong>Section:</strong> {{selectedKaizen.section}}</div>
                <div><strong>Category:</strong> {{selectedKaizen.kaizen_category || 'N/A'}}</div>
                <div class="details-full">
                    <strong>Kaizen Details:</strong><br>
                    {{selectedKaizen.before_desc || selectedKaizen.theme}}
                </div>
            </div>

            <!-- FIX: Use safeImgSrc() helper so images always render correctly -->
            <div class="comparison-chamber">
              <div class="chamber-box">
                <span class="img-badge red">BEFORE</span>
                <img *ngIf="safeImgSrc(selectedKaizen.before_img)"
                     [src]="safeImgSrc(selectedKaizen.before_img)"
                     style="width:100%; height:320px; object-fit:contain; background:#000;">
                <div *ngIf="!safeImgSrc(selectedKaizen.before_img)" class="no-img-placeholder">
                  <span>No Image Available</span>
                </div>
              </div>
              <div class="chamber-box">
                <span class="img-badge green">AFTER</span>
                <img *ngIf="safeImgSrc(selectedKaizen.after_img)"
                     [src]="safeImgSrc(selectedKaizen.after_img)"
                     style="width:100%; height:320px; object-fit:contain; background:#000;">
                <div *ngIf="!safeImgSrc(selectedKaizen.after_img)" class="no-img-placeholder">
                  <span>No Image Available</span>
                </div>
              </div>
            </div>
            
            <div class="judgement-footer">
              <label>Executive Remarks (Current: {{selectedKaizen.hod_remarks || 'None'}})</label>
              <textarea #remarks [value]="selectedKaizen.hod_remarks || ''" placeholder="Provide reason for approval or rejection..."></textarea>
              <div class="btn-group">
                <button class="btn-decline" (click)="process(selectedKaizen, 'Rejected', remarks.value)">REJECT KAIZEN</button>
                <button class="btn-endorse" (click)="process(selectedKaizen, 'Approved', remarks.value)">APPROVE KAIZEN</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@500;800&family=Inter:wght@300;400;600;700;900&display=swap');

    :host { 
      --shaktiman-orange: #ff6a00;
      --gold: #c5a059;
      --midnight: #0b0f19;
      --sb-width: 290px;
    }

    .app-container { display: flex; height: 100vh; width: 100vw; overflow: hidden; background: #f0f2f5; font-family: 'Inter', sans-serif; }

    .sidebar-pillar {
      width: var(--sb-width); height: 100vh; background: var(--midnight); position: relative;
      display: flex; flex-direction: column; transition: all 0.5s cubic-bezier(0.16, 1, 0.3, 1);
      z-index: 1000; box-shadow: 15px 0 50px rgba(0,0,0,0.4); border-right: 1px solid rgba(255,255,255,0.05);
    }
    .sidebar-pillar.is-collapsed { transform: translateX(-100%); margin-right: calc(var(--sb-width) * -1); }
    .gloss-shine { position: absolute; top: 0; left: 0; right: 0; height: 100%; background: linear-gradient(135deg, rgba(255,255,255,0.08) 0%, rgba(255,255,255,0) 40%); pointer-events: none; }
    .sidebar-header { padding: 40px 20px; text-align: center; }
    .brand-shell { display: flex; flex-direction: column; font-family: 'Orbitron', sans-serif; }
    .royal-logo { margin-bottom: 10px; display: flex; justify-content: center; }
    .gold-accent { font-size: 2.2rem; font-weight: 900; color: var(--gold); border: 2px solid var(--gold); padding: 0 12px; border-radius: 8px; box-shadow: 0 0 15px rgba(197, 160, 89, 0.3); }
    .brand-name { font-size: 1.8rem; font-weight: 800; color: white; letter-spacing: 5px; }
    .brand-sub { font-size: 0.65rem; color: var(--gold); letter-spacing: 3px; margin-top: 5px; opacity: 0.8; }

    .navigation-hub { 
      flex: 1; 
      padding: 20px 15px; 
      overflow-y: auto;
      overflow-x: hidden;
    }
    .navigation-hub::-webkit-scrollbar { width: 5px; }
    .navigation-hub::-webkit-scrollbar-track { background: rgba(0, 0, 0, 0.1); }
    .navigation-hub::-webkit-scrollbar-thumb { background: var(--gold); border-radius: 10px; }

    .nav-label { padding: 20px 20px 10px; font-size: 0.65rem; color: #475569; letter-spacing: 2px; font-weight: 800; }
    .nav-item {
      position: relative; display: flex; align-items: center; padding: 14px 25px; margin-bottom: 8px;
      color: #94a3b8; text-decoration: none; font-weight: 600; font-size: 0.85rem; letter-spacing: 1px;
      transition: 0.3s; border-radius: 12px; overflow: hidden; cursor: pointer;
    }
    .nav-glow { position: absolute; top: 0; left: -100%; width: 100%; height: 100%; background: linear-gradient(90deg, transparent, rgba(197,160,89,0.1), transparent); transition: 0.5s; z-index: 1; }
    .nav-item:hover { color: #fff; background: rgba(255,255,255,0.05); }
    .nav-item.active { background: rgba(197,160,89,0.1); color: var(--gold); border: 1px solid rgba(197,160,89,0.2); }
    .nav-icon { margin-right: 15px; font-size: 1.1rem; z-index: 2; }
    .nav-label-text { z-index: 2; }
    .alert-badge { background: #ef4444; color: #fff; font-size: 0.65rem; padding: 2px 8px; border-radius: 20px; margin-left: auto; z-index: 2; }

    .sidebar-footer { padding: 20px; background: rgba(0,0,0,0.3); }
    .profile-preview { display: flex; gap: 12px; align-items: center; margin-bottom: 15px; padding: 0 10px; }
    .avatar { width: 40px; height: 40px; background: var(--gold); border-radius: 10px; color: #000; display: grid; place-items: center; font-weight: 900; }
    .details .name { display: block; font-size: 0.85rem; font-weight: bold; color: white; }
    .details .unit { font-size: 0.7rem; color: var(--gold); }
    .logout-trigger { width: 100%; padding: 12px; background: transparent; border: 1px solid #ef4444; color: #ef4444; border-radius: 8px; font-weight: 800; font-size: 0.7rem; cursor: pointer; transition: 0.3s; }
    .logout-trigger:hover { background: #ef4444; color: white; }

    .main-viewport { flex: 1; display: flex; flex-direction: column; min-width: 0; }
    .premium-topbar { height: 80px; background: linear-gradient(90deg, #FF8C00, #FF4500); display: flex; justify-content: space-between; align-items: center; padding: 0 35px; box-shadow: 0 10px 30px rgba(0,0,0,0.15); z-index: 900; }
    .bar-left { display: flex; align-items: center; gap: 25px; }
    .menu-toggle { background: rgba(255,255,255,0.15); border: none; width: 45px; height: 45px; border-radius: 50%; cursor: pointer; display: flex; align-items: center; justify-content: center; }
    .hamburger-box { display: flex; flex-direction: column; gap: 4px; }
    .line { width: 20px; height: 2px; background: white; border-radius: 5px; }
    .portal-heading { font-family: 'Orbitron', sans-serif; color: white; font-size: 1.3rem; font-weight: 800; margin: 0; }
    .thin { font-weight: 300; opacity: 0.8; font-size: 0.9rem; }
    .bar-right { display: flex; align-items: center; gap: 20px; }
    .status-chip { color: white; font-size: 0.65rem; font-weight: 900; border: 1px solid rgba(255,255,255,0.5); padding: 5px 15px; border-radius: 20px; background: rgba(255,255,255,0.1); }
    .logo-badge { background: white; padding: 8px 20px; border-radius: 50px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
    .logo-badge img { height: 30px; }

    .content-arena { flex: 1; overflow-y: auto; padding: 40px; background: #f8fafc; }
    .welcome-banner { margin-bottom: 30px; }
    .welcome-banner h2 { margin: 0; font-size: 1.8rem; font-weight: 900; color: #0f172a; }
    .welcome-banner p { margin: 5px 0 0; color: #64748b; font-size: 1rem; }

    .insight-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 25px; margin-bottom: 35px; }
    .insight-card-white { background: #fff; padding: 30px; border-radius: 20px; box-shadow: 0 10px 25px rgba(0,0,0,0.03); border-top: 6px solid #eee; transition: 0.3s; }
    .insight-card-white:hover { transform: translateY(-5px); box-shadow: 0 15px 35px rgba(0,0,0,0.08); }
    .insight-card-white .lab { font-size: 0.7rem; color: #64748b; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; }
    .insight-card-white .val { display: block; font-size: 2.8rem; font-weight: 900; margin: 10px 0; }
    .mini-trend { font-size: 0.75rem; color: #94a3b8; }
    .border-blue { border-top-color: #3b82f6; } .border-emerald { border-top-color: #10b981; } .border-royal { border-top-color: #6366f1; } .border-gold { border-top-color: var(--gold); }
    .color-blue { color: #3b82f6; } .color-emerald { color: #10b981; } .color-royal { color: #6366f1; } .color-gold { color: var(--gold); }
    .pulse-border { animation: pulse-border 2s infinite; }
    @keyframes pulse-border { 0% { box-shadow: 0 0 0 0 rgba(197, 160, 89, 0.4); } 70% { box-shadow: 0 0 0 12px rgba(197, 160, 89, 0); } }

    .white-box { background: #fff; padding: 30px; border-radius: 20px; box-shadow: 0 10px 25px rgba(0,0,0,0.03); }
    .white-box h3 { margin-top: 0; font-size: 1.1rem; color: #1e293b; font-weight: 800; }
    .impact-bar-track { height: 40px; background: #f1f5f9; border-radius: 10px; display: flex; overflow: hidden; margin-top: 20px; }
    .impact-segment { display: flex; align-items: center; justify-content: center; color: #fff; font-size: 0.75rem; font-weight: 900; transition: 0.8s cubic-bezier(0.2, 1, 0.3, 1); }
    .p-bg { background: #3b82f6; } .q-bg { background: #10b981; } .c-bg { background: #f59e0b; }
    .d-bg { background: #6366f1; } .s-bg { background: #f43f5e; } .m-bg { background: #8b5cf6; }
    .impact-legend { display: flex; gap: 20px; flex-wrap: wrap; margin-top: 25px; }
    .legend-item { font-size: 0.8rem; font-weight: 700; color: #475569; display: flex; align-items: center; gap: 8px; }
    .legend-item i { width: 12px; height: 12px; border-radius: 4px; display: inline-block; }

    .white-table-card { background: #fff; border-radius: 20px; box-shadow: 0 10px 25px rgba(0,0,0,0.03); overflow: hidden; }
    .card-head { padding: 25px 30px; border-bottom: 1px solid #f1f5f9; background: #fafafa; }
    .card-head h3 { margin: 0; font-size: 1rem; font-weight: 800; color: #0f172a; }
    .clean-table { width: 100%; border-collapse: collapse; }
    .clean-table th { background: #f8fafc; text-align: left; padding: 18px 25px; font-size: 0.7rem; color: #64748b; text-transform: uppercase; letter-spacing: 1px; }
    .clean-table td { padding: 20px 25px; border-bottom: 1px solid #f1f5f9; font-size: 0.9rem; color: #334155; }
    .section-pill { background: #f1f5f9; padding: 5px 12px; border-radius: 8px; font-size: 0.7rem; font-weight: 800; color: #475569; text-transform: uppercase; }
    .btn-review { background: #0f172a; color: white; border: none; padding: 10px 20px; border-radius: 10px; font-weight: 700; font-size: 0.8rem; cursor: pointer; transition: 0.2s; }
    .btn-review:hover { background: var(--shaktiman-orange); transform: scale(1.05); }
    .btn-review.secondary { background: #475569; }

    .status-indicator { font-weight: 800; font-size: 0.8rem; text-transform: uppercase; }
    .status-indicator.approved { color: #10b981; }
    .status-indicator.rejected { color: #ef4444; }
    .status-indicator.pending { color: #64748b; }

    .overlay-blur { position: fixed; inset: 0; background: rgba(15, 23, 42, 0.7); backdrop-filter: blur(8px); display: grid; place-items: center; z-index: 2000; padding: 20px; }
    .decision-modal-white { background: #fff; width: 100%; max-width: 950px; border-radius: 24px; overflow: hidden; box-shadow: 0 30px 60px rgba(0,0,0,0.4); }
    .modal-top { padding: 25px 35px; border-bottom: 1px solid #f1f5f9; display: flex; justify-content: space-between; align-items: center; background: #fafafa; }
    .modal-top h3 { margin: 0; font-size: 1.2rem; font-weight: 900; color: #0f172a; }
    .modal-content-area { max-height: 80vh; overflow-y: auto; padding: 35px; }
    .manager-details-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px; background: #f8fafc; padding: 25px; border-radius: 16px; border: 1px solid #e2e8f0; }
    .details-full { grid-column: span 2; background: #fff; padding: 15px; border-radius: 10px; border: 1px solid #e2e8f0; margin-top: 10px; font-size: 0.9rem; }
    .comparison-chamber { display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-bottom: 35px; }
    .chamber-box { position: relative; border-radius: 16px; overflow: hidden; box-shadow: 0 10px 20px rgba(0,0,0,0.1); background: #000; display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 320px; }
    .no-img-placeholder { display: flex; align-items: center; justify-content: center; width: 100%; height: 320px; background: #1e293b; color: #475569; font-size: 0.9rem; font-style: italic; }
    .img-badge { position: absolute; top: 15px; left: 15px; padding: 6px 15px; border-radius: 6px; font-size: 0.7rem; font-weight: 900; color: #fff; letter-spacing: 1px; z-index: 1; }
    .img-badge.red { background: #ef4444; } .img-badge.green { background: #10b981; }
    .judgement-footer label { display: block; font-size: 0.85rem; font-weight: 800; margin-bottom: 12px; color: #475569; }
    textarea { width: 100%; height: 110px; border: 2px solid #f1f5f9; border-radius: 12px; padding: 20px; font-family: inherit; font-size: 0.95rem; background: #f8fafc; resize: none; transition: 0.3s; box-sizing: border-box; }
    textarea:focus { border-color: var(--shaktiman-orange); background: #fff; outline: none; }
    .btn-group { display: flex; gap: 20px; margin-top: 25px; }
    .btn-endorse { flex: 2; background: #10b981; color: #fff; border: none; padding: 18px; border-radius: 12px; font-weight: 900; font-size: 0.9rem; cursor: pointer; transition: 0.3s; }
    .btn-decline { flex: 1; background: #fff; border: 2px solid #ef4444; color: #ef4444; padding: 18px; border-radius: 12px; font-weight: 900; cursor: pointer; }
    .btn-endorse:hover { background: #059669; transform: translateY(-2px); }
    .x-close { background: none; border: none; font-size: 2.5rem; cursor: pointer; color: #94a3b8; line-height: 1; }

    .empty-notif, .empty-msg { padding: 40px; text-align: center; color: #94a3b8; font-style: italic; }
    .empty-notif-big { padding: 60px; text-align: center; }
    .empty-notif-big .icon { font-size: 3.5rem; display: block; margin-bottom: 15px; }
    .empty-notif-big p { color: #64748b; font-weight: 600; }
  `]
})
export class HodDashboardComponent implements OnInit {
  plantId: string = '';
  currentView: string = 'dashboard';
  isSidebarClosed: boolean = false;
  kaizens: any[] = [];
  selectedKaizen: any = null;
  counts = { op: 0, sup: 0, man: 0, pending: 0 };
  impactData: any = { Productivity: 0, Quality: 0, Cost: 0, Delivery: 0, Safety: 0, Morale: 0 };
  impactTotal: number = 0;
  private isLoading: boolean = false;

  constructor(private http: HttpClient, private cdr: ChangeDetectorRef, private router: Router, private ngZone: NgZone) {}

  ngOnInit() {
    const plant = sessionStorage.getItem('plant_id');
    this.plantId = plant ? plant.replace('-', ' ') : 'Unit 1';
    this.loadData();
  }

  // ── FIX: openKaizen now correctly merges detail over list data ─────────
  openKaizen(k: any) {
    // Show modal immediately with whatever data we have
    this.selectedKaizen = { ...k };
    this.cdr.detectChanges();

    const role = k.role_type || 'Manager';
    this.http.get<any>(
      `http://localhost:8080/api/kaizen/detail?id=${k.id}&role=${role}`
    ).subscribe({
      next: (detail) => {
        // detail has full images; spread detail LAST so its values win over null from list
        this.selectedKaizen = { ...k, ...detail };
        this.cdr.detectChanges();
      },
      error: () => {
        // Modal stays open with the list data even if detail fails
      }
    });
  }

  loadData() {
    if (this.isLoading) return;
    this.isLoading = true;

    const url = `http://localhost:8080/api/kaizen?plant_id=${encodeURIComponent(this.plantId)}`;
    this.http.get(url).subscribe({
      next: (res: any) => {
        if (!res) { this.isLoading = false; return; }
        this.kaizens = res.list || [];
        this.counts = res.counts ? { ...res.counts } : { op: 0, sup: 0, man: 0, pending: 0 };
        if (res.impact) {
          this.impactData = { ...res.impact };
          this.impactTotal = Object.values(res.impact)
            .reduce((a: any, b: any) => Number(a) + Number(b), 0) as number;
        } else {
          this.impactTotal = 0;
        }
        this.isLoading = false;
        this.cdr.markForCheck();
        this.cdr.detectChanges();
      },
      error: () => { this.isLoading = false; }
    });
  }

  getPendingList() {
    return this.kaizens.filter(k =>
      !k.hod_status || k.hod_status === 'Pending'
    );
  }

  // ── FIX: unified safe image helper ────────────────────────────────────
  safeImgSrc(imgData: any): string | null {
    if (!imgData) return null;
    const str = String(imgData).trim();
    if (!str) return null;
    // Already a full URL (backend now returns full URL)
    if (str.startsWith('http://') || str.startsWith('https://')) return str;
    // Already a data URI
    if (str.startsWith('data:')) return str;
    // Raw filename fallback
    if (str.includes('.jpg') || str.includes('.png') || str.includes('.jpeg') || str.includes('.gif') || str.includes('.webp')) {
      return 'http://localhost/kaizen-backend/uploads/' + str;
    }
    // Long base64 string
    if (str.length > 100) return 'data:image/jpeg;base64,' + str;
    return null;
  }

  getW(key: string): number {
    if (this.impactTotal === 0 || !this.impactData[key]) return 0;
    return (Number(this.impactData[key]) / this.impactTotal) * 100;
  }

  // ── FIX: process() now checks res.status === 'success' not 'updated' ──
  process(k: any, status: string, remark: string) {
    if (!remark) {
      alert("Feedback Required for modification trail");
      return;
    }
    this.http.post('http://localhost:8080/api/kaizen/update', {
      id: k.id,
      action: status,
      hod_remarks: remark,
      role_type: k.role_type
    }).subscribe({
      next: (res: any) => {
        if (res && res.error) {
          alert("Error: " + res.error);
        } else {
          alert(`Action Modified for ${k.kaizen_id} to ${status}`);
          this.selectedKaizen = null;
          this.loadData();   // refresh table so status updates immediately
        }
      },
      error: () => alert("Modification Failed.")
    });
  }

  logout() {
    sessionStorage.clear();
    this.router.navigate(['/admin-login']);
  }
}