import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, HttpClientModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  // Login
  userId   = '';
  password = '';
  liveTime = '';
  showPwd  = false;

  // Forgot password flow
  // step: 'login' | 'enter-id' | 'enter-otp' | 'new-password' | 'done'
  step          = 'login';
  forgotUserId  = '';
  maskedEmail   = '';
  devOtp        = '';  // only shown when SMTP not configured
  otp           = '';
  otpError      = '';
  newPassword   = '';
  confirmPwd    = '';
  pwdError      = '';
  forgotError   = '';
  isLoading     = false;

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit() {
    this.updateTime();
    setInterval(() => this.updateTime(), 1000);
  }

  updateTime() {
    this.liveTime = new Date().toLocaleTimeString('en-IN', {
      timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', second: '2-digit'
    });
  }

  onLogin(event: Event) {
    event.preventDefault();
    const loginData = { user_id: this.userId, password: this.password };
    this.http.post('http://localhost:8080/api/auth/login', loginData).subscribe({
      next: (response: any) => {
        if (response.status === 'success') {
          const user = response.user;
          sessionStorage.setItem('emp_id',   user.user_id);
          sessionStorage.setItem('role',     user.role);
          sessionStorage.setItem('plant_id', user.plant_id || user.plant || '');
          sessionStorage.setItem('section',  user.section || '');
          localStorage.setItem('user', JSON.stringify(user));
          this.router.navigate(['/dashboard']);
        } else {
          alert(response.message);
        }
      },
      error: () => alert('Connection Error. Make sure Spring Boot is running on port 8080.')
    });
  }

  // Step 1 — request OTP
  sendOtp() {
    this.forgotError = '';
    if (!this.forgotUserId.trim()) {
      this.forgotError = 'Please enter your User ID'; return;
    }
    this.isLoading = true;
    this.http.post<any>('http://localhost:8080/api/auth/forgot-password',
      { user_id: this.forgotUserId }).subscribe({
      next: (res) => {
        this.isLoading = false;
        if (res.status === 'success') {
          this.maskedEmail = res.masked_email;
          this.devOtp      = res.dev_otp || ''; // shown only when SMTP not ready
          this.step        = 'enter-otp';
        } else {
          this.forgotError = res.message;
        }
      },
      error: () => { this.isLoading = false; this.forgotError = 'Connection error.'; }
    });
  }

  // Step 2 — verify OTP
  verifyOtp() {
    this.otpError = '';
    if (!this.otp.trim()) {
      this.otpError = 'Please enter the OTP'; return;
    }
    this.isLoading = true;
    this.http.post<any>('http://localhost:8080/api/auth/verify-otp',
      { user_id: this.forgotUserId, otp: this.otp }).subscribe({
      next: (res) => {
        this.isLoading = false;
        if (res.status === 'success') {
          this.step = 'new-password';
        } else {
          this.otpError = res.message;
        }
      },
      error: () => { this.isLoading = false; this.otpError = 'Connection error.'; }
    });
  }

  // Step 3 — set new password
  setNewPassword() {
    this.pwdError = '';
    if (!this.newPassword || !this.confirmPwd) {
      this.pwdError = 'Please fill all fields'; return;
    }
    if (this.newPassword !== this.confirmPwd) {
      this.pwdError = 'Passwords do not match'; return;
    }
    // Validate password policy
    const letters = (this.newPassword.match(/[a-zA-Z]/g) || []).length;
    const numbers = (this.newPassword.match(/[0-9]/g) || []).length;
    const special = (this.newPassword.match(/[^a-zA-Z0-9]/g) || []).length;
    if (letters < 6 || numbers < 1 || special < 1) {
      this.pwdError = 'Password must have min 6 letters, 1 number, 1 special character'; return;
    }
    this.isLoading = true;
    this.http.post<any>('http://localhost:8080/api/auth/set-new-password', {
      user_id:      this.forgotUserId,
      new_password: this.newPassword
    }).subscribe({
      next: (res) => {
        this.isLoading = false;
        if (res.status === 'success') {
          this.step = 'done';
        } else {
          this.pwdError = res.message;
        }
      },
      error: () => { this.isLoading = false; this.pwdError = 'Connection error.'; }
    });
  }

  resetForgot() {
    this.step = 'login';
    this.forgotUserId = ''; this.maskedEmail = ''; this.devOtp = '';
    this.otp = ''; this.otpError = ''; this.newPassword = '';
    this.confirmPwd = ''; this.pwdError = ''; this.forgotError = '';
  }
}