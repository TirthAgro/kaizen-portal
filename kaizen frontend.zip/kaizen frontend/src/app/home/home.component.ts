import { Component, OnInit, OnDestroy, ViewEncapsulation } from '@angular/core';

import { RouterLink } from '@angular/router';

import { CommonModule } from '@angular/common';


@Component({

  selector: 'app-home',

  standalone: true,

  imports: [RouterLink, CommonModule],

  templateUrl: './home.component.html',

  styleUrls: ['./home.component.css'],

  // This allows your CSS to behave exactly like it did in your old HTML file

  encapsulation: ViewEncapsulation.None

})

export class HomeComponent implements OnInit, OnDestroy {

  menuLeft = '-280px';

  modalVisible = false;

  modalTitle = '';

  modalBody = '';

  liveTime = '';

  timeInterval: any;


  kaizenData: any = {

    "Restorative": "Restorative Kaizen is defined as an improvement effort aimed at restoring a machine or process...",

    "Renovative": "Renovative Kaizen is a type of Kaizen that focuses on making significant improvements...",

    "Innovative": "Innovative Kaizen focuses on making significant and creative improvements...",

    "Breakthrough": "Breakthrough Kaizen (Kaikaku) is a radical approach focusing on revolutionary change."

  };


  ngOnInit() {

    this.hidePreloader();

    this.updateTime();

    this.timeInterval = setInterval(() => this.updateTime(), 1000);

  }


  ngOnDestroy() {

    if (this.timeInterval) clearInterval(this.timeInterval);

  }


  hidePreloader() {

    setTimeout(() => {

      const preloader = document.getElementById("preloader");

      if (preloader) {

        preloader.style.opacity = "0";

        setTimeout(() => preloader.style.display = "none", 500);

      }

    }, 1000);

  }


  openMenu() { this.menuLeft = '0px'; }

  closeMenu() { this.menuLeft = '-280px'; this.modalVisible = false; }


  showKaizenInfo(type: string) {

    this.modalTitle = type + " Kaizen";

    this.modalBody = this.kaizenData[type];

    this.modalVisible = true;

  }


  closeModal() { this.modalVisible = false; }


  updateTime() {

    this.liveTime = new Date().toLocaleTimeString('en-IN', {

      timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', second: '2-digit'

    });

  }

}