import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';

import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx-js-style';

@Component({
  selector: 'app-download-report',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, HttpClientModule],
  encapsulation: ViewEncapsulation.None,
  template: `
<div class="report-container-fluid">
    <div class="report-header-flex">
        <div class="title-area">
            <h1 class="main-title">Master Analytics & Reports</h1>
            <p class="sub-title">Filter, view, and export Kaizen records across all units</p>
        </div>
        <div class="stats-card">
            <span class="stats-label">RECORDS FOUND</span>
            <span class="stats-count">{{ filteredData.length }}</span>
        </div>
    </div>

    <div class="filter-card-premium">
        <div class="filter-row">
            <div class="filter-group grow-2">
                <label>Global Search</label>
                <input type="text" [(ngModel)]="filters.search" (input)="fetchReportData()"
                       placeholder="Search Kaizen No, Theme, Section...">
            </div>
            <div class="filter-group grow-1">
                <label>Created From</label>
                <input type="date" [(ngModel)]="filters.fromDate" (change)="fetchReportData()">
            </div>
            <div class="filter-group grow-1">
                <label>Created From</label>
                <input type="date" [(ngModel)]="filters.toDate" (change)="fetchReportData()">
            </div>
        </div>

        <div class="filter-row mt-20">
            <div class="filter-group grow-1">
                <label>Unit Filter</label>
                <select [(ngModel)]="filters.unit" (change)="fetchReportData()">
                    <option [value]="''">All Units</option>
                    <option *ngFor="let u of units" [value]="u">{{u}}</option>
                </select>
            </div>
            <div class="filter-group grow-1">
                <label>Role Filter</label>
                <select [(ngModel)]="filters.role" (change)="fetchReportData()">
                    <option [value]="''">All Roles</option>
                    <option value="Operator">Operator</option>
                    <option value="Supervisor">Supervisor</option>
                    <option value="Manager">Manager</option>
                </select>
            </div>
            <div class="filter-group grow-1">
                <label>Status Filter</label>
                <select [(ngModel)]="filters.status" (change)="fetchReportData()">
                    <option value="">All Status</option>
                    <option value="Approved">Approved</option>
                    <option value="Pending">Pending</option>
                    <option value="Rejected">Rejected</option>
                </select>
            </div>
            <div class="filter-actions-group">
                <button (click)="exportExcel()" [disabled]="filteredData.length === 0" class="btn-exp excel">
                    <span>📗 EXCEL</span>
                </button>
                <button (click)="exportPDF()" [disabled]="filteredData.length === 0" class="btn-exp pdf">
                    <span>📕 PDF</span>
                </button>
            </div>
        </div>

        <div class="table-frame">
            <table class="premium-table">
                <thead>
                    <tr>
                        <th>Kaizen No</th>
                        <th>Role</th>
                        <th>Theme</th>
                        <th>Unit</th>
                        <th>Section</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr *ngFor="let row of filteredData" (click)="viewKaizen(row)">
                        <td><b class="k-code">{{ row.kaizen_id }}</b></td>
                        <td><span class="role-pill">{{ row.role }}</span></td>
                        <td class="theme-cell">{{ row.theme }}</td>
                        <td>{{ row.unit }}</td>
                        <td>{{ row.section || '-' }}</td>
                        <td>
                            <span class="status-pill" [ngClass]="getStatusClass(row.status)">
                                {{ row.status || 'Pending' }}
                            </span>
                        </td>
                    </tr>
                    <tr *ngIf="filteredData.length === 0">
                        <td colspan="6" class="empty-msg">No records found matching your criteria.</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
  `,
  styles: [`
    .report-container-fluid { animation: fadeIn 0.4s ease-out; width: 100%; }
    .report-header-flex {
        display: flex; justify-content: space-between; align-items: center;
        margin-bottom: 30px; padding-bottom: 20px; border-bottom: 2px solid #e2e8f0;
    }
    .main-title { font-family: 'Orbitron', sans-serif; font-size: 1.8rem; color: #0f172a; margin: 0; letter-spacing: 1px; }
    .sub-title { color: #64748b; margin: 5px 0 0 0; font-size: 0.95rem; }
    .stats-card {
        background: white; padding: 12px 25px; border-radius: 15px; text-align: center;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05); border: 1px solid #f1f5f9;
    }
    .stats-label { display: block; font-size: 10px; font-weight: 800; color: #94a3b8; letter-spacing: 1px; }
    .stats-count { font-size: 1.5rem; font-weight: 900; color: #ff6a00; }
    .filter-card-premium { background: white; border-radius: 20px; padding: 30px; box-shadow: 0 10px 40px rgba(0,0,0,0.03); }
    .filter-row { display: flex; gap: 20px; flex-wrap: wrap; align-items: flex-end; }
    .mt-20 { margin-top: 20px; }
    .grow-1 { flex: 1; min-width: 150px; }
    .grow-2 { flex: 2; min-width: 250px; }
    .filter-group label { display: block; font-size: 11px; font-weight: 700; color: #475569; margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.5px; }
    .filter-group input, .filter-group select {
        width: 100%; padding: 12px 15px; border: 1px solid #e2e8f0; border-radius: 10px;
        background: #f8fafc; font-size: 14px; transition: 0.3s;
    }
    .filter-group input:focus { border-color: #ff6a00; background: white; outline: none; box-shadow: 0 0 0 4px rgba(255,106,0,0.1); }
    .filter-actions-group { display: flex; gap: 12px; }
    .btn-exp {
        border: none; padding: 12px 25px; border-radius: 10px; color: white;
        font-weight: 700; font-size: 12px; cursor: pointer; transition: 0.3s;
        display: flex; align-items: center; gap: 8px;
    }
    .btn-exp.excel { background: #10b981; }
    .btn-exp.pdf { background: #ef4444; }
    .btn-exp:hover:not(:disabled) { transform: translateY(-3px); box-shadow: 0 8px 20px rgba(0,0,0,0.1); }
    .btn-exp:disabled { opacity: 0.3; cursor: not-allowed; }
    .table-frame { margin-top: 30px; border-radius: 12px; overflow: hidden; border: 1px solid #f1f5f9; }
    .premium-table { width: 100%; border-collapse: collapse; background: white; }
    .premium-table th { background: #f8fafc; padding: 15px 20px; text-align: left; font-size: 11px; color: #64748b; text-transform: uppercase; border-bottom: 2px solid #f1f5f9; }
    .premium-table td { padding: 15px 20px; border-bottom: 1px solid #f1f5f9; font-size: 14px; color: #334155; }
    .premium-table tr:hover { background: #fffaf0; cursor: pointer; }
    .k-code { color: #ff6a00; font-family: 'Orbitron', sans-serif; font-size: 13px; }
    .role-pill { background: #f1f5f9; padding: 4px 10px; border-radius: 6px; font-size: 11px; font-weight: 600; color: #475569; }
    .theme-cell { font-weight: 600; color: #0f172a; }
    .status-pill { padding: 5px 12px; border-radius: 50px; font-size: 10px; font-weight: 800; text-transform: uppercase; }
    .status-approved { background: #dcfce7; color: #166534; }
    .status-rejected { background: #fee2e2; color: #991b1b; }
    .status-pending { background: #fef9c3; color: #854d0e; }
    .empty-msg { text-align: center; padding: 60px !important; color: #94a3b8; font-style: italic; }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
  `]
})
export class DownloadReportComponent implements OnInit {
  api = 'http://localhost:8080/api/bex';
  units = ['Unit 1', 'Unit 2', 'Unit 3', 'Unit 4', 'Unit 5'];
  filteredData: any[] = [];

  filters = {
    search: '',
    unit: '',
    role: '',
    status: '',
    fromDate: '',
    toDate: ''
  };

  constructor(
    private http: HttpClient,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.fetchReportData();
  }

  fetchReportData() {
    const params = new URLSearchParams({
      action: 'master_list',
      unit: this.filters.unit,
      role: this.filters.role,
      status: this.filters.status,
      search: this.filters.search,
      from: this.filters.fromDate,
      to: this.filters.toDate
    });

    this.http.get<any[]>(`${this.api}?${params.toString()}`).subscribe({
      next: (res) => {
        this.filteredData = res;
        this.cdr.detectChanges();
      },
      error: (err) => {}
    });
  }

  viewKaizen(row: any) {
    let type = '';
    const role = (row.role || '').toLowerCase();
    if (role === 'operator') type = 'operator_kaizen';
    else if (role === 'supervisor') type = 'supervisor_kaizen';
    else if (role === 'manager') type = 'manager_kaizen';

    this.router.navigate(['/glob-kaizen'], {
      queryParams: { id: row.id, type: type }
    });
  }

  getStatusClass(status: string): string {
    if (status === 'Approved') return 'status-approved';
    if (status === 'Rejected') return 'status-rejected';
    return 'status-pending';
  }

  // ─────────────────────────────────────────────────────────────
  // EXCEL EXPORT — matches SHAKTIMAN KAIZEN Registration format
  // ─────────────────────────────────────────────────────────────
  exportExcel() {
    const wb = XLSX.utils.book_new();
    const ws: any = {};

    // ── Styles ──────────────────────────────────────────────────
    const titleStyle = {
      font: { bold: true, sz: 16, color: { rgb: '000000' } },
      alignment: { horizontal: 'center', vertical: 'center', wrapText: true }
    };

    const formatStyle = {
      font: { sz: 9 },
      alignment: { horizontal: 'left', vertical: 'center', wrapText: true }
    };

    const headerStyle = {
      font: { bold: true, sz: 9, color: { rgb: '000000' } },
      fill: { fgColor: { rgb: 'F2F2F2' } },
      alignment: { horizontal: 'center', vertical: 'center', wrapText: true },
      border: {
        top:    { style: 'thin', color: { rgb: '000000' } },
        bottom: { style: 'thin', color: { rgb: '000000' } },
        left:   { style: 'thin', color: { rgb: '000000' } },
        right:  { style: 'thin', color: { rgb: '000000' } }
      }
    };

    const dataStyle = {
      font: { sz: 9 },
      alignment: { horizontal: 'center', vertical: 'center', wrapText: true },
      border: {
        top:    { style: 'thin', color: { rgb: 'CCCCCC' } },
        bottom: { style: 'thin', color: { rgb: 'CCCCCC' } },
        left:   { style: 'thin', color: { rgb: 'CCCCCC' } },
        right:  { style: 'thin', color: { rgb: 'CCCCCC' } }
      }
    };

    const dataLeftStyle = {
      ...dataStyle,
      alignment: { horizontal: 'left', vertical: 'center', wrapText: true }
    };

    // ── Helper ──────────────────────────────────────────────────
    const C = (v: any, t: string, s: any) => ({ v, t, s });

    // ── Column widths (A to Q) ───────────────────────────────────
    ws['!cols'] = [
      { wch: 5  },  // A - Sr No
      { wch: 9  },  // B - Month/Year
      { wch: 12 },  // C - Business Unit
      { wch: 14 },  // D - Deptt./Section
      { wch: 32 },  // E - KAIZEN THEME
      { wch: 20 },  // F - Kaizen Type
      { wch: 20 },  // G - Kaizen Category
      { wch: 12 },  // H - Category Code
      { wch: 12 },  // I - Group PQCDSME-5S
      { wch: 28 },  // J - Advantage Description
      { wch: 26 },  // K - KMI
      { wch: 26 },  // L - KPI
      { wch: 30 },  // M - Kaizen Performed by
      { wch: 8  },  // N - Count
      { wch: 18 },  // O - Certified by
      { wch: 28 },  // P - CFT Verification
      { wch: 18 },  // Q - Approved by
    ];

    // ── Row heights ─────────────────────────────────────────────
    ws['!rows'] = [
      { hpt: 45 },  // Row 1 - Title row
      { hpt: 80 },  // Row 2 - Header row
    ];

    // ── Merges ──────────────────────────────────────────────────
    ws['!merges'] = [
      { s: { r: 0, c: 0  }, e: { r: 0, c: 1  } },  // A1:B1  - logo
      { s: { r: 0, c: 2  }, e: { r: 0, c: 12 } },  // C1:M1  - title
      { s: { r: 0, c: 13 }, e: { r: 0, c: 16 } },  // N1:Q1  - format no
    ];

    // ── Row 1: Header bar ────────────────────────────────────────
    ws['A1'] = C('SHAKTIMAN', 's', {
      font: { bold: true, sz: 10, color: { rgb: 'FF6A00' } },
      alignment: { horizontal: 'center', vertical: 'center' }
    });
    ws['C1'] = C('KAIZEN Registration', 's', titleStyle);
    ws['N1'] = C('Format No. : TA/QMS/KR\nRevision : 00   04.04.2026', 's', formatStyle);

    // ── Row 2: Column headers ────────────────────────────────────
    const headers: [string, string][] = [
      ['A2', 'Sr\nNo'],
      ['B2', 'Month\n/\nYear'],
      ['C2', 'Business\nUnit'],
      ['D2', 'Deptt. /\nSection'],
      ['E2', 'KAIZEN THEME'],
      ['F2', 'Kaizen Type\nRestorative /\nRenovative /\nInnovative /\nBreakthrough /\nRoutine'],
      ['G2', 'Kaizen Category\nSee at Sheet NO. 2'],
      ['H2', 'Category\ncode\nSee at Sheet\nNO. 2'],
      ['I2', 'Group\nPQCDSME\n- 5S'],
      ['J2', 'Advantage description\nPQCDSME – 5S\n(Measurable Achievement)'],
      ['K2', 'KMI\n(Update relavant KMI\nExclusively for Best\nKaizens)'],
      ['L2', 'KPI\n(Update relavant KPI\nExclusively for\nBest Kaizens)'],
      ['M2', 'Kaizen\nPerformed\nby'],
      ['N2', 'Count'],
      ['O2', 'Certified by\nProcess\nOwner'],
      ['P2', 'CFT Verification\n(applicable in case\nof Critical change\nrelated to\nProcess / Product)'],
      ['Q2', 'Approved by\nHOD / BU\nHead'],
    ];

    headers.forEach(([addr, val]) => {
      ws[addr] = C(val, 's', headerStyle);
    });

    // ── Data rows (starting at row 3) ────────────────────────────
    const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

    this.filteredData.forEach((row, i) => {
      const r = i + 3;
      const dateObj = new Date(row.created_at);
      const monthYear = isNaN(dateObj.getTime())
        ? ''
        : `${months[dateObj.getMonth()]} / ${dateObj.getFullYear()}`;

      // ── Compute performed_by BEFORE the cols array ──────────────
      const perfFormatted: string = row.performed_by || row.emp_name || '';

      const cols: [string, any, string][] = [
        [`A${r}`, i + 1,                        'n'],
        [`B${r}`, monthYear,                    's'],
        [`C${r}`, row.unit || '',               's'],
        [`D${r}`, row.section || '',            's'],
        [`E${r}`, row.theme || '',              's'],
        [`F${r}`, row.kaizen_type || '',        's'],
        [`G${r}`, row.kaizen_category || '',    's'],
        [`H${r}`, row.category_code || '',      's'],
        [`I${r}`, row.pqcdsm || '',             's'],
        [`J${r}`, row.advantage_desc || '',     's'],
        [`K${r}`, row.kmi || '',                's'],
        [`L${r}`, row.kpi || '',                's'],
        [`M${r}`, perfFormatted,                's'],
        [`N${r}`, row.emp_count ?? 0,           'n'],
        [`O${r}`, row.certified_by || '',       's'],
        [`P${r}`, row.cft_verification || '',   's'],
        [`Q${r}`, row.approved_by || '',        's'],
      ];

      cols.forEach(([addr, val, type]) => {
        const style = (addr.startsWith('E') || addr.startsWith('J') || addr.startsWith('M'))
          ? dataLeftStyle
          : dataStyle;
        ws[addr] = C(val, type, style);
      });

      if (!ws['!rows']) ws['!rows'] = [];
      ws['!rows'][r - 1] = { hpt: Math.max(25, perfFormatted.split('\n').length * 15) };  
    });

    // ── Sheet range ──────────────────────────────────────────────
    const lastRow = Math.max(this.filteredData.length + 2, 2);
    ws['!ref'] = `A1:Q${lastRow}`;

    XLSX.utils.book_append_sheet(wb, ws, 'Kaizen Registration');
    XLSX.writeFile(wb, `Kaizen_Registration_${new Date().getTime()}.xlsx`);
  }

  // ─────────────────────────────────────────────────────────────
  // PDF EXPORT
  // ─────────────────────────────────────────────────────────────
  exportPDF() {
    const doc: any = new jsPDF('l', 'mm', 'a4');
    const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text('KAIZEN Registration', 148, 12, { align: 'center' });

    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text('Format No. : TA/QMS/KR  |  Revision : 00   04.04.2026', 270, 10, { align: 'right' });

    const headers = [[
      'Sr\nNo', 'Month/\nYear', 'Unit', 'Section', 'KAIZEN THEME',
      'Kaizen\nType', 'Category', 'Cat.\nCode', 'Group\nPQCDSME',
      'Advantage\nDesc.', 'KMI', 'KPI',
      'Performed\nby', 'Count', 'Certified\nby', 'CFT\nVerify', 'Approved\nby'
    ]];

    const body = this.filteredData.map((row, i) => {
      const dateObj = new Date(row.created_at);
      const monthYear = isNaN(dateObj.getTime())
        ? ''
        : `${months[dateObj.getMonth()]}/${dateObj.getFullYear()}`;

      const perfFormatted: string = row.performed_by || row.emp_name || '';
      const perfParts = perfFormatted.split('\n').filter((s: string) => s.length > 0);

      return [
        i + 1,
        monthYear,
        row.unit || '',
        row.section || '',
        (row.theme || '').substring(0, 35),
        row.kaizen_type || '',
        row.kaizen_category || '',
        row.category_code || '',
        row.pqcdsm || '',
        (row.advantage_desc || '').substring(0, 20),
        row.kmi || '',
        row.kpi || '',
        perfFormatted,
        row.emp_count ?? 0,
        row.certified_by || '',
        row.cft_verification || '',
        row.approved_by || ''
      ];
    });

    (doc as any).autoTable({
      head: headers,
      body: body,
      startY: 18,
      theme: 'grid',
      styles: { fontSize: 7, cellPadding: 2, valign: 'middle', halign: 'center' },
      headStyles: { fillColor: [242, 242, 242], textColor: [0, 0, 0], fontStyle: 'bold', fontSize: 7 },
      columnStyles: {
        0:  { cellWidth: 8  },
        1:  { cellWidth: 13 },
        2:  { cellWidth: 13 },
        3:  { cellWidth: 13 },
        4:  { cellWidth: 28, halign: 'left' },
        5:  { cellWidth: 16 },
        6:  { cellWidth: 16 },
        7:  { cellWidth: 11 },
        8:  { cellWidth: 13 },
        9:  { cellWidth: 18, halign: 'left' },
        10: { cellWidth: 14 },
        11: { cellWidth: 14 },
        12: { cellWidth: 16, halign: 'left' },
        13: { cellWidth: 8  },
        14: { cellWidth: 14 },
        15: { cellWidth: 16 },
        16: { cellWidth: 14 }
      }
    });

    doc.save(`Kaizen_Registration_${new Date().getTime()}.pdf`);
  }
}