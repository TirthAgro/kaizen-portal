import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-glob-kaizen',
  standalone: true,
  // REMOVED BexLayoutComponent from imports because it's now the parent in routes
  imports: [CommonModule, HttpClientModule, FormsModule], 
  encapsulation: ViewEncapsulation.None,
  template: `
    <div class="high-end-card">
      
      <div class="header-section">
        <div class="title-group">
          <h1>🌍 Global Kaizen Repository</h1>
          <p>Business Excellence Management Portal</p>
        </div>
        <button class="refresh-btn" (click)="fetchAllKaizens()">
          <i class="fas fa-sync-alt"></i> Refresh Data
        </button>
      </div>

      <div class="filter-bar">
        <div class="filter-group">
          <label>Unit</label>
          <select [(ngModel)]="filters.unit" (change)="applyFilters()">
            <option value="">All Units</option>
            <option value="Unit 1">Unit 1</option>
            <option value="Unit 2">Unit 2</option>
            <option value="Unit 3">Unit 3</option>
            <option value="Unit 4">Unit 4</option>
            <option value="Unit 5">Unit 5</option>
          </select>
        </div>

        <div class="filter-group">
          <label>Role</label>
          <select [(ngModel)]="filters.role" (change)="applyFilters()">
            <option value="">All Roles</option>
            <option value="Operator">Operator</option>
            <option value="Supervisor">Supervisor</option>
            <option value="Manager">Manager</option>
          </select>
        </div>

        <div class="filter-group">
          <label>Status</label>
          <select [(ngModel)]="filters.status" (change)="applyFilters()">
            <option value="">All Status</option>
            <option value="Pending">Pending</option>
            <option value="Approved">Approved</option>
            <option value="Rejected">Rejected</option>
          </select>
        </div>

        <div class="filter-group search">
          <label>Search Theme / ID</label>
          <div style="display: flex; gap: 10px;">
            <input type="text" [(ngModel)]="filters.search" (input)="applyFilters()" placeholder="Type to search..." style="flex: 1;">
            <button class="clear-filters-btn" (click)="clearAllFilters()">Clear All</button>
          </div>
        </div>
      </div>

      <div *ngIf="isLoading" class="state-container">
        <div class="custom-loader"></div>
        <p class="animate-pulse">Accessing Secure Records...</p>
      </div>

      <div class="table-responsive" *ngIf="!isLoading && filteredKaizens.length > 0">
        <table class="modern-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Role</th>
              <th>Plant Unit</th>
              <th>Department</th>
              <th>Kaizen Theme</th>
              <th>Status</th>
              <th class="text-center">Action</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let k of filteredKaizens">
              <td><span class="id-text">{{ k.kaizen_id }}</span></td>
              <td><span [class]="'role-badge ' + k.role?.toLowerCase()">{{ k.role }}</span></td>
              <td>{{ k.unit }}</td>
              <td>{{ k.section }}</td>
              <td class="theme-cell" [title]="k.theme">{{ k.theme }}</td>
              <td><span [class]="'status-pill ' + k.status?.toLowerCase()">{{ k.status }}</span></td>
              <td class="text-center">
                <button class="audit-btn" (click)="openAudit(k)">Review Audit</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div *ngIf="!isLoading && filteredKaizens.length === 0" class="state-container">
          <p>No records match your filter criteria.</p>
      </div>
    </div>

    <div class="modal-overlay" *ngIf="showModal">
      <div class="modal-card">
        <div class="modal-header">
          <h3>Kaizen Master Audit: {{ selectedKaizen?.kaizen_id }}</h3>
          <button class="close-icon" (click)="showModal = false">&times;</button>
        </div>
        
        <div class="modal-body scrollable-modal">
          <div class="section-title">General Information</div>
          <div class="info-grid">
            <div class="info-item"><strong>Originator:</strong> {{ selectedKaizen?.emp_name }} ({{selectedKaizen?.emp_id}})</div>
            <div class="info-item"><strong>Plant/Unit:</strong> {{ selectedKaizen?.unit }}</div>
            <div class="info-item"><strong>Department:</strong> {{ selectedKaizen?.section }}</div>
            <div class="info-item"><strong>Machine No:</strong> {{ selectedKaizen?.machine_no || 'N/A' }}</div>
            <div class="info-item"><strong>Type:</strong> {{ selectedKaizen?.kaizen_type }}</div>
            <div class="info-item"><strong>Category:</strong> {{ selectedKaizen?.kaizen_category }}</div>
            <div class="info-item"><strong>PQCDSM:</strong> {{ selectedKaizen?.pqcdsm }}</div>
            <div class="info-item"><strong>Submission:</strong> {{ selectedKaizen?.created_at | date:'medium' }}</div>
          </div>

          <div class="section-title">Visual Evidence</div>
          <div class="image-container-grid">
            <div class="img-box">
  <label>Before Improvement</label>
  <div class="image-wrapper">
    <img *ngIf="safeImgSrc(selectedKaizen?.before_img)"
         [src]="safeImgSrc(selectedKaizen?.before_img)" alt="Before">
    <p *ngIf="!safeImgSrc(selectedKaizen?.before_img)">No Image Available</p>
  </div>
  <p class="img-desc">{{ selectedKaizen?.before_desc || 'No description provided.' }}</p>
</div>
<div class="img-box">
  <label>After Improvement</label>
  <div class="image-wrapper">
    <img *ngIf="safeImgSrc(selectedKaizen?.after_img)"
         [src]="safeImgSrc(selectedKaizen?.after_img)" alt="After">
    <p *ngIf="!safeImgSrc(selectedKaizen?.after_img)">No Image Available</p>
  </div>
  <p class="img-desc">{{ selectedKaizen?.after_desc || 'No description provided.' }}</p>
</div>
          </div>

          <div class="section-title">Kaizen Details</div>
          <div class="details-section">
            <label>Improvement Theme</label>
            <p>{{ selectedKaizen?.theme }}</p>
            
            <label>Problem Description / Idea</label>
            <p>{{ selectedKaizen?.idea || 'Refer to attachments for visual details.' }}</p>
            
            <div *ngIf="selectedKaizen?.role === 'Manager'">
               <label>Managerial Impact & Benefits (PQCDSM)</label>
               <p class="highlight-p">{{ selectedKaizen?.benefits_pqcdsm || 'Standard Managerial Improvement' }}</p>
            </div>
            
            <div *ngIf="selectedKaizen?.role === 'Supervisor'">
               <label>Root Cause Analysis</label>
               <p>{{ selectedKaizen?.root_cause || 'Process optimization focus.' }}</p>
            </div>

            <label>Horizontal Deployment</label>
            <p>{{ selectedKaizen?.horizantal_deployment || 'Not applicable' }}</p>
          </div>

          <div class="action-panel">
            <div class="section-title">Business Excellence Verdict</div>
            <label>Audit Remarks</label>
            <textarea [(ngModel)]="bexRemark" placeholder="Provide reason for approval or rejection..."></textarea>
            
            <div class="btn-group">
              <button class="btn-approve" (click)="updateStatus('Approved')">Authorize & Approve</button>
              <button class="btn-reject" (click)="updateStatus('Rejected')">Reject Kaizen</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    /* Styles remain exactly the same as your code */
    .high-end-card { background: white; border-radius: 16px; box-shadow: 0 10px 40px rgba(0,0,0,0.05); border: 1px solid #e2e8f0; overflow: hidden; margin-bottom: 20px; }
    .header-section { background: linear-gradient(to right, #1a2a6c, #b21f1f, #fdbb2d); padding: 30px; display: flex; justify-content: space-between; align-items: center; color: white; }
    .header-section h1 { margin: 0; font-size: 24px; font-weight: 700; }
    .filter-bar { display: flex; gap: 20px; padding: 20px 30px; background: #f8fafc; border-bottom: 1px solid #e2e8f0; flex-wrap: wrap; }
    .filter-group { display: flex; flex-direction: column; gap: 5px; }
    .filter-group label { font-size: 11px; font-weight: 700; color: #64748b; text-transform: uppercase; }
    .filter-group select, .filter-group input { padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 13px; outline: none; background: white; min-width: 150px; }
    .filter-group.search { flex-grow: 1; }
    .clear-filters-btn { background: #f1f5f9; border: 1px solid #cbd5e1; padding: 0 15px; border-radius: 6px; cursor: pointer; font-weight: 600; color: #475569; }
    .refresh-btn { background: rgba(255,255,255,0.2); border: 1px solid rgba(255,255,255,0.4); color: white; padding: 10px 20px; border-radius: 30px; cursor: pointer; font-weight: 600; transition: 0.3s; }
    .image-container-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px; }
    .img-box { background: #f8fafc; padding: 10px; border-radius: 8px; border: 1px solid #e2e8f0; }
    .img-box label { font-size: 11px; font-weight: 700; display: block; margin-bottom: 5px; color: #1a2a6c; }
   .image-wrapper { 
  height: 180px; 
  background: #000; 
  border-radius: 4px; 
  display: flex; 
  align-items: center; 
  justify-content: center; 
  overflow: hidden; 
}
.image-wrapper img { 
  width: 100%; 
  height: 100%; 
  object-fit: contain;
  background: #000;
}
    .img-desc { font-size: 12px; margin-top: 8px; color: #64748b; font-style: italic; }
    .table-responsive { padding: 10px 20px 30px; }
    .modern-table { width: 100%; border-collapse: collapse; }
    .modern-table th { text-align: left; padding: 15px; color: #64748b; font-size: 12px; text-transform: uppercase; border-bottom: 2px solid #f1f5f9; }
    .modern-table td { padding: 15px; border-bottom: 1px solid #f1f5f9; color: #1e293b; font-size: 14px; }
    .role-badge, .status-pill { display: inline-block; width: 100px; text-align: center; padding: 6px 0; border-radius: 6px; font-size: 11px; font-weight: 700; text-transform: uppercase; }
    .role-badge.operator { background: #e0f2fe; color: #0369a1; border: 1px solid #bae6fd; }
    .role-badge.supervisor { background: #fef3c7; color: #b45309; border: 1px solid #fde68a; }
    .role-badge.manager { background: #ede9fe; color: #6d28d9; border: 1px solid #ddd6fe; }
    .status-pill.approved { background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0; }
    .status-pill.pending { background: #f1f5f9; color: #475569; border: 1px solid #e2e8f0; }
    .status-pill.rejected { background: #fee2e2; color: #b91c1c; border: 1px solid #fecaca; }
    .audit-btn { background: #1e293b; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-weight: 600; transition: 0.2s; }
    .scrollable-modal { max-height: 70vh; overflow-y: auto; padding-right: 10px; }
    .scrollable-modal::-webkit-scrollbar { width: 6px; }
    .scrollable-modal::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
    .section-title { font-size: 12px; font-weight: 800; color: #1a2a6c; text-transform: uppercase; margin: 20px 0 10px; padding-bottom: 5px; border-bottom: 1px solid #e2e8f0; }
    .highlight-p { border-left: 4px solid #fdbb2d !important; background: #fffbeb !important; }
    .modal-overlay { position: fixed; top:0; left:0; width:100%; height:100%; background: rgba(15, 23, 42, 0.85); display: flex; align-items: center; justify-content: center; z-index: 2000; }
    .modal-card { background: white; width: 95%; max-width: 800px; border-radius: 16px; overflow: hidden; }
    .modal-header { background: #f8fafc; padding: 20px; display: flex; justify-content: space-between; }
    .modal-body { padding: 25px; }
    .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 15px; }
    .details-section p { background: #f8fafc; padding: 12px; border-radius: 8px; margin-bottom: 15px; border: 1px solid #f1f5f9; }
    .action-panel textarea { width: 100%; height: 80px; padding: 10px; border: 1px solid #cbd5e1; border-radius: 8px; margin-bottom: 15px; }
    .btn-group { display: flex; gap: 10px; }
    .btn-approve { flex: 1; background: #16a34a; color: white; border:none; padding: 14px; border-radius: 8px; font-weight: 700; cursor: pointer; }
    .btn-reject { flex: 1; background: #dc2626; color: white; border:none; padding: 14px; border-radius: 8px; font-weight: 700; cursor: pointer; }
    .custom-loader { border: 4px solid #f3f3f3; border-top: 4px solid #1a2a6c; border-radius: 50%; width: 40px; height: 40px; animation: spin 1s linear infinite; margin: 0 auto 20px; }
    @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    .state-container { padding: 60px; text-align: center; color: #64748b; }
  `]
})
export class GlobKaizenComponent implements OnInit {
  // Logic remains exactly as you had it
  apiBase = 'http://localhost:8080/api/bex';
  isLoading: boolean = true;
  allKaizens: any[] = [];
  filteredKaizens: any[] = [];
  
  filters = { unit: '', role: '', status: '', search: '' };
  showModal: boolean = false;
  selectedKaizen: any = null;
  bexRemark: string = '';

  constructor(private http: HttpClient, private cdr: ChangeDetectorRef) {}

  ngOnInit() { this.fetchAllKaizens(); }

  fetchAllKaizens() {
    this.isLoading = true;
    this.http.get<any[]>(`${this.apiBase}?action=master_list`).subscribe({
      next: (res) => {
        this.allKaizens = Array.isArray(res) ? res : [];
        this.applyFilters();
        this.isLoading = false;
        this.cdr.detectChanges();
      },
      error: () => { this.isLoading = false; this.cdr.detectChanges(); }
    });
  }

  applyFilters() {
    this.filteredKaizens = this.allKaizens.filter(k => {
      const matchUnit = !this.filters.unit || k.unit === this.filters.unit;
      const matchRole = !this.filters.role || k.role === this.filters.role;
      const matchStatus = !this.filters.status || k.status === this.filters.status;
      const matchSearch = !this.filters.search || 
                          k.theme?.toLowerCase().includes(this.filters.search.toLowerCase()) ||
                          k.kaizen_id?.toLowerCase().includes(this.filters.search.toLowerCase());
      return matchUnit && matchRole && matchStatus && matchSearch;
    });
  }

  clearAllFilters() {
    this.filters = { unit: '', role: '', status: '', search: '' };
    this.applyFilters();
  }

  safeImgSrc(imgData: any): string | null {
  if (!imgData) return null;
  const str = String(imgData).trim();
  if (!str) return null;
  if (str.startsWith('http://') || str.startsWith('https://')) return str;
  if (str.startsWith('data:')) return str;
  if (str.includes('.jpg') || str.includes('.png') || str.includes('.jpeg') || str.includes('.gif') || str.includes('.webp')) {
    return 'http://localhost/kaizen-backend/uploads/' + str;
  }
  if (str.length > 100) return 'data:image/jpeg;base64,' + str;
  return null;
}

  openAudit(kaizen: any) {
    this.selectedKaizen = kaizen;
    this.bexRemark = kaizen.admin_remark || '';
    this.showModal = true;
  }

  updateStatus(newStatus: string) {
    if (!this.bexRemark && newStatus === 'Rejected') {
      alert("Please provide a remark for rejection.");
      return;
    }
    const payload = {
      id: this.selectedKaizen.id,
      role: this.selectedKaizen.role,
      status: newStatus,
      remark: this.bexRemark
    };
    this.http.post(`${this.apiBase}/final-update`, payload).subscribe({
      next: (res: any) => {
        if (res.status === 'updated') {
          alert(`Kaizen ${this.selectedKaizen.kaizen_id} has been ${newStatus} successfully.`);
          this.showModal = false;
          this.fetchAllKaizens();
        } else {
          alert("Update failed: " + (res.message || "Unknown error"));
        }
      },
      error: (err) => { alert("Server error during update."); }
    });
  }
}