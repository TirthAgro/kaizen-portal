import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-manage-users',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, HttpClientModule],
  template: `
    <div class="content-wrapper">
        <div class="form-container">
            <h5 class="mb-4">{{ editMode ? 'Modify User' : 'Enroll New User' }}</h5>
            <form (ngSubmit)="saveUser()">
                <div class="form-group">
                    <label>User ID</label>
                    <input type="text" [(ngModel)]="form.user_id" name="user_id" required class="form-control">
                </div>
                <div class="form-group">
                    <label>Password <span class="req">*</span></label>
                    <input type="text" 
                           [(ngModel)]="form.password" 
                           name="password" 
                           required 
                           class="form-control"
                           (input)="validatePassword(form.password)"
                           placeholder="Min 6 letters, 1 number, 1 special char">

                    <!-- Password strength indicator -->
                    <div class="pwd-rules" *ngIf="form.password">
                      <div class="pwd-rule" [class.pass]="(form.password.match(/[a-zA-Z]/g)||[]).length >= 6">
                        <span class="rule-icon">{{ (form.password.match(/[a-zA-Z]/g)||[]).length >= 6 ? '✓' : '✗' }}</span>
                        Minimum 6 alphabets ({{(form.password.match(/[a-zA-Z]/g)||[]).length}}/6)
                      </div>
                      <div class="pwd-rule" [class.pass]="(form.password.match(/[0-9]/g)||[]).length >= 1">
                        <span class="rule-icon">{{ (form.password.match(/[0-9]/g)||[]).length >= 1 ? '✓' : '✗' }}</span>
                        At least 1 number
                      </div>
                      <div class="pwd-rule" [class.pass]="(form.password.match(/[^a-zA-Z0-9]/g)||[]).length >= 1">
                        <span class="rule-icon">{{ (form.password.match(/[^a-zA-Z0-9]/g)||[]).length >= 1 ? '✓' : '✗' }}</span>
                        At least 1 special character (@#$! etc.)
                      </div>
                    </div>

                    <!-- Overall strength bar -->
                    <div class="pwd-strength-bar" *ngIf="form.password">
                      <div class="pwd-bar-fill"
                           [style.width.%]="getPwdStrength()"
                           [style.background]="getPwdStrengthColor()">
                      </div>
                    </div>
                    <div class="pwd-strength-label" *ngIf="form.password">
                      {{ getPwdStrengthLabel() }}
                    </div>
                </div>
                <div class="form-group">
                    <label>Role</label>
                    <select [(ngModel)]="form.role" name="role" required class="form-select">
                        <option value="" disabled selected>Select Role</option>
                        <option value="Supervisor">Supervisor</option>
                        <option value="Manager">Manager</option>
                        <option value="HOD">HOD</option>
                        <option value="Business Excellence">Business Excellence</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Plant</label>
                    <select [(ngModel)]="form.plant_id" name="plant_id" class="form-select">
                        <option value="" disabled selected>Select Plant (Optional)</option>
                        <option *ngFor="let u of units" [value]="u">{{u}}</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Section</label>
                    <input type="text" [(ngModel)]="form.section" name="section" class="form-control">
                </div>

                <div class="form-group">
                    <label>Email (for password reset)</label>
                    <input type="email" [(ngModel)]="form.email" name="email" 
                           class="form-control" placeholder="user@company.com">
                </div>

                <button type="submit" class="primary-btn mt-3">
                    {{ editMode ? 'UPDATE USER' : 'SAVE USER' }}
                </button>
                <button type="button" class="cancel-btn" *ngIf="editMode" (click)="resetForm()">
                    CANCEL
                </button>
            </form>
        </div>

        <div class="table-container">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="m-0">Existing Identities</h5>
                <div class="search-box">
                    <input type="text" 
                           [(ngModel)]="searchTerm" 
                           placeholder="Search by ID, Role or Plant..." 
                           class="form-control search-input">
                </div>
            </div>

            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th style="text-align: left;">User ID</th>
                            <th style="text-align: left;">Role</th>
                            <th style="text-align: left;">Plant</th>
                            <th style="text-align: left;">Section</th>
                            <th style="text-align: center;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr *ngFor="let user of filteredUsers()">
                            <td style="text-align: left;"><b>{{user.user_id}}</b></td>
                            <td style="text-align: left;">
                                <span class="role-badge" [ngClass]="user.role.toLowerCase().replace(' ', '-')">
                                    {{user.role}}
                                </span>
                            </td>
                            <td style="text-align: left;">{{user.plant_id || '-'}}</td>
                            <td style="text-align: left;">{{user.section || '-'}}</td>
                            <td style="text-align: center;">
                                <button class="edit-btn me-2" (click)="editUser(user)">✏</button>
                                <button class="delete-btn" (click)="deleteUser(user)">🗑</button>
                            </td>
                        </tr>
                        <tr *ngIf="filteredUsers().length === 0">
                            <td colspan="5" style="text-align:center; padding: 30px; color: #888;">
                                No users found matching "{{searchTerm}}"
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
  `,
  styles: [`
    .content-wrapper { display:flex; gap:25px; padding:10px; }
    .form-container, .table-container { background:white; padding:25px; border-radius:15px; box-shadow:0 8px 20px rgba(0,0,0,.04); }
    .form-container { flex:1; height: fit-content; }
    .table-container { flex:2.5; }
    
    /* Search Bar Styles */
    .search-box { width: 300px; }
    .search-input { 
        background: #f8f9fa; 
        border: 1px solid #e0e0e0; 
        font-size: 14px;
        border-radius: 10px;
    }
    .search-input:focus { background: white; border-color: #3498db; }

    .form-group { margin-bottom:15px; }
    .form-group label { font-size: 13px; font-weight: 600; color: #555; margin-bottom: 5px; display: block; }
    .form-control, .form-select { padding:10px; border-radius:8px; border:1px solid #e0e0e0; width: 100%; }
    .primary-btn { width:100%; padding:12px; border-radius:10px; border:none; background:#3498db; color:white; font-weight:600; cursor:pointer; }
    .cancel-btn { width:100%; padding:10px; border-radius:10px; border:1px solid #ccc; background:white; margin-top:10px; cursor:pointer; }
    
    table { width:100%; border-collapse: separate; border-spacing: 0 8px; }
    th { font-size: 13px; text-transform: uppercase; color: #888; letter-spacing: 0.5px; padding: 10px 15px; border-bottom: 1px solid #eee; }
    td { padding:12px 15px; background: #fff; vertical-align: middle; border-bottom: 1px solid #f9f9f9; }
    
    .role-badge { display: inline-block; padding: 5px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; text-align: center; min-width: 100px; color: white; }
    .supervisor { background: #17a2b8; }
    .manager { background: #6f42c1; }
    .hod { background: #fd7e14; }
    .business-excellence { background: #28a745; }
    .edit-btn { background:#e3f2fd; color:#1976d2; border:none; padding:8px 12px; border-radius:8px; cursor:pointer; }
    .delete-btn { background:#ffebee; color:#d32f2f; border:none; padding:8px 12px; border-radius:8px; cursor:pointer; }
    
    .d-flex { display: flex; }
    .justify-content-between { justify-content: space-between; }
    .align-items-center { align-items: center; }
    .m-0 { margin: 0; }
    .req { color: #ef4444; font-weight: 900; margin-left: 2px; }
    .pwd-rules { margin-top: 8px; display: flex; flex-direction: column; gap: 4px; }
    .pwd-rule { font-size: 12px; color: #ef4444; display: flex; align-items: center; gap: 6px; font-weight: 600; transition: 0.3s; }
    .pwd-rule.pass { color: #10b981; }
    .rule-icon { font-weight: 900; font-size: 13px; width: 16px; }
    .pwd-strength-bar { height: 5px; background: #e2e8f0; border-radius: 10px; margin-top: 10px; overflow: hidden; }
    .pwd-bar-fill { height: 100%; border-radius: 10px; transition: width 0.4s ease, background 0.4s ease; }
    .pwd-strength-label { font-size: 11px; font-weight: 700; margin-top: 4px; color: #64748b; }
  `]
})
export class ManageUsersComponent implements OnInit {
  api = 'http://localhost:8080/api/bex';
  editMode = false;
  searchTerm: string = ''; // New variable for search
  units = ['Unit 1','Unit 2','Unit 3','Unit 4','Unit 5'];
  users:any[] = [];
  form:any = { user_id:'', password:'', role:'', plant_id:'', section:'', old_user_id: '', email: '' };
  passwordErrors: string[] = [];
  passwordValid: boolean = false;

  constructor(private router:Router, private http:HttpClient, private cdr: ChangeDetectorRef){}

  ngOnInit(){ this.loadUsers(); }

  // Logic to filter users based on searchTerm
  filteredUsers() {
    if (!this.searchTerm) return this.users;
    
    const term = this.searchTerm.toLowerCase();
    return this.users.filter(user => 
      user.user_id.toLowerCase().includes(term) ||
      user.role.toLowerCase().includes(term) ||
      (user.plant_id && user.plant_id.toLowerCase().includes(term)) ||
      (user.section && user.section.toLowerCase().includes(term))
    );
  }

  loadUsers() {
  this.http.get<any[]>(`${this.api}?action=get_users&t=${new Date().getTime()}`).subscribe(res => {
    this.users = [...res];
    this.cdr.detectChanges();
  });
}

  saveUser(){
    if(!this.form.role){ alert("Please select a role"); return; }
    this.validatePassword(this.form.password);
    if (!this.passwordValid) {
      alert("Password does not meet requirements:\n" + this.passwordErrors.join("\n"));
      return;
    }
    this.http.post(`${this.api}/save-user`, this.form).subscribe(() => {
        alert(this.editMode ? "User Updated" : "User Enrolled");
        this.resetForm();
        this.loadUsers();
    });
  }

  editUser(user:any){
    this.editMode = true;
    this.form = { ...user, old_user_id: user.user_id };
    window.scrollTo(0,0);
  }

  deleteUser(user:any){
    if(confirm("Are you sure you want to delete this user?")){
      this.http.post(`${this.api}/delete-user`, {user_id: user.user_id}).subscribe(() => {
        this.loadUsers();
      });
    }
  }

  validatePassword(pwd: string) {
    const errors: string[] = [];

    const letters = (pwd.match(/[a-zA-Z]/g) || []).length;
    const numbers = (pwd.match(/[0-9]/g) || []).length;
    const special = (pwd.match(/[^a-zA-Z0-9]/g) || []).length;

    if (letters < 6) errors.push(`Minimum 6 alphabets (currently ${letters})`);
    if (numbers < 1) errors.push('At least 1 number required');
    if (special < 1) errors.push('At least 1 special character required (e.g. @#$!)');

    this.passwordErrors = errors;
    this.passwordValid  = errors.length === 0;
  }

  getPwdStrength(): number {
    const pwd = this.form.password || '';
    const letters = (pwd.match(/[a-zA-Z]/g) || []).length;
    const numbers = (pwd.match(/[0-9]/g) || []).length;
    const special = (pwd.match(/[^a-zA-Z0-9]/g) || []).length;
    let score = 0;
    if (letters >= 6) score += 34;
    if (numbers >= 1) score += 33;
    if (special >= 1) score += 33;
    return score;
  }

  getPwdStrengthColor(): string {
    const s = this.getPwdStrength();
    if (s <= 33)  return '#ef4444'; // red - weak
    if (s <= 66)  return '#f59e0b'; // amber - medium
    return '#10b981';               // green - strong
  }

  getPwdStrengthLabel(): string {
    const s = this.getPwdStrength();
    if (s <= 33)  return 'Weak';
    if (s <= 66)  return 'Medium';
    return 'Strong ✓';
  }

  resetForm() {
  this.editMode = false;
  this.form = { 
    user_id: '', password: '', role: '', plant_id: '', 
    section: '', old_user_id: '', email: '' 
  };
  this.searchTerm = '';
  this.passwordErrors = [];
  this.passwordValid  = false;
  this.cdr.detectChanges();
}
}