import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { RouterModule, Router } from '@angular/router';
import { ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'app-bex-dashboard',
  standalone: true,
  imports: [CommonModule, HttpClientModule, RouterModule],
  encapsulation: ViewEncapsulation.None,
  template: `
    <div class="container py-4">

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="text-secondary">Global Performance Overview</h3>
            <div class="badge-custom">
                Total Kaizens: {{ grandTotal }}
            </div>
        </div>

        <div class="unit-grid">
            <div class="unit-box"
                 *ngFor="let unit of unitData; let i = index"
                 [ngClass]="gradients[i]">

                <div class="unit-title">
                    Unit 0{{ i+1 }}
                </div>

                <div class="unit-value">
                    {{ unit }}
                </div>

                <div class="unit-label">
                    Total Submissions
                </div>
            </div>
        </div>

        <div class="summary-section">
            <div class="summary-card">
                <span>Total Units</span>
                <h2>{{ unitData.length }}</h2>
            </div>

            <div class="summary-card highlight">
                <span>Highest Performing Unit</span>
                <h2>Unit {{ getTopUnit() }}</h2>
            </div>

            <div class="summary-card">
                <span>Average Submissions</span>
                <h2>{{ getAverage() }}</h2>
            </div>
        </div>

        <div class="admin-controls-box mt-5">
            <h5>Administrative Controls</h5>
            <hr>
            <div class="admin-wrapper">
                <button class="admin-btn" routerLink="/manage-users">
                    <i class="fas fa-user-plus"></i>
                    Provision New User
                </button>

                <button class="admin-btn" routerLink="/glob-kaizen">
                    <i class="fas fa-list"></i>
                    View Master List
                </button>

                <button class="admin-btn" routerLink="/report">
                    <i class="fas fa-file-excel"></i>
                    Download Reports
                </button>
            </div>
        </div>
    </div>
  `,
  styles: [`
    /* Cleaned Styles: Removed Sidebar/Main-Content positioning */
    .badge-custom {
        font-size: 16px;
        padding: 8px 16px;
        border-radius: 8px;
        background: linear-gradient(135deg, #e67e22, #d35400);
        color: white;
        font-weight: 600;
    }

    /* Unit Squares */
    .unit-grid {
        display: flex;
        gap: 20px;
        margin-bottom: 40px;
    }

    .unit-box {
        flex: 1;
        border-radius: 18px;
        padding: 25px;
        color: white;
        height: 180px;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        box-shadow: 0 10px 25px rgba(0,0,0,0.08);
        transition: 0.3s;
    }
    .unit-box:hover {
        transform: translateY(-6px);
        box-shadow: 0 18px 35px rgba(0,0,0,0.15);
    }

    .unit-title { font-size: 13px; text-transform: uppercase; opacity: 0.8; letter-spacing: 1px; }
    .unit-value { font-size: 40px; font-weight: 800; }
    .unit-label { font-size: 12px; opacity: 0.9; }

    /* Gradients */
    .bg-unit1 { background: linear-gradient(45deg, #6c757d, #495057); }
    .bg-unit2 { background: linear-gradient(45deg, #17a2b8, #117a8b); }
    .bg-unit3 { background: linear-gradient(45deg, #007bff, #0056b3); }
    .bg-unit4 { background: linear-gradient(45deg, #e67e22, #d35400); }
    .bg-unit5 { background: linear-gradient(45deg, #6f42c1, #563d7c); }

    /* Summary Cards */
    .summary-section {
        display: flex;
        gap: 20px;
        margin-bottom: 40px;
    }

    .summary-card {
        flex: 1;
        background: #ffffff;
        padding: 25px;
        border-radius: 18px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.05);
        transition: 0.3s ease;
        border-top: 4px solid #ff7a18;
    }
    .summary-card span { font-size: 12px; text-transform: uppercase; color: #888; }
    .summary-card h2 { margin-top: 10px; font-size: 26px; font-weight: 700; color: #111827; }
    .summary-card.highlight { border-top-color: #111827; }

    /* Admin Controls */
    .admin-controls-box {
        background: white;
        padding: 30px;
        border-radius: 18px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.05);
    }
    .admin-wrapper { display: flex; gap: 20px; }
    .admin-btn {
        flex: 1;
        padding: 25px;
        border-radius: 16px;
        border: 2px solid #e5e7eb;
        background: #ffffff;
        font-size: 14px;
        font-weight: 600;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 10px;
        cursor: pointer;
        transition: 0.3s;
    }
    .admin-btn i { font-size: 20px; color: #111827; }
    .admin-btn:hover {
        border-color: #ff7a18;
        background: linear-gradient(135deg, #ff7a18, #ffb347);
        color: white;
    }
    .admin-btn:hover i { color: white; }
  `]
})
export class BexDashboardComponent implements OnInit {

  api = 'http://localhost:8080/api/bex';

  unitData: number[] = [0, 0, 0, 0, 0];
  grandTotal = 0;

  gradients = [
    'bg-unit1',
    'bg-unit2',
    'bg-unit3',
    'bg-unit4',
    'bg-unit5'
  ];

  constructor(
    private http: HttpClient, 
    private router: Router, 
    private cd: ChangeDetectorRef
  ) {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
  }

  ngOnInit(): void {
    this.loadDashboard();
  }

  getTopUnit(): number {
    const max = Math.max(...this.unitData);
    return this.unitData.indexOf(max) + 1;
  }

  getAverage(): number {
    if (this.unitData.length === 0) return 0;
    const total = this.unitData.reduce((a, b) => a + b, 0);
    return Math.round(total / this.unitData.length);
  }

loadDashboard() {
  this.http.get<any[]>(`${this.api}?action=dashboard`)
    .subscribe({
      next: (res) => {
        this.unitData = res.map(r => Number(r.total));
        this.grandTotal = this.unitData.reduce((a, b) => a + b, 0);
        this.cd.detectChanges();
      },
      error: (err) => {}
    });
}

  // logout() is now handled in the sidebar/layout, 
  // but keeping it here if needed for the admin buttons.
  logout() {
    this.router.navigate(['/admin-login']);
  }
}