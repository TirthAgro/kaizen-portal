import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';

@Component({
  selector: 'app-bex-layout',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="app-container">
      <aside class="sidebar-pillar" [class.is-collapsed]="sidebarClosed">
        <div class="gloss-shine"></div>
        
        <div class="sidebar-header">
           <div class="brand-shell">
             <span class="brand-name">BEX</span>
             <span class="brand-sub">PRECISION</span>
           </div>
        </div>

        <nav class="navigation-hub">
          <a routerLink="/bex-dashboard" routerLinkActive="active" class="nav-item">
            <div class="nav-glow"></div>
            <i class="nav-icon">📊</i>
            <span class="nav-label">DASHBOARD</span>
          </a>
          <a routerLink="/manage-users" routerLinkActive="active" class="nav-item">
            <div class="nav-glow"></div>
            <i class="nav-icon">👥</i>
            <span class="nav-label">USER CONTROL</span>
          </a>
          <a routerLink="/report" routerLinkActive="active" class="nav-item">
            <div class="nav-glow"></div>
            <i class="nav-icon">📂</i>
            <span class="nav-label">ANALYTICS</span>
          </a>
          <a routerLink="/glob-kaizen" routerLinkActive="active" class="nav-item">
            <div class="nav-glow"></div>
            <i class="nav-icon">🌐</i>
            <span class="nav-label">GLOBAL REPO</span>
          </a>
        </nav>

        <div class="sidebar-footer">
          <button (click)="logout()" class="logout-trigger">
            <span>EXIT PORTAL</span>
          </button>
        </div>
      </aside>

      <div class="main-viewport">
        <header class="premium-topbar">
          <div class="bar-left">
            <button class="menu-toggle" (click)="toggleSidebar()">
              <div class="hamburger-box">
                <span class="line"></span>
                <span class="line"></span>
                <span class="line"></span>
              </div>
            </button>
            <h1 class="portal-heading">SHAKTIMAN <span class="thin">KAIZEN PORTAL</span></h1>
          </div>

          <div class="bar-right">
             <div class="logo-badge">
               <img src="assets/shaktiman_logo.png" alt="Shaktiman">
             </div>
          </div>
        </header>

        <main class="content-arena">
    <router-outlet></router-outlet> 
</main>
      </div>
    </div>
  `,
  styles: [`
    @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@500;800&family=Inter:wght@300;400;700&display=swap');

    :host { 
      --sb-width: 290px;
      --shaktiman-orange: #ff6a00;
      --gloss-bg: #0b0f19;
    }

    .app-container {
      display: flex;
      height: 100vh;
      width: 100vw;
      overflow: hidden;
      background: #f0f2f5;
      font-family: 'Inter', sans-serif;
    }

    /* SIDEBAR PILLAR - FULL HEIGHT */
    .sidebar-pillar {
      width: var(--sb-width);
      height: 100vh;
      background: var(--gloss-bg);
      position: relative;
      display: flex;
      flex-direction: column;
      transition: all 0.5s cubic-bezier(0.16, 1, 0.3, 1);
      z-index: 1000;
      box-shadow: 15px 0 50px rgba(0,0,0,0.4);
      border-right: 1px solid rgba(255,255,255,0.05);
    }

    .sidebar-pillar.is-collapsed {
      transform: translateX(-100%);
      margin-right: calc(var(--sb-width) * -1);
    }

    /* GLOSSY EFFECT */
    .gloss-shine {
      position: absolute; top: 0; left: 0; right: 0; height: 100%;
      background: linear-gradient(135deg, rgba(255,255,255,0.08) 0%, rgba(255,255,255,0) 40%);
      pointer-events: none;
    }

    .sidebar-header { padding: 50px 20px; text-align: center; }
    
    .brand-shell {
      display: flex; flex-direction: column;
      font-family: 'Orbitron', sans-serif;
    }
    .brand-name { 
      font-size: 2.2rem; font-weight: 800; color: white; 
      letter-spacing: 8px; text-shadow: 0 0 15px rgba(255,255,255,0.3);
    }
    .brand-sub { 
      font-size: 0.7rem; color: var(--shaktiman-orange); 
      letter-spacing: 5px; margin-top: -5px; 
    }

    /* NAVIGATION ITEMS */
    .navigation-hub { flex: 1; padding: 20px 15px; }
    
    .nav-item {
      position: relative;
      display: flex; align-items: center;
      padding: 16px 25px; margin-bottom: 10px;
      color: #64748b; text-decoration: none;
      font-weight: 600; font-size: 0.85rem; letter-spacing: 1.5px;
      transition: 0.4s ease;
      border-radius: 12px;
      overflow: hidden;
    }

    .nav-icon { font-size: 1.2rem; margin-right: 18px; z-index: 2; transition: 0.3s; }
    .nav-label { z-index: 2; transition: 0.3s; }

    /* HOVER ANIMATIONS */
    .nav-glow {
      position: absolute; top: 0; left: -100%; width: 100%; height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255,106,0,0.1), transparent);
      transition: 0.5s; z-index: 1;
    }

    .nav-item:hover { color: #fff; transform: translateX(8px); }
    .nav-item:hover .nav-glow { left: 100%; }
    .nav-item:hover .nav-icon { transform: scale(1.2) rotate(-5deg); color: var(--shaktiman-orange); }

    .nav-item.active {
      background: rgba(255,106,0,0.1);
      color: white;
      box-shadow: 0 4px 15px rgba(0,0,0,0.2);
      border: 1px solid rgba(255,106,0,0.2);
    }
    .nav-item.active .nav-label { color: var(--shaktiman-orange); font-weight: 800; }

    /* VIEWPORT & TOPBAR */
    .main-viewport { flex: 1; display: flex; flex-direction: column; min-width: 0; }

    .premium-topbar {
      height: 80px;
      background: linear-gradient(90deg, #FF8C00, #FF4500);
      display: flex; justify-content: space-between; align-items: center;
      padding: 0 35px; box-shadow: 0 10px 30px rgba(0,0,0,0.15);
      z-index: 900;
    }

    .bar-left { display: flex; align-items: center; gap: 30px; }
    
    /* HIGH END HAMBURGER */
    .menu-toggle {
      background: rgba(255,255,255,0.15); border: none;
      width: 50px; height: 50px; border-radius: 50%;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      transition: 0.3s;
    }
    .menu-toggle:hover { background: white; }
    .menu-toggle:hover .line { background: #FF4500; }

    .hamburger-box { display: flex; flex-direction: column; gap: 5px; }
    .line { width: 22px; height: 2px; background: white; border-radius: 5px; transition: 0.3s; }

    .portal-heading {
      font-family: 'Orbitron', sans-serif;
      color: white; font-size: 1.4rem; font-weight: 800; margin: 0;
    }
    .thin { font-weight: 300; opacity: 0.8; font-size: 1rem; }

    .logo-badge {
      background: white; padding: 10px 25px; border-radius: 50px;
      box-shadow: 0 5px 20px rgba(0,0,0,0.2);
    }
    .logo-badge img { height: 35px; width: auto; }

    .content-arena { flex: 1; overflow-y: auto; padding: 40px; background: #f8fafc; }

    .logout-trigger {
      margin: 30px; width: calc(100% - 60px); padding: 14px;
      background: transparent; border: 1px solid #ef4444;
      color: #ef4444; border-radius: 50px; cursor: pointer;
      font-weight: 800; font-size: 0.7rem; letter-spacing: 2px;
      transition: 0.3s;
    }
    .logout-trigger:hover { background: #ef4444; color: white; box-shadow: 0 0 20px rgba(239, 68, 68, 0.4); }
  `]
})
export class BexLayoutComponent {
  sidebarClosed = false;
  constructor(private router: Router) {}
  toggleSidebar() { this.sidebarClosed = !this.sidebarClosed; }
  logout() { this.router.navigate(['/admin-login']); }
}