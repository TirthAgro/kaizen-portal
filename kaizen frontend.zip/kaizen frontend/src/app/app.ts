/*import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router'; // Add this line

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet], // Make sure RouterOutlet is here
  templateUrl: './app.html'
})
export class AppComponent { }*/






















import { Component, OnInit, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterModule, RouterOutlet],
  template: `<router-outlet></router-outlet>`
})
export class AppComponent implements OnInit {
  private timeout: any;
  private readonly TIMEOUT_MS = 30 * 60 * 1000; // 30 minutes

  constructor(private router: Router) {}

  ngOnInit() { this.resetTimer(); }

  @HostListener('document:mousemove')
  @HostListener('document:keypress')
  @HostListener('document:click')
  resetTimer() {
    clearTimeout(this.timeout);
    this.timeout = setTimeout(() => {
      sessionStorage.clear();
      localStorage.clear();
      this.router.navigate(['/login']);
      alert('Session expired. Please login again.');
    }, this.TIMEOUT_MS);
  }
}