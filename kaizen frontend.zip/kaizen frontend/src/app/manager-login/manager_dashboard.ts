import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-manager-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, HttpClientModule, FormsModule],
  encapsulation: ViewEncapsulation.None,
  template: `
    <div class="app-container">
      <aside class="sidebar-pillar" [class.is-collapsed]="sidebarClosed">
        <div class="gloss-shine"></div>
        
        <div class="sidebar-header">
           <div class="brand-shell">
             <span class="brand-name">MANAGER</span>
             <span class="brand-sub">PRO PANEL</span>
           </div>
        </div>

        <nav class="navigation-hub">
          <a (click)="currentView = 'insights'" class="nav-item" [class.active]="currentView === 'insights'">
            <div class="nav-glow"></div>
            <i class="nav-icon">📊</i>
            <span class="nav-label">INSIGHTS HUB</span>
          </a>
          <a routerLink="/manager-registration" class="nav-item">
            <div class="nav-glow"></div>
            <i class="nav-icon">➕</i>
            <span class="nav-label">NEW KAIZEN</span>
          </a>
          <a (click)="currentView = 'approvals'" class="nav-item" [class.active]="currentView === 'approvals'">
            <div class="nav-glow"></div>
            <i class="nav-icon">✅</i>
            <span class="nav-label">
  APPROVAL QUEUE
  <span *ngIf="pendingApprovalCount > 0" class="notify-badge">
    {{ pendingApprovalCount }}
  </span>
</span>
          </a>
          <a (click)="currentView = 'tracker'" class="nav-item" [class.active]="currentView === 'tracker'">
            <div class="nav-glow"></div>
            <i class="nav-icon">🕒</i>
            <span class="nav-label">TEAM TRACKER</span>
          </a>
        </nav>

        <div class="sidebar-footer">
          <button (click)="logout()" class="logout-trigger">
            <span>EXIT PORTAL</span>
          </button>
        </div>
      </aside>

      <div class="main-viewport">
        <header class="premium-topbar">
          <div class="bar-left">
            <button class="menu-toggle" (click)="toggleSidebar()">
              <div class="hamburger-box">
                <span class="line"></span>
                <span class="line"></span>
                <span class="line"></span>
              </div>
            </button>
            <h1 class="portal-heading">SHAKTIMAN <span class="thin">KAIZEN PORTAL</span></h1>
          </div>

          <div class="bar-right">
             <div class="logo-badge">
               <img src="assets/shaktiman_logo.png" alt="Shaktiman">
             </div>
          </div>
        </header>

        <main class="content-arena">
          <ng-container *ngIf="currentView === 'insights'">
             <div class="dashboard-header-stats">
                <div class="breadcrumb-dark">
                  <span class="parent">Kaizen Portal</span> / <span class="current">Manager Dashboard</span>
                </div>
                <button (click)="fetchDbStats()" class="refresh-action-btn">
                  <i class="fas fa-sync-alt"></i> Sync Data
                </button>
             </div>

             <div class="bento-grid">
                <div class="bento-tile welcome-tile">
                  <h2>Welcome back, Manager!</h2>
                  <p>You have <strong>{{ pendingApprovalCount }}</strong> submissions pending your approval.</p>
                  <button (click)="currentView = 'approvals'" class="cta-pill">Review Now</button>
                </div>

                <div class="stat-mini-card bg-primary-gradient">
                  <div class="stat-content">
                    <span class="label">Total Records</span>
                    <span class="value">{{ myTotalCount }}</span>
                  </div>
                  <i class="fas fa-database icon-bg"></i>
                </div>

                <div class="stat-mini-card bg-warning-gradient">
                  <div class="stat-content">
                    <span class="label">Pending</span>
                    <span class="value">{{ pendingApprovalCount }}</span>
                  </div>
                  <i class="fas fa-clock icon-bg"></i>
                </div>

                <div class="stat-mini-card bg-success-gradient">
                  <div class="stat-content">
                    <span class="label">Approved</span>
                    <span class="value">{{ approvedCount }}</span>
                  </div>
                  <i class="fas fa-check-circle icon-bg"></i>
                </div>

                <div class="bento-tile graph-tile">
                  <div class="tile-header">
                    <h3>Department Efficiency</h3>
                    <span class="subtitle">Monthly Submissions</span>
                  </div>
                  <div class="custom-bar-chart">
                    <div class="bar-col" *ngFor="let val of [40, 70, 50, 90, 60, 85]">
                      <div class="bar-fill" [style.height.%]="val"></div>
                    </div>
                  </div>
                  <div class="chart-labels">
                    <span>Jan</span><span>Feb</span><span>Mar</span><span>Apr</span><span>May</span><span>Jun</span>
                  </div>
                </div>

                <div class="bento-tile progress-tile">
                  <h3>Target Progress</h3>
                  <div class="circular-container">
                    <svg viewBox="0 0 36 36" class="circular-chart">
                      <path class="circle-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                      <path class="circle-path" [attr.stroke-dasharray]="getPercentage() + ', 100'" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                      <text x="18" y="21" class="percentage">{{ getPercentage() }}%</text>
                    </svg>
                  </div>
                  <p class="goal-text">Goal: 20 Approved Kaizens</p>
                </div>
              </div>
          </ng-container>

          <ng-container *ngIf="currentView === 'approvals'">
            <div class="view-header">
              <div class="breadcrumb-dark">
                Approvals / <span class="unit-tag">{{ plantId || 'N/A' }}</span> / <strong>{{ section || 'N/A' }} SECTION</strong>
              </div>
              <button class="refresh-btn" (click)="fetchPendingData()">
                <i class="fas fa-sync-alt"></i> Refresh Data
              </button>
            </div>

            <div class="table-container shadow-smooth">
              <table class="modern-table">
                <thead>
                  <tr>
                    <th>Kaizen ID</th>
                    <th>Employee</th>
                    <th>Theme</th>
                    <th>Level</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <tr *ngFor="let k of pendingKaizens">
                    <td><strong>{{ k.kaizen_id }}</strong></td>
                    <td>{{ k.emp_name }}</td>
                    <td>{{ k.theme }}</td>
                    <td>
                      <span *ngIf="k.role_type" class="level-badge" [ngClass]="k.role_type.toLowerCase().substring(0,3)">
                        {{ k.role_type }}
                      </span>
                    </td>

                    <td style="text-align: center;">
                        <div class="action-holder">
                        <button class="view-btn" (click)="openReview(k)">
                          Review
                        </button>
                        </div>
                    </td>
                  </tr>
                  <tr *ngIf="pendingKaizens.length === 0">
                    <td colspan="5" class="empty-state">No pending approvals found for {{ section }}.</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </ng-container>

          <ng-container *ngIf="currentView === 'tracker'">
            <div class="view-header">
              <div class="breadcrumb-dark">
                History / <span class="unit-tag">{{ plantId }}</span> / <strong>{{ section }} SECTION</strong>
              </div>
              <div class="search-box">
                <i class="fas fa-search"></i>
                <input type="text" [(ngModel)]="searchTerm" (input)="filterTrackerData()" placeholder="Search employee or theme...">
              </div>
            </div>

            <div class="table-container shadow-smooth">
              <table class="modern-table">
                <thead>
                  <tr>
                    <th>Kaizen ID</th>
                    <th>Level</th>
                    <th>Employee</th>
                    <th>Theme</th>
                    <th>Status</th>
                    <th>Remarks</th>
                  </tr>
                </thead>
                <tbody>
                  <tr *ngFor="let k of filteredHistory">
                    <td><strong>{{ k.kaizen_id }}</strong></td>
                    <td>
                      <span *ngIf="k.role_type" class="level-badge" [ngClass]="k.role_type.toLowerCase().substring(0,3)">
                        {{ k.role_type }}
                      </span>
                    </td>
                    <td>{{ k.emp_name }}</td>
                    <td>{{ k.theme }}</td>
                    <td>
                      <span class="status-pill" [ngClass]="k.status.toLowerCase()">
                        {{ k.status }}
                      </span>
                    </td>
                    <td>{{ k.hod_remarks || '---' }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </ng-container>
        </main>
      </div>

      <div class="modal-overlay" *ngIf="selectedKaizen">
        <div class="modal-card">
          <div class="modal-header">
            <h3>Review Kaizen: {{ selectedKaizen.kaizen_id }}</h3>
            <button class="close-x" (click)="selectedKaizen = null">×</button>
          </div>
          <div class="modal-body">
            <div class="info-grid">
              <p><strong>Employee:</strong> {{selectedKaizen.emp_name}}</p>
              <p><strong>Category:</strong> {{selectedKaizen.kaizen_category}}</p>
              <p class="full-width"><strong>Theme:</strong> {{selectedKaizen.theme}}</p>
            </div>
            
            <div *ngIf="selectedKaizen.role_type === 'Supervisor'" class="supervisor-block">
              <p><strong>PQCDSM Details:</strong> {{selectedKaizen.pqcdsm}}</p>
              <p><strong>Problem Status:</strong> {{selectedKaizen.problem_status}}</p>
              <p><strong>Countermeasure:</strong> {{selectedKaizen.countermeasure}}</p>
              <p><strong>Analysis:</strong> {{selectedKaizen.analysis}}</p>
            </div>

                <div class="comparison-container">
      <div class="comp-box">
        <span class="label before">BEFORE</span>
        <img *ngIf="safeImgSrc(selectedKaizen.before_img)"
             [src]="safeImgSrc(selectedKaizen.before_img)"
             class="review-img">
        <div *ngIf="!safeImgSrc(selectedKaizen.before_img)"
             style="width:100%;height:280px;display:flex;align-items:center;justify-content:center;color:#475569;font-style:italic;">
          No Image Available
        </div>
        <p class="desc">{{ selectedKaizen.before_desc }}</p>
      </div>
      <div class="comp-box">
        <span class="label after">AFTER</span>
        <img *ngIf="safeImgSrc(selectedKaizen.after_img)"
             [src]="safeImgSrc(selectedKaizen.after_img)"
             class="review-img">
        <div *ngIf="!safeImgSrc(selectedKaizen.after_img)"
             style="width:100%;height:280px;display:flex;align-items:center;justify-content:center;color:#475569;font-style:italic;">
          No Image Available
        </div>
        <p class="desc">{{ selectedKaizen.after_desc }}</p>
      </div>
    </div>

            <div class="benefits-block">
              <h4>Benefits</h4>
              <p>{{selectedKaizen.benefits}}</p>
            </div>

            <div class="manager-input">
              <label>Manager Remarks</label>
              <textarea [(ngModel)]="managerRemark" placeholder="Enter reason for approval/rejection..."></textarea>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn-reject" (click)="updateStatus('Rejected')" [disabled]="!managerRemark">Reject</button>
            <button class="btn-approve" (click)="updateStatus('Approved')">Approve</button>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@500;800&family=Inter:wght@300;400;700&display=swap');

    :host { 
      --sb-width: 290px;
      --shaktiman-orange: #ff6a00;
      --gloss-bg: #0b0f19;
    }

    /* CONTAINER & SIDEBAR PILLAR */
    .app-container { display: flex; height: 100vh; width: 100vw; overflow: hidden; background: #000000; font-family: 'Inter', sans-serif; }
    
    .sidebar-pillar {
      width: var(--sb-width); height: 100vh; background: var(--gloss-bg); position: relative;
      display: flex; flex-direction: column; transition: all 0.5s cubic-bezier(0.16, 1, 0.3, 1);
      z-index: 1000; box-shadow: 15px 0 50px rgba(207, 6, 6, 0.4); border-right: 1px solid rgba(88, 190, 110, 0.05);
    }
    .sidebar-pillar.is-collapsed { transform: translateX(-100%); margin-right: calc(var(--sb-width) * -1); }
    .gloss-shine { position: absolute; top: 0; left: 0; right: 0; height: 100%; background: linear-gradient(135deg, rgba(197, 7, 134, 0.08) 0%, rgba(255,255,255,0) 40%); pointer-events: none; }
    
    .sidebar-header { padding: 50px 20px; text-align: center; }
    .brand-shell { display: flex; flex-direction: column; font-family: 'Orbitron', sans-serif; }
    .brand-name { font-size: 1.8rem; font-weight: 800; color: white; letter-spacing: 4px; }
    .brand-sub { font-size: 0.7rem; color: var(--shaktiman-orange); letter-spacing: 5px; margin-top: -5px; }

    /* NAVIGATION */
    .navigation-hub { flex: 1; padding: 20px 15px; }
    .nav-item {
      position: relative; display: flex; align-items: center; padding: 16px 25px; margin-bottom: 10px;
      color: #94a3b8; text-decoration: none; font-weight: 600; font-size: 0.85rem; letter-spacing: 1.5px;
      transition: 0.4s ease; border-radius: 12px; overflow: hidden; cursor: pointer;
    }
    .nav-icon { font-size: 1.2rem; margin-right: 18px; z-index: 2; }
    .nav-label { z-index: 2; }
    .nav-glow { position: absolute; top: 0; left: -100%; width: 100%; height: 100%; background: linear-gradient(90deg, transparent, rgba(255,106,0,0.1), transparent); transition: 0.5s; z-index: 1; }
    .nav-item:hover { color: #fff; transform: translateX(8px); }
    .nav-item:hover .nav-glow { left: 100%; }
    .nav-item.active { background: rgba(255,106,0,0.1); color: white; border: 1px solid rgba(255,106,0,0.2); }
    .nav-item.active .nav-label { color: var(--shaktiman-orange); font-weight: 800; }

    /* PREMIUM TOPBAR (ORANGE) */
    .main-viewport { flex: 1; display: flex; flex-direction: column; min-width: 0; }
    .premium-topbar {
      height: 80px; background: linear-gradient(90deg, #FF8C00, #FF4500);
      display: flex; justify-content: space-between; align-items: center;
      padding: 0 35px; box-shadow: 0 10px 30px rgba(0,0,0,0.15); z-index: 900;
    }
    .bar-left { display: flex; align-items: center; gap: 30px; }
    .menu-toggle { background: rgba(255,255,255,0.15); border: none; width: 45px; height: 45px; border-radius: 50%; cursor: pointer; display: flex; align-items: center; justify-content: center; }
    .menu-toggle:hover { background: white; }
    .line { width: 20px; height: 2px; background: white; margin: 4px 0; display: block; transition: 0.3s; }
    .menu-toggle:hover .line { background: #FF4500; }
    .portal-heading { font-family: 'Orbitron', sans-serif; color: white; font-size: 1.3rem; font-weight: 800; }
    .logo-badge { background: white; padding: 8px 20px; border-radius: 50px; }
    .logo-badge img { height: 30px; }

    /* CONTENT AREA */
    .content-arena { flex: 1; overflow-y: auto; padding: 30px; background: #f8fafc; }
    .dashboard-header-stats, .view-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
    .breadcrumb-dark { color: #64748b; font-size: 0.9rem; }
    .breadcrumb-dark strong { color: #1e293b; }

    /* BENTO TILES & STATS */
    .bento-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; }
    .bento-tile { background: white; border-radius: 16px; padding: 22px; border: 1px solid #e2e8f0; }
    .welcome-tile { grid-column: span 2; background: #1e293b; color: white; }
    .stat-mini-card { padding: 20px; border-radius: 16px; color: white; position: relative; overflow: hidden; display: flex; align-items: center; }
    .bg-primary-gradient { background: linear-gradient(135deg, #6366f1, #4338ca); }
    .bg-warning-gradient { background: linear-gradient(135deg, #f59e0b, #d97706); }
    .bg-success-gradient { background: linear-gradient(135deg, #22c55e, #15803d); }
    .icon-bg { position: absolute; right: -10px; bottom: -10px; font-size: 50px; opacity: 0.1; }
    .value { font-size: 2rem; font-weight: 800; display: block; }
    .cta-pill { background: var(--shaktiman-orange); border: none; padding: 10px 20px; border-radius: 50px; color: white; font-weight: bold; cursor: pointer; margin-top: 15px; }

    /* TABLE STYLES */
    .table-container { background: white; border-radius: 12px; overflow: hidden; border: 1px solid #e2e8f0; }
    .modern-table { 
  width: 100%; 
  border-collapse: collapse;
  table-layout: fixed;
}
    .modern-table th { 
  background: #f8fafc; 
  padding: 15px; 
  text-align: left; 
  font-size: 0.75rem; 
  text-transform: uppercase; 
  color: #0f54b4; 
}

/* Fix action column width */
.modern-table th:last-child,
.modern-table td:last-child {
  width: 140px;
  text-align: center;
}

/* Center level column perfectly */
.modern-table th:nth-child(4),
.modern-table td:nth-child(4) {
  text-align: center;
}

.modern-table tbody tr {
  transition: all 0.25s ease;
}

.modern-table tbody tr:hover {
  background: #f1f5f9;
  transform: scale(1.002);
}
    .modern-table td { padding: 15px; border-bottom: 1px solid #f1f5f9; }
    .modern-table td strong {
  color: #1e293b;
  font-weight: 700;
}

    /* Ensure consistent vertical alignment across all cells */
.modern-table td,
.modern-table th {
  vertical-align: middle;
}

/* Force consistent row height */
.modern-table tbody tr {
  height: 70px;
}

/* Center level badge perfectly */
.level-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

/* Center action holder properly */
.action-holder {
  display: flex;
  align-items: center;
  justify-content: center;
}


    /* Role Badge Styling */
.level-badge {
  display: inline-block;
  padding: 4px 12px;
  border-radius: 50px;
  font-size: 0.7rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: white;
  text-align: center;
  min-width: 85px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

/* Operator: Emerald Green - Represents the foundation/execution */
.level-badge.ope { 
  background: linear-gradient(135deg, #10b981, #059669); 
  border: 1px solid #047857;
}

/* Supervisor: Amber/Orange - Represents oversight (Matches Shaktiman Brand) */
.level-badge.sup { 
  background: linear-gradient(135deg, #f59e0b, #d97706); 
  border: 1px solid #b45309;
}

/* Manager: Royal Indigo/Blue - Represents strategy and final approval */
.level-badge.man { 
  background: linear-gradient(135deg, #6366f1, #4338ca); 
  border: 1px solid #3730a3;
}
   /* .level-badge { padding: 4px 12px; border-radius: 50px; font-size: 0.7rem; font-weight: 700; color: white; }
    .level-badge.mgr { background: #6366f1; }
    .level-badge.sup { background: #f59e0b; }
    .level-badge.op { background: #10b981; }*/
    .view-btn { background: var(--shaktiman-orange); color: white; border: none; padding: 6px 15px; border-radius: 6px; cursor: pointer; }
    .status-pill { padding: 4px 12px; border-radius: 50px; font-size: 0.75rem; font-weight: bold; }
    .status-pill.approved { background: #dcfce7; color: #166534; }
    .status-pill.pending { background: #fef3c7; color: #92400e; }
    .status-pill.rejected { background: #fee2e2; color: #991b1b; }
    /* Status animation */
.status-pill.approved {
  animation: approvedPulse 0.6s ease;
}

.status-pill.rejected {
  animation: rejectedPulse 0.6s ease;
}

@keyframes approvedPulse {
  0% { transform: scale(0.8); opacity: 0.4; }
  100% { transform: scale(1); opacity: 1; }
}

@keyframes rejectedPulse {
  0% { transform: scale(0.8); opacity: 0.4; }
  100% { transform: scale(1); opacity: 1; }
}

.notify-badge {
  background: #ef4444;
  color: white;
  font-size: 10px;
  padding: 2px 6px;
  border-radius: 50px;
  margin-left: 8px;
  font-weight: 700;
}
    /* SEARCH BOX */
    .search-box { position: relative; }
    .search-box i { position: absolute; left: 12px; top: 12px; color: #94a3b8; }
    .search-box input { padding: 8px 15px 8px 35px; border: 1px solid #e2e8f0; border-radius: 8px; width: 250px; }

    /* FOOTER & LOGOUT */
    .sidebar-footer { padding: 20px; border-top: 1px solid rgba(255,255,255,0.05); }
    .logout-trigger { width: 100%; padding: 12px; background: transparent; border: 1px solid #ef4444; color: #ef4444; border-radius: 50px; cursor: pointer; font-weight: 800; font-size: 0.7rem; letter-spacing: 1px; transition: 0.3s; }
    .logout-trigger:hover { background: #ef4444; color: white; box-shadow: 0 0 15px rgba(239, 68, 68, 0.4); }

    /* MODALS */
    .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.6); display: flex; align-items: center; justify-content: center; z-index: 2000; }
    .modal-card { background: white; width: 900px; max-height: 90vh; border-radius: 20px; overflow: hidden; display: flex; flex-direction: column; }
    .modal-header { padding: 20px; background: #f8fafc; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; }
    .modal-body { padding: 25px; overflow-y: auto; }
    .comparison-container { display: flex; gap: 20px; margin: 20px 0; }
   .comp-box { 
  flex: 1; 
  background: #000; 
  border-radius: 12px; 
  padding: 10px; 
  text-align: center; 
  color: white;
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 320px;
}
.comp-box img { 
  width: 100%; 
  flex: 1;
  object-fit: contain; 
  background: #000; 
  border-radius: 8px;
}
    .label { font-size: 0.7rem; font-weight: 800; padding: 4px 10px; border-radius: 4px; display: inline-block; margin-bottom: 10px; }
    .before { background: #ef4444; }
    .after { background: #10b981; }
    .manager-input textarea { width: 100%; height: 100px; border: 1px solid #e2e8f0; border-radius: 12px; padding: 15px; margin-top: 10px; }
    .btn-approve { background: #10b981; color: white; border: none; padding: 12px 25px; border-radius: 8px; cursor: pointer; font-weight: bold; }
    .btn-reject { background: #ef4444; color: white; border: none; padding: 12px 25px; border-radius: 8px; cursor: pointer; font-weight: bold; }
    .btn-reject:disabled { opacity: 0.3; }

    /* SYNC & REFRESH BUTTONS */
    .refresh-action-btn, .refresh-btn {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 10px 18px;
      background: white;
      border: 1px solid #e2e8f0;
      border-radius: 10px;
      color: #475569;
      font-size: 0.85rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }

    .refresh-action-btn i, .refresh-btn i {
      color: var(--shaktiman-orange);
      transition: transform 0.5s ease;
    }

    .refresh-action-btn:hover, .refresh-btn:hover {
      background: #f8fafc;
      border-color: var(--shaktiman-orange);
      color: var(--shaktiman-orange);
      box-shadow: 0 4px 12px rgba(255, 106, 0, 0.15);
    }

    .refresh-action-btn:hover i, .refresh-btn:hover i {
      transform: rotate(180deg);
    }

    .refresh-action-btn:active, .refresh-btn:active {
      transform: scale(0.96);
    }

    /* Surrounding Oval 'Well' Container */
    .action-holder {
      background: #0a73db;      
      padding: 5px 12px;        
      border-radius: 50px;      
      display: inline-flex;     
      align-items: center;
      justify-content: center;
      border: 1px solid #e2e8f0;
      box-shadow: inset 0 2px 4px rgba(0,0,0,0.03);
    }

    /* Updated Oval Review Button with Scale Transition */
    .view-btn {
      background: var(--shaktiman-orange);
      color: white;
      border: none;
      padding: 6px 20px;
      border-radius: 50px;      
      cursor: pointer;
      font-weight: 700;
      font-size: 0.75rem;
      text-transform: uppercase;
      letter-spacing: 1px;
      transition: all 0.4s cubic-bezier(0.165, 0.84, 0.44, 1);
      box-shadow: 0 4px 10px rgba(206, 90, 8, 0.2);
      outline: none;
    }

    .view-btn:hover {
      background: #e65c00;
      transform: scale(1.05);   
      box-shadow: 0 6px 15px rgba(255, 106, 0, 0.4);
    }

    .view-btn:active {
      transform: scale(0.95);
    }

    /* Image zoom feature */
.review-img {
  width: 100%; 
  height: 300px; 
  object-fit: contain; 
  background: #000; 
  border-radius: 8px; 
}

.review-img:active {
  transform: scale(2);
  z-index: 999;
  position: relative;
}

    /* CHARTS */
    .custom-bar-chart { height: 120px; display: flex; align-items: flex-end; justify-content: space-between; }
    .bar-col { width: 12%; background: #f1f5f9; height: 100%; position: relative; border-radius: 4px; }
    .bar-fill { position: absolute; bottom: 0; width: 100%; background: var(--shaktiman-orange); border-radius: 4px; }
    .circular-container { width: 80px; height: 80px; margin: 15px auto; }
    .circle-bg { fill: none; stroke: #f1f5f9; stroke-width: 3; }
    .circle-path { fill: none; stroke: var(--shaktiman-orange); stroke-width: 3; stroke-linecap: round; }
    .percentage { font-size: 8px; text-anchor: middle; font-weight: 800; }
  `]
})
export class ManagerDashboardComponent implements OnInit {
  public currentView: string = 'insights';
  public sidebarClosed: boolean = false;
  public plantId: string = "";
  public section: string = "";
  
  public myTotalCount: number = 0;
  public pendingApprovalCount: number = 0;
  public approvedCount: number = 0;

  public pendingKaizens: any[] = [];
  public history: any[] = [];
  public filteredHistory: any[] = [];

  public selectedKaizen: any = null;
  public managerRemark: string = "";
  public searchTerm: string = "";

  constructor(
    private router: Router, 
    private http: HttpClient,
    private cdr: ChangeDetectorRef,
    private route: ActivatedRoute 
  ) {}

  ngOnInit(): void {
  this.plantId = sessionStorage.getItem('plant_id') || "";
  this.section = sessionStorage.getItem('section') || "";

  if (!this.plantId || !this.section) {
    alert("Session expired. Please login again.");
    this.router.navigate(['/admin-login']);
    return;
  }

  // ← ADD THIS BLOCK to handle sidebar navigation from registration page
  this.route.queryParams.subscribe(params => {
    if (params['view']) {
      this.currentView = params['view'];
    }
  });

  this.refreshAllData();
}

  refreshAllData() {
    this.fetchDbStats();
    this.fetchPendingData();
    this.fetchTrackerData();
  }

  fetchDbStats() {
    const url = `http://localhost:8080/api/manager?action=stats&unit=${encodeURIComponent(this.plantId)}&section=${encodeURIComponent(this.section)}`;


    this.http.get<any>(url).subscribe({
      next: (res) => {
        if (!res) return;
        this.myTotalCount = res.total ?? 0;
        this.pendingApprovalCount = res.pending ?? 0;
        this.approvedCount = res.approved ?? 0;
        this.cdr.detectChanges();
      },
      error: (err) => {}
    });
  }

  fetchPendingData() {
    const url = `http://localhost:8080/api/manager?action=pending&unit=${encodeURIComponent(this.plantId)}&section=${encodeURIComponent(this.section)}`;

    this.http.get<any[]>(url).subscribe({
      next: (res) => {
        this.pendingKaizens = res ?? [];
        this.cdr.detectChanges();
      },
      error: (err) => {}
    });
  }

  fetchTrackerData() {
   const url = `http://localhost:8080/api/manager?action=tracker&unit=${encodeURIComponent(this.plantId)}&section=${encodeURIComponent(this.section)}`;

    this.http.get<any[]>(url).subscribe({
      next: (res) => {
        this.history = res ?? [];
        this.filteredHistory = res ?? [];
        this.cdr.detectChanges();
      },
      error: (err) => {}
    });
  }

  openReview(kaizen: any) {
    // Show modal immediately
    this.selectedKaizen = kaizen;
    this.managerRemark = "";
    this.cdr.detectChanges();
 
    // Then fetch full detail with images
    this.http.get<any>(
      `http://localhost:8080/api/kaizen/detail?id=${kaizen.id}&role=${kaizen.role_type}`
    ).subscribe({
      next: (detail) => {
        this.selectedKaizen = { ...kaizen, ...detail };
        this.cdr.detectChanges();
      },
      error: () => { /* modal stays open with list data */ }
    });
  }

  updateStatus(status: string) {
    if (!this.selectedKaizen) return;
    if (status === 'Rejected' && !this.managerRemark.trim()) {
      alert("Manager remark is required for rejection.");
      return;
    }

    const payload = {
      kaizen_id: this.selectedKaizen.kaizen_id,
      role_type: this.selectedKaizen.role_type,
      status: status,
      manager_remark: this.managerRemark
    };

    this.http.post('http://localhost:8080/api/manager/update-status', payload).subscribe({
      next: () => {
        this.pendingKaizens = this.pendingKaizens.filter(k => k.kaizen_id !== this.selectedKaizen.kaizen_id);
        this.selectedKaizen = null;
        this.refreshAllData();
        alert(`Kaizen ${status} Successfully!`);
      },
      error: (err) => alert("Update failed.")
    });
  }

    safeImgSrc(imgData: any): string | null {
    if (!imgData) return null;
    const str = String(imgData).trim();
    if (!str) return null;
    if (str.startsWith('http://') || str.startsWith('https://')) return str;
    if (str.startsWith('data:')) return str;
    if (str.includes('.jpg') || str.includes('.png') || str.includes('.jpeg') || str.includes('.gif') || str.includes('.webp')) {
      return 'http://localhost/kaizen-backend/uploads/' + str;
    }
    if (str.length > 100) return 'data:image/jpeg;base64,' + str;
    return null;
  }

  filterTrackerData() {
    const term = this.searchTerm.toLowerCase();
    this.filteredHistory = this.history.filter(k => 
      (k.emp_name?.toLowerCase().includes(term)) || 
      (k.theme?.toLowerCase().includes(term)) ||
      (k.kaizen_id?.toLowerCase().includes(term))
    );
  }

  getPercentage() {
    const goal = 20;
    if (this.approvedCount === 0) return 0;
    const pct = (this.approvedCount / goal) * 100;
    return pct > 100 ? 100 : Math.round(pct);
  }

  toggleSidebar() { this.sidebarClosed = !this.sidebarClosed; }

  logout() {
    if(confirm("Logout?")) {
      sessionStorage.clear();
      this.router.navigate(['/admin-login']);
    }
  }
}




















































































































// FULL FILE STARTS HERE (DO NOT REMOVE ANYTHING)

/*import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-manager-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, HttpClientModule, FormsModule],
  encapsulation: ViewEncapsulation.None,
  template: `
    <div class="portal-wrapper">
      <aside class="modern-sidebar" [class.collapsed]="sidebarClosed">
        <div class="sidebar-brand">
          <div class="brand-logo">M</div>
          <span class="brand-text">MANAGER<span>PRO</span></span>
        </div>
        
        <nav class="sidebar-nav">
          <a (click)="currentView = 'insights'" class="nav-item" [class.active]="currentView === 'insights'">
            <i class="fas fa-chart-pie"></i> <span>Insights Hub</span>
          </a>
          <a routerLink="/manager-registration" class="nav-item">
            <i class="fas fa-plus-circle"></i> <span>New Kaizen</span>
          </a>
          <a (click)="currentView = 'approvals'" class="nav-item" [class.active]="currentView === 'approvals'">
            <i class="fas fa-clipboard-check"></i> <span>Approval Queue</span>
          </a>
          <a (click)="currentView = 'tracker'" class="nav-item" [class.active]="currentView === 'tracker'">
            <i class="fas fa-history"></i> <span>Team Tracker</span>
          </a>
          
          <div class="nav-divider"></div>
          
          <a (click)="logout()" class="nav-item logout" style="cursor:pointer">
            <i class="fas fa-power-off"></i> <span>Sign Out</span>
          </a>
        </nav>
      </aside>

      <main class="main-viewport">
        <ng-container *ngIf="currentView === 'insights'">
          <header class="glass-header">
            <div class="header-left">
              <button class="menu-btn" (click)="toggleSidebar()">
                <i class="fas fa-bars"></i>
              </button>
              <div class="breadcrumb">
                <span class="parent">Kaizen Portal</span> / <span class="current">Manager Dashboard</span>
              </div>
            </div>
            
            <div class="header-right">
               <button (click)="fetchDbStats()" class="refresh-action-btn" title="Sync Data">
                  <i class="fas fa-sync-alt"></i> <span>Sync Data</span>
              </button>
              <div class="plant-badge">
                <i class="fas fa-map-marker-alt"></i> {{ plantId }} | {{ section }}
              </div>
              <div class="user-avatar-circle">M</div>
            </div>
          </header>

          <div class="content-scroller">
            <div class="bento-grid">
              <div class="bento-tile welcome-tile">
                <h2>Welcome back, Manager!</h2>
                <p>You have <strong>{{ pendingApprovalCount }}</strong> submissions pending your approval.</p>
                <button (click)="currentView = 'approvals'" class="cta-pill">Review Now</button>
              </div>

              <div class="stat-mini-card bg-primary-gradient">
                <div class="stat-content">
                  <span class="label">Total Records</span>
                  <span class="value">{{ myTotalCount }}</span>
                </div>
                <i class="fas fa-database icon-bg"></i>
              </div>

              <div class="stat-mini-card bg-warning-gradient">
                <div class="stat-content">
                  <span class="label">Pending</span>
                  <span class="value">{{ pendingApprovalCount }}</span>
                </div>
                <i class="fas fa-clock icon-bg"></i>
              </div>

              <div class="stat-mini-card bg-success-gradient">
                <div class="stat-content">
                  <span class="label">Approved</span>
                  <span class="value">{{ approvedCount }}</span>
                </div>
                <i class="fas fa-check-circle icon-bg"></i>
              </div>

              <div class="bento-tile graph-tile">
                <div class="tile-header">
                  <h3>Department Efficiency</h3>
                  <span class="subtitle">Monthly Submissions</span>
                </div>
                <div class="custom-bar-chart">
                  <div class="bar-col" *ngFor="let val of [40, 70, 50, 90, 60, 85]">
                    <div class="bar-fill" [style.height.%]="val"></div>
                  </div>
                </div>
                <div class="chart-labels">
                  <span>Jan</span><span>Feb</span><span>Mar</span><span>Apr</span><span>May</span><span>Jun</span>
                </div>
              </div>

              <div class="bento-tile progress-tile">
                <h3>Target Progress</h3>
                <div class="circular-container">
                  <svg viewBox="0 0 36 36" class="circular-chart">
                    <path class="circle-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                    <path class="circle-path" [attr.stroke-dasharray]="getPercentage() + ', 100'" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                    <text x="18" y="21" class="percentage">{{ getPercentage() }}%</text>
                  </svg>
                </div>
                <p class="goal-text">Goal: 20 Approved Kaizens</p>
              </div>
            </div>
          </div>
        </ng-container>

        <ng-container *ngIf="currentView === 'approvals'">
          <header class="glass-header">
            <div class="header-left">
              <div class="breadcrumb">
                Approvals / <span class="unit-tag">{{ plantId || 'N/A' }}</span> / <strong>{{ section || 'N/A' }} SECTION</strong>
              </div>
            </div>
            <div class="header-right">
              <button class="refresh-btn" (click)="fetchPendingData()">
                <i class="fas fa-sync-alt"></i> Refresh Data
              </button>
            </div>
          </header>

          <div class="content-scroller">
            <div class="table-container shadow-smooth">
              <table class="modern-table">
                <thead>
                  <tr>
                    <th>Kaizen ID</th>
                    <th>Employee</th>
                    <th>Theme</th>
                    <th>Level</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <tr *ngFor="let k of pendingKaizens">
                    <td><strong>{{ k.kaizen_id }}</strong></td>
                    <td>{{ k.emp_name }}</td>
                    <td>{{ k.theme }}</td>
                    <td>
                      <span *ngIf="k.role_type"
      class="level-badge"
      [ngClass]="k.role_type === 'Supervisor' ? 'sup' : 
                 k.role_type === 'Operator' ? 'op' : 'mgr'">
  {{ k.role_type }}
</span>
                    </td>
                    <td>
                      <button class="view-btn" (click)="openReview(k)">Review</button>
                    </td>
                  </tr>
                  <tr *ngIf="pendingKaizens.length === 0">
                    <td colspan="5" class="empty-state">No pending approvals found for {{ section }}.</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </ng-container>

        <ng-container *ngIf="currentView === 'tracker'">
          <header class="glass-header">
            <div class="header-left">
              <div class="breadcrumb">
                History / <span class="unit-tag">{{ plantId }}</span> / <strong>{{ section }} SECTION</strong>
              </div>
            </div>
            <div class="header-right search-box">
                <i class="fas fa-search"></i>
                <input type="text" [(ngModel)]="searchTerm" (input)="filterTrackerData()" placeholder="Search employee or theme...">
            </div>
          </header>

          <div class="content-scroller">
            <div class="table-container shadow-smooth">
              <table class="modern-table">
                <thead>
                  <tr>
                    <th>Kaizen ID</th>
                    <th>Level</th>
                    <th>Employee</th>
                    <th>Theme</th>
                    <th>Status</th>
                    <th>Remarks</th>
                  </tr>
                </thead>
                <tbody>
  <tr *ngFor="let k of filteredHistory">

    <td><strong>{{ k.kaizen_id }}</strong></td>

    <td>
      <span *ngIf="k.role_type"
            class="level-badge"
            [ngClass]="{
              'op': k.role_type === 'Operator',
              'sup': k.role_type === 'Supervisor',
              'mgr': k.role_type === 'Manager'
            }">
        {{ k.role_type }}
      </span>
    </td>

    <td>{{ k.emp_name }}</td>

    <td>{{ k.theme }}</td>

    <td>
      <span class="status-pill"
            [ngClass]="{
              'pending': k.status === 'Pending',
              'approved': k.status === 'Approved',
              'rejected': k.status === 'Rejected'
            }">
        {{ k.status }}
      </span>
    </td>

    <td>{{ k.hod_remarks || '---' }}</td>

  </tr>

  <tr *ngIf="filteredHistory.length === 0">
    <td colspan="6" class="empty-state">
      No records found.
    </td>
  </tr>
</tbody>
              </table>
            </div>
          </div>
        </ng-container>
      </main>

      <div class="modal-overlay" *ngIf="selectedKaizen">
  <div class="modal-card">
    <div class="modal-header">
      <h3>Review Kaizen: {{ selectedKaizen.kaizen_id }}</h3>
      <button class="close-x" (click)="selectedKaizen = null">×</button>
    </div>

    <div class="modal-body">

      <div class="info-grid">
        <p><strong>Employee:</strong> {{selectedKaizen.emp_name}}</p>
        <p><strong>Category:</strong> {{selectedKaizen.kaizen_category}}</p>
        <p class="full-width"><strong>Theme:</strong> {{selectedKaizen.theme}}</p>
      </div>

      <!-- Supervisor Extra Fields -->
      <div *ngIf="selectedKaizen.role_type === 'Supervisor'" class="supervisor-block">
    
        <p><strong>PQCDSM Details:</strong> {{selectedKaizen.pqcdsm}}</p>
        
        <p><strong>Problem Status:</strong> {{selectedKaizen.problem_status}}</p>
        <p><strong>Countermeasure:</strong> {{selectedKaizen.countermeasure}}</p>
        <p><strong>Analysis:</strong> {{selectedKaizen.analysis}}</p>
        
     
      </div>

      <div class="comparison-container">

  <div class="comp-box">
    <span class="label before">BEFORE</span>

    <img *ngIf="selectedKaizen?.before_img"
         [src]="selectedKaizen.before_img"
         class="review-img">

    <p class="desc" *ngIf="selectedKaizen?.before_desc">
      {{ selectedKaizen.before_desc }}
    </p>
  </div>

  <div class="comp-box">
    <span class="label after">AFTER</span>

    <img *ngIf="selectedKaizen?.after_img"
         [src]="selectedKaizen.after_img"
         class="review-img">

    <p class="desc" *ngIf="selectedKaizen?.after_desc">
      {{ selectedKaizen.after_desc }}
    </p>
  </div>

</div>

      <div class="benefits-block">
        <h4>Benefits</h4>
        <p>{{selectedKaizen.benefits}}</p>
      </div>

      

      <div class="manager-input">
        <label>Manager Remarks</label>
        <textarea [(ngModel)]="managerRemark"></textarea>
      </div>

    </div>

    <div class="modal-footer">
      <button class="btn-reject"
              (click)="updateStatus('Rejected')"
              [disabled]="!managerRemark">
        Reject
      </button>

      <button class="btn-approve"
              (click)="updateStatus('Approved')">
        Approve
      </button>
    </div>
  </div>
</div>
    </div>
  `,
  styles: [`
    /* Styles preserved as requested 
    .portal-wrapper { display: flex; height: 100vh; width: 100vw; background: #f4f7fe; overflow: hidden; font-family: 'Segoe UI', sans-serif; }
    .modern-sidebar { width: 260px; background: #000; color: white; transition: 0.3s; display: flex; flex-direction: column; z-index: 100; }
    .modern-sidebar.collapsed { width: 80px; }
    .sidebar-brand { padding: 25px; display: flex; align-items: center; gap: 12px; border-bottom: 1px solid #1e293b; }
    .brand-logo { background: #ff7f27; padding: 5px 12px; border-radius: 8px; font-weight: bold; }
    .sidebar-nav { flex: 1; padding: 20px 10px; }
    .nav-item { display: flex; align-items: center; gap: 15px; padding: 12px 15px; color: #94a3b8; text-decoration: none; border-radius: 8px; margin-bottom: 8px; cursor: pointer; }
    .nav-item.active { background: #1e293b; color: #fff; border-left: 4px solid #ff7f27; }
    .nav-divider { height: 1px; background: #1e293b; margin: 15px 5px; }
    .nav-item.logout { color: #ef4444; }
    .main-viewport { flex: 1; display: flex; flex-direction: column; overflow: hidden; }
    .glass-header { height: 70px; background: white; display: flex; justify-content: space-between; align-items: center; padding: 0 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.03); border-bottom: 1px solid #e2e8f0; }
    .header-left { display: flex; align-items: center; gap: 20px; }
    .menu-btn { background: none; border: none; font-size: 18px; cursor: pointer; color: #64748b; }
    .header-right { display: flex; align-items: center; gap: 15px; }
    .refresh-action-btn, .refresh-btn { background: #f8fafc; border: 1px solid #e2e8f0; padding: 8px 14px; border-radius: 8px; cursor: pointer; display: flex; align-items: center; gap: 8px; font-size: 13px; font-weight: 600; color: #475569; }
    .plant-badge { background: #fff7ed; color: #c2410c; padding: 8px 16px; border-radius: 20px; font-size: 13px; font-weight: 700; border: 1px solid #ffedd5; }
    .unit-tag { color: #ff7f27; font-weight: bold; }
    .user-avatar-circle { width: 38px; height: 38px; background: #f1f5f9; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; color: #475569; border: 1px solid #e2e8f0; }
    .content-scroller { flex: 1; padding: 25px; overflow-y: auto; }
    .bento-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; max-width: 1400px; margin: 0 auto; }
    .bento-tile { background: white; border-radius: 16px; padding: 22px; border: 1px solid #e2e8f0; box-shadow: 0 4px 6px rgba(0,0,0,0.01); }
    .welcome-tile { grid-column: span 2; background: linear-gradient(135deg, #1e293b 0%, #000 100%); color: white; }
    .cta-pill { background: #ff7f27; border: none; padding: 8px 20px; border-radius: 20px; color: white; font-weight: bold; cursor: pointer; margin-top: 10px; }
    .stat-mini-card { padding: 20px; border-radius: 16px; color: white; position: relative; overflow: hidden; display: flex; align-items: center; }
    .bg-primary-gradient { background: linear-gradient(135deg, #6366f1 0%, #4338ca 100%); }
    .bg-warning-gradient { background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); }
    .bg-success-gradient { background: linear-gradient(135deg, #22c55e 0%, #15803d 100%); }
    .icon-bg { position: absolute; right: -10px; bottom: -10px; font-size: 55px; opacity: 0.15; transform: rotate(-15deg); }
    .value { font-size: 28px; font-weight: bold; display: block; }
    .table-container { background: white; border-radius: 12px; overflow: hidden; border: 1px solid #e2e8f0; }
    .modern-table { width: 100%; border-collapse: collapse; }
    .modern-table th { background: #f8fafc; padding: 15px; text-align: left; color: #64748b; font-size: 12px; text-transform: uppercase; }
    .modern-table td { padding: 18px 15px; border-bottom: 1px solid #f1f5f9; font-size: 14px; }
    .level-badge { padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight:600;color: #fff;display: inline-block; }
    .level-badge.sup { background: #fff7ed; color: #c2410c; }
    .level-badge.op { background: #f0f9ff; color: #0369a1; }
    .view-btn { background: #ff7f27; color: white; border: none; padding: 8px 16px; border-radius: 8px; cursor: pointer; font-weight: 600; }
    .status-pill { padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: bold; }
    .status-pill.pending { background: #fff3cd; color: #856404; }
    .status-pill.approved { background: #dcfce7; color: #166534; }
    .status-pill.rejected { background: #fee2e2; color: #991b1b; }
    .empty-state { text-align: center; padding: 40px; color: #94a3b8; }
    .search-box { position: relative; }
    .search-box input { padding: 8px 12px 8px 35px; border: 1px solid #ddd; border-radius: 8px; width: 250px; }
    .search-box i { position: absolute; left: 12px; top: 11px; color: #999; }
    .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; }
    .modal-card { background: white; width: 800px; max-height: 90vh; border-radius: 12px; display: flex; flex-direction: column; }
    .modal-header { padding: 20px; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; }
    .modal-body { padding: 20px; overflow-y: auto; }
    .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 20px; }
    .full-width { grid-column: span 2; }
    .comparison-container { display: flex; gap: 15px; margin-bottom: 20px; }
    .comp-box { flex: 1; border: 1px solid #eee; border-radius: 12px; padding: 15px; position: relative;background: #fafafa;display: flex;flex-direction: column;align-items: center; }
    .comp-box img { width: 100%; height: 350px; object-fit: contain ;background: #000; border-radius: 8px;margin-top: 25px; }
    .label { position: absolute; top: 10px; left: 10px; padding: 4px 12px; color: white; font-size: 11px; font-weight: bold; border-radius: 4px;z-index: 10; }
    .before { background: #ef4444; }
    .after { background: #22c55e; }
    .manager-input textarea { width: 100%; height: 80px; padding: 10px; border: 1px solid #ddd; border-radius: 8px; resize: vertical; }
    .modal-footer { padding: 20px; border-top: 1px solid #eee; display: flex; justify-content: flex-end; gap: 10px; }
    .btn-approve { background: #22c55e; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: bold; }
    .btn-reject { background: #ef4444; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: bold; }
    .btn-reject:disabled { opacity: 0.5; cursor: not-allowed; }
    .close-x { background: none; border: none; font-size: 20px; cursor: pointer; }
    .graph-tile { grid-column: span 2; }
    .custom-bar-chart { height: 130px; display: flex; align-items: flex-end; justify-content: space-between; margin-top: 20px; padding: 0 10px; }
    .bar-col { width: 12%; background: #f1f5f9; border-radius: 6px; height: 100%; position: relative; }
    .bar-fill { position: absolute; bottom: 0; width: 100%; background: linear-gradient(to top, #ff7f27, #ff9d5c); border-radius: 6px; }
    .chart-labels { display: flex; justify-content: space-between; margin-top: 10px; padding: 0 10px; }
    .chart-labels span { font-size: 11px; font-weight: 600; color: #94a3b8; width: 12%; text-align: center; }
    .circular-container { width: 100px; height: 100px; margin: 15px 0; }
    .circle-bg { fill: none; stroke: #f1f5f9; stroke-width: 3.8; }
    .circle-path { fill: none; stroke: #ff7f27; stroke-width: 3.8; stroke-linecap: round; }
    .percentage { fill: #1e293b; font-size: 8px; text-anchor: middle; font-weight: bold; }
  `]
})
export class ManagerDashboardComponent implements OnInit {
  public currentView: string = 'insights';
  public sidebarClosed: boolean = false;
  public plantId: string = "";
  public section: string = "";
  
  public myTotalCount: number = 0;
  public pendingApprovalCount: number = 0;
  public approvedCount: number = 0;

  public pendingKaizens: any[] = [];
  public history: any[] = [];
  public filteredHistory: any[] = [];

  public selectedKaizen: any = null;
  public managerRemark: string = "";
  public searchTerm: string = "";

  constructor(
    private router: Router, 
    private http: HttpClient,
    private cdr: ChangeDetectorRef 
  ) {}

  ngOnInit(): void {
    this.plantId = sessionStorage.getItem('plant_id') || "";
    this.section = sessionStorage.getItem('section') || "";

    // 🔥 IMPORTANT FIX
    if (!this.plantId || !this.section) {
      alert("Session expired. Please login again.");
      this.router.navigate(['/admin-login']);
      return;
    }

    this.refreshAllData();
  }

  refreshAllData() {
    this.fetchDbStats();
    this.fetchPendingData();
    this.fetchTrackerData();
  }

  fetchDbStats() {
    const url = `http://localhost/kaizen-backend/demo/manager_handler.php?action=stats&unit=${encodeURIComponent(this.plantId)}&section=${encodeURIComponent(this.section)}`;
    
    this.http.get<any>(url).subscribe({
      next: (res) => {
        if (!res) return;

        this.myTotalCount = res.total ?? 0;
        this.pendingApprovalCount = res.pending ?? 0;
        this.approvedCount = res.approved ?? 0;
        this.cdr.detectChanges();
      },
      error: (err) => {}
    });
  }

  fetchPendingData() {
    const url = `http://localhost/kaizen-backend/demo/manager_handler.php?action=pending&unit=${encodeURIComponent(this.plantId)}&section=${encodeURIComponent(this.section)}`;
    
    this.http.get<any[]>(url).subscribe({
      next: (res) => {
        this.pendingKaizens = res ?? [];
        this.cdr.detectChanges();
      },
      error: (err) => {}
    });
  }

  fetchTrackerData() {
    const url = `http://localhost/kaizen-backend/demo/manager_handler.php?action=tracker&unit=${encodeURIComponent(this.plantId)}&section=${encodeURIComponent(this.section)}`;
    
    this.http.get<any[]>(url).subscribe({
      next: (res) => {
        this.history = res ?? [];
        this.filteredHistory = res ?? [];
        this.cdr.detectChanges();
      },
      error: (err) => {}
    });
  }

  openReview(kaizen: any) {
    this.selectedKaizen = kaizen;
    this.managerRemark = "";
    this.cdr.detectChanges();
  }

  updateStatus(status: string) {

  if (!this.selectedKaizen) return;

  if (status === 'Rejected' && !this.managerRemark.trim()) {
    alert("Manager remark is required for rejection.");
    return;
  }

  const payload = {
    kaizen_id: this.selectedKaizen.kaizen_id,
    role_type: this.selectedKaizen.role_type,
    status: status,
    manager_remark: this.managerRemark
  };

  this.http.post(
  'http://localhost/kaizen-backend/demo/manager_handler.php?action=update_status',
  payload
).subscribe({
    next: () => {

      // ✅ REMOVE from local list immediately
      this.pendingKaizens = this.pendingKaizens.filter(
        k => k.kaizen_id !== this.selectedKaizen.kaizen_id
      );

      this.selectedKaizen = null;

      // ✅ Refresh everything
      this.refreshAllData();

      alert(`Kaizen ${status} Successfully!`);
    },
    error: (err) => {
      (err);
      alert("Update failed.");
    }
  });
}

  filterTrackerData() {
    const term = this.searchTerm.toLowerCase();
    this.filteredHistory = this.history.filter(k => 
      (k.emp_name?.toLowerCase().includes(term)) || 
      (k.theme?.toLowerCase().includes(term)) ||
      (k.kaizen_id?.toLowerCase().includes(term))
    );
  }

  getPercentage() {
    const goal = 20;
    if (this.approvedCount === 0) return 0;
    const pct = (this.approvedCount / goal) * 100;
    return pct > 100 ? 100 : Math.round(pct);
  }

  toggleSidebar() { this.sidebarClosed = !this.sidebarClosed; }

  logout() {
    if(confirm("Logout?")) {
      sessionStorage.clear();
      this.router.navigate(['/admin-login']);
    }
  }
}*/

























/*
------old------

import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-manager-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, HttpClientModule, FormsModule],
  encapsulation: ViewEncapsulation.None,
  template: `
    <div class="portal-wrapper">
      <aside class="modern-sidebar" [class.collapsed]="sidebarClosed">
        <div class="sidebar-brand">
          <div class="brand-logo">M</div>
          <span class="brand-text">MANAGER<span>PRO</span></span>
        </div>
        
        <nav class="sidebar-nav">
          <a (click)="currentView = 'insights'" class="nav-item" [class.active]="currentView === 'insights'">
            <i class="fas fa-chart-pie"></i> <span>Insights Hub</span>
          </a>
          <a routerLink="/manager-registration" class="nav-item">
            <i class="fas fa-plus-circle"></i> <span>New Kaizen</span>
          </a>
          <a (click)="currentView = 'approvals'" class="nav-item" [class.active]="currentView === 'approvals'">
            <i class="fas fa-clipboard-check"></i> <span>Approval Queue</span>
          </a>
          <a (click)="currentView = 'tracker'" class="nav-item" [class.active]="currentView === 'tracker'">
            <i class="fas fa-history"></i> <span>Team Tracker</span>
          </a>
          
          <div class="nav-divider"></div>
          
          <a (click)="logout()" class="nav-item logout" style="cursor:pointer">
            <i class="fas fa-power-off"></i> <span>Sign Out</span>
          </a>
        </nav>
      </aside>

      <main class="main-viewport">
        <ng-container *ngIf="currentView === 'insights'">
          <header class="glass-header">
            <div class="header-left">
              <button class="menu-btn" (click)="toggleSidebar()">
                <i class="fas fa-bars"></i>
              </button>
              <div class="breadcrumb">
                <span class="parent">Kaizen Portal</span> / <span class="current">Manager Dashboard</span>
              </div>
            </div>
            
            <div class="header-right">
               <button (click)="fetchDbStats()" class="refresh-action-btn" title="Sync Data">
                  <i class="fas fa-sync-alt"></i> <span>Sync Data</span>
              </button>
              <div class="plant-badge">
                <i class="fas fa-map-marker-alt"></i> {{ plantId }} | {{ section }}
              </div>
              <div class="user-avatar-circle">M</div>
            </div>
          </header>

          <div class="content-scroller">
            <div class="bento-grid">
              <div class="bento-tile welcome-tile">
                <h2>Welcome back, Manager!</h2>
                <p>You have <strong>{{ pendingApprovalCount }}</strong> submissions pending your approval.</p>
                <button (click)="currentView = 'approvals'" class="cta-pill">Review Now</button>
              </div>

              <div class="stat-mini-card bg-primary-gradient">
                <div class="stat-content">
                  <span class="label">Total Records</span>
                  <span class="value">{{ myTotalCount }}</span>
                </div>
                <i class="fas fa-database icon-bg"></i>
              </div>

              <div class="stat-mini-card bg-warning-gradient">
                <div class="stat-content">
                  <span class="label">Pending</span>
                  <span class="value">{{ pendingApprovalCount }}</span>
                </div>
                <i class="fas fa-clock icon-bg"></i>
              </div>

              <div class="stat-mini-card bg-success-gradient">
                <div class="stat-content">
                  <span class="label">Approved</span>
                  <span class="value">{{ approvedCount }}</span>
                </div>
                <i class="fas fa-check-circle icon-bg"></i>
              </div>

              <div class="bento-tile graph-tile">
                <div class="tile-header">
                  <h3>Department Efficiency</h3>
                  <span class="subtitle">Monthly Submissions</span>
                </div>
                <div class="custom-bar-chart">
                  <div class="bar-col" *ngFor="let val of [40, 70, 50, 90, 60, 85]">
                    <div class="bar-fill" [style.height.%]="val"></div>
                  </div>
                </div>
                <div class="chart-labels">
                  <span>Jan</span><span>Feb</span><span>Mar</span><span>Apr</span><span>May</span><span>Jun</span>
                </div>
              </div>

              <div class="bento-tile progress-tile">
                <h3>Target Progress</h3>
                <div class="circular-container">
                  <svg viewBox="0 0 36 36" class="circular-chart">
                    <path class="circle-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                    <path class="circle-path" [attr.stroke-dasharray]="getPercentage() + ', 100'" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                    <text x="18" y="21" class="percentage">{{ getPercentage() }}%</text>
                  </svg>
                </div>
                <p class="goal-text">Goal: 20 Approved Kaizens</p>
              </div>
            </div>
          </div>
        </ng-container>

        <ng-container *ngIf="currentView === 'approvals'">
          <header class="glass-header">
            <div class="header-left">
              <div class="breadcrumb">
                Approvals / <span class="unit-tag">{{ plantId || 'N/A' }}</span> / <strong>{{ section || 'N/A' }} SECTION</strong>
              </div>
            </div>
            <div class="header-right">
              <button class="refresh-btn" (click)="fetchPendingData()">
                <i class="fas fa-sync-alt"></i> Refresh Data
              </button>
            </div>
          </header>

          <div class="content-scroller">
            <div class="table-container shadow-smooth">
              <table class="modern-table">
                <thead>
                  <tr>
                    <th>Kaizen ID</th>
                    <th>Employee</th>
                    <th>Theme</th>
                    <th>Level</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <tr *ngFor="let k of pendingKaizens">
                    <td><strong>{{ k.kaizen_id }}</strong></td>
                    <td>{{ k.emp_name }}</td>
                    <td>{{ k.theme }}</td>
                    <td>
                      <span class="level-badge" [ngClass]="k.level === 'Supervisor' ? 'sup' : 'op'">
                        {{ k.level }}
                      </span>
                    </td>
                    <td>
                      <button class="view-btn" (click)="openReview(k)">Review</button>
                    </td>
                  </tr>
                  <tr *ngIf="pendingKaizens.length === 0">
                    <td colspan="5" class="empty-state">No pending approvals found for {{ section }}.</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </ng-container>

        <ng-container *ngIf="currentView === 'tracker'">
          <header class="glass-header">
            <div class="header-left">
              <div class="breadcrumb">
                History / <span class="unit-tag">{{ plantId }}</span> / <strong>{{ section }} SECTION</strong>
              </div>
            </div>
            <div class="header-right search-box">
                <i class="fas fa-search"></i>
                <input type="text" [(ngModel)]="searchTerm" (input)="filterTrackerData()" placeholder="Search employee or theme...">
            </div>
          </header>

          <div class="content-scroller">
            <div class="table-container shadow-smooth">
              <table class="modern-table">
                <thead>
                  <tr>
                    <th>Kaizen ID</th>
                    <th>Employee</th>
                    <th>Theme</th>
                    <th>Status</th>
                    <th>Remarks</th>
                  </tr>
                </thead>
                <tbody>
                  <tr *ngFor="let k of filteredHistory">
                    <td><strong>{{ k.kaizen_id }}</strong></td>
                    <td>
                      {{ k.emp_name }}
                      <span class="level-badge" [ngClass]="k.level === 'Supervisor' ? 'sup' : 'op'">{{ k.level }}</span>
                    </td>
                    <td>{{ k.theme }}</td>
                    <td>
                      <span class="status-pill" [ngClass]="k.status.toLowerCase()">
                        {{ k.status }}
                      </span>
                    </td>
                    <td class="remark-cell">{{ k.hod_remarks || '---' }}</td>
                  </tr>
                  <tr *ngIf="filteredHistory.length === 0">
                    <td colspan="5" class="empty-state">No records found for your search.</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </ng-container>
      </main>

      <div class="modal-overlay" *ngIf="selectedKaizen">
        <div class="modal-card">
          <div class="modal-header">
            <h3>Review Kaizen: {{ selectedKaizen.kaizen_id }}</h3>
            <button class="close-x" (click)="selectedKaizen = null">×</button>
          </div>
          
          <div class="modal-body">
            <div class="info-grid">
              <p><strong>Employee:</strong> {{selectedKaizen.emp_name}}</p>
              <p><strong>Category:</strong> {{selectedKaizen.kaizen_category}}</p>
              <p class="full-width"><strong>Theme:</strong> {{selectedKaizen.theme}}</p>
            </div>
            
            <div class="comparison-container">
              <div class="comp-box">
                <span class="label before">BEFORE</span>
                <img *ngIf="selectedKaizen.before_img" [src]="'data:image/png;base64,' + selectedKaizen.before_img">
                <p class="desc">{{selectedKaizen.before_desc}}</p>
              </div>
              <div class="comp-box">
                <span class="label after">AFTER</span>
                <img *ngIf="selectedKaizen.after_img" [src]="'data:image/png;base64,' + selectedKaizen.after_img">
                <p class="desc">{{selectedKaizen.after_desc}}</p>
              </div>
            </div>

            <div class="manager-input">
              <label>Manager Remarks (Required for Rejection/Correction)</label>
              <textarea [(ngModel)]="managerRemark" placeholder="Add your comments here..."></textarea>
            </div>
          </div>

          <div class="modal-footer">
            <button class="btn-reject" (click)="updateStatus('Rejected')" [disabled]="!managerRemark">Reject</button>
            <button class="btn-approve" (click)="updateStatus('Approved')">Approve</button>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    /* Styles preserved as requested 
    .portal-wrapper { display: flex; height: 100vh; width: 100vw; background: #f4f7fe; overflow: hidden; font-family: 'Segoe UI', sans-serif; }
    .modern-sidebar { width: 260px; background: #000; color: white; transition: 0.3s; display: flex; flex-direction: column; z-index: 100; }
    .modern-sidebar.collapsed { width: 80px; }
    .sidebar-brand { padding: 25px; display: flex; align-items: center; gap: 12px; border-bottom: 1px solid #1e293b; }
    .brand-logo { background: #ff7f27; padding: 5px 12px; border-radius: 8px; font-weight: bold; }
    .sidebar-nav { flex: 1; padding: 20px 10px; }
    .nav-item { display: flex; align-items: center; gap: 15px; padding: 12px 15px; color: #94a3b8; text-decoration: none; border-radius: 8px; margin-bottom: 8px; cursor: pointer; }
    .nav-item.active { background: #1e293b; color: #fff; border-left: 4px solid #ff7f27; }
    .nav-divider { height: 1px; background: #1e293b; margin: 15px 5px; }
    .nav-item.logout { color: #ef4444; }
    .main-viewport { flex: 1; display: flex; flex-direction: column; overflow: hidden; }
    .glass-header { height: 70px; background: white; display: flex; justify-content: space-between; align-items: center; padding: 0 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.03); border-bottom: 1px solid #e2e8f0; }
    .header-left { display: flex; align-items: center; gap: 20px; }
    .menu-btn { background: none; border: none; font-size: 18px; cursor: pointer; color: #64748b; }
    .header-right { display: flex; align-items: center; gap: 15px; }
    .refresh-action-btn, .refresh-btn { background: #f8fafc; border: 1px solid #e2e8f0; padding: 8px 14px; border-radius: 8px; cursor: pointer; display: flex; align-items: center; gap: 8px; font-size: 13px; font-weight: 600; color: #475569; }
    .plant-badge { background: #fff7ed; color: #c2410c; padding: 8px 16px; border-radius: 20px; font-size: 13px; font-weight: 700; border: 1px solid #ffedd5; }
    .unit-tag { color: #ff7f27; font-weight: bold; }
    .user-avatar-circle { width: 38px; height: 38px; background: #f1f5f9; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; color: #475569; border: 1px solid #e2e8f0; }
    .content-scroller { flex: 1; padding: 25px; overflow-y: auto; }
    .bento-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; max-width: 1400px; margin: 0 auto; }
    .bento-tile { background: white; border-radius: 16px; padding: 22px; border: 1px solid #e2e8f0; box-shadow: 0 4px 6px rgba(0,0,0,0.01); }
    .welcome-tile { grid-column: span 2; background: linear-gradient(135deg, #1e293b 0%, #000 100%); color: white; }
    .cta-pill { background: #ff7f27; border: none; padding: 8px 20px; border-radius: 20px; color: white; font-weight: bold; cursor: pointer; margin-top: 10px; }
    .stat-mini-card { padding: 20px; border-radius: 16px; color: white; position: relative; overflow: hidden; display: flex; align-items: center; }
    .bg-primary-gradient { background: linear-gradient(135deg, #6366f1 0%, #4338ca 100%); }
    .bg-warning-gradient { background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); }
    .bg-success-gradient { background: linear-gradient(135deg, #22c55e 0%, #15803d 100%); }
    .icon-bg { position: absolute; right: -10px; bottom: -10px; font-size: 55px; opacity: 0.15; transform: rotate(-15deg); }
    .value { font-size: 28px; font-weight: bold; display: block; }
    .table-container { background: white; border-radius: 12px; overflow: hidden; border: 1px solid #e2e8f0; }
    .modern-table { width: 100%; border-collapse: collapse; }
    .modern-table th { background: #f8fafc; padding: 15px; text-align: left; color: #64748b; font-size: 12px; text-transform: uppercase; }
    .modern-table td { padding: 18px 15px; border-bottom: 1px solid #f1f5f9; font-size: 14px; }
    .level-badge { padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: bold; }
    .level-badge.sup { background: #fff7ed; color: #c2410c; }
    .level-badge.op { background: #f0f9ff; color: #0369a1; }
    .view-btn { background: #ff7f27; color: white; border: none; padding: 8px 16px; border-radius: 8px; cursor: pointer; font-weight: 600; }
    .status-pill { padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: bold; }
    .status-pill.approved { background: #dcfce7; color: #166534; }
    .status-pill.rejected { background: #fee2e2; color: #991b1b; }
    .empty-state { text-align: center; padding: 40px; color: #94a3b8; }
    .search-box { position: relative; }
    .search-box input { padding: 8px 12px 8px 35px; border: 1px solid #ddd; border-radius: 8px; width: 250px; }
    .search-box i { position: absolute; left: 12px; top: 11px; color: #999; }
    .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; }
    .modal-card { background: white; width: 800px; max-height: 90vh; border-radius: 12px; display: flex; flex-direction: column; }
    .modal-header { padding: 20px; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; }
    .modal-body { padding: 20px; overflow-y: auto; }
    .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 20px; }
    .full-width { grid-column: span 2; }
    .comparison-container { display: flex; gap: 15px; margin-bottom: 20px; }
    .comp-box { flex: 1; border: 1px solid #eee; border-radius: 12px; padding: 15px; position: relative;background: #fafafa;display: flex;flex-direction: column;align-items: center; }
    .comp-box img { width: 100%; height: 350px; object-fit: contain ;background: #000; border-radius: 8px;margin-top: 25px; }
    .label { position: absolute; top: 10px; left: 10px; padding: 4px 12px; color: white; font-size: 11px; font-weight: bold; border-radius: 4px;z-index: 10; }
    .before { background: #ef4444; }
    .after { background: #22c55e; }
    .manager-input textarea { width: 100%; height: 80px; padding: 10px; border: 1px solid #ddd; border-radius: 8px; resize: vertical; }
    .modal-footer { padding: 20px; border-top: 1px solid #eee; display: flex; justify-content: flex-end; gap: 10px; }
    .btn-approve { background: #22c55e; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: bold; }
    .btn-reject { background: #ef4444; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: bold; }
    .btn-reject:disabled { opacity: 0.5; cursor: not-allowed; }
    .close-x { background: none; border: none; font-size: 20px; cursor: pointer; }
    .graph-tile { grid-column: span 2; }
    .custom-bar-chart { height: 130px; display: flex; align-items: flex-end; justify-content: space-between; margin-top: 20px; padding: 0 10px; }
    .bar-col { width: 12%; background: #f1f5f9; border-radius: 6px; height: 100%; position: relative; }
    .bar-fill { position: absolute; bottom: 0; width: 100%; background: linear-gradient(to top, #ff7f27, #ff9d5c); border-radius: 6px; }
    .chart-labels { display: flex; justify-content: space-between; margin-top: 10px; padding: 0 10px; }
    .chart-labels span { font-size: 11px; font-weight: 600; color: #94a3b8; width: 12%; text-align: center; }
    .circular-container { width: 100px; height: 100px; margin: 15px 0; }
    .circle-bg { fill: none; stroke: #f1f5f9; stroke-width: 3.8; }
    .circle-path { fill: none; stroke: #ff7f27; stroke-width: 3.8; stroke-linecap: round; }
    .percentage { fill: #1e293b; font-size: 8px; text-anchor: middle; font-weight: bold; }
  `]
})
export class ManagerDashboardComponent implements OnInit {
  public currentView: string = 'insights';
  public sidebarClosed: boolean = false;
  public plantId: string = "";
  public section: string = "";
  
  // Dashboard Stats
  public myTotalCount: number = 0;
  public pendingApprovalCount: number = 0;
  public approvedCount: number = 0;

  // IMPORTANT: Initialized as empty arrays [] to prevent .length null errors
  public pendingKaizens: any[] = [];
  public history: any[] = [];
  public filteredHistory: any[] = [];

  public selectedKaizen: any = null;
  public managerRemark: string = "";
  public searchTerm: string = "";

  constructor(
    private router: Router, 
    private http: HttpClient,
    private cdr: ChangeDetectorRef 
  ) {}

  ngOnInit(): void {
    this.plantId = sessionStorage.getItem('plant_id') || "";
    this.section = sessionStorage.getItem('section') || "";
    this.refreshAllData();
  }

  refreshAllData() {
    this.fetchDbStats();
    this.fetchPendingData();
    this.fetchTrackerData();
  }

  fetchDbStats() {
    if (!this.plantId || !this.section) return;
    const url = `http://localhost/kaizen-backend/demo/manager_handler.php?action=stats&unit=${encodeURIComponent(this.plantId)}&section=${encodeURIComponent(this.section)}`;
    
    this.http.get<any>(url).subscribe({
      next: (res) => {
        this.myTotalCount = res.total || 0;
        this.pendingApprovalCount = res.pending || 0;
        this.approvedCount = res.approved || 0;
        this.cdr.detectChanges();
      },
      error: (err) => {}
    });
  }

  fetchPendingData() {
    if (!this.plantId || !this.section) return;
    // Updated to use the correct PHP action "pending"
    const url = `http://localhost/kaizen-backend/demo/manager_handler.php?action=pending&unit=${encodeURIComponent(this.plantId)}&section=${encodeURIComponent(this.section)}`;
    this.http.get<any[]>(url).subscribe({
      next: (res) => {
        this.pendingKaizens = res || [];
        this.cdr.detectChanges();
      },
      error: (err) => {}
    });
  }

  fetchTrackerData() {
    if (!this.plantId || !this.section) return;
    // Updated to use the correct PHP action "tracker"
    const url = `http://localhost/kaizen-backend/demo/manager_handler.php?action=tracker&unit=${encodeURIComponent(this.plantId)}&section=${encodeURIComponent(this.section)}`;
    this.http.get<any[]>(url).subscribe({
      next: (res) => {
        this.history = res || [];
        this.filteredHistory = res || [];
        this.cdr.detectChanges();
      },
      error: (err) => {}
    });
  }

  openReview(kaizen: any) {
    this.selectedKaizen = kaizen;
    this.managerRemark = "";
    this.cdr.detectChanges();
  }

  updateStatus(status: string) {
    if (!this.selectedKaizen) return;
    const payload = {
      kaizen_id: this.selectedKaizen.kaizen_id,
      level: this.selectedKaizen.level,
      status: status,
      remark: this.managerRemark
    };

    // Note: Update-status requires your existing API. Ensure this endpoint is also on Port 80
    this.http.post('http://localhost/kaizen-backend/api/kaizen/update-status', payload).subscribe({
      next: () => {
        alert(`Kaizen ${status} Successfully!`);
        this.selectedKaizen = null;
        this.refreshAllData();
      }
    });
  }

  filterTrackerData() {
    const term = this.searchTerm.toLowerCase();
    this.filteredHistory = this.history.filter(k => 
      (k.emp_name?.toLowerCase().includes(term)) || 
      (k.theme?.toLowerCase().includes(term)) ||
      (k.kaizen_id?.toLowerCase().includes(term))
    );
  }

  getPercentage() {
    const goal = 20;
    if (this.approvedCount === 0) return 0;
    const pct = (this.approvedCount / goal) * 100;
    return pct > 100 ? 100 : Math.round(pct);
  }

  toggleSidebar() { this.sidebarClosed = !this.sidebarClosed; }

  logout() {
    if(confirm("Logout?")) {
      sessionStorage.clear();
      this.router.navigate(['/admin-login']);
    }
  }
}*/