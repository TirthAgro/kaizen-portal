import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot } from '@angular/router';

@Injectable({ providedIn: 'root' })
export class RoleGuard implements CanActivate {
  constructor(private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot): boolean {
    const userRole = sessionStorage.getItem('role');
    const allowedRoles: string[] = route.data['roles'];

    if (!userRole || !allowedRoles.includes(userRole)) {
      alert('Access Denied. You do not have permission to view this page.');
      this.router.navigate(['/login']);
      return false;
    }
    return true;
  }
}