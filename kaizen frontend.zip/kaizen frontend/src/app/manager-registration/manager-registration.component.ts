import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-manager-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule, RouterModule],
  encapsulation: ViewEncapsulation.None,
  template: `
    <div class="app-container">
      <aside class="sidebar-pillar" [class.is-collapsed]="sidebarClosed">
        <div class="gloss-shine"></div>
        <div class="sidebar-header">
           <div class="brand-shell">
             <span class="brand-name">MANAGER</span>
             <span class="brand-sub">PRO PANEL</span>
           </div>
        </div>
        <nav class="navigation-hub">
          <a routerLink="/manager-dashboard" class="nav-item">
            <div class="nav-glow"></div>
            <i class="nav-icon">📊</i>
            <span class="nav-label">INSIGHTS HUB</span>
          </a>
          <a routerLink="/manager-registration" class="nav-item active">
            <div class="nav-glow"></div>
            <i class="nav-icon">➕</i>
            <span class="nav-label">NEW KAIZEN</span>
          </a>
          <a routerLink="/manager-dashboard" [queryParams]="{view: 'approvals'}" class="nav-item">
            <div class="nav-glow"></div>
            <i class="nav-icon">✅</i>
            <span class="nav-label">APPROVAL QUEUE</span>
          </a>
          <a routerLink="/manager-dashboard" [queryParams]="{view: 'tracker'}" class="nav-item">
            <div class="nav-glow"></div>
            <i class="nav-icon">🕒</i>
            <span class="nav-label">TEAM TRACKER</span>
          </a>
        </nav>
        <div class="sidebar-footer">
          <button (click)="logout()" class="logout-trigger"><span>EXIT PORTAL</span></button>
        </div>
      </aside>

      <div class="main-viewport">
        <header class="premium-topbar">
          <div class="bar-left">
            <button class="menu-toggle" (click)="toggleSidebar()">
              <div class="hamburger-box">
                <span class="line"></span><span class="line"></span><span class="line"></span>
              </div>
            </button>
            <h1 class="portal-heading">SHAKTIMAN <span class="thin">KAIZEN PORTAL</span></h1>
          </div>
          <div class="bar-right">
             <div class="logo-badge"><img src="assets/shaktiman_logo.png" alt="Shaktiman"></div>
          </div>
        </header>

        <main class="content-arena">

          <!-- CONFIRM MODAL -->
          <div class="custom-overlay" *ngIf="showConfirmModal">
            <div class="modern-modal">
              <div class="modal-icon">?</div>
              <h3>Confirm Registration</h3>
              <p>Are you sure you want to submit this Manager Kaizen?</p>
              <div class="modal-preview-box">
                <strong>Kaizen ID:</strong> {{ kaizenNo }}<br>
                <strong>Theme:</strong> {{ kaizenForm.value.theme }}
              </div>
              <div class="modal-actions">
                <button class="btn-cancel" (click)="showConfirmModal = false">Review</button>
                <button class="btn-confirm" (click)="finalSubmit()">Submit Now</button>
              </div>
            </div>
          </div>

          <!-- SUCCESS MODAL -->
          <div class="custom-overlay" *ngIf="showSuccessModal">
            <div class="modern-modal success-style">
              <div class="modal-icon check">✔</div>
              <h3>Success!</h3>
              <p>Manager Kaizen <strong>{{ lastSubmittedNo }}</strong> registered.</p>
              <button class="btn-confirm" (click)="showSuccessModal = false">Great!</button>
            </div>
          </div>

          <div class="container-main">
            <div class="form-card">
              <header class="form-header-inner" style="display:flex;justify-content:space-between;align-items:center;">
                <div>
                  <span class="brand-label">SHAKTIMAN KAIZEN PORTAL</span>
                  <h2>Manager Level Entry</h2>
                </div>
                <div style="text-align:right;">
                  <div style="font-size:14px;font-weight:bold;color:#fff;">ID: {{ kaizenNo }}</div>
                  <div style="font-size:12px;color:#ff7f27;">{{ today | date:'dd-MMM-yyyy' }}</div>
                </div>
              </header>

              <form [formGroup]="kaizenForm" (ngSubmit)="onPreSubmit()" class="form-content">

                <div class="row-grid">
                  <div class="field">
                    <label>Employee ID <span class="req">*</span></label>
                    <input type="text" formControlName="emp_id"
                           (keypress)="allowNumbersOnly($event)" placeholder="Numbers only">
                    <div class="err-msg" *ngIf="kaizenForm.get('emp_id')?.touched && kaizenForm.get('emp_id')?.errors?.['required']">Employee ID is required</div>
                    <div class="err-msg" *ngIf="kaizenForm.get('emp_id')?.touched && kaizenForm.get('emp_id')?.errors?.['pattern']">Numbers only allowed</div>
                  </div>
                  <div class="field">
                    <label>Manager Name <span class="req">*</span></label>
                    <input type="text" formControlName="emp_name"
                           (keypress)="allowAlphabetsOnly($event)" placeholder="Alphabets only">
                    <div class="err-msg" *ngIf="kaizenForm.get('emp_name')?.touched && kaizenForm.get('emp_name')?.errors?.['required']">Manager Name is required</div>
                    <div class="err-msg" *ngIf="kaizenForm.get('emp_name')?.touched && kaizenForm.get('emp_name')?.errors?.['pattern']">Alphabets only allowed</div>
                  </div>
                  <div class="field">
                    <label>Plant (Unit) <span class="req">*</span></label>
                    <select formControlName="unit" (change)="onPlantChange()">
                      <option value="">Select Plant</option>
                      <option value="Unit 1">Unit 1</option>
                      <option value="Unit 2">Unit 2</option>
                      <option value="Unit 3">Unit 3</option>
                      <option value="Unit 4">Unit 4</option>
                      <option value="Unit 5">Unit 5</option>
                    </select>
                    <div class="err-msg" *ngIf="kaizenForm.get('unit')?.touched && kaizenForm.get('unit')?.errors?.['required']">Plant is required</div>
                  </div>
                </div>

                <!-- Department: only visible after Plant is selected -->
                <div class="row-grid" *ngIf="kaizenForm.get('unit')?.value">
                  <div class="field">
                    <label>Department <span class="req">*</span></label>
                    <select formControlName="department" (change)="onDepartmentChange()">
                      <option value="">Select Department</option>
                      <option *ngFor="let dept of departmentOptions" [value]="dept">{{ dept }}</option>
                    </select>
                    <div class="err-msg" *ngIf="kaizenForm.get('department')?.touched && kaizenForm.get('department')?.errors?.['required']">Department is required</div>
                  </div>

                  <!-- Section: only visible after Department is selected -->
                  <div class="field" *ngIf="kaizenForm.get('department')?.value">
                    <label>Section <span class="req">*</span></label>
                    <select formControlName="section">
                      <option value="">Select Section</option>
                      <option *ngFor="let sec of sectionOptions" [value]="sec">{{ sec }}</option>
                    </select>
                    <div class="err-msg" *ngIf="kaizenForm.get('section')?.touched && kaizenForm.get('section')?.errors?.['required']">Section is required</div>
                  </div>

                  <div class="field">
                    <label>Machine Name <span class="req">*</span></label>
                    <input type="text" formControlName="machine_no">
                    <div class="err-msg" *ngIf="kaizenForm.get('machine_no')?.touched && kaizenForm.get('machine_no')?.errors?.['required']">Machine name is required</div>
                  </div>
                </div>

                <div class="row-grid">
                  <div class="field">
                    <label>Kaizen Type <span class="req">*</span></label>
                    <select formControlName="kaizen_type">
                      <option value="Innovative">Innovative</option>
                      <option value="Restorative">Restorative</option>
                      <option value="Renovative">Renovative</option>
                      <option value="Breakthrough">Breakthrough</option>
                    </select>
                  </div>
                </div>

                <div class="row-grid-cat">
                  <div class="field">
                    <label>Group (PQCDSM) <span class="req">*</span></label>
                    <select formControlName="pqcdsm">
                      <option value="">Select Group</option>
                      <option value="P - Productivity">P - Productivity</option>
                      <option value="Q - Quality">Q - Quality</option>
                      <option value="C - Cost">C - Cost</option>
                      <option value="D - Delivery">D - Delivery</option>
                      <option value="S - Safety">S - Safety</option>
                      <option value="M - Morale">M - Morale</option>
                    </select>
                    <div class="err-msg" *ngIf="kaizenForm.get('pqcdsm')?.touched && kaizenForm.get('pqcdsm')?.errors?.['required']">PQCDSM is required</div>
                  </div>
                  <div class="field">
                    <label>Kaizen Category <span class="req">*</span></label>
                    <select formControlName="kaizen_category">
                      <option value="">Select Category</option>
                      <option *ngFor="let cat of categories" [value]="cat.v">{{cat.l}}</option>
                    </select>
                    <div class="err-msg" *ngIf="kaizenForm.get('kaizen_category')?.touched && kaizenForm.get('kaizen_category')?.errors?.['required']">Category is required</div>
                  </div>
                </div>

                <div class="full-row field">
                  <label>Kaizen Theme <span class="req">*</span></label>
                  <input type="text" formControlName="theme"
                         (input)="checkDuplicateTheme()"
                         [class.error-border]="isDuplicate"
                         placeholder="Enter theme title">
                  <div class="err-msg" *ngIf="isDuplicate">⚠ This Kaizen Theme already exists. Please use a unique title.</div>
                  <div class="err-msg" *ngIf="kaizenForm.get('theme')?.touched && kaizenForm.get('theme')?.errors?.['required'] && !isDuplicate">Theme is required</div>
                </div>

                <hr class="divider">

                <div class="row-grid-2">
                  <div class="field evidence-panel-grey">
                    <label class="evidence-title">5-WHY ANALYSIS</label>
                    <div class="field mb-2">
                      <label>Why 1 <span class="req">*</span></label>
                      <input type="text" formControlName="why1" placeholder="Why did the problem occur?">
                      <div class="err-msg" *ngIf="kaizenForm.get('why1')?.touched && kaizenForm.get('why1')?.errors?.['required']">Why 1 is required</div>
                    </div>
                    <div class="field mb-2">
                      <label>Why 2 <span class="req">*</span></label>
                      <input type="text" formControlName="why2" placeholder="Why did Why 1 happen?">
                      <div class="err-msg" *ngIf="kaizenForm.get('why2')?.touched && kaizenForm.get('why2')?.errors?.['required']">Why 2 is required</div>
                    </div>
                    <div class="field mb-2">
                      <label>Why 3 <span class="req">*</span></label>
                      <input type="text" formControlName="why3" placeholder="Why did Why 2 happen?">
                      <div class="err-msg" *ngIf="kaizenForm.get('why3')?.touched && kaizenForm.get('why3')?.errors?.['required']">Why 3 is required</div>
                    </div>
                    <div class="field mb-2">
                      <label>Why 4 <span style="color:#94a3b8;font-size:11px;">(Optional)</span></label>
                      <input type="text" formControlName="why4" placeholder="Why did Why 3 happen?">
                    </div>
                    <div class="field">
                      <label>Why 5 <span style="color:#94a3b8;font-size:11px;">(Optional)</span></label>
                      <input type="text" formControlName="why5" placeholder="Root cause confirmation">
                    </div>
                  </div>
                  <div class="field">
                    <label>Activity Pillar <span class="req">*</span></label>
                    <select formControlName="pillar">
                      <option *ngFor="let p of pillars" [value]="p">{{p}}</option>
                    </select>
                    <label class="mt-3">Root Cause Summary <span class="req">*</span></label>
                    <textarea formControlName="root_cause" rows="5"></textarea>
                    <div class="err-msg" *ngIf="kaizenForm.get('root_cause')?.touched && kaizenForm.get('root_cause')?.errors?.['required']">Root cause is required</div>
                  </div>
                </div>

                <hr class="divider">

                <div class="row-grid-2">
                  <div class="field">
                    <label>Current Problem <span class="req">*</span></label>
                    <textarea formControlName="problem_status" rows="3"></textarea>
                    <div class="err-msg" *ngIf="kaizenForm.get('problem_status')?.touched && kaizenForm.get('problem_status')?.errors?.['required']">Problem is required</div>
                  </div>
                  <div class="field">
                    <label>Improvement Idea <span class="req">*</span></label>
                    <textarea formControlName="idea" rows="3"></textarea>
                    <div class="err-msg" *ngIf="kaizenForm.get('idea')?.touched && kaizenForm.get('idea')?.errors?.['required']">Idea is required</div>
                  </div>
                </div>

                <div class="full-row field">
                  <label>Countermeasure (Action Taken) <span class="req">*</span></label>
                  <textarea formControlName="countermeasure" rows="2"></textarea>
                  <div class="err-msg" *ngIf="kaizenForm.get('countermeasure')?.touched && kaizenForm.get('countermeasure')?.errors?.['required']">Countermeasure is required</div>
                </div>

                <div class="row-grid mt-3">
                  <div class="field"><label>Benchmark</label><input type="text" formControlName="benchmark"></div>
                  <div class="field"><label>Target</label><input type="text" formControlName="target"></div>
                  <div class="field"><label>Analysis Summary</label><textarea formControlName="analysis" rows="1"></textarea></div>
                </div>

                <div class="row-grid">
                  <div class="field">
                    <label>Start Date <span class="req">*</span></label>
                    <input type="date" formControlName="start_date">
                    <div class="err-msg" *ngIf="kaizenForm.get('start_date')?.touched && kaizenForm.get('start_date')?.errors?.['required']">Start Date is required</div>
                  </div>
                  <div class="field">
                    <label>End Date <span class="req">*</span></label>
                    <input type="date" formControlName="end_date">
                    <div class="err-msg" *ngIf="kaizenForm.get('end_date')?.touched && kaizenForm.get('end_date')?.errors?.['required']">End Date is required</div>
                  </div>
                  <div class="field">
                    <label>Final Result Value <span class="req">*</span></label>
                    <input type="text" formControlName="final_result">
                    <div class="err-msg" *ngIf="kaizenForm.get('final_result')?.touched && kaizenForm.get('final_result')?.errors?.['required']">Final result is required</div>
                  </div>
                </div>

                <div class="row-grid-2">
                  <div class="evidence-panel red-style">
                    <label class="evidence-title">Before Improvement (Image) <span class="req">*</span></label>
                    <input type="file" (change)="onFileChange($event, 'before_img')" accept="image/*">
                    <p class="file-hint">Any size — auto-compressed to under 500KB</p>
                    <div class="err-msg" *ngIf="compressing['before_img']">⏳ Compressing image...</div>
                    <div class="compress-info" *ngIf="compressInfo['before_img']">{{compressInfo['before_img']}}</div>
                    <textarea formControlName="before_desc" placeholder="Before status description..." class="mt-2" rows="2"></textarea>
                    <div class="err-msg" *ngIf="kaizenForm.get('before_desc')?.touched && kaizenForm.get('before_desc')?.errors?.['required']">Before description is required</div>
                  </div>
                  <div class="evidence-panel green-style">
                    <label class="evidence-title">After Improvement (Image) <span class="req">*</span></label>
                    <input type="file" (change)="onFileChange($event, 'after_img')" accept="image/*">
                    <p class="file-hint">Any size — auto-compressed to under 500KB</p>
                    <div class="err-msg" *ngIf="compressing['after_img']">⏳ Compressing image...</div>
                    <div class="compress-info" *ngIf="compressInfo['after_img']">{{compressInfo['after_img']}}</div>
                    <textarea formControlName="after_desc" placeholder="After status description..." class="mt-2" rows="2"></textarea>
                    <div class="err-msg" *ngIf="kaizenForm.get('after_desc')?.touched && kaizenForm.get('after_desc')?.errors?.['required']">After description is required</div>
                  </div>
                </div>

                <div class="deployment-container mt-4">
                  <div class="table-header-flex">
                    <label class="evidence-title">Horizontal Deployment</label>
                    <button type="button" class="btn-add-row" (click)="addRow()">+ Add Machine</button>
                  </div>
                  <table class="manager-modern-table">
                    <thead>
                      <tr><th>Sr.</th><th>Area/Machine</th><th>Resp.</th><th>Target</th><th>Status</th><th>Action</th></tr>
                    </thead>
                    <tbody formArrayName="deployments">
                      <tr *ngFor="let row of deploymentRows.controls; let i=index" [formGroupName]="i">
                        <td>{{i+1}}</td>
                        <td><input type="text" formControlName="area"></td>
                        <td><input type="text" formControlName="resp" (keypress)="allowAlphabetsOnly($event)"></td>
                        <td><input type="date" formControlName="target"></td>
                        <td>
                          <select formControlName="status">
                            <option value="Pending">Pending</option>
                            <option value="Done">Done</option>
                          </select>
                        </td>
                        <td>
                          <button type="button" (click)="removeRow(i)" *ngIf="deploymentRows.length > 1" class="btn-del">🗑</button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <div class="row-grid-2 mt-4">
                  <div class="field">
                    <label>Benefits (PQCDSM) <span class="req">*</span></label>
                    <textarea formControlName="benefits_pqcdsm" rows="4"></textarea>
                    <div class="err-msg" *ngIf="kaizenForm.get('benefits_pqcdsm')?.touched && kaizenForm.get('benefits_pqcdsm')?.errors?.['required']">Benefits is required</div>
                  </div>
                  <div class="field">
                    <label>Team Members <span class="req">*</span></label>
                    <textarea formControlName="team_members" rows="4"
                              (keypress)="allowTeamInput($event)"
                              (keydown)="handleTeamNumbering($event)"
                              placeholder="1. Member Name"></textarea>
                    <p class="file-hint">Alphabets and spaces only</p>
                    <div class="err-msg" *ngIf="kaizenForm.get('team_members')?.touched && kaizenForm.get('team_members')?.errors?.['required']">Team members is required</div>
                  </div>
                </div>

                <button type="submit" class="btn-submit"
                        [disabled]="kaizenForm.invalid || isDuplicate || isAnyCompressing()">
                  {{ isAnyCompressing() ? 'COMPRESSING...' : (kaizenForm.invalid ? 'FILL ALL REQUIRED FIELDS' : (isDuplicate ? 'DUPLICATE THEME' : '✔ SUBMIT MANAGER KAIZEN')) }}
                </button>
              </form>
            </div>
          </div>
        </main>
      </div>
    </div>
  `,
  styles: [`
    @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@500;800&family=Inter:wght@300;400;700&display=swap');
    :host { --sb-width: 290px; --shaktiman-orange: #ff6a00; --gloss-bg: #0b0f19; }
    .app-container { display: flex; height: 100vh; width: 100vw; overflow: hidden; background: #000000; font-family: 'Inter', sans-serif; }
    .sidebar-pillar { width: var(--sb-width); height: 100vh; background: var(--gloss-bg); position: relative; display: flex; flex-direction: column; transition: all 0.5s cubic-bezier(0.16, 1, 0.3, 1); z-index: 1000; box-shadow: 15px 0 50px rgba(207,6,6,0.4); border-right: 1px solid rgba(88,190,110,0.05); }
    .sidebar-pillar.is-collapsed { transform: translateX(-100%); margin-right: calc(var(--sb-width) * -1); }
    .gloss-shine { position: absolute; top: 0; left: 0; right: 0; height: 100%; background: linear-gradient(135deg, rgba(197,7,134,0.08) 0%, rgba(255,255,255,0) 40%); pointer-events: none; }
    .sidebar-header { padding: 50px 20px; text-align: center; }
    .brand-shell { display: flex; flex-direction: column; font-family: 'Orbitron', sans-serif; }
    .brand-name { font-size: 1.8rem; font-weight: 800; color: white; letter-spacing: 4px; }
    .brand-sub { font-size: 0.7rem; color: var(--shaktiman-orange); letter-spacing: 5px; margin-top: -5px; }
    .navigation-hub { flex: 1; padding: 20px 15px; }
    .nav-item { position: relative; display: flex; align-items: center; padding: 16px 25px; margin-bottom: 10px; color: #94a3b8; text-decoration: none; font-weight: 600; font-size: 0.85rem; letter-spacing: 1.5px; transition: 0.4s ease; border-radius: 12px; overflow: hidden; cursor: pointer; }
    .nav-icon { font-size: 1.2rem; margin-right: 18px; z-index: 2; }
    .nav-label { z-index: 2; }
    .nav-glow { position: absolute; top: 0; left: -100%; width: 100%; height: 100%; background: linear-gradient(90deg, transparent, rgba(255,106,0,0.1), transparent); transition: 0.5s; z-index: 1; }
    .nav-item:hover { color: #fff; transform: translateX(8px); }
    .nav-item:hover .nav-glow { left: 100%; }
    .nav-item.active { background: rgba(255,106,0,0.1); color: white; border: 1px solid rgba(255,106,0,0.2); }
    .nav-item.active .nav-label { color: var(--shaktiman-orange); font-weight: 800; }
    .sidebar-footer { padding: 30px 20px; }
    .logout-trigger { width: 100%; padding: 15px; background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.2); color: #ef4444; border-radius: 12px; font-weight: 800; letter-spacing: 2px; cursor: pointer; transition: 0.3s; }
    .logout-trigger:hover { background: #ef4444; color: white; }
    .main-viewport { flex: 1; display: flex; flex-direction: column; min-width: 0; }
    .premium-topbar { height: 80px; background: linear-gradient(90deg, #FF8C00, #FF4500); display: flex; justify-content: space-between; align-items: center; padding: 0 35px; box-shadow: 0 10px 30px rgba(0,0,0,0.15); z-index: 900; }
    .bar-left { display: flex; align-items: center; gap: 30px; }
    .menu-toggle { background: rgba(255,255,255,0.15); border: none; width: 45px; height: 45px; border-radius: 50%; cursor: pointer; display: flex; align-items: center; justify-content: center; }
    .menu-toggle:hover { background: white; }
    .hamburger-box { display: flex; flex-direction: column; gap: 4px; }
    .line { width: 20px; height: 2px; background: white; transition: 0.3s; }
    .menu-toggle:hover .line { background: #FF4500; }
    .portal-heading { font-family: 'Orbitron', sans-serif; color: white; font-size: 1.4rem; font-weight: 800; margin: 0; }
    .thin { font-weight: 300; opacity: 0.8; font-size: 1rem; }
    .logo-badge { background: white; padding: 10px 25px; border-radius: 50px; box-shadow: 0 5px 20px rgba(0,0,0,0.2); }
    .logo-badge img { height: 35px; width: auto; }
    .content-arena { flex: 1; overflow-y: auto; padding: 40px; background: #f8fafc; position: relative; }
    .container-main { max-width: 1050px; margin: 0 auto; }
    .form-card { background: #fff; border-radius: 20px; box-shadow: 0 15px 40px rgba(0,0,0,0.12); overflow: hidden; }
    .form-header-inner { background: #000; color: #fff; padding: 20px 35px; border-bottom: 5px solid var(--shaktiman-orange); }
    .brand-label { color: var(--shaktiman-orange); font-weight: 900; letter-spacing: 1.5px; font-size: 11px; }
    .form-content { padding: 35px; }
    .row-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; margin-bottom: 20px; }
    .row-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
    .row-grid-cat { display: grid; grid-template-columns: 1fr 2fr; gap: 20px; margin-bottom: 20px; }
    .field { display: flex; flex-direction: column; gap: 6px; }
    .field label { font-weight: 700; color: #334155; font-size: 13px; text-transform: uppercase; }
    .req { color: #ef4444; font-size: 14px; font-weight: 900; margin-left: 2px; text-transform: none; }
    input, select, textarea { padding: 12px; border: 2px solid #e2e8f0; border-radius: 10px; font-size: 14px; background: #fdfdfd; width: 100%; box-sizing: border-box; }
    input:focus, select:focus, textarea:focus { border-color: var(--shaktiman-orange); outline: none; background: #fff; }
    .error-border { border-color: #ef4444 !important; }
    .err-msg { color: #ef4444; font-size: 11px; font-weight: bold; margin-top: 4px; }
    .compress-info { color: #10b981; font-size: 11px; font-weight: 600; margin-top: 4px; }
    .divider { margin: 30px 0; border: 0; border-top: 2px dashed #eee; }
    .evidence-panel-grey { padding: 18px; border-radius: 12px; background: #f8fafc; border: 2px solid #e2e8f0; }
    .red-style { border-left: 6px solid #ef4444; background: #fff5f5; padding: 15px; border-radius: 12px; border: 1px solid #fee2e2; border-left-width: 6px; display: flex; flex-direction: column; gap: 6px; }
    .green-style { border-left: 6px solid #22c55e; background: #f0fdf4; padding: 15px; border-radius: 12px; border: 1px solid #dcfce7; border-left-width: 6px; display: flex; flex-direction: column; gap: 6px; }
    .evidence-title { display: block; font-weight: 800; font-size: 12px; margin-bottom: 10px; text-transform: uppercase; color: #64748b; }
    .file-hint { font-size: 11px; color: #94a3b8; font-weight: 600; margin-top: 4px; }
    .manager-modern-table { width: 100%; border-collapse: collapse; border: 1px solid #e2e8f0; font-size: 13px; }
    .manager-modern-table th { background: #f8fafc; padding: 12px; text-align: left; border-bottom: 2px solid #e2e8f0; color: #475569; }
    .manager-modern-table td { padding: 10px; border-bottom: 1px solid #f1f5f9; }
    .btn-submit { width: 100%; padding: 18px; background: #000; color: #fff; border: none; border-radius: 12px; font-size: 16px; font-weight: 800; cursor: pointer; transition: 0.2s; margin-top: 20px; }
    .btn-submit:hover:not(:disabled) { background: var(--shaktiman-orange); transform: translateY(-2px); }
    .btn-submit:disabled { background: #cbd5e1; cursor: not-allowed; }
    .btn-add-row { background: #000; color: #fff; border: none; padding: 8px 15px; border-radius: 8px; font-weight: bold; cursor: pointer; font-size: 12px; }
    .table-header-flex { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
    .custom-overlay { position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(0,0,0,0.75); z-index: 99999; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(6px); }
    .modern-modal { background: #ffffff; width: 440px; padding: 40px 35px; border-radius: 24px; text-align: center; box-shadow: 0 25px 60px rgba(0,0,0,0.4); animation: modalPop 0.3s cubic-bezier(0.34,1.56,0.64,1); position: relative; z-index: 100000; }
    .modern-modal h3 { font-size: 1.4rem; font-weight: 800; color: #1e293b; margin: 15px 0 10px; }
    .modern-modal p { color: #64748b; font-size: 0.95rem; margin-bottom: 20px; }
    .modal-icon { width: 65px; height: 65px; background: var(--shaktiman-orange); color: #fff; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 15px; font-size: 28px; font-weight: 900; }
    .modal-icon.check { background: #22c55e; }
    .modal-preview-box { background: #f8fafc; padding: 15px 20px; border-radius: 12px; margin: 15px 0 25px; text-align: left; border-left: 4px solid var(--shaktiman-orange); font-size: 0.9rem; line-height: 1.8; color: #334155; }
    .modal-actions { display: flex; gap: 12px; }
    .btn-cancel { flex:1; padding: 13px; border: 2px solid #e2e8f0; border-radius: 12px; background: #fff; cursor: pointer; font-weight: 700; color: #64748b; }
    .btn-cancel:hover { border-color: #ef4444; color: #ef4444; }
    .btn-confirm { flex:1; padding: 13px; border: none; border-radius: 12px; background: #000; color: #fff; font-weight: 800; cursor: pointer; }
    .btn-confirm:hover { background: var(--shaktiman-orange); }
    .success-style { border-top: 6px solid #22c55e; }
    @keyframes modalPop { 0% { transform: scale(0.8); opacity: 0; } 100% { transform: scale(1); opacity: 1; } }
    .mb-2 { margin-bottom: 8px; }
    .mt-2 { margin-top: 8px; }
    .mt-3 { margin-top: 15px; }
    .mt-4 { margin-top: 25px; }
  `]
})
export class ManagerRegistrationComponent implements OnInit {

  public sidebarClosed  = false;
  public kaizenNo       = "";
  public today          = new Date();
  public kaizenForm!: FormGroup;
  public showConfirmModal = false;
  public showSuccessModal = false;
  public lastSubmittedNo  = "";
  public isDuplicate      = false;

  public compressing:  { [key: string]: boolean } = { before_img: false, after_img: false };
  public compressInfo: { [key: string]: string  } = { before_img: '', after_img: '' };
  public fileErrors:   { [key: string]: boolean } = { before_img: false, after_img: false };
  private files:       { [key: string]: File | null } = { before_img: null, after_img: null };
  private allThemes:   string[] = [];

  // ── Cascade data ──────────────────────────────────────────────
  public departmentOptions: string[] = [];
  public sectionOptions:    string[] = [];

  private readonly plantDeptMap: { [plant: string]: string[] } = {
    'Unit 1': ['Production', 'Maintenance', 'Quality', 'Stores', 'HR & Admin'],
    'Unit 2': ['Production', 'Maintenance', 'Quality', 'Stores', 'HR & Admin'],
    'Unit 3': ['Production', 'Maintenance', 'Quality', 'Stores', 'HR & Admin'],
    'Unit 4': ['Production', 'Maintenance', 'Quality', 'Stores', 'HR & Admin'],
    'Unit 5': ['Production', 'Maintenance', 'Quality', 'Stores', 'HR & Admin'],
  };

  private readonly deptSectionMap: { [dept: string]: string[] } = {
    'Production':  ['Assembly', 'Welding', 'Machining', 'Painting', 'Packing'],
    'Maintenance': ['Electrical', 'Mechanical', 'Civil', 'Utilities'],
    'Quality':     ['Incoming', 'In-Process', 'Final Inspection', 'Lab'],
    'Stores':      ['Raw Material', 'Finished Goods', 'Spare Parts'],
    'HR & Admin':  ['Recruitment', 'Training', 'Payroll', 'Administration'],
  };
  // ─────────────────────────────────────────────────────────────

  public pillars = ['KK','JH','PM','QM','NEDM','NPDM','DM','E&T','SHE','LM'];

  public categories = [
    { v: "C-1|Restorative (TPM)", l: "C-1: Restorative (Using TPM Methodology)" },
    { v: "C-2|Renovative (TPM)", l: "C-2: Renovative (Using TPM Methodology)" },
    { v: "C-3|Innovative (TPM)", l: "C-3: Innovative (Using TPM Methodology)" },
    { v: "C-4|Breakthrough (TPM)", l: "C-4: Breakthrough (Using TPM Methodology)" },
    { v: "C-5|Poka Yoke (TPM)", l: "C-5: Poka Yoke (Using TPM Methodology)" },
    { v: "C-6|KARAKURI & YUTORI", l: "C-6: KARAKURI (No Energy Loss) & YUTORI" },
    { v: "C-7|JH Shop Floor Visualization", l: "C-7: JH - Shop Floor Visualization" },
    { v: "C-8|KK OEE Compliance", l: "C-8: KK OEE Compliance (Top 5 Machines across BU)" },
    { v: "C-9|KK Bottleneck Process Solution", l: "C-9: KK Bottleneck Process Identified & Solution" },
    { v: "C-10|JH Circle Board Updating", l: "C-10: JH - Circle Board updating, Key indicators Monitoring" },
    { v: "C-11|JH One Point Lessons", l: "C-11: JH - One Point Lessons for the month" },
    { v: "C-12|JH White Tag Abnormality", l: "C-12: JH: Max no. of white tag abnormality Identified & Rectified" },
    { v: "C-13|JH (HTA / SOC / Ease for CLITA)", l: "C-13: JH (HTA / SOC / Ease for CLITA)" },
    { v: "C-14|JH Step 4 M-M Combination", l: "C-14: JH step 4 Man-Machine combination" },
    { v: "C-15|JH Step 5 M-M Combination", l: "C-15: JH step 5 Man-Machine combination" },
    { v: "C-16|JH Step 1, 2, 3 Repeat", l: "C-16: JH: Repeat of JH Step 1, 2, 3" },
    { v: "C-17|JH Minor Stoppage Monitoring", l: "C-17: JH: Minor Stoppage Monitoring and DO Kaizen" },
    { v: "C-18|JH RED Tag Abnormality", l: "C-18: JH: Max no. of RED tag abnormality type Identified by TPM Circle" },
    { v: "C-19|QM Assembly Pokamapping", l: "C-19: QM: Product Assembly Pokamapping & closure of issues" },
    { v: "C-20|PM MP Sheets Generation", l: "C-20: PM: Generation of MP sheets" },
    { v: "C-21|NEDM MP Sheets Implementation", l: "C-21: NEDM: Successful Implementation of MP sheets" },
    { v: "C-22|NEDM Low Cost Automation", l: "C-22: NEDM: Low Cost Automation" },
    { v: "C-23|OTPM MAKIGAMI", l: "C-23: OTPM: MAKIGAMI" },
    { v: "C-24|OTPM Red Tag Office", l: "C-24: OTPM: Red tag at Office area (5S)" },
    { v: "C-25|SHE Near Miss/Unsafe Condition", l: "C-25: SHE: identified Near miss situation & Unsafe condition" },
    { v: "C-26|SHE Unsafe Act", l: "C-26: SHE: Unsafe act" },
    { v: "C-27|SHE Ergonomic Hazard", l: "C-27: SHE: Ergonomic hazard Condition" },
    { v: "C-28|SHE CO2 Emission Reduction", l: "C-28: SHE: CO2 emission reduction by using Renewable Energy" },
    { v: "C-29|SHE Micro Level HIRA", l: "C-29: SHE: Micro level HIRA for listed all Processes / Activities" },
    { v: "C-30|5S Zone Space Saved", l: "C-30: 5S: Zone wise space saved THROUGH 5s" },
    { v: "C-31|5S Best 1S-3S", l: "C-31: 5S: Best 1S, 2S, 3S, at Zones" },
    { v: "C-32|All Members", l: "C-32: Sure Appreciation" },
    { v: "C-33|All Members", l: "C-33: Won the Awards from CII (Platinium & Gold)" },
    { v: "C-34|All Members", l: "C-34: Won the Awards from CII (Jury Challenger, Champion of Champians, Jury Champion )" },
  ];

  constructor(
    private router: Router,
    private http: HttpClient,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.generateKaizenNo();
    this.loadExistingThemes();
    this.kaizenForm = new FormGroup({
      emp_id:          new FormControl('', [Validators.required, Validators.pattern('^[0-9]+$')]),
      emp_name:        new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z ]+$')]),
      unit:            new FormControl('', Validators.required),
      department:      new FormControl('', Validators.required),
      section:         new FormControl('', Validators.required),
      machine_no:      new FormControl('', Validators.required),
      kaizen_type:     new FormControl('Innovative', Validators.required),
      pqcdsm:          new FormControl('', Validators.required),
      kaizen_category: new FormControl('', Validators.required),
      theme:           new FormControl('', Validators.required),
      problem_status:  new FormControl('', Validators.required),
      idea:            new FormControl('', Validators.required),
      countermeasure:  new FormControl('', Validators.required),
      pillar:          new FormControl('KK', Validators.required),
      why1:            new FormControl('', Validators.required),
      why2:            new FormControl('', Validators.required),
      why3:            new FormControl('', Validators.required),
      why4:            new FormControl(''),
      why5:            new FormControl(''),
      root_cause:      new FormControl('', Validators.required),
      analysis:        new FormControl(''),
      benchmark:       new FormControl(''),
      target:          new FormControl(''),
      start_date:      new FormControl('', Validators.required),
      end_date:        new FormControl('', Validators.required),
      final_result:    new FormControl('', Validators.required),
      before_desc:     new FormControl('', Validators.required),
      after_desc:      new FormControl('', Validators.required),
      benefits_pqcdsm: new FormControl('', Validators.required),
      team_members:    new FormControl('1. ', Validators.required),
      deployments:     new FormArray([this.createRow()])
    });
  }

  // ── Cascade handlers ──────────────────────────────────────────
  onPlantChange() {
    const plant = this.kaizenForm.get('unit')?.value;
    this.departmentOptions = plant ? (this.plantDeptMap[plant] || []) : [];
    this.sectionOptions = [];
    this.kaizenForm.patchValue({ department: '', section: '' });
  }

  onDepartmentChange() {
    const dept = this.kaizenForm.get('department')?.value;
    this.sectionOptions = dept ? (this.deptSectionMap[dept] || []) : [];
    this.kaizenForm.patchValue({ section: '' });
  }
  // ─────────────────────────────────────────────────────────────

  generateKaizenNo() {
    const currentYear = new Date().getFullYear();
    this.http.get<any>('http://localhost:8080/api/manager?action=count').subscribe(res => {
      const nextId = (res.count + 1).toString().padStart(3, '0');
      this.kaizenNo = `MG-${currentYear}-${nextId}`;
    });
  }

  loadExistingThemes() {
    this.http.get<any[]>('http://localhost:8080/api/kaizen/my-kaizens').subscribe({
      next: (res) => {
        this.allThemes = res.map(k => (k.theme || '').toLowerCase().trim()).filter(t => t.length > 0);
      },
      error: () => { this.allThemes = []; }
    });
  }

  toggleSidebar() { this.sidebarClosed = !this.sidebarClosed; }

  createRow() {
    return new FormGroup({
      area:   new FormControl(''),
      resp:   new FormControl(''),
      target: new FormControl(''),
      status: new FormControl('Pending')
    });
  }

  get deploymentRows() { return this.kaizenForm.get('deployments') as FormArray; }
  addRow()    { this.deploymentRows.push(this.createRow()); }
  removeRow(i: number) { this.deploymentRows.removeAt(i); }

  allowNumbersOnly(event: KeyboardEvent): boolean {
    return event.charCode >= 48 && event.charCode <= 57;
  }

  allowAlphabetsOnly(event: KeyboardEvent): boolean {
    const c = event.charCode;
    return (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c === 32;
  }

  allowTeamInput(event: KeyboardEvent): boolean {
    const c = event.charCode;
    return (c >= 65 && c <= 90) || (c >= 97 && c <= 122) ||
           c === 32 || c === 46 || (c >= 48 && c <= 57);
  }

  checkDuplicateTheme() {
    const theme = this.kaizenForm.get('theme')?.value?.toLowerCase().trim();
    this.isDuplicate = theme && theme.length > 2 ? this.allThemes.includes(theme) : false;
  }

  onFileChange(event: any, field: string) {
    const file = event.target.files[0];
    if (!file) return;

    if (file.size <= 512000) {
      this.fileErrors[field]   = false;
      this.compressInfo[field] = `✓ ${Math.round(file.size/1024)}KB — ready`;
      this.files[field]        = file;
      this.cdr.detectChanges();
      return;
    }

    this.compressing[field]  = true;
    this.compressInfo[field] = '';
    this.cdr.detectChanges();

    this.compressImage(file, 500).then(compressed => {
      this.compressing[field]  = false;
      this.fileErrors[field]   = false;
      this.files[field]        = compressed;
      this.compressInfo[field] =
        `✓ Compressed: ${Math.round(file.size/1024)}KB → ${Math.round(compressed.size/1024)}KB`;
      this.cdr.detectChanges();
    }).catch(() => {
      this.compressing[field] = false;
      this.fileErrors[field]  = true;
      this.cdr.detectChanges();
      event.target.value = '';
    });
  }

  compressImage(file: File, maxSizeKB: number): Promise<File> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (e: any) => {
        const img = new Image();
        img.src = e.target.result;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let w = img.width, h = img.height;
          const MAX = 1200;
          if (w > MAX || h > MAX) {
            if (w > h) { h = Math.round(h * MAX / w); w = MAX; }
            else        { w = Math.round(w * MAX / h); h = MAX; }
          }
          canvas.width = w; canvas.height = h;
          canvas.getContext('2d')!.drawImage(img, 0, 0, w, h);
          let quality = 0.9;
          const tryCompress = () => {
            const dataUrl = canvas.toDataURL('image/jpeg', quality);
            const sizeKB  = Math.round(dataUrl.length * 3 / 4 / 1024);
            if (sizeKB <= maxSizeKB || quality <= 0.3) {
              const arr  = dataUrl.split(',');
              const bstr = atob(arr[1]);
              let n = bstr.length;
              const u8 = new Uint8Array(n);
              while (n--) u8[n] = bstr.charCodeAt(n);
              resolve(new File([u8], file.name, { type: 'image/jpeg' }));
            } else { quality -= 0.1; tryCompress(); }
          };
          tryCompress();
        };
        img.onerror = () => reject();
      };
      reader.onerror = () => reject();
    });
  }

  isAnyCompressing(): boolean {
    return Object.values(this.compressing).some(v => v);
  }

  hasFileError(): boolean {
    return Object.values(this.fileErrors).some(v => v);
  }

  handleTeamNumbering(e: any) {
    if (e.key === 'Enter') {
      const val = e.target.value;
      const lines = val.split('\n');
      if (lines[lines.length - 1].trim().length > 3) {
        e.preventDefault();
        this.kaizenForm.patchValue({ team_members: val + '\n' + (lines.length + 1) + '. ' });
      }
    }
  }

  onPreSubmit() {
    Object.keys(this.kaizenForm.controls).forEach(k => this.kaizenForm.get(k)?.markAsTouched());
    if (this.kaizenForm.valid && !this.hasFileError() && !this.isDuplicate &&
        !this.isAnyCompressing() && this.files['before_img'] && this.files['after_img']) {
      this.showConfirmModal = true;
    } else {
      alert('Please fill all required fields and select both images.');
    }
  }

  finalSubmit() {
    this.showConfirmModal = false;
    const formData = new FormData();
    Object.keys(this.kaizenForm.value).forEach(key => {
      if (key !== 'deployments') formData.append(key, this.kaizenForm.value[key]);
    });
    formData.append('deployments', JSON.stringify(this.kaizenForm.value.deployments));
    formData.append('kaizen_id', this.kaizenNo);
    // Send department as 'depo' to match the backend/DB field
    formData.append('depo', this.kaizenForm.value.department);
    if (this.files['before_img']) formData.append('before_img', this.files['before_img']!);
    if (this.files['after_img'])  formData.append('after_img',  this.files['after_img']!);

    this.http.post('http://localhost:8080/api/manager/save', formData).subscribe({
      next: (res: any) => {
        if (res && res.status === 'success') {
          this.lastSubmittedNo = this.kaizenNo;
          this.showSuccessModal = true;
          this.kaizenForm.reset({ unit: '', department: '', section: '', kaizen_type: 'Innovative', pillar: 'KK', team_members: '1. ' });
          this.departmentOptions = [];
          this.sectionOptions    = [];
          while (this.deploymentRows.length !== 0) { this.deploymentRows.removeAt(0); }
          this.addRow();
          this.files        = { before_img: null, after_img: null };
          this.fileErrors   = { before_img: false, after_img: false };
          this.compressing  = { before_img: false, after_img: false };
          this.compressInfo = { before_img: '', after_img: '' };
          document.querySelectorAll<HTMLInputElement>('input[type="file"]').forEach(i => i.value = '');
          this.generateKaizenNo();
          this.loadExistingThemes();
        } else {
          alert("Backend Error: " + (res?.message || "Unknown Error"));
        }
      },
      error: (err) => {
        alert("Submission failed. Check backend connection.");
      }
    });
  }

  logout() { sessionStorage.clear(); this.router.navigate(['/admin-login']); }
}